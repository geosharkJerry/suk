# X402 Protocol Specification
# X402协议：按播放时间点计费标准

**版本**: 1.0.0  
**日期**: 2024-11-16  
**状态**: 🟢 Production Ready  
**创新**: 🚀 革命性视频计费模式

---

## 📋 目录

- [协议概述](#协议概述)
- [核心原理](#核心原理)
- [技术架构](#技术架构)
- [计费模型](#计费模型)
- [数据结构](#数据结构)
- [API接口](#api接口)
- [实现指南](#实现指南)
- [安全机制](#安全机制)

---

## 🎯 协议概述

### 什么是X402协议？

**X402（eXact 402 Payment Required）** 是一种革命性的视频内容计费协议，它打破了传统的"按集收费"模式，实现了**按播放时间点精准计费**。

### 传统模式 vs X402协议

| 对比维度 | 传统模式 | X402协议 |
|---------|---------|----------|
| **计费单位** | 按集（整集） | 按秒（时间点） |
| **付费时机** | 开始观看前 | 观看过程中 |
| **费用计算** | 固定价格/集 | 累计价格/秒 |
| **用户体验** | 预付费，风险高 | 后付费，更公平 |
| **收益模式** | 按集数统计 | 按观看时长统计 |
| **跨集观看** | 需多次付费 | 连续计费 |

### 核心优势

#### 🎯 用户优势
- ✅ **按需付费**：只为实际观看的内容付费
- ✅ **无需预判**：不用担心整集付费后不喜欢
- ✅ **透明计费**：实时显示已消费金额
- ✅ **灵活控制**：随时停止，费用精准

#### 💰 创作者优势
- ✅ **公平收益**：按实际观看时长获得收益
- ✅ **降低门槛**：用户更愿意尝试新内容
- ✅ **精准数据**：了解用户真实观看习惯
- ✅ **持续收益**：重复观看持续计费

#### 📊 平台优势
- ✅ **降低流失**：减少付费障碍
- ✅ **提升转化**：用户更容易开始观看
- ✅ **数据价值**：精准的观看行为数据
- ✅ **差异化竞争**：独特的商业模式

---

## 🔧 核心原理

### 1. 时间点计费原理

```
总剧集时长 = 80集 × 5分钟 = 400分钟 = 24,000秒
总价格 = 120 SUK

每秒价格 = 120 SUK ÷ 24,000秒 = 0.005 SUK/秒

用户观看到第15集第3分钟20秒时：
- 总观看时长 = 14集×300秒 + 3×60秒 + 20秒 = 4,200秒 + 180秒 + 20秒 = 4,400秒
- 应付费用 = 4,400秒 × 0.005 SUK/秒 = 22 SUK
```

### 2. 计费触发机制

**实时计费模式**（推荐）：
```
每观看10秒触发一次计费检查
- 检查用户余额是否充足
- 计算增量费用（最后10秒的费用）
- 执行微支付交易
- 更新用户余额和观看记录
```

**预充值模式**（备选）：
```
用户预充值一定金额到账户
播放器持续扣除预充值余额
余额不足时提示充值
支持自动充值功能
```

### 3. 跨集连续计费

传统模式：
```
第1集: 支付 5 SUK → 观看
第2集: 支付 5 SUK → 观看  
第3集: 支付 5 SUK → 观看
总计: 3次付费，15 SUK
```

X402协议：
```
开始观看 → 持续计费
观看时间: 0-300秒 (第1集) → 1.5 SUK
观看时间: 300-600秒 (第2集) → +1.5 SUK = 3 SUK
观看时间: 600-900秒 (第3集) → +1.5 SUK = 4.5 SUK
总计: 1次连续计费，4.5 SUK
```

---

## 🏗 技术架构

### 系统架构图

```
┌─────────────────────────────────────────────────────────────┐
│                        用户客户端                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  视频播放器   │  │  计费显示UI  │  │  余额管理    │      │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘      │
│         │                  │                  │               │
│         └──────────────────┼──────────────────┘               │
│                           │                                   │
└───────────────────────────┼───────────────────────────────────┘
                            │ WebSocket/HTTP
┌───────────────────────────┼───────────────────────────────────┐
│                           ▼                                   │
│                  X402 计费网关                                 │
│  ┌──────────────────────────────────────────────────────┐    │
│  │  - 实时计费引擎                                        │    │
│  │  - 播放进度验证                                        │    │
│  │  - 防刷机制                                           │    │
│  │  - 费用计算器                                         │    │
│  └─────────┬──────────┬──────────┬──────────────────────┘    │
│            │          │          │                            │
└────────────┼──────────┼──────────┼────────────────────────────┘
             │          │          │
    ┌────────▼───┐  ┌──▼─────┐  ┌▼──────────┐
    │   MongoDB  │  │ Redis  │  │ Blockchain│
    │  观看记录   │  │ 缓存   │  │  支付     │
    └────────────┘  └────────┘  └───────────┘
```

### 核心组件

#### 1. 播放器客户端
```javascript
class X402Player {
    constructor(dramaId, videoElement) {
        this.dramaId = dramaId;
        this.video = videoElement;
        this.currentTime = 0;
        this.lastBilledTime = 0;
        this.billingInterval = 10; // 每10秒计费
        this.pricePerSecond = 0;
        this.totalCost = 0;
    }
    
    // 初始化计费信息
    async initialize() {
        const dramaInfo = await this.fetchDramaInfo();
        this.pricePerSecond = dramaInfo.totalPrice / dramaInfo.totalDuration;
    }
    
    // 播放进度监听
    onTimeUpdate() {
        this.currentTime = this.video.currentTime;
        
        // 每10秒触发计费
        if (this.currentTime - this.lastBilledTime >= this.billingInterval) {
            this.processBilling();
        }
    }
    
    // 处理计费
    async processBilling() {
        const watchedSeconds = this.currentTime - this.lastBilledTime;
        const cost = watchedSeconds * this.pricePerSecond;
        
        const result = await this.submitBillingRequest({
            dramaId: this.dramaId,
            startTime: this.lastBilledTime,
            endTime: this.currentTime,
            cost: cost
        });
        
        if (result.success) {
            this.lastBilledTime = this.currentTime;
            this.totalCost += cost;
            this.updateUI();
        } else {
            this.handleInsufficientBalance();
        }
    }
}
```

#### 2. 计费网关
```javascript
class X402BillingGateway {
    // 处理计费请求
    async processBilling(userId, dramaId, startTime, endTime, cost) {
        // 1. 验证播放进度真实性
        const isValid = await this.validatePlayback(userId, dramaId, startTime, endTime);
        if (!isValid) throw new Error('Invalid playback data');
        
        // 2. 检查用户余额
        const balance = await this.getUserBalance(userId);
        if (balance < cost) throw new Error('Insufficient balance');
        
        // 3. 执行扣费
        await this.deductBalance(userId, cost);
        
        // 4. 记录观看历史
        await this.recordWatchHistory({
            userId,
            dramaId,
            startTime,
            endTime,
            cost,
            timestamp: Date.now()
        });
        
        // 5. 分配收益
        await this.distributeRevenue(dramaId, cost);
        
        return { success: true, remainingBalance: balance - cost };
    }
    
    // 防刷验证
    async validatePlayback(userId, dramaId, startTime, endTime) {
        // 检查时间合理性
        const duration = endTime - startTime;
        if (duration > 60 || duration < 0) return false;
        
        // 检查播放连续性
        const lastRecord = await this.getLastWatchRecord(userId, dramaId);
        if (lastRecord && startTime !== lastRecord.endTime) return false;
        
        // 检查播放速度（防止快进刷进度）
        const realTimeDiff = Date.now() - lastRecord.timestamp;
        if (realTimeDiff < duration * 1000 * 0.8) return false;
        
        return true;
    }
}
```

---

## 💰 计费模型

### 1. 基础计费公式

```
每秒价格 = 剧集总价格 ÷ 剧集总时长（秒）

实时费用 = 已观看时长（秒） × 每秒价格

显示公式 = floor(实时费用 × 100) / 100  // 保留2位小数
```

### 2. 计费示例

**剧集信息**：
- 剧名：霸总的心尖宠
- 总集数：80集
- 每集时长：5分钟
- 总时长：400分钟 = 24,000秒
- 总价格：125 SUK
- 每秒价格：0.00520833 SUK/秒

**观看场景**：

| 观看时长 | 剧集位置 | 累计费用 | 显示金额 |
|---------|---------|---------|---------|
| 0秒 | 开始 | 0 SUK | 免费试看 |
| 300秒 | 第1集完成 | 1.56 SUK | 1.56 SUK |
| 600秒 | 第2集完成 | 3.13 SUK | 3.13 SUK |
| 900秒 | 第3集完成 | 4.69 SUK | 4.69 SUK |
| 3,000秒 | 第10集完成 | 15.63 SUK | 15.63 SUK |
| 12,000秒 | 第40集完成 | 62.50 SUK | 62.50 SUK |
| 24,000秒 | 全部完成 | 125.00 SUK | 125.00 SUK |

### 3. 折扣模型（可选）

**累计观看折扣**：
```
观看进度 < 20%  → 1.0倍价格（原价）
观看进度 20-50% → 0.95倍价格（95折）
观看进度 50-80% → 0.90倍价格（90折）
观看进度 > 80%  → 0.85倍价格（85折）
```

**会员折扣**：
```
普通用户 → 1.0倍价格
VIP会员  → 0.8倍价格
SVIP会员 → 0.6倍价格
```

---

## 📊 数据结构

### 1. 剧集定价信息

```javascript
{
    "dramaId": "1",
    "title": "霸总的心尖宠",
    "pricing": {
        "model": "X402",  // 计费模式
        "totalPrice": 125,  // SUK
        "totalPriceUSD": 1.25,  // USD
        "totalEpisodes": 80,
        "episodeDuration": 300,  // 秒
        "totalDuration": 24000,  // 秒
        "pricePerSecond": 0.00520833,  // SUK/秒
        "pricePerMinute": 0.3125,  // SUK/分钟
        "pricePerEpisode": 1.5625,  // SUK/集（参考值）
        
        // 免费试看
        "freeDuration": 180,  // 前3分钟免费
        "freeEpisodes": 1,  // 第1集免费
        
        // 折扣配置
        "discounts": {
            "volumeDiscount": {
                "enabled": true,
                "tiers": [
                    { "minProgress": 0.2, "rate": 0.95 },
                    { "minProgress": 0.5, "rate": 0.90 },
                    { "minProgress": 0.8, "rate": 0.85 }
                ]
            },
            "membershipDiscount": {
                "vip": 0.8,
                "svip": 0.6
            }
        }
    }
}
```

### 2. 用户观看记录

```javascript
{
    "_id": "watch_record_123",
    "userId": "user_456",
    "dramaId": "1",
    "sessionId": "session_789",  // 本次观看会话ID
    
    // 时间信息
    "startTime": 0,  // 观看起始位置（秒）
    "endTime": 4400,  // 观看结束位置（秒）
    "duration": 4400,  // 观看时长（秒）
    "watchedAt": 1700112000000,  // 观看时间戳
    
    // 计费信息
    "billingModel": "X402",
    "pricePerSecond": 0.00520833,
    "baseCost": 22.92,  // 基础费用
    "discount": 0.95,  // 折扣率
    "finalCost": 21.77,  // 实际费用
    "currency": "SUK",
    
    // 支付信息
    "paid": true,
    "paymentId": "pay_123456",
    "transactionHash": "0x1234...5678",
    
    // 进度信息
    "progress": 0.183,  // 18.3% (4400/24000)
    "episodeReached": 15,  // 看到第15集
    "episodeProgress": 0.67,  // 当前集观看67%
    
    // 统计信息
    "pauseCount": 3,  // 暂停次数
    "seekCount": 2,  // 拖动次数
    "playbackSpeed": 1.0,  // 播放速度
    
    // 验证信息
    "verified": true,  // 是否通过防刷验证
    "trustScore": 95,  // 信任分数（0-100）
    
    // 元数据
    "createdAt": 1700112000000,
    "updatedAt": 1700115600000
}
```

### 3. 实时计费会话

```javascript
{
    "sessionId": "session_789",
    "userId": "user_456",
    "dramaId": "1",
    "status": "active",  // active, paused, ended
    
    // 会话时间
    "sessionStart": 1700112000000,
    "sessionEnd": null,
    "lastHeartbeat": 1700112300000,
    
    // 播放状态
    "currentTime": 4400,  // 当前播放位置（秒）
    "lastBilledTime": 4400,  // 最后计费位置（秒）
    "nextBillingTime": 4410,  // 下次计费位置（秒）
    
    // 费用统计
    "totalCost": 21.77,  // 本次会话总费用
    "billingHistory": [
        { "time": 4200, "cost": 20.92, "timestamp": 1700112200000 },
        { "time": 4400, "cost": 21.77, "timestamp": 1700112300000 }
    ],
    
    // 用户余额
    "userBalance": 103.23,  // 当前余额
    "balanceWarning": false,  // 余额不足警告
    
    // 设备信息
    "deviceId": "device_abc",
    "ipAddress": "192.168.1.100",
    "userAgent": "Mozilla/5.0..."
}
```

---

## 🔌 API接口

### 1. 开始观看会话

**Endpoint**: `POST /api/x402/session/start`

**Request**:
```json
{
    "userId": "user_456",
    "dramaId": "1",
    "startTime": 0,
    "deviceId": "device_abc"
}
```

**Response**:
```json
{
    "success": true,
    "data": {
        "sessionId": "session_789",
        "pricePerSecond": 0.00520833,
        "freeDuration": 180,
        "userBalance": 125.00,
        "estimatedCost": {
            "perMinute": 0.3125,
            "perEpisode": 1.5625,
            "fullDrama": 125.00
        }
    }
}
```

### 2. 提交计费请求

**Endpoint**: `POST /api/x402/billing/charge`

**Request**:
```json
{
    "sessionId": "session_789",
    "dramaId": "1",
    "startTime": 4200,
    "endTime": 4400,
    "clientTimestamp": 1700112300000
}
```

**Response**:
```json
{
    "success": true,
    "data": {
        "charged": 1.04,
        "totalCost": 21.77,
        "remainingBalance": 103.23,
        "progress": 0.183,
        "estimatedFullCost": 118.96,
        "balanceWarning": false
    }
}
```

### 3. 查询当前会话状态

**Endpoint**: `GET /api/x402/session/{sessionId}`

**Response**:
```json
{
    "success": true,
    "data": {
        "sessionId": "session_789",
        "status": "active",
        "currentTime": 4400,
        "totalCost": 21.77,
        "userBalance": 103.23,
        "canContinue": true
    }
}
```

### 4. 结束观看会话

**Endpoint**: `POST /api/x402/session/end`

**Request**:
```json
{
    "sessionId": "session_789",
    "finalTime": 4400,
    "reason": "user_stopped"
}
```

**Response**:
```json
{
    "success": true,
    "data": {
        "sessionSummary": {
            "duration": 4400,
            "totalCost": 21.77,
            "progress": 0.183,
            "episodesWatched": 14.67
        },
        "recommendation": {
            "continueWatching": true,
            "estimatedRemainingCost": 97.19
        }
    }
}
```

---

## 🛡 安全机制

### 1. 防刷机制

```javascript
// 播放速度检测
function validatePlaybackSpeed(startTime, endTime, realTimeDiff) {
    const expectedDuration = (endTime - startTime) * 1000;  // 毫秒
    const speedRatio = realTimeDiff / expectedDuration;
    
    // 允许0.8-1.2倍速
    return speedRatio >= 0.8 && speedRatio <= 1.2;
}

// 连续性检测
function validateContinuity(userId, dramaId, startTime) {
    const lastRecord = getLastRecord(userId, dramaId);
    
    // 必须从上次结束的地方继续
    // 允许5秒的误差
    return Math.abs(lastRecord.endTime - startTime) <= 5;
}

// 设备指纹
function generateDeviceFingerprint() {
    return hash(
        userAgent +
        screenResolution +
        timezone +
        language +
        plugins
    );
}
```

### 2. 余额保护

```javascript
// 余额预警
function checkBalanceWarning(balance, pricePerSecond) {
    const remainingMinutes = balance / (pricePerSecond * 60);
    
    if (remainingMinutes < 5) {
        return {
            level: 'critical',
            message: '余额不足5分钟观看时长，请充值'
        };
    } else if (remainingMinutes < 15) {
        return {
            level: 'warning',
            message: '余额较低，建议充值'
        };
    }
    
    return null;
}

// 自动暂停
function autoPauseOnInsufficientBalance(player, balance) {
    if (balance <= 0) {
        player.pause();
        showRechargeModal();
    }
}
```

### 3. 数据加密

```javascript
// 计费请求签名
function signBillingRequest(data, secretKey) {
    const payload = JSON.stringify({
        ...data,
        timestamp: Date.now(),
        nonce: generateNonce()
    });
    
    return {
        payload,
        signature: hmacSHA256(payload, secretKey)
    };
}

// 服务端验证
function verifyBillingRequest(payload, signature, secretKey) {
    const expectedSignature = hmacSHA256(payload, secretKey);
    return signature === expectedSignature;
}
```

---

## 🚀 实现指南

### 快速开始

#### 1. 前端集成

```html
<!-- 引入X402播放器SDK -->
<script src="js/x402-player.js"></script>

<video id="drama-player" controls></video>
<div id="billing-info"></div>

<script>
// 初始化X402播放器
const player = new X402Player({
    videoElement: document.getElementById('drama-player'),
    dramaId: '1',
    userId: 'user_456',
    apiEndpoint: 'https://api.suk.link',
    
    // 计费配置
    billingInterval: 10,  // 每10秒计费
    
    // 回调函数
    onBillingSuccess: (data) => {
        updateBillingDisplay(data);
    },
    onBalanceWarning: (data) => {
        showBalanceWarning(data);
    },
    onInsufficientBalance: () => {
        showRechargeModal();
    }
});

// 开始播放
player.play();
</script>
```

#### 2. 后端实现

```javascript
// Express.js 路由
const express = require('express');
const router = express.Router();

// 开始观看会话
router.post('/x402/session/start', async (req, res) => {
    const { userId, dramaId, startTime } = req.body;
    
    const session = await X402Service.createSession({
        userId,
        dramaId,
        startTime
    });
    
    res.json({
        success: true,
        data: session
    });
});

// 处理计费请求
router.post('/x402/billing/charge', async (req, res) => {
    const { sessionId, dramaId, startTime, endTime } = req.body;
    
    try {
        const result = await X402Service.processBilling({
            sessionId,
            dramaId,
            startTime,
            endTime
        });
        
        res.json({
            success: true,
            data: result
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            error: error.message
        });
    }
});

module.exports = router;
```

---

## 📈 性能优化

### 1. 缓存策略

```javascript
// Redis缓存会话状态
const sessionKey = `x402:session:${sessionId}`;
await redis.setex(sessionKey, 3600, JSON.stringify(sessionData));

// 批量计费（减少数据库写入）
const billingBatch = [];
if (billingBatch.length >= 10) {
    await db.batchInsert('billing_records', billingBatch);
    billingBatch = [];
}
```

### 2. 异步处理

```javascript
// 计费请求异步处理
async function processBillingAsync(billingData) {
    // 立即返回成功响应
    res.json({ success: true });
    
    // 异步写入数据库
    await queue.add('billing', billingData);
}
```

---

## 📊 监控指标

### 关键指标

1. **计费成功率**: 计费成功次数 / 总计费请求
2. **平均延迟**: 计费请求响应时间
3. **欺诈检测率**: 被拦截的异常请求比例
4. **用户留存**: X402模式 vs 传统模式的留存对比
5. **平均观看时长**: 用户平均付费时长
6. **转化率**: 免费试看 → 付费观看的转化率

---

## 🎯 最佳实践

### 1. 用户体验

- ✅ 提供至少3分钟免费试看
- ✅ 实时显示当前费用和剩余余额
- ✅ 余额不足时提前10分钟提醒
- ✅ 支持暂停时不计费
- ✅ 提供费用预估功能

### 2. 技术实现

- ✅ 使用WebSocket保持连接
- ✅ 计费请求加密签名
- ✅ 实现断线重连机制
- ✅ 支持离线观看（预付费模式）
- ✅ 多设备同步观看进度

### 3. 商业策略

- ✅ 设置合理的每秒价格
- ✅ 提供观看进度折扣
- ✅ 会员享受专属折扣
- ✅ 支持充值赠送活动
- ✅ 提供月度观看套餐

---

## 📝 总结

X402协议代表了视频内容计费的**未来方向**：

- 🎯 **更公平**：用户和创作者都受益
- 💰 **更灵活**：按需付费，降低门槛
- 📊 **更精准**：数据驱动的决策
- 🚀 **更创新**：差异化竞争优势

**X402协议：Pay for What You Watch, Not What You Buy**

---

**版权所有 © 2024 SUK Protocol**  
**协议版本**: 1.0.0  
**最后更新**: 2024-11-16
