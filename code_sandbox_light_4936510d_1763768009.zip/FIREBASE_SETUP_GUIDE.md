# 🔥 Firebase + Web3 完整设置指南

## 📋 概述

本指南将帮助您完成 SUK Protocol 的 Firebase 后端配置，包括：
- Firebase 项目创建
- 认证系统配置
- Firestore 数据库设置
- Cloud Functions 部署
- 安全规则配置
- Web3 集成

---

## ✅ 已创建的文件

### JavaScript 模块 (3个)
- `js/firebase-config.js` - Firebase 配置和初始化
- `js/firebase-auth.js` - 认证系统（支持邮箱和钱包登录）
- `js/firebase-db.js` - Firestore 数据库操作

### Cloud Functions (2个)
- `functions/index.js` - 服务器端函数
- `functions/package.json` - 依赖配置

### 安全规则 (2个)
- `firestore.rules` - Firestore 安全规则
- `storage.rules` - Storage 安全规则

### 配置文件 (2个)
- `firebase.json` - Firebase 项目配置
- `firestore.indexes.json` - 数据库索引

---

## 🚀 第一步：创建 Firebase 项目

### 1. 访问 Firebase Console

1. 打开 [https://console.firebase.google.com/](https://console.firebase.google.com/)
2. 使用 Google 账号登录
3. 点击"添加项目"

### 2. 创建项目

```
项目名称: suk-protocol（或您选择的名称）
√ 为此项目启用 Google Analytics（可选）
选择 Analytics 位置: 亚洲
```

### 3. 添加 Web 应用

1. 在项目概览页面，点击 "Web" 图标（</>）
2. 注册应用：
   ```
   应用昵称: SUK Protocol Web
   √ 同时为此应用设置 Firebase Hosting
   ```
3. 点击"注册应用"

### 4. 获取配置信息

复制显示的配置对象：

```javascript
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "suk-protocol.firebaseapp.com",
  projectId: "suk-protocol",
  storageBucket: "suk-protocol.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123",
  measurementId: "G-XXXXXXX"
};
```

---

## 🔧 第二步：配置前端项目

### 1. 更新 firebase-config.js

打开 `js/firebase-config.js`，替换配置：

```javascript
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",                    // 替换这里
    authDomain: "YOUR_PROJECT.firebaseapp.com", // 替换这里
    projectId: "YOUR_PROJECT_ID",               // 替换这里
    storageBucket: "YOUR_PROJECT.appspot.com",  // 替换这里
    messagingSenderId: "YOUR_SENDER_ID",        // 替换这里
    appId: "YOUR_APP_ID",                       // 替换这里
    measurementId: "YOUR_MEASUREMENT_ID"        // 替换这里（可选）
};
```

### 2. 在 HTML 中引入 Firebase SDK

在所有需要使用 Firebase 的 HTML 文件的 `<head>` 标签中添加：

```html
<!-- Firebase App (核心) -->
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js"></script>

<!-- Firebase Authentication -->
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-auth-compat.js"></script>

<!-- Firebase Firestore -->
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore-compat.js"></script>

<!-- Firebase Storage -->
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-storage-compat.js"></script>

<!-- Firebase Functions -->
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-functions-compat.js"></script>

<!-- Firebase Cloud Messaging (可选) -->
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-messaging-compat.js"></script>

<!-- Firebase配置 -->
<script src="js/firebase-config.js"></script>
<script src="js/firebase-auth.js"></script>
<script src="js/firebase-db.js"></script>
```

---

## 🔐 第三步：配置 Authentication

### 1. 启用邮箱/密码登录

1. 在 Firebase Console，点击"Authentication"
2. 选择"Sign-in method"标签
3. 启用"电子邮件/密码"
4. 点击"保存"

### 2. 配置授权域名

1. 在"Settings"标签
2. 添加您的域名到"授权域名"列表
3. 开发环境添加: `localhost`

---

## 💾 第四步：配置 Firestore Database

### 1. 创建数据库

1. 点击"Firestore Database"
2. 点击"创建数据库"
3. 选择位置: `asia-east1 (Taiwan)` 或 `asia-northeast1 (Tokyo)`
4. 安全规则: 选择"生产模式"

### 2. 部署安全规则

在项目根目录运行：

```bash
firebase deploy --only firestore:rules
```

或在 Firebase Console 手动复制 `firestore.rules` 内容到规则编辑器。

### 3. 部署索引

```bash
firebase deploy --only firestore:indexes
```

或等待 Firebase 自动建议索引。

---

## ☁️ 第五步：部署 Cloud Functions

### 1. 安装 Firebase CLI

```bash
npm install -g firebase-tools
```

### 2. 登录 Firebase

```bash
firebase login
```

### 3. 初始化项目

```bash
firebase init
```

选择：
- √ Firestore
- √ Functions
- √ Hosting
- √ Storage

语言选择: **JavaScript**

### 4. 安装 Functions 依赖

```bash
cd functions
npm install
```

### 5. 配置环境变量

```bash
firebase functions:config:set \
  blockchain.rpc_url="https://polygon-rpc.com" \
  blockchain.suk_token_address="0x..." \
  blockchain.drama_factory_address="0x..."
```

### 6. 部署 Functions

```bash
firebase deploy --only functions
```

---

## 📦 第六步：配置 Storage

### 1. 启用 Storage

1. 在 Firebase Console，点击"Storage"
2. 点击"开始使用"
3. 选择位置（与 Firestore 相同）

### 2. 部署安全规则

```bash
firebase deploy --only storage
```

---

## 🧪 第七步：本地测试

### 1. 启动 Firebase 模拟器

```bash
firebase emulators:start
```

模拟器地址：
- Auth: `http://localhost:9099`
- Firestore: `http://localhost:8080`
- Functions: `http://localhost:5001`
- Storage: `http://localhost:9199`
- UI: `http://localhost:4000`

### 2. 连接到模拟器

在代码中调用：

```javascript
// 在 firebase-config.js 中
FirebaseConfig.useEmulators();
```

### 3. 测试功能

1. 打开 `auth.html`
2. 注册新用户
3. 查看 Firestore 中的数据
4. 测试钱包登录

---

## 🌐 第八步：部署到生产环境

### 1. 部署前端到 Firebase Hosting

```bash
firebase deploy --only hosting
```

您的网站将部署到:
```
https://YOUR_PROJECT_ID.web.app
https://YOUR_PROJECT_ID.firebaseapp.com
```

### 2. 配置自定义域名（可选）

1. 在 Firebase Console → Hosting
2. 点击"添加自定义域名"
3. 按照说明配置 DNS

---

## 🔗 第九步：集成智能合约

### 1. 更新合约地址

在 `js/firebase-config.js` 中：

```javascript
contracts: {
    // Polygon Mumbai Testnet
    80001: {
        sukToken: '0xYOUR_SUK_TOKEN_ADDRESS',
        dramaFactory: '0xYOUR_DRAMA_FACTORY_ADDRESS',
        staking: '0xYOUR_STAKING_ADDRESS',
        marketplace: '0xYOUR_MARKETPLACE_ADDRESS'
    },
    // Polygon Mainnet
    137: {
        sukToken: '0x...',
        dramaFactory: '0x...',
        staking: '0x...',
        marketplace: '0x...'
    }
}
```

### 2. 配置 Cloud Functions

```bash
firebase functions:config:set \
  blockchain.suk_token_address="0xYOUR_ADDRESS" \
  blockchain.chain_id="137"
```

### 3. 重新部署 Functions

```bash
firebase deploy --only functions
```

---

## 📊 使用示例

### 用户注册（邮箱）

```javascript
const result = await FirebaseAuthManager.registerWithEmail(
    'user@example.com',
    'password123',
    'username'
);
```

### 用户登录（钱包）

```javascript
const walletAddress = '0x...';
const result = await FirebaseAuthManager.loginWithWallet(walletAddress);
```

### 添加短剧

```javascript
const drama = await FirebaseDB.addDrama({
    title: '都市霸总',
    description: '精彩短剧',
    category: '都市爱情',
    episodes: 80,
    price: 12.5,
    apy: 8.5,
    tvl: 5000000
});
```

### 获取用户投资记录

```javascript
const investments = await FirebaseDB.getUserInvestments(userId);
```

### 监听数据变化

```javascript
const unsubscribe = FirebaseDB.watchDrama(dramaId, (drama) => {
    console.log('短剧更新:', drama);
});
```

---

## 🛡️ 安全最佳实践

### 1. 保护 API 密钥

- ✅ Firebase API 密钥可以公开（已通过安全规则保护）
- ❌ 不要将私钥、密码、JWT Secret 提交到代码
- ✅ 使用环境变量存储敏感信息

### 2. 配置安全规则

- ✅ 使用 `firestore.rules` 限制数据访问
- ✅ 验证用户身份和权限
- ❌ 不要使用 `allow read, write: if true;`

### 3. 启用 App Check（推荐）

防止滥用和欺诈：

```bash
firebase appcheck:create web --app-id=YOUR_APP_ID
```

---

## 💰 成本优化

### 免费套餐限制

**Spark Plan（免费）：**
- Firestore: 1GB 存储，50K 读取/天，20K 写入/天
- Functions: 2M 调用/月，400K GB-秒/月
- Hosting: 10GB 存储，360MB/天传输
- Authentication: 无限用户

### 升级到 Blaze Plan

按用量付费，适合生产环境：

**预计成本（1000活跃用户）：**
- Firestore: ~$5-15/月
- Functions: ~$5-10/月
- Hosting: ~$0-5/月
- **总计: ~$10-30/月**

---

## 🔍 常见问题

### Q: Firebase 配置后没有反应？

**A:** 检查：
1. 浏览器控制台是否有错误
2. Firebase SDK 是否正确引入
3. 配置信息是否正确填写

### Q: 用户注册后无法登录？

**A:** 检查：
1. Authentication 是否已启用
2. 安全规则是否正确配置
3. 用户邮箱是否需要验证

### Q: Cloud Functions 部署失败？

**A:** 常见原因：
1. Node.js 版本不匹配（需要 Node 18）
2. 依赖安装失败
3. 配置信息缺失

### Q: Firestore 读写失败？

**A:** 检查：
1. 安全规则是否正确
2. 用户是否已登录
3. 索引是否已创建

---

## 📚 参考文档

- [Firebase 官方文档](https://firebase.google.com/docs)
- [Firestore 安全规则](https://firebase.google.com/docs/firestore/security/get-started)
- [Cloud Functions 指南](https://firebase.google.com/docs/functions)
- [Firebase Authentication](https://firebase.google.com/docs/auth)

---

## 🆘 获取帮助

遇到问题？

1. 查看浏览器控制台错误
2. 检查 Firebase Console 的日志
3. 参考本文档的常见问题
4. 查看 Firebase 官方文档

---

<div align="center">
  <strong>🔥 Firebase + Web3 集成完成！</strong>
  <br><br>
  <sub>SUK Protocol | v1.4.0</sub>
</div>
