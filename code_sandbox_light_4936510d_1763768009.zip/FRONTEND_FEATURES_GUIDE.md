# 🎨 SUK Protocol 前端功能使用指南

## 📋 新增功能概览

本次更新为 SUK Protocol 添加了完整的前端用户管理和数据交互功能：

### ✅ 已完成功能

1. **用户认证系统** (`auth.html` + `js/auth.js`)
2. **数据管理面板** (`admin-panel.html` + `js/table-api.js`)
3. **交易历史记录** (`transactions.html` + `js/transactions.js`)
4. **浏览器通知系统** (`js/notifications.js`)
5. **模拟数据生成器** (集成在各模块中)

---

## 1️⃣ 用户认证系统

### 功能特性

- ✅ 邮箱/用户名登录
- ✅ 用户注册（含密码强度检测）
- ✅ MetaMask 钱包一键登录/注册
- ✅ 记住登录状态
- ✅ LocalStorage 数据存储

### 使用方法

**访问登录页面：**
```
打开 auth.html
```

**登录方式：**

1. **传统登录**
   - 输入邮箱或用户名
   - 输入密码
   - 可选：勾选"记住我"
   - 点击"登录"按钮

2. **钱包登录**
   - 点击"MetaMask 登录"按钮
   - 在 MetaMask 弹窗中授权连接
   - 自动创建或登录账户

**注册账户：**

1. 切换到"注册"标签
2. 填写用户名、邮箱、密码
3. 确认密码（密码强度会实时显示）
4. 勾选服务条款
5. 点击"创建账户"

**代码示例：**

```javascript
// 检查用户是否已登录
if (AuthManager.isLoggedIn()) {
    const user = AuthManager.getCurrentUser();
    console.log('当前用户:', user.username);
}

// 要求用户登录（未登录则跳转）
AuthManager.requireLogin();

// 登出
AuthManager.logout();
```

### ⚠️ 安全提示

- **仅用于演示**：密码未加密存储在 LocalStorage
- **生产环境**：需要后端服务器进行真实认证
- **数据安全**：LocalStorage 数据用户可以修改

---

## 2️⃣ 数据管理面板

### 功能特性

- ✅ 管理 4 种数据表：短剧数据、投资记录、收益记录、用户数据
- ✅ CRUD 操作：创建、读取、更新、删除
- ✅ 搜索和筛选功能
- ✅ 分页显示
- ✅ 表单验证
- ✅ 使用 Table API 或 LocalStorage

### 使用方法

**访问数据管理：**
```
打开 admin-panel.html
需要先登录
```

**切换数据表：**
- 点击顶部标签切换不同的数据表
- 短剧数据、投资记录、收益记录、用户数据

**添加数据：**
1. 点击"添加数据"按钮
2. 填写表单字段
3. 点击"保存"按钮

**编辑数据：**
1. 点击数据行的"编辑"图标
2. 修改表单内容
3. 点击"保存"

**删除数据：**
1. 点击数据行的"删除"图标
2. 确认删除操作

**搜索数据：**
- 在搜索框中输入关键词
- 实时搜索（支持所有字段）

### 代码示例

```javascript
// 加载表格数据
await TableAPI.loadTable('dramas');

// 添加记录
await TableAPI.addRecord({
    title: '新短剧',
    description: '描述',
    category: '都市爱情',
    episodes: 80,
    price: 12.50,
    apy: 8.5,
    tvl: 5000000
});

// 更新记录
await TableAPI.updateRecord('drama_id_123', {
    price: 15.00,
    tvl: 6000000
});

// 删除记录
await TableAPI.deleteRecord('drama_id_123');
```

### 💡 Table API 集成

**切换到真实 API：**

在 `js/table-api.js` 中，将模拟调用替换为真实 API：

```javascript
// 替换 getMockData() 为真实 API 调用
async fetchData() {
    const params = new URLSearchParams({
        page: this.currentPage,
        limit: this.pageLimit,
        search: searchQuery
    });
    
    const response = await fetch(`tables/${this.currentTable}?${params}`);
    const data = await response.json();
    
    this.currentData = data.data;
    this.totalRecords = data.total;
    
    this.renderTable();
    this.updatePagination();
}
```

---

## 3️⃣ 交易历史记录

### 功能特性

- ✅ 显示所有链上交易
- ✅ 5种交易类型筛选：购买、出售、收益领取、质押、解押
- ✅ 交易详情展示：金额、代币数量、Gas费用、区块高度
- ✅ 复制交易哈希
- ✅ 在区块浏览器中查看
- ✅ 统计数据汇总

### 使用方法

**访问交易历史：**
```
打开 transactions.html
需要先登录
```

**查看交易：**
- 页面自动加载最近的交易记录
- 每条记录显示详细信息

**筛选交易：**
- 点击顶部筛选按钮
- 全部、购买、出售、收益领取、质押操作

**查看详情：**
- 点击交易哈希链接
- 在 Polygon 区块浏览器中查看

**复制哈希：**
- 点击复制按钮
- 交易哈希复制到剪贴板

### 区块链集成

**从真实区块链读取：**

在 `js/transactions.js` 中集成 ethers.js：

```javascript
async loadFromBlockchain(address) {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const blockNumber = await provider.getBlockNumber();
    
    // 获取最近的交易
    for (let i = 0; i < 100; i++) {
        const block = await provider.getBlockWithTransactions(blockNumber - i);
        block.transactions.forEach(tx => {
            if (tx.from.toLowerCase() === address.toLowerCase() || 
                tx.to?.toLowerCase() === address.toLowerCase()) {
                this.transactions.push(this.parseTransaction(tx));
            }
        });
    }
}
```

**监听合约事件：**

```javascript
// 监听代币购买事件
contract.on('TokenPurchased', (buyer, dramaId, amount, tokens) => {
    const transaction = {
        type: 'buy',
        from: buyer,
        dramaId: dramaId,
        amount: amount,
        tokens: tokens,
        timestamp: Date.now()
    };
    
    TransactionManager.transactions.unshift(transaction);
    TransactionManager.renderTransactions();
    
    showNotification(`成功购买 ${tokens} 个代币`, 'success');
});
```

---

## 4️⃣ 浏览器通知系统

### 功能特性

- ✅ 页面内 Toast 通知
- ✅ 浏览器原生通知（需要授权）
- ✅ 4种类型：成功、错误、警告、信息
- ✅ 自动关闭
- ✅ 通知历史记录

### 使用方法

**显示通知：**

```javascript
// 成功通知
showNotification('操作成功！', 'success');

// 错误通知
showNotification('操作失败', 'error');

// 警告通知
showNotification('请注意', 'warning');

// 信息通知
showNotification('提示信息', 'info');

// 自定义持续时间（毫秒）
showNotification('3秒后消失', 'info', 3000);

// 永久显示（直到用户点击）
showNotification('重要提示', 'warning', 0);
```

**请求浏览器通知权限：**

```javascript
// 请求权限
await requestNotificationPermission();

// 显示浏览器原生通知
NotificationManager.showNativeNotification('SUK Protocol', {
    body: '您有新的收益到账',
    icon: 'logo.png',
    onClick: () => {
        window.location.href = 'dashboard.html';
    }
});
```

**管理通知：**

```javascript
// 添加通知到历史
NotificationManager.addNotification(
    '收益到账',
    '您从《都市霸总》获得 ¥123.45 收益',
    'success'
);

// 获取未读通知数量
const unreadCount = NotificationManager.getUnreadCount();

// 标记为已读
NotificationManager.markAsRead(notificationId);

// 标记全部已读
NotificationManager.markAllAsRead();

// 清空所有通知
NotificationManager.clearAll();
```

### 集成到应用

**在关键操作时显示通知：**

```javascript
// 登录成功
AuthManager.handleLogin().then(() => {
    showNotification('登录成功！', 'success');
});

// 数据保存
TableAPI.addRecord(data).then(() => {
    showNotification('数据已保存', 'success');
});

// 交易完成
contract.buyTokens(amount).then((tx) => {
    showNotification('交易已提交，等待确认...', 'info');
    
    tx.wait().then(() => {
        showNotification('交易成功！代币已到账', 'success');
        
        // 显示浏览器通知
        NotificationManager.showNativeNotification('交易完成', {
            body: '您已成功购买代币'
        });
    });
});
```

---

## 5️⃣ 模拟数据生成器

### 功能说明

为了方便演示和测试，所有模块都内置了模拟数据生成器：

**短剧数据：**
- 15个模拟短剧
- 包含：标题、描述、分类、集数、价格、APY、TVL、播放量

**投资记录：**
- 25条模拟投资记录
- 包含：用户ID、短剧ID、投资金额、代币数量、购买价格

**收益记录：**
- 15条模拟收益记录
- 包含：短剧ID、收益来源、金额、日期、分配状态

**用户数据：**
- 15个模拟用户
- 包含：用户名、邮箱、钱包地址、投资额、收益、认证状态

**交易记录：**
- 25条模拟交易
- 包含：交易类型、金额、代币数量、Gas费用、区块高度、哈希

### 数据存储

所有模拟数据存储在 LocalStorage：

```javascript
// 短剧数据
localStorage.getItem('suk_table_dramas')

// 投资记录
localStorage.getItem('suk_table_investments')

// 用户数据
localStorage.getItem('suk_users')

// 当前用户
localStorage.getItem('suk_current_user')

// 通知记录
localStorage.getItem('suk_notifications')

// 活动日志
localStorage.getItem('suk_activities')
```

### 清空数据

**清空所有数据：**

```javascript
// 在浏览器控制台执行
localStorage.clear();
location.reload();
```

**清空特定数据：**

```javascript
// 清空短剧数据
localStorage.removeItem('suk_table_dramas');

// 清空用户数据
localStorage.removeItem('suk_users');
localStorage.removeItem('suk_current_user');
```

---

## 🔧 技术栈

### 前端技术
- **HTML5** - 语义化标记
- **CSS3** - Flexbox, Grid, 动画
- **JavaScript ES6+** - 原生 JS，无框架依赖
- **Font Awesome** - 图标库
- **Google Fonts** - Inter 字体

### 数据存储
- **LocalStorage** - 浏览器本地存储（5-10MB）
- **Table API** - RESTful API（可选）
- **区块链** - 从链上读取交易（需要 ethers.js）

### Web3 集成
- **MetaMask** - 钱包连接
- **ethers.js** - 区块链交互（已准备）
- **Polygon** - Layer 2 网络支持

---

## 📝 文件结构

```
suk-protocol/
├── auth.html                  # 登录/注册页面 ⭐ NEW
├── admin-panel.html           # 数据管理面板 ⭐ NEW
├── transactions.html          # 交易历史页面 ⭐ NEW
├── js/
│   ├── auth.js               # 用户认证逻辑 ⭐ NEW
│   ├── table-api.js          # Table API 集成 ⭐ NEW
│   ├── transactions.js       # 交易历史逻辑 ⭐ NEW
│   └── notifications.js      # 通知系统 ⭐ NEW
└── ... (其他现有文件)
```

---

## 🚀 快速开始

### 1. 启动本地服务器

```bash
# Python 3
python -m http.server 8000

# Node.js
npx serve .

# VS Code Live Server
右键 HTML 文件 → Open with Live Server
```

### 2. 访问页面

```
登录/注册:        http://localhost:8000/auth.html
数据管理:         http://localhost:8000/admin-panel.html
交易历史:         http://localhost:8000/transactions.html
测试导航:         http://localhost:8000/test-index.html
```

### 3. 测试流程

1. **注册账户**
   - 访问 auth.html
   - 注册新用户或使用 MetaMask 登录

2. **查看仪表盘**
   - 登录后自动跳转到 dashboard.html
   - 查看资产概览和投资组合

3. **管理数据**
   - 访问 admin-panel.html
   - 添加、编辑、删除数据

4. **查看交易**
   - 访问 transactions.html
   - 查看交易历史和详情

---

## ⚠️ 限制说明

### 当前实现的限制

1. **认证系统**
   - ❌ 无真实服务器验证
   - ❌ 密码未加密
   - ❌ 无会话管理
   - ❌ 无跨域登录

2. **数据存储**
   - ❌ 数据存储在浏览器本地
   - ❌ 清除缓存会丢失数据
   - ❌ 无法跨设备访问
   - ❌ 数据可被用户修改

3. **交易记录**
   - ❌ 使用模拟数据
   - ❌ 未实际从区块链读取
   - ❌ 需要部署合约才能使用真实数据

4. **通知系统**
   - ❌ 无服务器推送
   - ❌ 无离线通知
   - ❌ 仅在页面打开时有效

### 生产环境需要

要将这些功能用于生产环境，需要：

1. **后端服务器**
   - Node.js/Python/Java 等
   - 数据库（PostgreSQL/MongoDB）
   - JWT 认证
   - RESTful API

2. **智能合约部署**
   - 部署到 Polygon 主网/测试网
   - 配置合约地址
   - 集成 ethers.js

3. **安全加固**
   - HTTPS
   - 密码加密（bcrypt）
   - XSS/CSRF 防护
   - 速率限制

4. **推送服务**
   - Firebase Cloud Messaging
   - WebSocket
   - Service Worker

---

## 💡 最佳实践

### 用户体验

1. **即时反馈**
   - 所有操作都显示通知
   - 加载状态显示
   - 错误信息清晰

2. **数据持久化**
   - 登录状态记住
   - 表单数据自动保存草稿
   - 通知历史保留

3. **响应式设计**
   - 移动端友好
   - 触摸操作优化
   - 自适应布局

### 代码质量

1. **模块化**
   - 每个功能独立模块
   - 清晰的接口定义
   - 易于维护和扩展

2. **错误处理**
   - Try-catch 包裹异步操作
   - 友好的错误提示
   - 详细的控制台日志

3. **性能优化**
   - 防抖搜索
   - 分页加载
   - 懒加载图片

---

## 📞 技术支持

如有问题或建议，请：

1. 查看浏览器控制台的错误信息
2. 检查 LocalStorage 数据
3. 参考代码注释和文档
4. 查看 README.md 了解项目整体架构

---

<div align="center">
  <strong>🎬 开始使用 SUK Protocol 前端功能！</strong>
  <br><br>
  <sub>v1.3.0 | 2024-11-15</sub>
</div>
