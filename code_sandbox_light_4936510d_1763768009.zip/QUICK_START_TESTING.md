# 🚀 Telegram Mini App 本地测试 - 快速开始

## ⚡ 3步开始测试（最快2分钟）

### 步骤1: 启动服务器
```bash
chmod +x scripts/test-mini-app-local.sh
./scripts/test-mini-app-local.sh
```

### 步骤2: 打开测试工具
```
浏览器访问: http://localhost:8080/test-mini-app.html
```

### 步骤3: 运行测试
```
点击页面上的 "▶️ 运行所有测试" 按钮
```

**完成！** 等待测试完成，查看结果 ✅

---

## 📱 手动测试URL

### 主页（短剧列表）
```
http://localhost:8080/telegram-app.html
```
**验证**: 显示8部短剧，分类筛选有效

### 详情页（付费短剧）
```
http://localhost:8080/telegram-drama-detail.html?id=drama-001
```
**验证**: 显示支付选项，前3集免费

### 详情页（免费短剧）
```
http://localhost:8080/telegram-drama-detail.html?id=drama-002
```
**验证**: 无支付卡片，全部剧集可看

---

## ✅ 快速检查清单

### Console日志（F12打开）
```javascript
✓ 🚀 初始化Telegram Mini App
✓ 🔧 开发模式：使用模拟用户数据
✓ ✅ Mock数据加载成功: 8
✓ ✅ Telegram Mini App 已就绪
✓ 🌍 环境: 开发模式
```

### 主页显示
```
✓ 用户信息: 张三 开发者 ⭐ Premium
✓ 8部短剧卡片
✓ 6个分类标签
✓ 价格和评分显示正确
```

### 详情页显示
```
✓ 封面完整
✓ 支付选项（付费剧集）
✓ 剧集列表（前3集无🔒）
✓ 评论区（3条评论）
```

---

## 🔍 常见问题速查

### 页面空白？
```bash
1. 检查Console是否有错误
2. 清除缓存 (Ctrl+Shift+Delete)
3. 确认服务器运行中
```

### 短剧不显示？
```bash
1. 查看Console是否显示 "Mock数据加载成功: 8"
2. 检查Network面板是否有404
3. 刷新页面
```

### 图片不显示？
```bash
1. 检查网络连接（使用Unsplash图片）
2. 图片会自动fallback到placeholder
3. 这是正常现象，不影响测试
```

### 端口被占用？
```bash
# 使用其他端口
http-server . -p 8888 -c-1

# 或停止占用进程
lsof -ti :8080 | xargs kill -9
```

---

## 📚 详细文档

需要更多信息？查看：

- 📖 **[LOCAL_TESTING_COMPLETE.md](LOCAL_TESTING_COMPLETE.md)** - 测试工具完整说明
- 📖 **[LOCAL_TESTING_GUIDE.md](LOCAL_TESTING_GUIDE.md)** - 详细测试指南（19个测试用例）
- 📖 **[TELEGRAM_MINI_APP_GUIDE.md](TELEGRAM_MINI_APP_GUIDE.md)** - 开发完整指南（13KB）

---

## 🎯 测试目标

- [x] 主页加载和显示（7项）
- [x] 详情页功能（9项）
- [x] 边界情况处理（3项）
- [x] 总计19个测试用例

---

## 🎉 完成测试后

1. ✅ 查看测试报告
2. ✅ 保存测试截图（可选）
3. ✅ 继续开发下一功能
4. ✅ 或准备真机测试

---

## ⚡ 一键启动命令

```bash
# 完整命令（复制粘贴即可）
chmod +x scripts/test-mini-app-local.sh && ./scripts/test-mini-app-local.sh
```

---

**预计测试时间**: 
- 自动化测试: **2分钟** ⚡
- 手动验证: **15分钟** 📋
- 完整测试: **30分钟** 📸

**现在就开始吧！** 🚀
