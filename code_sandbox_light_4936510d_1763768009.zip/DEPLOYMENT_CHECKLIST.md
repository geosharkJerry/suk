# SUK 智能合约部署清单

## 📋 部署前检查

### 环境准备
- [ ] Node.js 已安装（v18+）
- [ ] npm 已安装
- [ ] MetaMask 钱包已安装并配置
- [ ] 钱包中有足够的测试/主网 ETH（用于 Gas 费）

### 账户准备
- [ ] Infura 账户已创建
- [ ] Infura API Key 已获取
- [ ] Etherscan 账户已创建（用于合约验证）
- [ ] Etherscan API Key 已获取

### 测试网准备（推荐先测试）
- [ ] 已从 Goerli Faucet 获取测试 ETH
- [ ] 钱包地址余额充足（建议 > 0.5 ETH）

---

## 🔧 第一步：环境配置

### 1. 安装依赖

```bash
npm install --save-dev hardhat @nomiclabs/hardhat-ethers ethers
npm install --save-dev @nomiclabs/hardhat-etherscan
npm install @openzeppelin/contracts
```

**验证**：
```bash
npx hardhat --version
# 应输出: Hardhat version 2.x.x
```

### 2. 配置环境变量

创建 `.env` 文件：

```bash
# 部署者私钥（从 MetaMask 导出）
PRIVATE_KEY=your_private_key_here

# Infura API 密钥
INFURA_API_KEY=your_infura_api_key_here

# Etherscan API 密钥（用于合约验证）
ETHERSCAN_API_KEY=your_etherscan_api_key_here

# 可选：自定义时间（Unix 时间戳）
WHITELIST_START_TIME=1735000000
```

**验证**：
```bash
# 检查 .env 文件
cat .env | grep PRIVATE_KEY
# 应显示你的私钥（确保不要泄露！）
```

---

## 🚀 第二步：编译合约

```bash
npx hardhat compile
```

**预期输出**：
```
Compiled 2 Solidity files successfully
```

**验证**：
- [ ] 编译成功，无错误
- [ ] `artifacts/` 目录已创建
- [ ] `cache/` 目录已创建

---

## 📦 第三步：部署到测试网

### 1. 部署 SUKToken

```bash
npx hardhat run scripts/1-deploy-suk-token.js --network goerli
```

**预期输出**：
```
🚀 开始部署 SUKToken...
✅ SUKToken 已部署!
   地址: 0x1234567890123456789012345678901234567890
   总供应量: 1000000000 SUK
   ...
```

**记录**：
- [ ] 合约地址已记录
- [ ] 交易哈希已记录
- [ ] 部署信息已保存到 `deployment/` 目录

**SUKToken 地址**: `_____________________________`

### 2. 部署 SUKAirdrop

```bash
npx hardhat run scripts/2-deploy-airdrop.js --network goerli
```

**预期输出**：
```
🚀 开始部署 SUKAirdrop...
✅ SUKAirdrop 已部署!
   地址: 0xABCDEF1234567890123456789012345678901234
   ...
```

**记录**：
- [ ] 合约地址已记录
- [ ] 交易哈希已记录
- [ ] 部署信息已保存

**SUKAirdrop 地址**: `_____________________________`

### 3. 转账 100万 SUK 到空投合约

```bash
npx hardhat run scripts/3-fund-airdrop.js --network goerli
```

**预期输出**：
```
🚀 开始向空投合约转账...
✅ 转账成功!
   转账金额: 1000000 SUK
   ...
```

**验证**：
- [ ] 转账交易成功
- [ ] 空投合约余额正确（1,000,000 SUK）

---

## ✅ 第四步：验证合约

### 1. 验证 SUKToken

```bash
npx hardhat verify --network goerli <SUKToken地址> "<你的钱包地址>"
```

**示例**：
```bash
npx hardhat verify --network goerli 0x1234... "0x5678..."
```

**预期输出**：
```
Successfully verified contract SUKToken
https://goerli.etherscan.io/address/0x1234...#code
```

**验证**：
- [ ] 合约已在 Etherscan 上验证
- [ ] 可以在浏览器中查看源代码
- [ ] Read/Write Contract 功能可用

### 2. 验证 SUKAirdrop

```bash
npx hardhat verify --network goerli <SUKAirdrop地址> "<SUKToken地址>" <白名单开始时间> <公开开始时间> <结束时间>
```

**获取时间参数**（从部署记录中）：
```bash
cat deployment/suk-airdrop-goerli-*.json | grep Time
```

**预期输出**：
```
Successfully verified contract SUKAirdrop
```

**验证**：
- [ ] 合约已验证
- [ ] 合约参数正确显示

---

## 📋 第五步：导入白名单

### 1. 准备白名单文件

创建 `whitelist.csv`：

```csv
address
0x1111111111111111111111111111111111111111
0x2222222222222222222222222222222222222222
0x3333333333333333333333333333333333333333
```

**验证**：
- [ ] CSV 格式正确
- [ ] 地址格式有效（0x + 40个十六进制字符）
- [ ] 文件保存为 UTF-8 编码

### 2. 导入白名单

```bash
npx hardhat run scripts/import-whitelist.js --network goerli
```

**预期输出**：
```
🚀 开始导入白名单...
📊 总计地址数: 150
✅ 白名单导入完成!
   成功导入: 150 个地址
   ...
```

**验证**：
- [ ] 所有地址成功导入
- [ ] 在 Etherscan 上查看交易
- [ ] 使用 Read Contract 验证白名单

---

## 🎨 第六步：配置前端

### 1. 自动配置（推荐）

```bash
node scripts/update-frontend-config.js goerli <SUKToken地址> <SUKAirdrop地址>
```

**示例**：
```bash
node scripts/update-frontend-config.js goerli 0x1234... 0xABCD...
```

**预期输出**：
```
✅ 配置文件已更新: js/contract-config.js
✅ 部署记录已保存: deployment/frontend-config-goerli-*.json
```

**验证**：
- [ ] `js/contract-config.js` 已更新
- [ ] 合约地址正确配置
- [ ] 部署记录已保存

### 2. 手动配置（备选）

编辑 `js/contract-config.js`，找到 `goerli` 部分：

```javascript
goerli: {
    // ... 其他配置 ...
    contracts: {
        SUKToken: '0x你的SUKToken地址',      // ← 更新这里
        SUKAirdrop: '0x你的SUKAirdrop地址'   // ← 更新这里
    }
}
```

---

## 🧪 第七步：测试配置

### 1. 启动本地服务器

```bash
python -m http.server 8000
```

或使用 Node.js：
```bash
npx http-server -p 8000
```

### 2. 打开测试工具

浏览器访问：`http://localhost:8000/contract-config-test.html`

### 3. 执行测试

1. **选择网络**：Goerli Testnet
2. **连接钱包**：点击"连接 MetaMask"
3. **全面测试**：点击"全面测试"按钮

**预期结果**：
- [ ] 钱包连接成功
- [ ] SUKToken 测试通过 ✅
- [ ] SUKAirdrop 测试通过 ✅
- [ ] 所有功能正常

### 4. 测试空投页面

访问：`http://localhost:8000/suk-airdrop.html`

**测试步骤**：
1. 点击"连接钱包"
2. 查看空投统计信息
3. 检查个人状态（白名单/公开/已领取）
4. 如果符合条件，测试领取功能

**验证**：
- [ ] 页面正常加载
- [ ] 数据正确显示
- [ ] 领取功能正常（如适用）

---

## 🌐 第八步：部署到主网（可选）

### 准备工作

**警告**：主网部署需要真实的 ETH，请确保：
- [ ] 已在测试网充分测试
- [ ] 所有功能运行正常
- [ ] 钱包中有足够的 ETH（建议 > 0.5 ETH）
- [ ] 已备份私钥和助记词

### 部署步骤

与测试网相同，只需将 `--network goerli` 改为 `--network mainnet`：

```bash
# 1. 部署 SUKToken
npx hardhat run scripts/1-deploy-suk-token.js --network mainnet

# 2. 部署 SUKAirdrop
npx hardhat run scripts/2-deploy-airdrop.js --network mainnet

# 3. 转账
npx hardhat run scripts/3-fund-airdrop.js --network mainnet

# 4. 验证合约
npx hardhat verify --network mainnet <合约地址> <参数>

# 5. 导入白名单
npx hardhat run scripts/import-whitelist.js --network mainnet

# 6. 更新前端配置
node scripts/update-frontend-config.js mainnet <TOKEN> <AIRDROP>
```

**主网合约地址记录**：
- SUKToken: `_____________________________`
- SUKAirdrop: `_____________________________`

---

## 📊 第九步：监控和维护

### 1. 监控合约活动

**Etherscan 监控**：
- [ ] 添加合约到 Watch List
- [ ] 启用邮件通知
- [ ] 定期检查交易记录

**链接**：
- SUKToken: `https://goerli.etherscan.io/address/<地址>`
- SUKAirdrop: `https://goerli.etherscan.io/address/<地址>`

### 2. 记录关键信息

将以下信息保存到安全位置：

```
部署日期: ______________
网络: Goerli / Mainnet
部署者地址: ______________
SUKToken 地址: ______________
SUKAirdrop 地址: ______________
部署交易哈希:
  - SUKToken: ______________
  - SUKAirdrop: ______________
  - Fund: ______________
验证链接:
  - SUKToken: ______________
  - SUKAirdrop: ______________
```

### 3. 安全措施

- [ ] 私钥已安全保存（不要分享！）
- [ ] `.env` 文件已添加到 `.gitignore`
- [ ] 部署记录已备份
- [ ] 合约所有权已转移（如需要）

---

## ✅ 部署完成检查

### 合约部署
- [ ] SUKToken 已成功部署
- [ ] SUKAirdrop 已成功部署
- [ ] 100万 SUK 已转入空投合约
- [ ] 合约已在 Etherscan 上验证
- [ ] 白名单已成功导入

### 前端配置
- [ ] 配置文件已更新
- [ ] 测试工具验证通过
- [ ] 空投页面正常工作
- [ ] 用户可以连接钱包
- [ ] 用户可以查询状态
- [ ] 用户可以领取空投（如符合条件）

### 文档和记录
- [ ] 合约地址已记录
- [ ] 交易哈希已保存
- [ ] 部署记录已备份
- [ ] 监控已设置

---

## 🎉 恭喜！

您已成功完成 SUK 智能合约的部署和配置！

### 下一步

1. **宣传推广**
   - 在社交媒体宣布空投
   - 分享合约地址
   - 引导用户参与

2. **监控运营**
   - 定期检查合约状态
   - 监控 Gas 费用
   - 收集用户反馈

3. **持续优化**
   - 根据数据调整策略
   - 优化用户体验
   - 计划下一阶段功能

### 获取帮助

遇到问题？查看以下资源：

- 📖 [部署详细指南](DEPLOYMENT_STEP_BY_STEP.md)
- 🚀 [前端配置指南](FRONTEND_CONFIG_GUIDE.md)
- 🎁 [空投使用指南](SUK_AIRDROP_GUIDE.md)
- 🔧 [故障排查](FRONTEND_CONFIG_GUIDE.md#常见问题排查)

---

**部署完成日期**: _______________  
**部署者签名**: _______________  
**版本**: v1.0.0
