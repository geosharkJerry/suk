# SUK Protocol - Cloudflare Pages 快速部署指南 ⚡

> 🚀 3分钟快速部署 SUK Protocol 到 Cloudflare Pages 生产环境

---

## 🎯 三种部署方式

### 方式一：Git 连接自动部署（最推荐）⭐⭐⭐⭐⭐

**适合场景**: 团队协作、持续部署、自动化

**步骤**:
1. 登录 [Cloudflare Dashboard](https://dash.cloudflare.com/?to=/:account/pages)
2. 点击 **"Create a project"** → **"Connect to Git"**
3. 选择 GitHub/GitLab → 授权 → 选择 `suk-protocol` 仓库
4. 配置:
   ```
   项目名称: suk-protocol
   生产分支: main
   构建命令: (留空)
   构建输出目录: .
   ```
5. 点击 **"Save and Deploy"**
6. 完成！ 🎉 访问 `https://suk-protocol.pages.dev`

**优点**:
- ✅ Git push 自动部署
- ✅ 自动生成预览链接
- ✅ 无需本地配置
- ✅ 支持回滚

---

### 方式二：Wrangler CLI 手动部署 ⭐⭐⭐⭐

**适合场景**: 本地测试、快速部署、临时更新

**步骤**:

```bash
# 1. 安装 Wrangler
npm install -g wrangler

# 2. 登录 Cloudflare
wrangler login

# 3. 创建项目（首次）
wrangler pages project create suk-protocol

# 4. 部署
wrangler pages deploy . --project-name=suk-protocol
```

**优点**:
- ✅ 快速部署
- ✅ 本地控制
- ✅ 命令行操作
- ✅ 支持脚本自动化

---

### 方式三：GitHub Actions 自动部署 ⭐⭐⭐⭐⭐

**适合场景**: CI/CD 流程、自动化测试、企业项目

**步骤**:

1. **获取 Cloudflare API Token**:
   - 访问 [API Tokens](https://dash.cloudflare.com/profile/api-tokens)
   - 创建 Token (Edit Cloudflare Workers 权限)
   - 保存 Token

2. **获取 Account ID**:
   - 在 Cloudflare Dashboard 右侧找到 Account ID
   - 复制备用

3. **配置 GitHub Secrets**:
   - 仓库 → Settings → Secrets and variables → Actions
   - 添加:
     ```
     CLOUDFLARE_API_TOKEN: <你的 Token>
     CLOUDFLARE_ACCOUNT_ID: <你的 Account ID>
     ```

4. **推送代码触发部署**:
   ```bash
   git add .
   git commit -m "Deploy to Cloudflare"
   git push origin main
   ```

5. **完成！** 🎉 GitHub Actions 自动部署

**优点**:
- ✅ 完全自动化
- ✅ 支持自动测试
- ✅ 部署状态可见
- ✅ 企业级 CI/CD

---

## 🌐 自定义域名配置

### 快速步骤

1. **添加域名**:
   - Pages 项目 → Custom domains → Set up a custom domain
   - 输入域名: `suk.link`

2. **配置 DNS**:
   
   **如果域名在 Cloudflare**:
   - ✅ 自动配置（无需操作）
   
   **如果域名在其他 DNS 提供商**:
   ```
   类型: CNAME
   名称: @
   值: suk-protocol.pages.dev
   ```

3. **等待生效** (5-10分钟)

4. **完成！** 🎉 访问 `https://suk.link`

---

## ✅ 部署验证清单

部署完成后，逐一检查：

### 基础功能
- [ ] 主页打开正常: `https://suk-protocol.pages.dev`
- [ ] CSS 样式加载正常
- [ ] JavaScript 运行正常
- [ ] 图片显示正常

### 核心页面
- [ ] Staking Dashboard: `/staking-dashboard.html`
- [ ] Investor Dashboard: `/investor-dashboard.html`
- [ ] Revenue Claim: `/revenue-claim.html`
- [ ] Investor Subscription: `/investor-subscription.html`

### 钱包功能
- [ ] MetaMask 连接正常
- [ ] Phantom 连接正常
- [ ] 网络切换正常
- [ ] 合约交互正常

### 区块链功能
- [ ] Solana 交易正常
- [ ] Ethereum 交易正常
- [ ] 智能合约读取正常
- [ ] 智能合约写入正常

---

## 🚨 常见问题快速解决

### Q1: 部署后页面 404

```bash
# 检查 _redirects 文件
cat _redirects

# 确保包含 SPA 回退
/* /index.html 200
```

### Q2: 样式丢失

```html
<!-- 使用绝对路径 -->
<link rel="stylesheet" href="/css/style.css">

<!-- 清除缓存 -->
Ctrl + Shift + R
```

### Q3: 钱包无法连接

```bash
# 检查 _headers 文件的 CSP 配置
# 确保包含:
# script-src 'self' 'unsafe-inline' https://*.solana.com https://*.ethereum.org
```

### Q4: 部署时间过长

```bash
# 创建 .cfignore 排除不必要的文件
cat > .cfignore << EOF
node_modules/
.git/
*.md
.env*
*.log
deployment/
contracts/
scripts/
EOF
```

### Q5: 环境变量不生效

```javascript
// 纯静态网站使用配置文件
// config.js
const config = {
    apiUrl: 'https://api.suk.link',
    solanaRpc: 'https://api.mainnet-beta.solana.com'
};
```

---

## 📊 性能优化建议

### 1. 启用 Cloudflare Web Analytics

```
Dashboard → Analytics → Enable Web Analytics
```

### 2. 配置缓存规则

```bash
# _headers 文件已自动配置:
# - 静态资源: 1年缓存
# - CSS/JS: 1天缓存
# - HTML: 1小时缓存
```

### 3. 启用 Bot Protection

```
Dashboard → Security → Bots → Enable Super Bot Fight Mode
```

### 4. 图片优化

```bash
# 使用 Cloudflare Image Optimization
# 自动转换为 WebP 格式
# 自动调整大小
```

---

## 🎉 部署成功！下一步

部署完成后，您可以：

1. ✅ **配置自定义域名** → `suk.link`
2. ✅ **启用 Web Analytics** → 监控流量
3. ✅ **设置 Bot Protection** → 防止攻击
4. ✅ **配置告警通知** → 及时获知问题
5. ✅ **优化性能** → PageSpeed Insights

---

## 📞 获取帮助

遇到问题？

- 📖 [完整部署指南](./CLOUDFLARE_DEPLOYMENT_GUIDE.md)
- 🌐 [Cloudflare Pages 文档](https://developers.cloudflare.com/pages/)
- 💬 [Cloudflare Discord](https://discord.cloudflare.com/)
- 🐛 [GitHub Issues](https://github.com/your-repo/issues)

---

## 🎯 快速命令速查表

```bash
# 安装 Wrangler
npm install -g wrangler

# 登录
wrangler login

# 创建项目
wrangler pages project create suk-protocol

# 部署
wrangler pages deploy . --project-name=suk-protocol

# 查看部署
wrangler pages deployment list --project-name=suk-protocol

# 查看日志
wrangler pages deployment tail --project-name=suk-protocol
```

---

**🚀 现在就开始部署您的 SUK Protocol 到全球 CDN！**

**部署时间**: < 3分钟  
**全球访问**: < 50ms  
**成本**: 完全免费 💰

---

*最后更新: 2024-11-18*
