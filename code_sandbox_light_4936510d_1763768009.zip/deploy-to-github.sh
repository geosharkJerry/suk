#!/bin/bash

# ========================================
# SUK Protocol - GitHub 快速部署脚本
# ========================================
# 
# 用途: 快速将项目推送到 GitHub 仓库
# 仓库: https://github.com/geosharkJerry/suk
# 
# 使用方法:
#   chmod +x deploy-to-github.sh
#   ./deploy-to-github.sh
# ========================================

set -e  # 遇到错误立即退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 项目信息
REPO_URL="https://github.com/geosharkJerry/suk.git"
REPO_NAME="suk"
BRANCH="main"

echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  SUK Protocol - GitHub 快速部署${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# 1. 检查 Git 是否安装
echo -e "${YELLOW}[1/7] 检查 Git 环境...${NC}"
if ! command -v git &> /dev/null; then
    echo -e "${RED}❌ 错误: 未安装 Git${NC}"
    echo -e "${YELLOW}请先安装 Git: https://git-scm.com/downloads${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Git 已安装: $(git --version)${NC}"
echo ""

# 2. 检查是否已初始化 Git
echo -e "${YELLOW}[2/7] 检查 Git 仓库状态...${NC}"
if [ ! -d ".git" ]; then
    echo -e "${YELLOW}⚠️  未检测到 Git 仓库，正在初始化...${NC}"
    git init
    echo -e "${GREEN}✅ Git 仓库初始化完成${NC}"
else
    echo -e "${GREEN}✅ Git 仓库已存在${NC}"
fi
echo ""

# 3. 配置 Git 用户信息
echo -e "${YELLOW}[3/7] 检查 Git 用户配置...${NC}"
GIT_USER_NAME=$(git config user.name || echo "")
GIT_USER_EMAIL=$(git config user.email || echo "")

if [ -z "$GIT_USER_NAME" ] || [ -z "$GIT_USER_EMAIL" ]; then
    echo -e "${YELLOW}⚠️  Git 用户信息未配置${NC}"
    echo -e "${YELLOW}请输入您的 Git 用户名:${NC}"
    read -r INPUT_NAME
    echo -e "${YELLOW}请输入您的 Git 邮箱:${NC}"
    read -r INPUT_EMAIL
    
    git config user.name "$INPUT_NAME"
    git config user.email "$INPUT_EMAIL"
    echo -e "${GREEN}✅ Git 用户信息配置完成${NC}"
else
    echo -e "${GREEN}✅ Git 用户: $GIT_USER_NAME <$GIT_USER_EMAIL>${NC}"
fi
echo ""

# 4. 检查远程仓库
echo -e "${YELLOW}[4/7] 配置远程仓库...${NC}"
if git remote | grep -q "^origin$"; then
    EXISTING_URL=$(git remote get-url origin)
    if [ "$EXISTING_URL" != "$REPO_URL" ]; then
        echo -e "${YELLOW}⚠️  远程仓库地址不匹配，正在更新...${NC}"
        git remote set-url origin "$REPO_URL"
        echo -e "${GREEN}✅ 远程仓库地址已更新${NC}"
    else
        echo -e "${GREEN}✅ 远程仓库已配置: $REPO_URL${NC}"
    fi
else
    echo -e "${YELLOW}⚠️  正在添加远程仓库...${NC}"
    git remote add origin "$REPO_URL"
    echo -e "${GREEN}✅ 远程仓库已添加: $REPO_URL${NC}"
fi
echo ""

# 5. 添加文件
echo -e "${YELLOW}[5/7] 添加文件到 Git...${NC}"
echo -e "${BLUE}正在扫描文件...${NC}"
git add .
FILE_COUNT=$(git diff --cached --numstat | wc -l)
echo -e "${GREEN}✅ 已添加 $FILE_COUNT 个文件${NC}"
echo ""

# 6. 提交更改
echo -e "${YELLOW}[6/7] 提交更改...${NC}"
COMMIT_MSG="🚀 Deploy to GitHub: SUK Protocol

- ✅ 完整的前端界面
- ✅ Cloudflare Pages 部署配置
- ✅ X402 协议实现
- ✅ Solana DeFi 集成
- ✅ 多语言支持
- ✅ 奖励系统集成
- ✅ 邀请码系统
- ✅ 完整的文档

Deployed at: $(date '+%Y-%m-%d %H:%M:%S')"

git commit -m "$COMMIT_MSG" || echo -e "${YELLOW}⚠️  没有新的更改需要提交${NC}"
echo -e "${GREEN}✅ 更改已提交${NC}"
echo ""

# 7. 推送到 GitHub
echo -e "${YELLOW}[7/7] 推送到 GitHub...${NC}"
echo -e "${BLUE}正在推送到 $BRANCH 分支...${NC}"

# 尝试推送
if git push -u origin "$BRANCH"; then
    echo -e "${GREEN}✅ 推送成功！${NC}"
else
    echo -e "${YELLOW}⚠️  推送失败，可能需要先拉取远程更改${NC}"
    echo -e "${YELLOW}是否要强制推送？(y/N)${NC}"
    read -r FORCE_PUSH
    if [[ "$FORCE_PUSH" =~ ^[Yy]$ ]]; then
        echo -e "${YELLOW}正在强制推送...${NC}"
        git push -u origin "$BRANCH" --force
        echo -e "${GREEN}✅ 强制推送成功！${NC}"
    else
        echo -e "${RED}❌ 部署已取消${NC}"
        exit 1
    fi
fi
echo ""

# 部署成功总结
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  🎉 部署成功！${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${BLUE}📦 仓库地址:${NC}"
echo -e "   $REPO_URL"
echo ""
echo -e "${BLUE}🌐 下一步:${NC}"
echo -e "   1️⃣  访问 GitHub 仓库: https://github.com/geosharkJerry/suk"
echo -e "   2️⃣  连接 Cloudflare Pages:"
echo -e "      - 访问: https://dash.cloudflare.com/"
echo -e "      - Workers & Pages → Create → Connect to Git"
echo -e "      - 选择仓库: geosharkJerry/suk"
echo -e "      - 配置:"
echo -e "        项目名称: suk-protocol"
echo -e "        生产分支: main"
echo -e "        构建命令: [留空]"
echo -e "        输出目录: ."
echo -e "   3️⃣  部署完成后访问: https://suk-protocol.pages.dev"
echo ""
echo -e "${BLUE}📖 完整指南:${NC}"
echo -e "   查看 GITHUB_DEPLOYMENT_GUIDE.md"
echo ""
echo -e "${GREEN}========================================${NC}"
