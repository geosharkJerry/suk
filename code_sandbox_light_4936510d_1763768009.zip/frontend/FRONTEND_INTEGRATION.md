# SUK Protocol 前端集成指南

本文档提供 SUK Protocol 前端与智能合约集成的完整指南。

---

## 📋 目录

1. [架构概览](#架构概览)
2. [环境配置](#环境配置)
3. [Solana 集成](#solana-集成)
4. [Ethereum 集成](#ethereum-集成)
5. [钱包连接](#钱包连接)
6. [合约调用示例](#合约调用示例)
7. [错误处理](#错误处理)
8. [最佳实践](#最佳实践)

---

## 架构概览

```
┌──────────────────────────────────────────────────┐
│              Frontend Application                │
├──────────────────────────────────────────────────┤
│                                                  │
│  ┌────────────────┐      ┌─────────────────┐   │
│  │  Wallet Layer  │      │  Contract Layer │   │
│  ├────────────────┤      ├─────────────────┤   │
│  │ • Phantom      │◄────►│ • Anchor Client │   │
│  │ • MetaMask     │      │ • Ethers.js     │   │
│  └────────────────┘      └─────────────────┘   │
│                                                  │
│  ┌──────────────────────────────────────────┐   │
│  │         Contract Interaction             │   │
│  ├──────────────────────────────────────────┤   │
│  │ • Read Operations  (Free)                │   │
│  │ • Write Operations (Requires Signature)  │   │
│  └──────────────────────────────────────────┘   │
│                                                  │
└──────────────────────────────────────────────────┘
           ▲                       ▲
           │                       │
    ┌──────┴───────┐      ┌───────┴──────┐
    │    Solana    │      │   Ethereum   │
    │   Devnet/    │      │   Sepolia/   │
    │   Mainnet    │      │   Mainnet    │
    └──────────────┘      └──────────────┘
```

---

## 环境配置

### 步骤 1: 创建配置文件

在 `frontend` 目录创建 `config/contracts.js`:

```javascript
// config/contracts.js

const NETWORKS = {
  // Solana 配置
  solana: {
    devnet: {
      name: 'Devnet',
      rpcUrl: 'https://api.devnet.solana.com',
      programs: {
        sukToken: 'YOUR_SUK_TOKEN_PROGRAM_ID',
        dramaStaking: 'YOUR_DRAMA_STAKING_PROGRAM_ID'
      },
      explorer: 'https://explorer.solana.com'
    },
    mainnet: {
      name: 'Mainnet Beta',
      rpcUrl: 'https://api.mainnet-beta.solana.com',
      programs: {
        sukToken: 'MAINNET_SUK_TOKEN_PROGRAM_ID',
        dramaStaking: 'MAINNET_DRAMA_STAKING_PROGRAM_ID'
      },
      explorer: 'https://explorer.solana.com'
    }
  },

  // Ethereum 配置
  ethereum: {
    sepolia: {
      name: 'Sepolia Testnet',
      chainId: 11155111,
      rpcUrl: 'https://eth-sepolia.g.alchemy.com/v2/YOUR_KEY',
      contracts: {
        sukToken: '0xYOUR_SUK_TOKEN_ADDRESS',
        dramaStaking: '0xYOUR_DRAMA_STAKING_ADDRESS'
      },
      explorer: 'https://sepolia.etherscan.io'
    },
    mainnet: {
      name: 'Ethereum Mainnet',
      chainId: 1,
      rpcUrl: 'https://eth-mainnet.g.alchemy.com/v2/YOUR_KEY',
      contracts: {
        sukToken: '0xMAINNET_SUK_TOKEN_ADDRESS',
        dramaStaking: '0xMAINNET_DRAMA_STAKING_ADDRESS'
      },
      explorer: 'https://etherscan.io'
    }
  }
};

// 当前使用的网络
const CURRENT_NETWORK = {
  solana: 'devnet',  // 'devnet' | 'mainnet'
  ethereum: 'sepolia' // 'sepolia' | 'mainnet'
};

export { NETWORKS, CURRENT_NETWORK };
```

### 步骤 2: 安装依赖

```html
<!-- 在 HTML <head> 中添加 -->

<!-- Solana Web3.js -->
<script src="https://cdn.jsdelivr.net/npm/@solana/web3.js@latest/lib/index.iife.min.js"></script>

<!-- Anchor (如果使用) -->
<script src="https://cdn.jsdelivr.net/npm/@project-serum/anchor@0.29.0/dist/browser.js"></script>

<!-- Ethers.js -->
<script src="https://cdn.jsdelivr.net/npm/ethers@5.7.2/dist/ethers.umd.min.js"></script>
```

---

## Solana 集成

### 连接 Phantom 钱包

```javascript
// utils/solana-wallet.js

class SolanaWallet {
  constructor() {
    this.provider = null;
    this.publicKey = null;
  }

  // 检查 Phantom 是否安装
  isPhantomInstalled() {
    return window.solana && window.solana.isPhantom;
  }

  // 连接钱包
  async connect() {
    if (!this.isPhantomInstalled()) {
      window.open('https://phantom.app/', '_blank');
      throw new Error('请先安装 Phantom 钱包');
    }

    try {
      const response = await window.solana.connect();
      this.publicKey = response.publicKey.toString();
      this.provider = window.solana;
      
      console.log('Connected to Phantom:', this.publicKey);
      return this.publicKey;
    } catch (error) {
      console.error('Phantom connection error:', error);
      throw error;
    }
  }

  // 断开连接
  async disconnect() {
    if (this.provider) {
      await this.provider.disconnect();
      this.publicKey = null;
      console.log('Disconnected from Phantom');
    }
  }

  // 监听账户变化
  onAccountChanged(callback) {
    if (this.provider) {
      this.provider.on('accountChanged', (publicKey) => {
        if (publicKey) {
          this.publicKey = publicKey.toString();
          callback(this.publicKey);
        }
      });
    }
  }
}

export default new SolanaWallet();
```

### Solana 合约交互

```javascript
// utils/solana-contract.js

import { Connection, PublicKey, Transaction } from '@solana/web3.js';
import { AnchorProvider, Program } from '@project-serum/anchor';
import { NETWORKS, CURRENT_NETWORK } from '../config/contracts.js';

class SolanaContract {
  constructor() {
    const network = NETWORKS.solana[CURRENT_NETWORK.solana];
    this.connection = new Connection(network.rpcUrl, 'confirmed');
    this.programIds = network.programs;
  }

  // 获取 Anchor Provider
  getProvider(wallet) {
    return new AnchorProvider(
      this.connection,
      wallet,
      { commitment: 'confirmed' }
    );
  }

  // 查询 SUK 余额
  async getSUKBalance(walletAddress) {
    try {
      const publicKey = new PublicKey(walletAddress);
      
      // TODO: 替换为实际的 SPL Token 账户查询
      // 这里使用 getTokenAccountsByOwner
      const tokenAccounts = await this.connection.getTokenAccountsByOwner(
        publicKey,
        { mint: new PublicKey(this.programIds.sukToken) }
      );

      if (tokenAccounts.value.length > 0) {
        const accountInfo = await this.connection.getTokenAccountBalance(
          tokenAccounts.value[0].pubkey
        );
        return accountInfo.value.uiAmount;
      }
      
      return 0;
    } catch (error) {
      console.error('Error getting SUK balance:', error);
      return 0;
    }
  }

  // 提交短剧质押
  async submitDramaStaking(wallet, dramaData) {
    try {
      const provider = this.getProvider(wallet);
      const programId = new PublicKey(this.programIds.dramaStaking);
      
      // Load program IDL
      const idl = await Program.fetchIdl(programId, provider);
      const program = new Program(idl, programId, provider);

      // Call submit_drama_staking
      const tx = await program.methods
        .submitDramaStaking(
          dramaData.dramaId,
          dramaData.stakedAmount,
          dramaData.targetAmount,
          dramaData.expectedRevenue
        )
        .accounts({
          owner: provider.wallet.publicKey,
          // ... other accounts
        })
        .rpc();

      console.log('Transaction signature:', tx);
      return tx;
    } catch (error) {
      console.error('Submit staking error:', error);
      throw error;
    }
  }

  // 投资短剧
  async investInDrama(wallet, dramaId, amount) {
    try {
      const provider = this.getProvider(wallet);
      const programId = new PublicKey(this.programIds.dramaStaking);
      
      const idl = await Program.fetchIdl(programId, provider);
      const program = new Program(idl, programId, provider);

      const tx = await program.methods
        .investInDrama(dramaId, amount)
        .accounts({
          investor: provider.wallet.publicKey,
          // ... other accounts
        })
        .rpc();

      return tx;
    } catch (error) {
      console.error('Invest error:', error);
      throw error;
    }
  }

  // 提取收益
  async claimRevenue(wallet, dramaId) {
    try {
      const provider = this.getProvider(wallet);
      const programId = new PublicKey(this.programIds.dramaStaking);
      
      const idl = await Program.fetchIdl(programId, provider);
      const program = new Program(idl, programId, provider);

      const tx = await program.methods
        .claimRevenue(dramaId)
        .accounts({
          investor: provider.wallet.publicKey,
          // ... other accounts
        })
        .rpc();

      return tx;
    } catch (error) {
      console.error('Claim error:', error);
      throw error;
    }
  }
}

export default new SolanaContract();
```

---

## Ethereum 集成

### 连接 MetaMask 钱包

```javascript
// utils/ethereum-wallet.js

class EthereumWallet {
  constructor() {
    this.provider = null;
    this.signer = null;
    this.address = null;
  }

  // 检查 MetaMask 是否安装
  isMetaMaskInstalled() {
    return typeof window.ethereum !== 'undefined';
  }

  // 连接钱包
  async connect() {
    if (!this.isMetaMaskInstalled()) {
      window.open('https://metamask.io/download/', '_blank');
      throw new Error('请先安装 MetaMask 钱包');
    }

    try {
      await window.ethereum.request({ method: 'eth_requestAccounts' });
      this.provider = new ethers.providers.Web3Provider(window.ethereum);
      this.signer = this.provider.getSigner();
      this.address = await this.signer.getAddress();
      
      console.log('Connected to MetaMask:', this.address);
      return this.address;
    } catch (error) {
      console.error('MetaMask connection error:', error);
      throw error;
    }
  }

  // 切换网络
  async switchNetwork(chainId) {
    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: ethers.utils.hexValue(chainId) }],
      });
    } catch (error) {
      // 如果网络不存在，添加网络
      if (error.code === 4902) {
        await this.addNetwork(chainId);
      } else {
        throw error;
      }
    }
  }

  // 添加网络 (Sepolia)
  async addNetwork(chainId) {
    const networks = {
      11155111: {
        chainId: '0xaa36a7',
        chainName: 'Sepolia Testnet',
        nativeCurrency: {
          name: 'Sepolia ETH',
          symbol: 'ETH',
          decimals: 18
        },
        rpcUrls: ['https://sepolia.infura.io/v3/'],
        blockExplorerUrls: ['https://sepolia.etherscan.io']
      }
    };

    const network = networks[chainId];
    if (network) {
      await window.ethereum.request({
        method: 'wallet_addEthereumChain',
        params: [network]
      });
    }
  }

  // 监听账户变化
  onAccountChanged(callback) {
    if (window.ethereum) {
      window.ethereum.on('accountsChanged', (accounts) => {
        if (accounts.length > 0) {
          this.address = accounts[0];
          callback(this.address);
        }
      });
    }
  }

  // 监听网络变化
  onNetworkChanged(callback) {
    if (window.ethereum) {
      window.ethereum.on('chainChanged', (chainId) => {
        callback(parseInt(chainId, 16));
      });
    }
  }
}

export default new EthereumWallet();
```

### Ethereum 合约交互

```javascript
// utils/ethereum-contract.js

import { ethers } from 'ethers';
import { NETWORKS, CURRENT_NETWORK } from '../config/contracts.js';

// ABI (从编译输出获取)
import SUKTokenABI from '../abis/SUKToken.json';
import DramaStakingABI from '../abis/DramaIPStaking.json';

class EthereumContract {
  constructor() {
    const network = NETWORKS.ethereum[CURRENT_NETWORK.ethereum];
    this.contractAddresses = network.contracts;
    this.provider = null;
    this.contracts = {};
  }

  // 初始化合约实例
  async init(signer) {
    this.provider = signer.provider;

    // SUK Token Contract
    this.contracts.sukToken = new ethers.Contract(
      this.contractAddresses.sukToken,
      SUKTokenABI,
      signer
    );

    // Drama Staking Contract
    this.contracts.dramaStaking = new ethers.Contract(
      this.contractAddresses.dramaStaking,
      DramaStakingABI,
      signer
    );
  }

  // 查询 SUK 余额
  async getSUKBalance(address) {
    try {
      const balance = await this.contracts.sukToken.balanceOf(address);
      return ethers.utils.formatUnits(balance, 18);
    } catch (error) {
      console.error('Error getting SUK balance:', error);
      return '0';
    }
  }

  // 授权 SUK Token
  async approveSUK(spender, amount) {
    try {
      const amountWei = ethers.utils.parseUnits(amount.toString(), 18);
      const tx = await this.contracts.sukToken.approve(spender, amountWei);
      await tx.wait();
      return tx.hash;
    } catch (error) {
      console.error('Approve error:', error);
      throw error;
    }
  }

  // 提交短剧质押
  async submitDramaStaking(dramaData) {
    try {
      const tx = await this.contracts.dramaStaking.submitDramaStaking(
        dramaData.dramaId,
        ethers.utils.parseUnits(dramaData.stakedAmount.toString(), 18),
        ethers.utils.parseUnits(dramaData.targetAmount.toString(), 18),
        ethers.utils.parseUnits(dramaData.expectedRevenue.toString(), 18)
      );
      
      const receipt = await tx.wait();
      return receipt.transactionHash;
    } catch (error) {
      console.error('Submit staking error:', error);
      throw error;
    }
  }

  // 投资短剧
  async investInDrama(dramaId, amount) {
    try {
      // 先授权
      const stakingAddress = this.contractAddresses.dramaStaking;
      await this.approveSUK(stakingAddress, amount);

      // 然后投资
      const amountWei = ethers.utils.parseUnits(amount.toString(), 18);
      const tx = await this.contracts.dramaStaking.investInDrama(
        dramaId,
        amountWei
      );
      
      const receipt = await tx.wait();
      return receipt.transactionHash;
    } catch (error) {
      console.error('Invest error:', error);
      throw error;
    }
  }

  // 提取收益
  async claimRevenue(dramaId) {
    try {
      const tx = await this.contracts.dramaStaking.claimRevenue(dramaId);
      const receipt = await tx.wait();
      return receipt.transactionHash;
    } catch (error) {
      console.error('Claim error:', error);
      throw error;
    }
  }

  // 查询投资信息
  async getInvestmentInfo(dramaId, investor) {
    try {
      const info = await this.contracts.dramaStaking.investors(dramaId, investor);
      return {
        investedAmount: ethers.utils.formatUnits(info.investedAmount, 18),
        claimedRevenue: ethers.utils.formatUnits(info.claimedRevenue, 18),
        hasInvested: info.hasInvested
      };
    } catch (error) {
      console.error('Get investment info error:', error);
      return null;
    }
  }
}

export default new EthereumContract();
```

---

## 钱包连接

### 统一钱包管理

```javascript
// utils/wallet-manager.js

import SolanaWallet from './solana-wallet.js';
import EthereumWallet from './ethereum-wallet.js';

class WalletManager {
  constructor() {
    this.currentChain = null; // 'solana' | 'ethereum'
    this.wallets = {
      solana: SolanaWallet,
      ethereum: EthereumWallet
    };
  }

  // 连接钱包
  async connect(chain) {
    try {
      const wallet = this.wallets[chain];
      if (!wallet) {
        throw new Error(`Unsupported chain: ${chain}`);
      }

      const address = await wallet.connect();
      this.currentChain = chain;
      
      return {
        chain,
        address
      };
    } catch (error) {
      console.error('Wallet connection error:', error);
      throw error;
    }
  }

  // 获取当前钱包
  getCurrentWallet() {
    if (!this.currentChain) {
      throw new Error('No wallet connected');
    }
    return this.wallets[this.currentChain];
  }

  // 断开连接
  async disconnect() {
    if (this.currentChain) {
      await this.wallets[this.currentChain].disconnect();
      this.currentChain = null;
    }
  }
}

export default new WalletManager();
```

### 在页面中使用

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>SUK Protocol</title>
    <script type="module">
        import WalletManager from './utils/wallet-manager.js';
        import SolanaContract from './utils/solana-contract.js';
        import EthereumContract from './utils/ethereum-contract.js';

        // 连接 Solana 钱包
        document.getElementById('connectSolana').addEventListener('click', async () => {
            try {
                const { address } = await WalletManager.connect('solana');
                console.log('Solana address:', address);
                
                // 查询余额
                const balance = await SolanaContract.getSUKBalance(address);
                console.log('SUK balance:', balance);
            } catch (error) {
                alert('连接失败: ' + error.message);
            }
        });

        // 连接 Ethereum 钱包
        document.getElementById('connectEthereum').addEventListener('click', async () => {
            try {
                const { address } = await WalletManager.connect('ethereum');
                console.log('Ethereum address:', address);
                
                // 初始化合约
                const wallet = WalletManager.getCurrentWallet();
                await EthereumContract.init(wallet.signer);
                
                // 查询余额
                const balance = await EthereumContract.getSUKBalance(address);
                console.log('SUK balance:', balance);
            } catch (error) {
                alert('连接失败: ' + error.message);
            }
        });
    </script>
</head>
<body>
    <button id="connectSolana">Connect Solana</button>
    <button id="connectEthereum">Connect Ethereum</button>
</body>
</html>
```

---

## 合约调用示例

### 示例 1: 提交短剧质押

```javascript
async function submitStaking() {
    try {
        const dramaData = {
            dramaId: 'drama_001',
            stakedAmount: 1000000, // 1M SUK
            targetAmount: 5000000,  // 5M SUK
            expectedRevenue: 10000000 // 10M SUK
        };

        let txHash;
        if (WalletManager.currentChain === 'solana') {
            const wallet = WalletManager.getCurrentWallet();
            txHash = await SolanaContract.submitDramaStaking(wallet, dramaData);
        } else {
            txHash = await EthereumContract.submitDramaStaking(dramaData);
        }

        console.log('Transaction hash:', txHash);
        alert('质押提交成功!');
    } catch (error) {
        console.error('Submit error:', error);
        alert('质押失败: ' + error.message);
    }
}
```

### 示例 2: 投资短剧

```javascript
async function investDrama(dramaId, amount) {
    try {
        let txHash;
        if (WalletManager.currentChain === 'solana') {
            const wallet = WalletManager.getCurrentWallet();
            txHash = await SolanaContract.investInDrama(wallet, dramaId, amount);
        } else {
            txHash = await EthereumContract.investInDrama(dramaId, amount);
        }

        console.log('Investment transaction:', txHash);
        alert('投资成功!');
    } catch (error) {
        console.error('Invest error:', error);
        alert('投资失败: ' + error.message);
    }
}
```

### 示例 3: 提取收益

```javascript
async function claimRevenue(dramaId) {
    try {
        let txHash;
        if (WalletManager.currentChain === 'solana') {
            const wallet = WalletManager.getCurrentWallet();
            txHash = await SolanaContract.claimRevenue(wallet, dramaId);
        } else {
            txHash = await EthereumContract.claimRevenue(dramaId);
        }

        console.log('Claim transaction:', txHash);
        alert('收益提取成功!');
    } catch (error) {
        console.error('Claim error:', error);
        alert('提取失败: ' + error.message);
    }
}
```

---

## 错误处理

### 常见错误及处理

```javascript
function handleError(error) {
    // Solana 错误
    if (error.code === 4001) {
        return '用户拒绝了交易';
    }
    if (error.message.includes('insufficient funds')) {
        return '余额不足';
    }

    // Ethereum 错误
    if (error.code === 'INSUFFICIENT_FUNDS') {
        return 'ETH 余额不足 (Gas 费用)';
    }
    if (error.code === 'ACTION_REJECTED') {
        return '用户拒绝了交易';
    }
    if (error.message.includes('execution reverted')) {
        // 解析 revert 原因
        const reason = error.message.match(/reason="(.+?)"/);
        return reason ? reason[1] : '交易执行失败';
    }

    return error.message || '未知错误';
}

// 使用示例
try {
    await investDrama('drama_001', 1000);
} catch (error) {
    const userMessage = handleError(error);
    alert(userMessage);
}
```

---

## 最佳实践

### 1. 加载状态管理

```javascript
class LoadingManager {
    show(message = '处理中...') {
        document.getElementById('loadingModal').style.display = 'flex';
        document.getElementById('loadingMessage').textContent = message;
    }

    hide() {
        document.getElementById('loadingModal').style.display = 'none';
    }
}

const loading = new LoadingManager();

// 使用
async function performTransaction() {
    try {
        loading.show('正在提交交易...');
        await someContractCall();
        loading.hide();
        alert('成功!');
    } catch (error) {
        loading.hide();
        alert('失败: ' + error.message);
    }
}
```

### 2. 交易确认提示

```javascript
async function confirmTransaction(action, details) {
    const confirmed = confirm(
        `确认${action}?\n\n` +
        Object.entries(details)
            .map(([key, value]) => `${key}: ${value}`)
            .join('\n')
    );

    if (!confirmed) {
        throw new Error('用户取消了操作');
    }
}

// 使用
await confirmTransaction('投资', {
    '剧集': '霸总的替身新娘',
    '金额': '1000 SUK',
    '预计 Gas': '~0.002 ETH'
});
```

### 3. 缓存和性能优化

```javascript
class ContractCache {
    constructor(ttl = 30000) { // 30s TTL
        this.cache = new Map();
        this.ttl = ttl;
    }

    set(key, value) {
        this.cache.set(key, {
            value,
            timestamp: Date.now()
        });
    }

    get(key) {
        const item = this.cache.get(key);
        if (!item) return null;

        if (Date.now() - item.timestamp > this.ttl) {
            this.cache.delete(key);
            return null;
        }

        return item.value;
    }
}

const cache = new ContractCache();

// 使用缓存获取余额
async function getBalanceWithCache(address) {
    const cacheKey = `balance_${address}`;
    let balance = cache.get(cacheKey);

    if (balance === null) {
        balance = await EthereumContract.getSUKBalance(address);
        cache.set(cacheKey, balance);
    }

    return balance;
}
```

---

## 完整集成示例

查看以下文件了解完整的集成示例:

- `frontend/staking-dashboard.html` - 版权方仪表板
- `frontend/investor-dashboard.html` - 投资者仪表板
- `frontend/revenue-claim.html` - 收益提取界面
- `frontend/investor-subscription.html` - 投资认购界面

---

**最后更新**: 2025-06-18  
**版本**: v1.0.0
