

# 🎬 短剧点播系统 - 后端API实现指南

## 📋 目录

1. [技术架构](#技术架构)
2. [API端点列表](#api端点列表)
3. [详细实现代码](#详细实现代码)
4. [数据库设计](#数据库设计)
5. [区块链集成](#区块链集成)
6. [阿里云VoD集成](#阿里云vod集成)
7. [部署指南](#部署指南)

---

## 技术架构

```
┌─────────────┐
│   前端     │ 
│ React/Vue  │
└──────┬──────┘
       │ HTTP/WebSocket
       ↓
┌─────────────┐
│  后端API    │
│ Node.js +   │
│  Express    │
└──────┬──────┘
       │
   ┌───┴───┬────────┬────────┐
   ↓       ↓        ↓        ↓
┌──────┐┌──────┐┌───────┐┌────────┐
│MongoDB││Redis ││阿里云 ││区块链  │
│      ││      ││ VoD   ││Ethereum│
└──────┘└──────┘└───────┘└────────┘
```

---

## API端点列表

### 1. 短剧管理

| 方法 | 端点 | 描述 |
|------|------|------|
| GET | `/api/drama/list` | 获取短剧列表 |
| GET | `/api/drama/:dramaId` | 获取短剧详情 |
| GET | `/api/drama/:dramaId/episodes` | 获取剧集列表 |
| GET | `/api/drama/search` | 搜索短剧 |

### 2. 购买与支付

| 方法 | 端点 | 描述 |
|------|------|------|
| POST | `/api/purchase/episode` | 购买单集 |
| POST | `/api/purchase/drama` | 购买整部剧 |
| GET | `/api/purchase/verify/:episodeId` | 验证购买状态 |
| GET | `/api/purchase/history` | 购买历史 |

### 3. 视频播放

| 方法 | 端点 | 描述 |
|------|------|------|
| GET | `/api/video/play-auth/:episodeId` | 获取播放凭证 |
| POST | `/api/video/watch-progress` | 保存观看进度 |
| GET | `/api/video/watch-history` | 观看历史 |

### 4. 用户功能

| 方法 | 端点 | 描述 |
|------|------|------|
| POST | `/api/user/favorite` | 添加收藏 |
| DELETE | `/api/user/favorite/:dramaId` | 取消收藏 |
| GET | `/api/user/favorites` | 收藏列表 |
| POST | `/api/user/share` | 分享记录 |

---

## 详细实现代码

### 项目结构

```bash
backend/
├── src/
│   ├── routes/
│   │   ├── drama.routes.js      # 短剧相关路由
│   │   ├── purchase.routes.js   # 购买相关路由
│   │   ├── video.routes.js      # 视频播放路由
│   │   └── user.routes.js       # 用户功能路由
│   ├── controllers/
│   │   ├── drama.controller.js
│   │   ├── purchase.controller.js
│   │   ├── video.controller.js
│   │   └── user.controller.js
│   ├── services/
│   │   ├── aliyun-vod.service.js  # 阿里云VoD服务
│   │   ├── blockchain.service.js   # 区块链交互
│   │   └── cache.service.js        # Redis缓存
│   ├── models/
│   │   ├── Drama.js
│   │   ├── Purchase.js
│   │   ├── WatchHistory.js
│   │   └── User.js
│   ├── middleware/
│   │   ├── auth.middleware.js     # 身份验证
│   │   └── payment.middleware.js  # 支付验证
│   ├── config/
│   │   ├── database.js
│   │   ├── aliyun.js
│   │   └── blockchain.js
│   └── app.js
├── package.json
└── .env
```

### 1. 购买API实现

**src/controllers/purchase.controller.js**

```javascript
const Purchase = require('../models/Purchase');
const Drama = require('../models/Drama');
const BlockchainService = require('../services/blockchain.service');
const AliyunVoD = require('../services/aliyun-vod.service');
const CacheService = require('../services/cache.service');

class PurchaseController {
    /**
     * 购买单集
     */
    async purchaseEpisode(req, res) {
        try {
            const { dramaId, episodeId, sukAmount, txHash, userAddress } = req.body;
            
            // 1. 验证参数
            if (!dramaId || !episodeId || !sukAmount || !txHash) {
                return res.status(400).json({
                    success: false,
                    error: '缺少必要参数'
                });
            }
            
            // 2. 获取剧集信息
            const drama = await Drama.findById(dramaId);
            if (!drama) {
                return res.status(404).json({
                    success: false,
                    error: '短剧不存在'
                });
            }
            
            const episode = drama.episodes.find(ep => ep.episodeId === episodeId);
            if (!episode) {
                return res.status(404).json({
                    success: false,
                    error: '剧集不存在'
                });
            }
            
            // 3. 验证价格
            if (episode.sukPrice !== sukAmount) {
                return res.status(400).json({
                    success: false,
                    error: '支付金额不正确'
                });
            }
            
            // 4. 验证区块链交易
            const isValidTx = await BlockchainService.verifyTransaction(
                txHash,
                userAddress,
                sukAmount
            );
            
            if (!isValidTx) {
                return res.status(400).json({
                    success: false,
                    error: '区块链交易验证失败'
                });
            }
            
            // 5. 检查是否已购买
            const existingPurchase = await Purchase.findOne({
                userId: userAddress,
                dramaId,
                episodeId
            });
            
            if (existingPurchase) {
                return res.status(400).json({
                    success: false,
                    error: '您已购买过此剧集'
                });
            }
            
            // 6. 创建购买记录
            const purchase = new Purchase({
                userId: userAddress,
                dramaId,
                episodeId,
                sukAmount,
                txHash,
                purchaseType: 'episode',
                status: 'completed',
                timestamp: new Date()
            });
            
            await purchase.save();
            
            // 7. 生成播放凭证（30分钟有效期）
            const playAuth = await AliyunVoD.generatePlayAuth(
                episode.videoId,
                1800 // 30分钟
            );
            
            // 8. 缓存播放凭证
            await CacheService.set(
                `play_auth:${userAddress}:${episodeId}`,
                playAuth,
                1800 // 30分钟过期
            );
            
            // 9. 更新统计数据
            await Drama.updateOne(
                { _id: dramaId },
                { 
                    $inc: { 
                        purchaseCount: 1,
                        'episodes.$[elem].purchaseCount': 1
                    }
                },
                { 
                    arrayFilters: [{ 'elem.episodeId': episodeId }]
                }
            );
            
            res.json({
                success: true,
                message: '购买成功',
                data: {
                    purchaseId: purchase._id,
                    playAuth,
                    videoId: episode.videoId,
                    expiresIn: 1800
                }
            });
            
        } catch (error) {
            console.error('购买失败:', error);
            res.status(500).json({
                success: false,
                error: '购买处理失败: ' + error.message
            });
        }
    }
    
    /**
     * 购买整部剧
     */
    async purchaseDrama(req, res) {
        try {
            const { dramaId, sukAmount, txHash, userAddress } = req.body;
            
            // 获取短剧信息
            const drama = await Drama.findById(dramaId);
            if (!drama) {
                return res.status(404).json({
                    success: false,
                    error: '短剧不存在'
                });
            }
            
            // 验证价格
            if (drama.sukPrice !== sukAmount) {
                return res.status(400).json({
                    success: false,
                    error: '支付金额不正确'
                });
            }
            
            // 验证区块链交易
            const isValidTx = await BlockchainService.verifyTransaction(
                txHash,
                userAddress,
                sukAmount
            );
            
            if (!isValidTx) {
                return res.status(400).json({
                    success: false,
                    error: '区块链交易验证失败'
                });
            }
            
            // 创建购买记录（包含所有剧集）
            const episodeIds = drama.episodes.map(ep => ep.episodeId);
            const purchases = episodeIds.map(episodeId => ({
                userId: userAddress,
                dramaId,
                episodeId,
                sukAmount: drama.sukPrice / drama.episodes.length,
                txHash,
                purchaseType: 'full',
                status: 'completed',
                timestamp: new Date()
            }));
            
            await Purchase.insertMany(purchases);
            
            // 更新统计
            await Drama.updateOne(
                { _id: dramaId },
                { $inc: { purchaseCount: 1 } }
            );
            
            res.json({
                success: true,
                message: '购买成功',
                data: {
                    dramaId,
                    episodesUnlocked: episodeIds.length
                }
            });
            
        } catch (error) {
            console.error('购买失败:', error);
            res.status(500).json({
                success: false,
                error: '购买处理失败: ' + error.message
            });
        }
    }
    
    /**
     * 验证购买状态
     */
    async verifyPurchase(req, res) {
        try {
            const { episodeId } = req.params;
            const userAddress = req.user.address; // 从JWT获取
            
            const purchase = await Purchase.findOne({
                userId: userAddress,
                episodeId,
                status: 'completed'
            });
            
            res.json({
                success: true,
                isPurchased: !!purchase,
                purchaseDate: purchase?.timestamp
            });
            
        } catch (error) {
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
    
    /**
     * 获取购买历史
     */
    async getPurchaseHistory(req, res) {
        try {
            const userAddress = req.user.address;
            const { page = 1, limit = 20 } = req.query;
            
            const purchases = await Purchase.find({
                userId: userAddress,
                status: 'completed'
            })
            .populate('dramaId', 'title coverImage')
            .sort({ timestamp: -1 })
            .skip((page - 1) * limit)
            .limit(parseInt(limit));
            
            const total = await Purchase.countDocuments({
                userId: userAddress,
                status: 'completed'
            });
            
            res.json({
                success: true,
                data: purchases,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total,
                    pages: Math.ceil(total / limit)
                }
            });
            
        } catch (error) {
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
}

module.exports = new PurchaseController();
```

### 2. 视频播放API实现

**src/controllers/video.controller.js**

```javascript
const AliyunVoD = require('../services/aliyun-vod.service');
const Purchase = require('../models/Purchase');
const WatchHistory = require('../models/WatchHistory');
const CacheService = require('../services/cache.service');

class VideoController {
    /**
     * 获取播放凭证
     */
    async getPlayAuth(req, res) {
        try {
            const { episodeId } = req.params;
            const userAddress = req.user.address;
            
            // 1. 检查是否购买
            const purchase = await Purchase.findOne({
                userId: userAddress,
                episodeId,
                status: 'completed'
            });
            
            if (!purchase) {
                return res.status(403).json({
                    success: false,
                    error: '您尚未购买此剧集'
                });
            }
            
            // 2. 检查缓存
            const cachedAuth = await CacheService.get(
                `play_auth:${userAddress}:${episodeId}`
            );
            
            if (cachedAuth) {
                return res.json({
                    success: true,
                    playAuth: cachedAuth,
                    videoId: purchase.episodeId,
                    expiresIn: await CacheService.ttl(`play_auth:${userAddress}:${episodeId}`)
                });
            }
            
            // 3. 生成新的播放凭证
            const episode = await Drama.findOne(
                { 'episodes.episodeId': episodeId },
                { 'episodes.$': 1 }
            );
            
            if (!episode) {
                return res.status(404).json({
                    success: false,
                    error: '剧集不存在'
                });
            }
            
            const videoId = episode.episodes[0].videoId;
            const playAuth = await AliyunVoD.generatePlayAuth(videoId, 1800);
            
            // 4. 缓存播放凭证
            await CacheService.set(
                `play_auth:${userAddress}:${episodeId}`,
                playAuth,
                1800
            );
            
            res.json({
                success: true,
                playAuth,
                videoId,
                expiresIn: 1800
            });
            
        } catch (error) {
            console.error('获取播放凭证失败:', error);
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
    
    /**
     * 保存观看进度
     */
    async saveWatchProgress(req, res) {
        try {
            const { dramaId, episodeId, progress, duration } = req.body;
            const userAddress = req.user.address;
            
            await WatchHistory.findOneAndUpdate(
                {
                    userId: userAddress,
                    dramaId,
                    episodeId
                },
                {
                    watchProgress: progress,
                    totalDuration: duration,
                    lastWatchedAt: new Date()
                },
                { upsert: true, new: true }
            );
            
            res.json({
                success: true,
                message: '进度已保存'
            });
            
        } catch (error) {
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
    
    /**
     * 获取观看历史
     */
    async getWatchHistory(req, res) {
        try {
            const userAddress = req.user.address;
            const { page = 1, limit = 20 } = req.query;
            
            const history = await WatchHistory.find({
                userId: userAddress
            })
            .populate('dramaId', 'title coverImage')
            .sort({ lastWatchedAt: -1 })
            .skip((page - 1) * limit)
            .limit(parseInt(limit));
            
            res.json({
                success: true,
                data: history
            });
            
        } catch (error) {
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
}

module.exports = new VideoController();
```

### 3. 短剧搜索API实现

**src/controllers/drama.controller.js**

```javascript
const Drama = require('../models/Drama');

class DramaController {
    /**
     * 搜索短剧
     */
    async searchDramas(req, res) {
        try {
            const { q, category, minRating, maxPrice, page = 1, limit = 20 } = req.query;
            
            // 构建查询条件
            const query = {};
            
            // 关键词搜索
            if (q) {
                query.$or = [
                    { title: { $regex: q, $options: 'i' } },
                    { description: { $regex: q, $options: 'i' } },
                    { tags: { $in: [new RegExp(q, 'i')] } }
                ];
            }
            
            // 分类筛选
            if (category) {
                query.category = category;
            }
            
            // 评分筛选
            if (minRating) {
                query.rating = { $gte: parseFloat(minRating) };
            }
            
            // 价格筛选
            if (maxPrice) {
                query.sukPrice = { $lte: parseInt(maxPrice) };
            }
            
            // 执行查询
            const results = await Drama.find(query)
                .select('title description category coverImage rating views sukPrice totalEpisodes')
                .sort({ views: -1 })
                .skip((page - 1) * limit)
                .limit(parseInt(limit));
            
            const total = await Drama.countDocuments(query);
            
            res.json({
                success: true,
                data: results,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total,
                    pages: Math.ceil(total / limit)
                }
            });
            
        } catch (error) {
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
    
    /**
     * 获取短剧列表
     */
    async getDramaList(req, res) {
        try {
            const { category, sort = 'popular', page = 1, limit = 20 } = req.query;
            
            const query = {};
            if (category) query.category = category;
            
            // 排序规则
            const sortOptions = {
                popular: { views: -1 },
                latest: { createdAt: -1 },
                rating: { rating: -1 },
                price_asc: { sukPrice: 1 },
                price_desc: { sukPrice: -1 }
            };
            
            const dramas = await Drama.find(query)
                .sort(sortOptions[sort] || sortOptions.popular)
                .skip((page - 1) * limit)
                .limit(parseInt(limit));
            
            const total = await Drama.countDocuments(query);
            
            res.json({
                success: true,
                data: dramas,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total,
                    pages: Math.ceil(total / limit)
                }
            });
            
        } catch (error) {
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
    
    /**
     * 获取短剧详情
     */
    async getDramaDetail(req, res) {
        try {
            const { dramaId } = req.params;
            
            const drama = await Drama.findById(dramaId);
            
            if (!drama) {
                return res.status(404).json({
                    success: false,
                    error: '短剧不存在'
                });
            }
            
            // 增加浏览量
            await Drama.updateOne(
                { _id: dramaId },
                { $inc: { views: 1 } }
            );
            
            res.json({
                success: true,
                data: drama
            });
            
        } catch (error) {
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
}

module.exports = new DramaController();
```

### 4. 用户功能API实现

**src/controllers/user.controller.js**

```javascript
const Favorite = require('../models/Favorite');
const Drama = require('../models/Drama');

class UserController {
    /**
     * 添加收藏
     */
    async addFavorite(req, res) {
        try {
            const { dramaId } = req.body;
            const userAddress = req.user.address;
            
            // 检查是否已收藏
            const existing = await Favorite.findOne({
                userId: userAddress,
                dramaId
            });
            
            if (existing) {
                return res.status(400).json({
                    success: false,
                    error: '已收藏过此短剧'
                });
            }
            
            // 创建收藏
            const favorite = new Favorite({
                userId: userAddress,
                dramaId,
                createdAt: new Date()
            });
            
            await favorite.save();
            
            // 更新短剧收藏数
            await Drama.updateOne(
                { _id: dramaId },
                { $inc: { favoriteCount: 1 } }
            );
            
            res.json({
                success: true,
                message: '收藏成功'
            });
            
        } catch (error) {
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
    
    /**
     * 取消收藏
     */
    async removeFavorite(req, res) {
        try {
            const { dramaId } = req.params;
            const userAddress = req.user.address;
            
            const result = await Favorite.deleteOne({
                userId: userAddress,
                dramaId
            });
            
            if (result.deletedCount === 0) {
                return res.status(404).json({
                    success: false,
                    error: '收藏不存在'
                });
            }
            
            // 更新短剧收藏数
            await Drama.updateOne(
                { _id: dramaId },
                { $inc: { favoriteCount: -1 } }
            );
            
            res.json({
                success: true,
                message: '已取消收藏'
            });
            
        } catch (error) {
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
    
    /**
     * 获取收藏列表
     */
    async getFavorites(req, res) {
        try {
            const userAddress = req.user.address;
            const { page = 1, limit = 20 } = req.query;
            
            const favorites = await Favorite.find({
                userId: userAddress
            })
            .populate('dramaId')
            .sort({ createdAt: -1 })
            .skip((page - 1) * limit)
            .limit(parseInt(limit));
            
            const total = await Favorite.countDocuments({
                userId: userAddress
            });
            
            res.json({
                success: true,
                data: favorites.map(f => f.dramaId),
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total,
                    pages: Math.ceil(total / limit)
                }
            });
            
        } catch (error) {
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
    
    /**
     * 分享记录
     */
    async recordShare(req, res) {
        try {
            const { dramaId, episodeId, platform } = req.body;
            const userAddress = req.user?.address;
            
            // 记录分享（可用于统计和奖励）
            // TODO: 保存到数据库
            
            // 更新短剧分享数
            await Drama.updateOne(
                { _id: dramaId },
                { $inc: { shareCount: 1 } }
            );
            
            res.json({
                success: true,
                message: '分享成功',
                shareUrl: `https://suk-protocol.com/drama/${dramaId}?episode=${episodeId}&ref=${userAddress}`
            });
            
        } catch (error) {
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
}

module.exports = new UserController();
```

---

## 阿里云VoD集成

**src/services/aliyun-vod.service.js**

```javascript
const RPCClient = require('@alicloud/pop-core').RPCClient;

class AliyunVoDService {
    constructor() {
        this.client = new RPCClient({
            accessKeyId: process.env.ALIYUN_ACCESS_KEY_ID,
            accessKeySecret: process.env.ALIYUN_ACCESS_KEY_SECRET,
            endpoint: 'https://vod.cn-shanghai.aliyuncs.com',
            apiVersion: '2017-03-21'
        });
    }
    
    /**
     * 生成播放凭证
     */
    async generatePlayAuth(videoId, timeout = 1800) {
        try {
            const params = {
                VideoId: videoId,
                AuthInfoTimeout: timeout // 凭证有效期（秒）
            };
            
            const result = await this.client.request('GetVideoPlayAuth', params, {});
            
            return result.PlayAuth;
            
        } catch (error) {
            console.error('生成播放凭证失败:', error);
            throw error;
        }
    }
    
    /**
     * 上传视频
     */
    async uploadVideo(title, fileName, fileContent) {
        try {
            // 1. 获取上传地址和凭证
            const uploadAuth = await this.getUploadAuth(title, fileName);
            
            // 2. 上传视频文件到OSS
            // TODO: 使用OSS SDK上传
            
            // 3. 返回视频ID
            return uploadAuth.VideoId;
            
        } catch (error) {
            console.error('上传视频失败:', error);
            throw error;
        }
    }
    
    /**
     * 获取上传凭证
     */
    async getUploadAuth(title, fileName) {
        try {
            const params = {
                Title: title,
                FileName: fileName
            };
            
            const result = await this.client.request('CreateUploadVideo', params, {});
            
            return {
                VideoId: result.VideoId,
                UploadAuth: result.UploadAuth,
                UploadAddress: result.UploadAddress
            };
            
        } catch (error) {
            console.error('获取上传凭证失败:', error);
            throw error;
        }
    }
    
    /**
     * 获取视频信息
     */
    async getVideoInfo(videoId) {
        try {
            const params = {
                VideoId: videoId
            };
            
            const result = await this.client.request('GetVideoInfo', params, {});
            
            return result.Video;
            
        } catch (error) {
            console.error('获取视频信息失败:', error);
            throw error;
        }
    }
}

module.exports = new AliyunVoDService();
```

---

## 区块链集成

**src/services/blockchain.service.js**

```javascript
const { ethers } = require('ethers');

class BlockchainService {
    constructor() {
        // 连接以太坊节点
        this.provider = new ethers.providers.JsonRpcProvider(
            process.env.ETHEREUM_RPC_URL || 'https://mainnet.infura.io/v3/YOUR-PROJECT-ID'
        );
        
        // SUK代币合约地址
        this.sukTokenAddress = process.env.SUK_TOKEN_ADDRESS;
        
        // SUK代币合约ABI
        this.sukTokenABI = [
            'function transfer(address to, uint256 amount) returns (bool)',
            'function balanceOf(address owner) view returns (uint256)',
            'event Transfer(address indexed from, address indexed to, uint256 value)'
        ];
        
        this.sukContract = new ethers.Contract(
            this.sukTokenAddress,
            this.sukTokenABI,
            this.provider
        );
    }
    
    /**
     * 验证交易
     */
    async verifyTransaction(txHash, fromAddress, expectedAmount) {
        try {
            // 1. 获取交易详情
            const tx = await this.provider.getTransaction(txHash);
            
            if (!tx) {
                throw new Error('交易不存在');
            }
            
            // 2. 等待交易确认
            const receipt = await tx.wait();
            
            if (receipt.status !== 1) {
                throw new Error('交易失败');
            }
            
            // 3. 验证发送地址
            if (tx.from.toLowerCase() !== fromAddress.toLowerCase()) {
                throw new Error('发送地址不匹配');
            }
            
            // 4. 解析Transfer事件
            const transferEvent = receipt.logs.find(log => {
                try {
                    const parsedLog = this.sukContract.interface.parseLog(log);
                    return parsedLog.name === 'Transfer';
                } catch {
                    return false;
                }
            });
            
            if (!transferEvent) {
                throw new Error('未找到Transfer事件');
            }
            
            const parsedLog = this.sukContract.interface.parseLog(transferEvent);
            const amount = parsedLog.args.value;
            
            // 5. 验证金额
            const expectedAmountWei = ethers.utils.parseUnits(
                expectedAmount.toString(),
                18 // SUK代币精度
            );
            
            if (!amount.eq(expectedAmountWei)) {
                throw new Error('支付金额不匹配');
            }
            
            return true;
            
        } catch (error) {
            console.error('验证交易失败:', error);
            return false;
        }
    }
    
    /**
     * 获取SUK余额
     */
    async getSUKBalance(address) {
        try {
            const balance = await this.sukContract.balanceOf(address);
            return ethers.utils.formatUnits(balance, 18);
        } catch (error) {
            console.error('获取余额失败:', error);
            throw error;
        }
    }
}

module.exports = new BlockchainService();
```

---

## 部署指南

### 1. 环境变量配置

**.env**

```bash
# 服务器配置
PORT=3000
NODE_ENV=production

# 数据库
MONGODB_URI=mongodb://localhost:27017/suk_drama
REDIS_URL=redis://localhost:6379

# 阿里云VoD
ALIYUN_ACCESS_KEY_ID=your_access_key
ALIYUN_ACCESS_KEY_SECRET=your_secret_key
ALIYUN_VOD_REGION=cn-shanghai

# 区块链
ETHEREUM_RPC_URL=https://mainnet.infura.io/v3/YOUR-PROJECT-ID
SUK_TOKEN_ADDRESS=0x...

# JWT
JWT_SECRET=your_jwt_secret
JWT_EXPIRES_IN=7d

# CORS
ALLOWED_ORIGINS=https://suk-protocol.com,https://www.suk-protocol.com
```

### 2. 启动服务

```bash
# 安装依赖
npm install

# 开发环境
npm run dev

# 生产环境
npm start

# 使用PM2部署
pm2 start src/app.js --name suk-api -i max
```

### 3. Nginx配置

```nginx
server {
    listen 80;
    server_name api.suk-protocol.com;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## 📊 成本预估

### 阿里云VoD费用（每部短剧100集，每集2分钟）

| 项目 | 费用 |
|------|------|
| 存储（200分钟，约2GB） | ¥0.24/月 |
| 转码（200分钟，720P） | ¥6-10（一次性） |
| 流量（10万次播放，20GB） | ¥4.8 |
| **月度总成本** | **约¥5-15** |

### 服务器费用

| 项目 | 配置 | 月费用 |
|------|------|--------|
| 云服务器 | 2核4G | ¥100-200 |
| MongoDB | 基础版 | ¥50-100 |
| Redis | 1GB | ¥30-50 |
| **月度总成本** | | **¥180-350** |

---

## 📞 技术支持

- **阿里云VoD文档**: https://help.aliyun.com/product/29932.html
- **Ethers.js文档**: https://docs.ethers.io/
- **MongoDB文档**: https://docs.mongodb.com/

---

**最后更新**: 2025-11-15  
**版本**: v1.0.0
