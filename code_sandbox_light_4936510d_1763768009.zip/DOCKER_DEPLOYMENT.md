# Docker 部署指南
# Docker Deployment Guide

> **短剧平台 Docker 容器化部署完整指南**

---

## 📋 目录

- [快速开始](#快速开始)
- [系统要求](#系统要求)
- [环境准备](#环境准备)
- [部署步骤](#部署步骤)
- [配置说明](#配置说明)
- [常用命令](#常用命令)
- [故障排查](#故障排查)
- [生产环境优化](#生产环境优化)

---

## 快速开始

### 3步快速部署

```bash
# 1. 克隆项目
git clone https://github.com/your-username/drama-platform.git
cd drama-platform

# 2. 配置环境变量
cp .env.example .env
nano .env  # 编辑配置

# 3. 启动服务
docker-compose up -d
```

### 验证部署

```bash
# 查看服务状态
docker-compose ps

# 查看日志
docker-compose logs -f app

# 访问应用
curl http://localhost:3000/api/health
```

---

## 系统要求

### 最低配置

- **CPU**: 2核
- **内存**: 4GB
- **硬盘**: 20GB
- **系统**: Ubuntu 20.04+ / CentOS 7+ / macOS / Windows 10+

### 推荐配置

- **CPU**: 4核+
- **内存**: 8GB+
- **硬盘**: 50GB+ SSD
- **系统**: Ubuntu 22.04 LTS

### 软件依赖

- Docker 20.10+
- Docker Compose 2.0+

---

## 环境准备

### 1. 安装 Docker

#### Ubuntu/Debian

```bash
# 更新软件源
sudo apt-get update

# 安装依赖
sudo apt-get install -y \
    ca-certificates \
    curl \
    gnupg \
    lsb-release

# 添加 Docker 官方 GPG 密钥
sudo mkdir -p /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | \
    sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg

# 添加 Docker 软件源
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
  https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# 安装 Docker
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

# 启动 Docker
sudo systemctl start docker
sudo systemctl enable docker

# 验证安装
docker --version
docker-compose --version
```

#### CentOS/RHEL

```bash
# 安装依赖
sudo yum install -y yum-utils

# 添加 Docker 软件源
sudo yum-config-manager \
    --add-repo \
    https://download.docker.com/linux/centos/docker-ce.repo

# 安装 Docker
sudo yum install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

# 启动 Docker
sudo systemctl start docker
sudo systemctl enable docker

# 验证安装
docker --version
docker-compose --version
```

#### macOS

```bash
# 使用 Homebrew 安装
brew install --cask docker

# 或下载 Docker Desktop
# https://www.docker.com/products/docker-desktop
```

### 2. 配置 Docker 用户组（可选）

```bash
# 添加当前用户到 docker 组
sudo usermod -aG docker $USER

# 重新登录或执行
newgrp docker

# 测试（不需要 sudo）
docker ps
```

---

## 部署步骤

### 1. 准备项目文件

```bash
# 克隆项目
git clone https://github.com/your-username/drama-platform.git
cd drama-platform

# 查看项目结构
ls -la
```

### 2. 配置环境变量

```bash
# 复制环境变量模板
cp .env.example .env

# 编辑环境变量
nano .env
```

**必需配置项**：
```bash
# MongoDB
MONGODB_ROOT_USER=admin
MONGODB_ROOT_PASSWORD=your_strong_password_here
MONGODB_DATABASE=short_drama_platform

# 阿里云 VoD
ALIYUN_ACCESS_KEY_ID=your_access_key_id
ALIYUN_ACCESS_KEY_SECRET=your_access_key_secret

# JWT
JWT_SECRET=$(openssl rand -hex 64)

# 区块链
ETHEREUM_RPC_URL=https://mainnet.infura.io/v3/your_infura_project_id
SUK_TOKEN_CONTRACT=0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb
PLATFORM_WALLET_ADDRESS=0x_your_wallet_address

# TON
TON_WALLET_ADDRESS=your_ton_wallet_address
TON_API_KEY=your_ton_api_key

# Telegram Bot
TELEGRAM_BOT_TOKEN=your_telegram_bot_token
TELEGRAM_BOT_USERNAME=YourBotUsername
```

### 3. 构建镜像

```bash
# 构建应用镜像
docker-compose build

# 查看镜像
docker images | grep drama-platform
```

### 4. 启动服务

```bash
# 启动所有服务（后台运行）
docker-compose up -d

# 查看服务状态
docker-compose ps

# 查看日志
docker-compose logs -f
```

**服务启动顺序**：
1. MongoDB（数据库）
2. Redis（缓存）
3. App（主应用）
4. Nginx（反向代理，可选）

### 5. 初始化数据库

```bash
# 进入应用容器
docker-compose exec app sh

# 运行初始化脚本
node scripts/init-db.js --seed

# 退出容器
exit
```

### 6. 验证部署

```bash
# 健康检查
curl http://localhost:3000/api/health

# 预期响应
{
    "status": "healthy",
    "timestamp": "2024-11-15T10:30:00Z",
    "services": {
        "mongodb": {"status": "healthy"},
        "redis": {"status": "healthy"},
        "aliyunVod": {"status": "healthy"},
        "tonBlockchain": {"status": "healthy"},
        "sukBlockchain": {"status": "healthy"}
    }
}
```

---

## 配置说明

### Docker Compose 服务

#### 1. App（主应用）

```yaml
app:
  build: .
  ports:
    - "3000:3000"
  depends_on:
    - mongodb
    - redis
```

**配置项**：
- `PORT`: 3000（默认）
- `NODE_ENV`: production
- `环境变量`: 通过 .env 文件配置

#### 2. MongoDB

```yaml
mongodb:
  image: mongo:6.0
  ports:
    - "27017:27017"
  volumes:
    - mongodb-data:/data/db
```

**默认配置**：
- 端口: 27017
- 用户: admin
- 密码: 通过 .env 配置
- 数据持久化: mongodb-data volume

#### 3. Redis

```yaml
redis:
  image: redis:7-alpine
  ports:
    - "6379:6379"
  volumes:
    - redis-data:/data
```

**配置**：
- 端口: 6379
- 持久化: AOF（每秒同步）
- 最大内存: 256MB
- 淘汰策略: allkeys-lru

#### 4. Nginx（可选）

```bash
# 启动带 Nginx 的配置
docker-compose --profile with-nginx up -d
```

**功能**：
- HTTPS 反向代理
- 静态文件缓存
- Gzip 压缩
- Rate Limiting

---

## 常用命令

### 服务管理

```bash
# 启动服务
docker-compose up -d

# 停止服务
docker-compose down

# 重启服务
docker-compose restart

# 查看服务状态
docker-compose ps

# 查看日志
docker-compose logs -f [service_name]

# 只查看应用日志
docker-compose logs -f app

# 查看最近100行日志
docker-compose logs --tail=100 app
```

### 容器管理

```bash
# 进入容器
docker-compose exec app sh
docker-compose exec mongodb mongosh
docker-compose exec redis redis-cli

# 查看容器资源使用
docker stats

# 查看容器详情
docker inspect drama-platform-app
```

### 镜像管理

```bash
# 构建镜像
docker-compose build

# 强制重新构建
docker-compose build --no-cache

# 拉取最新镜像
docker-compose pull

# 查看镜像
docker images

# 删除未使用的镜像
docker image prune -a
```

### 数据管理

```bash
# 备份 MongoDB
docker-compose exec mongodb mongodump \
    --out /data/backup \
    --db short_drama_platform

# 复制备份到宿主机
docker cp drama-platform-mongodb:/data/backup ./mongodb_backup

# 恢复 MongoDB
docker-compose exec mongodb mongorestore \
    --db short_drama_platform \
    /data/backup/short_drama_platform

# 查看 volume
docker volume ls

# 删除所有 volume（危险！）
docker-compose down -v
```

### 清理

```bash
# 停止并删除容器、网络
docker-compose down

# 删除容器、网络、volume
docker-compose down -v

# 删除容器、网络、镜像
docker-compose down --rmi all

# 清理系统
docker system prune -a --volumes
```

---

## 故障排查

### 1. 服务无法启动

**症状**：
```bash
docker-compose up -d
# ERROR: Cannot start service app
```

**解决方案**：

```bash
# 查看详细错误
docker-compose logs app

# 检查端口占用
sudo netstat -tulpn | grep 3000

# 检查环境变量
docker-compose config

# 重新构建
docker-compose build --no-cache
docker-compose up -d
```

### 2. MongoDB 连接失败

**症状**：
```
MongoServerError: Authentication failed
```

**解决方案**：

```bash
# 进入 MongoDB 容器
docker-compose exec mongodb mongosh

# 创建用户
use admin
db.createUser({
    user: "admin",
    pwd: "your_password",
    roles: ["root"]
})

# 退出并重启
exit
docker-compose restart mongodb app
```

### 3. Redis 连接失败

**症状**：
```
Error: connect ECONNREFUSED 127.0.0.1:6379
```

**解决方案**：

```bash
# 检查 Redis 状态
docker-compose exec redis redis-cli ping
# 应该返回: PONG

# 查看 Redis 日志
docker-compose logs redis

# 重启 Redis
docker-compose restart redis app
```

### 4. 内存不足

**症状**：
```
container killed: OOMKilled
```

**解决方案**：

```bash
# 查看资源使用
docker stats

# 增加 swap
sudo dd if=/dev/zero of=/swapfile bs=1M count=2048
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile

# 或限制容器内存
# 在 docker-compose.yml 中添加:
services:
  app:
    mem_limit: 1g
    memswap_limit: 1g
```

### 5. 磁盘空间不足

```bash
# 查看磁盘使用
df -h

# 清理 Docker
docker system prune -a --volumes

# 清理日志
sudo truncate -s 0 /var/lib/docker/containers/*/*-json.log
```

---

## 生产环境优化

### 1. 配置 HTTPS

```bash
# 安装 Certbot
sudo apt-get install certbot

# 获取 SSL 证书
sudo certbot certonly --standalone -d your-domain.com

# 复制证书到项目
mkdir -p ./ssl
sudo cp /etc/letsencrypt/live/your-domain.com/fullchain.pem ./ssl/
sudo cp /etc/letsencrypt/live/your-domain.com/privkey.pem ./ssl/

# 启动带 Nginx 的配置
docker-compose --profile with-nginx up -d

# 配置自动续期
sudo crontab -e
# 添加: 0 0 1 * * certbot renew --quiet
```

### 2. 配置日志轮转

```bash
# 创建日志轮转配置
sudo nano /etc/logrotate.d/docker-drama-platform

# 添加内容:
/path/to/drama-platform/logs/*.log {
    daily
    rotate 14
    compress
    delaycompress
    notifempty
    create 0644 nodejs nodejs
    sharedscripts
    postrotate
        docker-compose -f /path/to/drama-platform/docker-compose.yml restart app
    endscript
}
```

### 3. 监控和告警

```bash
# 安装监控工具
docker run -d \
  --name=prometheus \
  -p 9090:9090 \
  prom/prometheus

docker run -d \
  --name=grafana \
  -p 3001:3000 \
  grafana/grafana
```

### 4. 备份自动化

```bash
# 创建备份脚本
nano backup.sh

#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="./backups"

# 备份 MongoDB
docker-compose exec -T mongodb mongodump \
    --archive=/tmp/backup_${DATE}.archive

docker cp drama-platform-mongodb:/tmp/backup_${DATE}.archive \
    ${BACKUP_DIR}/mongodb_${DATE}.archive

# 删除30天前的备份
find ${BACKUP_DIR} -name "*.archive" -mtime +30 -delete

# 添加到 crontab
chmod +x backup.sh
crontab -e
# 添加: 0 2 * * * /path/to/drama-platform/backup.sh
```

### 5. 性能优化

```yaml
# docker-compose.yml 优化配置
services:
  app:
    deploy:
      resources:
        limits:
          cpus: '2.0'
          memory: 2G
        reservations:
          cpus: '1.0'
          memory: 1G
    
  mongodb:
    command: 
      - --wiredTigerCacheSizeGB=1.5
      - --slowms=100
      - --profile=1
    
  redis:
    command: 
      - redis-server
      - --maxmemory 512mb
      - --maxmemory-policy allkeys-lru
      - --save 60 1000
```

---

## 更新部署

```bash
# 拉取最新代码
git pull origin main

# 重新构建镜像
docker-compose build --no-cache

# 停止旧服务
docker-compose down

# 启动新服务
docker-compose up -d

# 查看日志
docker-compose logs -f app
```

---

## 参考资源

- [Docker 官方文档](https://docs.docker.com/)
- [Docker Compose 文档](https://docs.docker.com/compose/)
- [项目 README](README.md)
- [API 文档](API.md)
- [测试文档](TESTING.md)

---

**最后更新**: 2024-11-15  
**版本**: v1.0.0
