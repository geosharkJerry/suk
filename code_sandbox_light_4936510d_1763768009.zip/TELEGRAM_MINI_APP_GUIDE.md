# SUK短剧平台 - Telegram Mini App 完整指南

## 📋 目录

1. [项目概述](#项目概述)
2. [技术架构](#技术架构)
3. [本地开发](#本地开发)
4. [Mini App 功能](#mini-app-功能)
5. [测试指南](#测试指南)
6. [部署流程](#部署流程)
7. [Bot 配置](#bot-配置)
8. [故障排查](#故障排查)

---

## 项目概述

### 🎯 项目定位

SUK短剧平台是一个基于Telegram生态的短剧分发平台，通过Telegram Mini App为用户提供无缝的观看体验。

### ✨ 核心特性

- **🔐 Telegram 原生集成**：无需注册，使用Telegram账号即可登录
- **💰 多币种支付**：支持SUK Token、Telegram Stars、TON三种支付方式
- **📱 移动端优化**：完美适配Telegram移动端
- **🎨 主题适配**：自动适配Telegram深色/浅色主题
- **⚡ 离线友好**：内置Mock数据，支持离线预览

---

## 技术架构

### 前端技术栈

```
- HTML5 + CSS3 + JavaScript (原生)
- Telegram WebApp SDK v6.0+
- 响应式设计（移动端优先）
- PWA友好
```

### 文件结构

```
SUK/
├── telegram-app.html              # Mini App 主页（短剧列表）
├── telegram-drama-detail.html     # 短剧详情页
├── telegram-payment.html          # 支付页面（待开发）
├── telegram-profile.html          # 用户个人中心（待开发）
├── firebase.json                  # Firebase Hosting配置
└── deployment/
    ├── telegram-sukrawbot-config.sh
    └── SUKRAWBOT_SETUP_GUIDE.md
```

### API 架构

```
生产环境：
- 官网：https://suk.link (Firebase Hosting)
- API：https://api.suk.link (云服务器)
- Mini App入口：https://suk.link/telegram-app.html

开发环境：
- 本地服务器：localhost
- Mock数据：内置在前端代码中
```

---

## 本地开发

### 1. 环境准备

```bash
# 安装 HTTP 服务器（任选其一）
npm install -g http-server
# 或
pip install http-server
# 或
brew install caddy
```

### 2. 启动开发服务器

```bash
# 使用 http-server（推荐）
http-server . -p 8080 -c-1

# 或使用 Python
python3 -m http.server 8080

# 或使用 Caddy
caddy file-server --listen :8080
```

### 3. 访问应用

```
浏览器访问：http://localhost:8080/telegram-app.html
```

### 4. 开发模式特性

**自动识别开发环境**：
```javascript
const isDevelopment = 
    window.location.hostname === 'localhost' || 
    window.location.hostname.includes('ngrok') || 
    !tg.initData;
```

**开发模式下的行为**：
- ✅ 使用内置Mock数据（8部短剧）
- ✅ 模拟Telegram用户（张三 @dev_zhangsan）
- ✅ API失败自动Fallback到Mock数据
- ✅ 详细的Console日志输出
- ✅ 无需Telegram环境即可预览

### 5. Mock 数据说明

**短剧列表Mock数据**（telegram-app.html）：
```javascript
MOCK_DRAMAS = [
    {
        id: 'drama-001',
        title: '霸总的替身娇妻',
        category: 'romance',
        price: 99,
        priceStars: 150,
        priceTON: 0.5,
        views: 1234567,
        rating: 4.8,
        episodes: 80,
        isFree: false,
        isHot: true
    },
    // ... 共8部短剧
]
```

**短剧详情Mock数据**（telegram-drama-detail.html）：
- 包含完整剧情简介
- 包含用户评论
- 包含剧集列表
- 包含多种支付选项

---

## Mini App 功能

### 📱 主页（telegram-app.html）

#### 功能模块

1. **用户信息卡片**
   - 显示Telegram头像
   - 显示用户名
   - Premium用户标识
   - 自动从`tg.initDataUnsafe.user`获取

2. **分类筛选**
   - 🔥 全部
   - 💕 爱情
   - ✨ 玄幻
   - 🎭 剧情
   - 😂 喜剧
   - ⚔️ 动作

3. **短剧网格**
   - 2列网格布局（手机）
   - 3-4列布局（平板/桌面）
   - 9:16竖屏封面
   - 免费/热门标签
   - 多币种价格显示

4. **主按钮（MainButton）**
   - 文字：💰 充值SUK代币
   - 颜色：#FF6B6B
   - 点击：显示充值提示

#### 交互特性

```javascript
// 触觉反馈
tg.HapticFeedback.impactOccurred('light|medium|heavy');
tg.HapticFeedback.notificationOccurred('success|warning|error');

// 主题适配
background: var(--tg-theme-bg-color);
color: var(--tg-theme-text-color);
button: var(--tg-theme-button-color);

// 全屏展开
tg.expand();

// 关闭确认
tg.enableClosingConfirmation();
```

### 🎬 详情页（telegram-drama-detail.html）

#### 功能模块

1. **封面区域**
   - 全屏封面图
   - 渐变遮罩
   - 标题、评分、播放量
   - 免费/热门/分类标签

2. **支付选项卡**（仅付费内容）
   - 💎 SUK Token
   - ⭐ Telegram Stars
   - 💎 TON
   - 可选中状态

3. **剧情简介**
   - 多段落文本
   - 自动换行

4. **剧集列表**
   - 网格布局（4/6/8列响应式）
   - 前3集免费预览
   - 🔒锁定状态（付费内容）
   - 点击播放/购买

5. **用户评论**
   - ⭐评分显示
   - 用户名 + 时间
   - 评论内容

6. **底部操作栏**
   - ❤️ 收藏按钮
   - ▶️ 开始观看 / 💰 购买观看

#### 状态管理

```javascript
// 短剧状态
drama.isFree = true/false        // 是否免费
drama.isPurchased = true/false    // 是否已购买
drama.isHot = true/false         // 是否热门

// 剧集解锁逻辑
if (!isFree && !isPurchased && episode > 3) {
    // 显示锁定状态
    // 点击触发购买
}
```

---

## 测试指南

### 🧪 本地测试流程

#### 1. 功能测试清单

**主页测试**：
- [ ] 页面加载正常
- [ ] 显示8部Mock短剧
- [ ] 分类筛选有效
- [ ] 点击卡片跳转到详情页
- [ ] 封面图显示正常
- [ ] 价格显示正确
- [ ] 免费/热门标签正确
- [ ] Console无错误日志

**详情页测试**：
- [ ] 从主页跳转成功
- [ ] 封面和信息显示正确
- [ ] 付费内容显示支付选项
- [ ] 免费内容不显示支付选项
- [ ] 已购买内容显示"已购买"提示
- [ ] 剧集列表渲染正常
- [ ] 前3集可点击（付费内容）
- [ ] 第4集+显示🔒（付费内容）
- [ ] 评论区显示正常
- [ ] 返回按钮有效

**交互测试**：
- [ ] 分类切换有响应动画
- [ ] 支付方式可选中
- [ ] 点击购买按钮有反馈
- [ ] 点击播放按钮有反馈
- [ ] 收藏按钮有反馈

#### 2. 浏览器测试

```bash
# Chrome/Edge
打开开发者工具 → Console
检查是否有错误或警告

# Safari（iOS模拟器）
偏好设置 → 高级 → 显示开发菜单
开发 → 进入响应式设计模式

# Firefox
按F12打开开发者工具
```

**测试尺寸**：
- iPhone SE (375x667)
- iPhone 12/13 (390x844)
- iPhone 14 Pro Max (430x932)
- iPad (768x1024)
- Desktop (1920x1080)

#### 3. Console日志检查

**正常日志输出**：
```
🚀 初始化Telegram Mini App
🔧 开发模式：使用模拟用户数据
🎨 已应用Telegram主题
🔘 主按钮已配置
🔧 开发模式：使用Mock数据
✅ Mock数据加载成功: 8
✅ Telegram Mini App 已就绪
🌍 环境: 开发模式
🔗 API地址: 相对路径
```

### 📱 Telegram 真机测试

#### 准备工作

1. **配置Bot**
```bash
cd deployment
chmod +x telegram-sukrawbot-config.sh
./telegram-sukrawbot-config.sh
```

2. **部署到公网**
```bash
# 方法1: 使用Firebase Hosting（推荐）
firebase deploy --only hosting

# 方法2: 使用ngrok
ngrok http 8080

# 方法3: 部署到服务器
rsync -avz . user@suk.link:/var/www/html/
```

3. **更新Bot配置**
```bash
# 更新WebApp URL到实际地址
BOT_TOKEN="7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg"
WEBAPP_URL="https://suk.link/telegram-app.html"

curl -X POST "https://api.telegram.org/bot${BOT_TOKEN}/setChatMenuButton" \
  -H "Content-Type: application/json" \
  -d "{\"menu_button\": {\"type\": \"web_app\", \"text\": \"🎬 打开短剧平台\", \"web_app\": {\"url\": \"$WEBAPP_URL\"}}}"
```

#### 测试步骤

**步骤1：打开Mini App**
1. 在Telegram中搜索 `@SUKRAWBOT`
2. 点击菜单按钮 或 发送 `/start`
3. 点击 "🎬 打开短剧平台" 按钮
4. Mini App应该在Telegram内打开

**步骤2：用户信息测试**
- [ ] 显示真实Telegram头像
- [ ] 显示真实用户名
- [ ] Premium用户显示⭐标识

**步骤3：功能测试**
- [ ] 短剧列表加载（API或Mock）
- [ ] 分类筛选
- [ ] 点击短剧跳转详情
- [ ] 详情页所有功能
- [ ] 返回主页

**步骤4：主题测试**
- 切换Telegram深色/浅色模式
- [ ] Mini App主题自动适配
- [ ] 文字颜色可读
- [ ] 按钮颜色适配

**步骤5：触觉反馈测试**（仅移动端）
- [ ] 点击分类有震动反馈
- [ ] 点击短剧卡片有反馈
- [ ] 选择支付方式有反馈
- [ ] 点击购买/播放有反馈

---

## 部署流程

### 🚀 Firebase Hosting 部署

#### 1. 初始化Firebase项目

```bash
# 安装Firebase CLI
npm install -g firebase-tools

# 登录
firebase login

# 初始化项目
firebase init hosting
```

**选项配置**：
```
? What do you want to use as your public directory? .
? Configure as a single-page app? No
? Set up automatic builds and deploys with GitHub? No
? File ./index.html already exists. Overwrite? No
```

#### 2. 部署

```bash
# 预览部署
firebase hosting:channel:deploy preview

# 生产部署
firebase deploy --only hosting

# 使用脚本部署
cd scripts
chmod +x deploy-firebase-website.sh
./deploy-firebase-website.sh
```

#### 3. 验证部署

```bash
# 检查网站可访问性
curl -I https://suk.link/telegram-app.html

# 应该返回
HTTP/2 200
content-type: text/html; charset=utf-8
cache-control: public, max-age=3600, must-revalidate
```

#### 4. 自定义域名

**在Firebase Console**：
1. Hosting → 添加自定义域名
2. 输入 `suk.link`
3. 按照指示配置DNS记录

**在GoDaddy配置DNS**：
```
Type: A
Name: @
Value: 151.101.1.195, 151.101.65.195

Type: A  
Name: www
Value: 151.101.1.195, 151.101.65.195
```

**等待时间**：
- DNS传播：15分钟 - 48小时
- SSL证书生成：24-48小时

---

## Bot 配置

### 🤖 @SUKRAWBOT 配置

#### 自动配置（推荐）

```bash
cd deployment
chmod +x telegram-sukrawbot-config.sh
./telegram-sukrawbot-config.sh
```

**配置内容**：
- ✅ Webhook：https://api.suk.link/api/telegram/webhook
- ✅ 菜单按钮：打开Mini App
- ✅ Bot描述
- ✅ Bot命令列表
- ✅ 欢迎消息

#### 手动配置

**1. 设置菜单按钮**：
```bash
curl -X POST "https://api.telegram.org/bot7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg/setChatMenuButton" \
  -H "Content-Type: application/json" \
  -d '{
    "menu_button": {
      "type": "web_app",
      "text": "🎬 打开短剧平台",
      "web_app": {
        "url": "https://suk.link/telegram-app.html"
      }
    }
  }'
```

**2. 设置命令列表**：
```bash
curl -X POST "https://api.telegram.org/bot7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg/setMyCommands" \
  -H "Content-Type: application/json" \
  -d '{
    "commands": [
      {"command": "start", "description": "开始使用"},
      {"command": "app", "description": "打开短剧平台"},
      {"command": "help", "description": "帮助信息"}
    ]
  }'
```

**3. 验证配置**：
```bash
# 获取菜单按钮
curl "https://api.telegram.org/bot7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg/getChatMenuButton"

# 获取命令列表
curl "https://api.telegram.org/bot7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg/getMyCommands"

# 获取Webhook信息
curl "https://api.telegram.org/bot7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg/getWebhookInfo"
```

---

## 故障排查

### 常见问题

#### 1. Mini App打不开

**症状**：点击菜单按钮无反应

**检查**：
```bash
# 1. 验证菜单按钮配置
curl "https://api.telegram.org/bot7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg/getChatMenuButton"

# 2. 检查URL是否可访问
curl -I https://suk.link/telegram-app.html

# 3. 检查SSL证书
curl -vI https://suk.link/telegram-app.html 2>&1 | grep SSL
```

**解决方案**：
- 重新配置菜单按钮
- 检查Firebase Hosting状态
- 等待SSL证书生效（最多48小时）

#### 2. 显示白屏

**症状**：Mini App打开后显示空白页

**检查**：
```javascript
// 打开浏览器Console
// 查看错误信息
console.log(window.Telegram)
console.log(tg.initDataUnsafe)
```

**可能原因**：
- JavaScript加载失败
- Telegram SDK未加载
- HTTPS证书问题

**解决方案**：
```html
<!-- 确保SDK正确引入 -->
<script src="https://telegram.org/js/telegram-web-app.js"></script>

<!-- 检查初始化代码 -->
<script>
const tg = window.Telegram?.WebApp;
if (!tg) {
    alert('Telegram WebApp SDK未加载');
}
</script>
```

#### 3. Mock数据不显示

**症状**：开发模式下看不到短剧列表

**检查Console**：
```
应该看到：
🔧 开发模式：使用Mock数据
✅ Mock数据加载成功: 8
```

**解决方案**：
```javascript
// 确认isDevelopment变量
console.log('isDevelopment:', isDevelopment);

// 手动触发加载
loadDramas('all');
```

#### 4. 主题颜色不对

**症状**：深色模式下文字看不清

**检查**：
```javascript
// 查看主题参数
console.log(tg.themeParams);

// 输出应该包含：
{
    bg_color: "#ffffff",
    text_color: "#000000",
    hint_color: "#999999",
    link_color: "#2481cc",
    button_color: "#2481cc",
    button_text_color: "#ffffff"
}
```

**解决方案**：
```javascript
// 确保调用了主题适配函数
applyTelegramTheme();

// 或手动设置
document.body.style.background = tg.themeParams.bg_color;
document.body.style.color = tg.themeParams.text_color;
```

#### 5. API请求失败

**症状**：生产环境下数据加载失败

**检查**：
```javascript
// Console应该显示
❌ 加载短剧失败: HTTP 404
⚠️ API失败，使用Mock数据作为Fallback
```

**检查API状态**：
```bash
# 测试API连通性
curl https://api.suk.link/api/telegram/dramas

# 检查CORS配置
curl -H "Origin: https://suk.link" \
     -H "Access-Control-Request-Method: GET" \
     -X OPTIONS \
     https://api.suk.link/api/telegram/dramas
```

**解决方案**：
- 确认API服务器运行正常
- 检查CORS配置
- 验证API路径正确
- 使用Mock数据作为临时方案

### Debug技巧

#### 1. 启用详细日志

```javascript
// 在telegram-app.html顶部添加
window.DEBUG = true;

// 在函数中添加日志
if (window.DEBUG) {
    console.log('🐛 [DEBUG] 函数名:', 参数);
}
```

#### 2. 使用Telegram开发者工具

```javascript
// 显示Telegram环境信息
console.log('Platform:', tg.platform);
console.log('Version:', tg.version);
console.log('Init Data:', tg.initData);
console.log('User:', tg.initDataUnsafe.user);
```

#### 3. 模拟不同环境

```javascript
// 强制使用Mock数据
const isDevelopment = true;

// 强制使用API
const isDevelopment = false;

// 模拟不同用户
currentUser = {
    id: 999999,
    first_name: 'Test',
    username: 'testuser',
    is_premium: true
};
```

---

## 📊 性能优化

### 加载优化

```javascript
// 图片懒加载
<img loading="lazy" src="...">

// 预连接到API域名
<link rel="preconnect" href="https://api.suk.link">

// 预加载Telegram SDK
<link rel="preload" href="https://telegram.org/js/telegram-web-app.js" as="script">
```

### 缓存策略

**Firebase Hosting缓存**（firebase.json）：
```json
{
  "headers": [
    {
      "source": "**/*.@(jpg|jpeg|png|gif|webp)",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "public, max-age=31536000, immutable"
        }
      ]
    },
    {
      "source": "**/*.@(css|js)",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "public, max-age=86400, must-revalidate"
        }
      ]
    },
    {
      "source": "**/*.html",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "public, max-age=3600, must-revalidate"
        }
      ]
    }
  ]
}
```

---

## 🔐 安全最佳实践

### 1. 验证initData

```javascript
// 生产环境必须验证
if (!isDevelopment && tg.initData) {
    // 发送到后端验证
    fetch('/api/telegram/validate', {
        method: 'POST',
        headers: {
            'X-Telegram-Init-Data': tg.initData
        }
    });
}
```

### 2. 防止XSS

```javascript
// 使用textContent而不是innerHTML
element.textContent = userInput;

// 如果必须使用innerHTML，先转义
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
```

### 3. HTTPS Only

```javascript
// 确保所有请求使用HTTPS
const API_BASE_URL = 'https://api.suk.link';

// 不要使用
const API_BASE_URL = 'http://api.suk.link';
```

---

## 📞 技术支持

### 联系方式

- **项目地址**：https://github.com/your-repo/suk-platform
- **官网**：https://suk.link
- **Telegram Bot**：@SUKRAWBOT
- **开发团队**：dev@suk.link

### 参考文档

- [Telegram Mini Apps文档](https://core.telegram.org/bots/webapps)
- [Telegram Bot API](https://core.telegram.org/bots/api)
- [Firebase Hosting文档](https://firebase.google.com/docs/hosting)
- [TON文档](https://docs.ton.org/)

---

## 📝 更新日志

### v1.0.0 (2025-01-16)

**新功能**：
- ✅ 完整的短剧列表页
- ✅ 短剧详情页
- ✅ Mock数据支持
- ✅ 开发/生产环境自动识别
- ✅ Telegram主题适配
- ✅ 触觉反馈
- ✅ 响应式布局

**待开发**：
- ⏳ 支付页面
- ⏳ 个人中心
- ⏳ 视频播放器
- ⏳ 评论功能
- ⏳ 收藏功能

---

## 🎉 快速开始

```bash
# 1. 启动本地服务器
http-server . -p 8080 -c-1

# 2. 打开浏览器
open http://localhost:8080/telegram-app.html

# 3. 开始开发！
# 所有修改会立即生效（浏览器刷新即可）

# 4. 准备部署
firebase deploy --only hosting

# 5. 更新Bot配置
cd deployment
./telegram-sukrawbot-config.sh

# 6. 测试
# 在Telegram中打开 @SUKRAWBOT
```

---

**祝开发顺利！🚀**
