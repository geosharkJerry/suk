# 🚀 Cloudflare 迁移开始执行

## ✅ 准备工作已完成

我已经为您创建了以下配置文件：

1. ✅ **wrangler.toml** - Cloudflare Pages 配置文件
2. ✅ **_.cloudflare-ignore** - 部署忽略文件列表
3. ✅ **_redirects** - URL 重定向规则
4. ✅ **_headers** - HTTP 头配置

---

## 📋 第一步：安装 Wrangler CLI

在您的本地终端执行：

```bash
# 使用 npm 安装（推荐）
npm install -g wrangler

# 或使用 yarn
yarn global add wrangler

# 验证安装
wrangler --version
```

**预期输出**:
```
⛅️ wrangler 3.x.x
```

---

## 🔑 第二步：登录 Cloudflare

```bash
# 登录 Cloudflare 账号
wrangler login
```

**会发生什么**:
1. 自动打开浏览器
2. 提示您登录 Cloudflare 账号
3. 授权 Wrangler 访问您的账号
4. 完成后返回终端

**如果没有 Cloudflare 账号**:
1. 访问 https://dash.cloudflare.com/sign-up
2. 免费注册账号
3. 验证邮箱
4. 返回执行 `wrangler login`

---

## 🚀 第三步：首次部署（测试环境）

```bash
# 部署到 Cloudflare Pages
wrangler pages publish . --project-name=suk-link --branch=test

# 命令说明：
# . = 当前目录
# --project-name=suk-link = 项目名称
# --branch=test = 部署到测试分支
```

**部署过程**:
```
⚡️ Compiling worker to "/tmp/..."
✨ Compiled Worker successfully
🌍 Uploading... (xx files)
✨ Success! Uploaded xx files (x.xx MB total)
🌎 Deploying...
✅ Deployment complete!

预览链接: https://xxxxxxxx.suk-link.pages.dev
```

---

## 🧪 第四步：测试验证

部署完成后，访问提供的预览链接，测试以下内容：

### 测试清单

```bash
# 1. 主页加载
访问: https://xxxxxxxx.suk-link.pages.dev
预期: 正常显示首页

# 2. 其他页面
访问: /drama-detail.html
访问: /dashboard.html
访问: /faq.html
预期: 所有页面正常加载

# 3. 静态资源
检查: CSS 是否生效
检查: JavaScript 是否运行
检查: 图片是否显示

# 4. API 重定向（重要！）
打开浏览器控制台
检查: API 请求是否正确重定向到 api.suk.link
```

### 如果发现问题

```bash
# 查看部署日志
wrangler pages deployment list --project-name=suk-link

# 查看实时日志
wrangler pages deployment tail --project-name=suk-link
```

---

## ✅ 第五步：部署到生产环境

**确认测试通过后**，部署到生产环境：

```bash
# 部署到生产分支
wrangler pages publish . --project-name=suk-link --branch=main
```

---

## 🌐 第六步：配置自定义域名

### 方法1: 使用 Wrangler CLI

```bash
# 添加自定义域名
wrangler pages domain add suk-link suk.link

# 添加 www 子域名
wrangler pages domain add suk-link www.suk.link
```

### 方法2: 使用 Dashboard（推荐新手）

1. 访问 https://dash.cloudflare.com
2. 进入 **Workers & Pages**
3. 选择项目 **suk-link**
4. 点击 **Custom domains**
5. 点击 **Set up a custom domain**
6. 输入: `suk.link`
7. 点击 **Continue** → **Activate domain**
8. 重复步骤添加 `www.suk.link`

---

## 🔧 第七步：DNS 配置

### 如果域名已在 Cloudflare

DNS 会自动配置，无需手动操作 ✅

### 如果域名不在 Cloudflare

需要将域名迁移到 Cloudflare DNS：

1. 登录 Cloudflare Dashboard
2. 点击 **Add a Site**
3. 输入域名: `suk.link`
4. 选择 **Free Plan**
5. Cloudflare 会提供 **2个 Nameservers**
6. 登录您的域名注册商（如 GoDaddy, Namecheap）
7. 修改域名的 Nameservers 为 Cloudflare 提供的
8. 等待 DNS 传播（通常 5分钟-24小时）

### 添加后端 API 记录

```bash
# 在 Cloudflare DNS 中添加记录

记录类型: A
名称: api
内容: <你的VPS服务器IP>
代理状态: 已代理（橙色云朵）✅

记录类型: A
名称: monitor
内容: <你的监控服务器IP>
代理状态: 已代理（橙色云朵）✅
```

---

## 🔒 第八步：启用安全功能

### SSL/TLS 配置

1. 进入 **SSL/TLS** 设置
2. 加密模式选择: **Full (strict)**
3. 启用: **Always Use HTTPS** ✅
4. 启用: **Automatic HTTPS Rewrites** ✅
5. 启用: **TLS 1.3** ✅

### 防火墙配置

1. 进入 **Security** → **WAF**
2. 启用: **Cloudflare Managed Ruleset** ✅
3. 启用: **OWASP Core Ruleset** ✅

### 性能优化

1. 进入 **Speed** → **Optimization**
2. 启用: **Auto Minify** (HTML, CSS, JS) ✅
3. 启用: **Brotli** ✅
4. 启用: **Early Hints** ✅

---

## 📊 第九步：监控验证

### 检查部署状态

```bash
# 查看所有部署
wrangler pages deployment list --project-name=suk-link

# 查看项目信息
wrangler pages project list
```

### 性能测试

```bash
# 测试全球访问速度
访问: https://www.webpagetest.org/
输入: https://suk.link
运行测试

# 测试 SSL 评级
访问: https://www.ssllabs.com/ssltest/
输入: suk.link
运行测试（预期: A+）

# 测试安全头
访问: https://securityheaders.com/
输入: https://suk.link
运行测试（预期: A 或 A+）
```

### 功能验证

```bash
# 1. 主页访问
curl -I https://suk.link
预期: 200 OK

# 2. HTTPS 重定向
curl -I http://suk.link
预期: 301 → https://suk.link

# 3. API 重定向
curl -I https://suk.link/api/health
预期: 301 → https://api.suk.link/api/health

# 4. DNS 解析
dig suk.link
nslookup suk.link
预期: 正确解析到 Cloudflare IP
```

---

## ⚠️ 重要提醒

### 后端配置更新

确保后端 CORS 配置包含 Cloudflare Pages 域名：

```javascript
// backend/config/cors.js
const allowedOrigins = [
  'https://suk.link',
  'https://www.suk.link',
  'https://suk-link.pages.dev',  // Cloudflare Pages 默认域名
  'https://api.suk.link'
];
```

### Webhook 更新

如果使用 Telegram Bot Webhook，更新配置：

```bash
# .env 文件
TELEGRAM_WEBHOOK_URL=https://api.suk.link/api/telegram/webhook
```

### 阿里云 VoD 回调

更新视频回调 URL：

```bash
# .env 文件
VOD_CALLBACK_URL=https://api.suk.link/api/video/callback
```

---

## 🔄 回滚计划

如果遇到问题需要回滚：

### 方法1: DNS 快速切换

```bash
# 在 Cloudflare Dashboard
1. 进入 DNS 设置
2. 修改 suk.link 记录
3. 改回 Firebase Hosting 的配置
4. 等待 5-10分钟生效
```

### 方法2: 保留 Firebase 部署

```bash
# Firebase 部署保持不动
# 仅通过 DNS 切换流量
# 可随时切回 Firebase
```

---

## 📈 预期结果

### 立即生效
- ✅ 全球 CDN 加速
- ✅ 自动 HTTPS
- ✅ DDoS 防护
- ✅ WAF 防火墙

### 24小时内
- ✅ DNS 全球生效
- ✅ SSL 证书激活
- ✅ 缓存预热完成

### 1周内
- ✅ 用户反馈速度提升
- ✅ 服务器负载降低
- ✅ 成本节省体现

---

## 🆘 故障排查

### 问题1: wrangler 命令不存在

```bash
# 解决方案
npm install -g wrangler
# 或
npx wrangler --version
```

### 问题2: 登录失败

```bash
# 解决方案
1. 确保能访问 Cloudflare
2. 检查防火墙设置
3. 尝试使用 VPN
4. 手动获取 API Token
```

### 问题3: 部署失败

```bash
# 检查忽略文件
cat .cloudflare-ignore

# 清理缓存重试
rm -rf .wrangler
wrangler pages publish . --project-name=suk-link
```

### 问题4: 域名无法访问

```bash
# 检查 DNS
dig suk.link
nslookup suk.link

# 检查 Cloudflare 代理状态
# 确保橙色云朵已启用
```

### 问题5: API 请求失败

```bash
# 检查 _redirects 文件
cat _redirects

# 测试 API 重定向
curl -v https://suk.link/api/health

# 检查后端 CORS 配置
# 确保包含 Cloudflare 域名
```

---

## 📞 获取帮助

### Cloudflare 资源
- 📖 [官方文档](https://developers.cloudflare.com/pages/)
- 💬 [社区论坛](https://community.cloudflare.com/)
- 🎮 [Discord](https://discord.cloudflare.com/)

### 命令速查

```bash
# 登录
wrangler login

# 部署
wrangler pages publish . --project-name=suk-link

# 查看部署
wrangler pages deployment list --project-name=suk-link

# 查看日志
wrangler pages deployment tail --project-name=suk-link

# 配置域名
wrangler pages domain add suk-link suk.link

# 查看项目
wrangler pages project list
```

---

## ✅ 迁移检查清单

### 部署前
- [x] ✅ 创建 wrangler.toml
- [x] ✅ 创建 .cloudflare-ignore
- [x] ✅ 创建 _redirects
- [x] ✅ 创建 _headers
- [ ] 安装 Wrangler CLI
- [ ] 登录 Cloudflare

### 部署中
- [ ] 部署到测试环境
- [ ] 功能验证测试
- [ ] 部署到生产环境
- [ ] 配置自定义域名

### 部署后
- [ ] DNS 配置确认
- [ ] SSL 证书激活
- [ ] 性能测试
- [ ] 安全功能启用
- [ ] 监控配置

### 优化配置
- [ ] 缓存规则配置
- [ ] 安全头配置
- [ ] 压缩功能启用
- [ ] 后端 CORS 更新

---

## 🎉 下一步

完成以上步骤后，您的网站将：

✅ 托管在 Cloudflare Pages（免费）  
✅ 全球 CDN 加速（300+ 节点）  
✅ 自动 HTTPS（A+ 评级）  
✅ DDoS 防护（无限制）  
✅ WAF 防火墙（免费）  
✅ 成本节省（$300/年）  
✅ 速度提升（50%+）  

---

**开始时间**: 2025-11-16  
**预计完成**: 30-60分钟  
**难度评级**: ⭐⭐ (简单)  
**推荐指数**: ⭐⭐⭐⭐⭐ (5/5)

🚀 **立即开始第一步：安装 Wrangler CLI！**
