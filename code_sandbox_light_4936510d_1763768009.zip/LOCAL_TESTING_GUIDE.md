# Telegram Mini App 本地测试指南

## 🎯 测试目标

验证Telegram Mini App在本地开发环境下的所有功能是否正常工作。

---

## 📋 测试前准备

### 1. 检查环境

```bash
# 检查Node.js版本
node --version
# 应该显示: v18.x.x 或更高

# 检查是否安装http-server
http-server --version
# 如果未安装，运行: npm install -g http-server
```

### 2. 检查文件

```bash
# 确认必需文件存在
ls -la telegram-app.html
ls -la telegram-drama-detail.html

# 应该看到两个HTML文件
```

---

## 🚀 测试步骤

### 步骤1: 启动本地服务器

```bash
# 在项目根目录运行
http-server . -p 8080 -c-1

# 应该看到类似输出：
# Starting up http-server, serving .
# Available on:
#   http://127.0.0.1:8080
#   http://192.168.x.x:8080
# Hit CTRL-C to stop the server
```

**注意事项**：
- `-p 8080` 指定端口为8080
- `-c-1` 禁用缓存（方便开发调试）
- 保持此终端窗口运行，不要关闭

---

## 🧪 测试用例

### 测试组1: 主页功能（telegram-app.html）

#### 测试1.1: 页面加载

**操作**：
```
浏览器访问: http://localhost:8080/telegram-app.html
```

**预期结果**：
- [x] 页面成功加载，无空白屏
- [x] 显示SUK短剧平台Logo
- [x] 显示用户信息卡片

**验证方法**：
1. 打开Chrome DevTools（F12）
2. 切换到Console标签
3. 应该看到以下日志：
```
🚀 初始化Telegram Mini App
🔧 开发模式：使用模拟用户数据
🎨 已应用Telegram主题
🔘 主按钮已配置
🔧 开发模式：使用Mock数据
✅ Mock数据加载成功: 8
✅ Telegram Mini App 已就绪
🌍 环境: 开发模式
🔗 API地址: 相对路径
```

**截图位置**：`tests/screenshots/01-homepage-load.png`

---

#### 测试1.2: 用户信息显示

**验证内容**：
- [x] 显示用户头像（圆形）
- [x] 显示用户名：张三 开发者
- [x] 显示用户名：@dev_zhangsan
- [x] 显示Premium标识：⭐ Premium

**操作**：
```
查看页面顶部用户卡片区域
```

**预期效果**：
```
┌─────────────────────────────────┐
│ 👤 张三 开发者    ⭐ Premium   │
│    @dev_zhangsan                │
└─────────────────────────────────┘
```

**截图位置**：`tests/screenshots/02-user-info.png`

---

#### 测试1.3: 分类筛选功能

**操作步骤**：
1. 点击 "全部" - 应显示8部短剧
2. 点击 "爱情" - 应显示3部短剧（霸总的替身娇妻、闪婚后大佬、我的冰山女总裁）
3. 点击 "玄幻" - 应显示2部短剧（修仙界的社畜日常、玄幻开局签到混沌体）
4. 点击 "剧情" - 应显示1部短剧（重生之我在八零年代当首富）
5. 点击 "喜剧" - 应显示1部短剧（搞笑一家人）
6. 点击 "动作" - 应显示1部短剧（都市神医归来）

**预期结果**：
- [x] 点击分类按钮后，该按钮变为蓝色高亮
- [x] 短剧列表根据分类过滤
- [x] 短剧数量正确
- [x] 有轻微的触觉反馈感（如果是触摸设备）

**Console日志**：
```javascript
// 每次点击应该看到：
📺 打开短剧: drama-xxx
```

**截图位置**：
- `tests/screenshots/03-category-all.png`
- `tests/screenshots/03-category-romance.png`
- `tests/screenshots/03-category-fantasy.png`

---

#### 测试1.4: 短剧卡片显示

**验证每个短剧卡片包含**：
- [x] 封面图片（9:16竖屏比例）
- [x] 标题
- [x] 评分（⭐ 4.5-4.9）
- [x] 播放量（格式化显示，如1.2M、987.6K）
- [x] 价格（💰 99 SUK 或 🎁 免费观看）
- [x] 支付选项（⭐ Stars、💎 TON）
- [x] 标签（免费/热门）

**测试数据验证**：

**短剧1: 霸总的替身娇妻**
- 封面：✓ 显示图片
- 标题：霸总的替身娇妻
- 评分：⭐ 4.8
- 播放量：👁️ 1.2M
- 价格：💰 99 SUK
- 标签：🔥 热门
- 支付选项：⭐ 150 Stars, 💎 0.5 TON

**短剧2: 重生之我在八零年代当首富**
- 封面：✓ 显示图片
- 标题：重生之我在八零年代当首富
- 评分：⭐ 4.9
- 播放量：👁️ 987.6K
- 价格：🎁 免费观看
- 标签：✓ 免费, 🔥 热门

**截图位置**：`tests/screenshots/04-drama-cards.png`

---

#### 测试1.5: 响应式布局

**测试不同屏幕尺寸**：

```javascript
// 打开Chrome DevTools -> Toggle Device Toolbar (Ctrl+Shift+M)
// 测试以下尺寸：
```

1. **iPhone SE (375x667)**
   - [x] 2列网格布局
   - [x] 卡片尺寸适中
   - [x] 文字清晰可读

2. **iPhone 12 (390x844)**
   - [x] 2列网格布局
   - [x] 用户卡片适配良好

3. **iPad (768x1024)**
   - [x] 3列网格布局
   - [x] 分类按钮排列美观

4. **Desktop (1920x1080)**
   - [x] 4列网格布局
   - [x] 整体布局居中

**截图位置**：
- `tests/screenshots/05-responsive-mobile.png`
- `tests/screenshots/05-responsive-tablet.png`
- `tests/screenshots/05-responsive-desktop.png`

---

#### 测试1.6: 主按钮功能

**操作**：
```
滚动到页面底部，或在Telegram环境中查看底部主按钮
（本地测试环境可能不显示主按钮，这是正常的）
```

**预期**：
- 按钮文字：💰 充值SUK代币
- 按钮颜色：红色（#FF6B6B）
- 点击后显示弹窗提示

---

### 测试组2: 详情页功能（telegram-drama-detail.html）

#### 测试2.1: 从主页跳转到详情页

**操作步骤**：
1. 在主页点击第一个短剧卡片（霸总的替身娇妻）
2. 页面应该跳转到详情页

**预期结果**：
- [x] 页面URL变为：`http://localhost:8080/telegram-drama-detail.html?id=drama-001`
- [x] 详情页成功加载

**Console日志**：
```
📺 打开短剧: drama-001
🚀 初始化短剧详情页
🔧 开发模式：使用Mock数据
✅ 短剧详情加载完成
```

**截图位置**：`tests/screenshots/06-detail-load.png`

---

#### 测试2.2: 封面区域显示

**验证内容**：
- [x] 全屏封面图片
- [x] 渐变遮罩效果
- [x] 返回按钮（左上角 ←）
- [x] 标题：霸总的替身娇妻
- [x] 元信息：⭐ 4.8  👁️ 1.2M  📺 80集
- [x] 标签：🔥 热门, 💕 爱情

**操作**：
```
查看页面顶部封面区域
```

**截图位置**：`tests/screenshots/07-detail-cover.png`

---

#### 测试2.3: 支付选项卡（付费内容）

**操作步骤**：
1. 查看支付选项卡区域
2. 点击 "💎 SUK代币" 选项
3. 点击 "⭐ Telegram Stars" 选项
4. 点击 "💎 TON" 选项

**预期结果**：
- [x] 显示3个支付选项
- [x] 点击后该选项高亮（蓝色背景）
- [x] 其他选项恢复正常状态
- [x] Console显示：`💰 选择支付方式: suk/stars/ton, 金额`

**支付选项内容验证**：
```
┌─────────────────────────────────┐
│ 💰 选择支付方式                 │
├─────────────────────────────────┤
│ 💎 SUK代币         99 SUK      │
├─────────────────────────────────┤
│ ⭐ Telegram Stars  150 Stars   │
├─────────────────────────────────┤
│ 💎 TON             0.5 TON     │
└─────────────────────────────────┘
```

**截图位置**：
- `tests/screenshots/08-payment-options.png`
- `tests/screenshots/08-payment-selected.png`

---

#### 测试2.4: 剧情简介

**验证内容**：
- [x] 显示 "📖 剧情简介" 标题
- [x] 显示完整的多段落简介文字
- [x] 文字自动换行
- [x] 字体大小和行高适中，易读

**简介内容示例**（霸总的替身娇妻）：
```
她本是被豪门抛弃的养女，却意外成为霸总的契约妻子。
本以为这只是一场交易，没想到霸总对她日渐深情...

从相识到相知，从误会到理解，他们经历了无数的波折。
当真相一步步揭开，她才发现，原来从一开始，
霸总就已经爱上了她。

这是一个关于爱情、救赎与成长的故事，甜中带虐，虐后更甜！
```

**截图位置**：`tests/screenshots/09-description.png`

---

#### 测试2.5: 剧集列表（付费内容锁定逻辑）

**验证内容**：

**前3集（可点击）**：
- [x] 第1集 - 无🔒标识，可点击
- [x] 第2集 - 无🔒标识，可点击
- [x] 第3集 - 无🔒标识，可点击

**第4集及以后（锁定）**：
- [x] 第4-80集 - 显示🔒标识
- [x] 半透明显示（opacity: 0.5）
- [x] 点击后不播放，而是触发购买流程

**操作步骤**：
1. 点击 "第1集"
2. 应该弹窗显示：`即将播放《霸总的替身娇妻》第1集\n\n视频播放功能开发中...`
3. 点击 "第4集"（带🔒）
4. 应该触发购买流程（如果未选择支付方式，提示选择）

**剧集网格布局验证**：
- 手机端：4列
- 平板端：6列
- 桌面端：8列

**截图位置**：
- `tests/screenshots/10-episodes-free.png`
- `tests/screenshots/10-episodes-locked.png`

---

#### 测试2.6: 用户评论区

**验证内容（霸总的替身娇妻有3条评论）**：

**评论1**：
- [x] 用户名：小甜甜
- [x] 评分：⭐⭐⭐⭐⭐ (5星)
- [x] 时间：2天前
- [x] 内容：太好看了！霸总好帅，女主好美！剧情紧凑，强烈推荐！

**评论2**：
- [x] 用户名：追剧狂魔
- [x] 评分：⭐⭐⭐⭐⭐ (5星)
- [x] 时间：3天前
- [x] 内容：看了三遍，每次都被甜到！演员演技在线，制作精良！

**评论3**：
- [x] 用户名：剧迷小张
- [x] 评分：⭐⭐⭐⭐ (4星)
- [x] 时间：5天前
- [x] 内容：剧情不错，就是更新有点慢，希望能快点更新完！

**截图位置**：`tests/screenshots/11-comments.png`

---

#### 测试2.7: 底部操作栏

**验证内容（付费且未购买状态）**：
- [x] 显示2个按钮
- [x] 左侧：❤️ 收藏
- [x] 右侧：💰 购买观看
- [x] 按钮固定在页面底部

**操作测试**：

1. **点击 "❤️ 收藏" 按钮**
   - 预期：弹窗显示 "✅ 已添加到收藏夹"
   - Console：`❤️ 添加到收藏: 霸总的替身娇妻`

2. **未选择支付方式时点击 "💰 购买观看"**
   - 预期：弹窗显示 "请先选择支付方式"

3. **选择支付方式后点击 "💰 购买观看"**
   - 预期：跳转到支付页面
   - URL：`telegram-payment.html?dramaId=drama-001&method=suk&amount=99`

**截图位置**：
- `tests/screenshots/12-bottom-actions.png`
- `tests/screenshots/12-favorite-alert.png`

---

#### 测试2.8: 返回按钮

**操作**：
```
点击左上角的 ← 返回按钮
```

**预期结果**：
- [x] 页面返回到主页
- [x] 主页状态保持（选中的分类、滚动位置等）

**截图位置**：`tests/screenshots/13-back-button.png`

---

#### 测试2.9: 测试免费短剧（重生之我在八零年代当首富）

**操作步骤**：
1. 返回主页
2. 点击第二个短剧（重生之我在八零年代当首富）

**预期结果（免费短剧）**：
- [x] **不显示**支付选项卡
- [x] 显示绿色提示卡片：
  ```
  ✅
  已购买，可以观看全部剧集
  ```
- [x] 底部按钮显示：
  - 左侧：❤️ 收藏
  - 右侧：▶️ 开始观看
- [x] 所有剧集（1-60集）都**无🔒标识**，全部可点击

**截图位置**：
- `tests/screenshots/14-free-drama.png`
- `tests/screenshots/14-free-episodes.png`

---

### 测试组3: 边界情况和错误处理

#### 测试3.1: 图片加载失败

**操作**：
```javascript
// 在Chrome DevTools Console中运行：
document.querySelector('.drama-cover img').src = 'https://invalid-url.com/image.jpg';
```

**预期结果**：
- [x] 图片自动替换为placeholder
- [x] 显示短剧标题的文字placeholder

**截图位置**：`tests/screenshots/15-image-fallback.png`

---

#### 测试3.2: 无效短剧ID

**操作**：
```
浏览器访问: http://localhost:8080/telegram-drama-detail.html?id=invalid-id
```

**预期结果**：
- [x] 自动降级到 drama-001 数据
- [x] Console显示警告但不报错
- [x] 页面正常显示

**截图位置**：`tests/screenshots/16-invalid-id.png`

---

#### 测试3.3: 缺少短剧ID

**操作**：
```
浏览器访问: http://localhost:8080/telegram-drama-detail.html
```

**预期结果**：
- [x] 显示错误提示："未找到短剧信息"
- [x] 或自动降级到 drama-001

**截图位置**：`tests/screenshots/17-missing-id.png`

---

## 📊 测试结果汇总

### 自动测试清单

复制以下清单到文本编辑器，完成测试后在 `[ ]` 中填入 `x`：

```markdown
## 主页测试
- [ ] 1.1 页面加载成功
- [ ] 1.2 用户信息显示正确
- [ ] 1.3 分类筛选工作正常（测试所有6个分类）
- [ ] 1.4 短剧卡片显示完整（8部短剧）
- [ ] 1.5 响应式布局适配（手机/平板/桌面）
- [ ] 1.6 主按钮功能正常

## 详情页测试
- [ ] 2.1 从主页跳转成功
- [ ] 2.2 封面区域显示完整
- [ ] 2.3 支付选项可选择（3种支付方式）
- [ ] 2.4 剧情简介显示正确
- [ ] 2.5 剧集列表锁定逻辑正确（前3集免费）
- [ ] 2.6 用户评论显示正常（3条评论）
- [ ] 2.7 底部操作栏功能正常
- [ ] 2.8 返回按钮工作正常
- [ ] 2.9 免费短剧显示正确（无支付卡片）

## 边界情况测试
- [ ] 3.1 图片加载失败有fallback
- [ ] 3.2 无效ID有处理
- [ ] 3.3 缺少ID有提示

## Console检查
- [ ] 无红色错误信息
- [ ] 显示完整的调试日志
- [ ] 日志格式规范（emoji + 中文）
```

---

## 🔍 问题排查

### 问题1: 页面显示空白

**可能原因**：
- HTTP服务器未启动
- 端口被占用
- 浏览器缓存问题

**解决方案**：
```bash
# 1. 检查服务器是否运行
lsof -i :8080

# 2. 强制清除浏览器缓存
# Chrome: Ctrl+Shift+Delete
# 或在DevTools中右键刷新按钮 -> "清空缓存并硬性重新加载"

# 3. 更换端口
http-server . -p 8888 -c-1
```

---

### 问题2: 短剧数据未显示

**检查步骤**：
1. 打开Console，查看是否有JavaScript错误
2. 检查是否显示 "✅ Mock数据加载成功: 8"
3. 检查Network面板，确认没有404错误

**常见原因**：
- JavaScript被浏览器拦截
- 文件路径错误

---

### 问题3: 图片不显示

**可能原因**：
- 网络连接问题（Mock数据使用Unsplash图片）
- 图片URL被防火墙拦截

**解决方案**：
- 检查网络连接
- 图片应该自动fallback到placeholder

---

## 📸 截图要求

### 截图工具
- **macOS**: Cmd+Shift+4
- **Windows**: Win+Shift+S
- **Chrome DevTools**: Ctrl+Shift+P -> "Capture full size screenshot"

### 截图命名规范
```
tests/screenshots/
  ├── 01-homepage-load.png
  ├── 02-user-info.png
  ├── 03-category-all.png
  ├── 03-category-romance.png
  ├── 04-drama-cards.png
  ├── 05-responsive-mobile.png
  ├── 05-responsive-tablet.png
  ├── 06-detail-load.png
  ├── 07-detail-cover.png
  ├── 08-payment-options.png
  ├── 08-payment-selected.png
  ├── 09-description.png
  ├── 10-episodes-free.png
  ├── 10-episodes-locked.png
  ├── 11-comments.png
  ├── 12-bottom-actions.png
  ├── 13-back-button.png
  ├── 14-free-drama.png
  ├── 15-image-fallback.png
  └── 16-invalid-id.png
```

---

## 📝 测试报告模板

```markdown
# Telegram Mini App 本地测试报告

**测试日期**: 2025-01-16
**测试人员**: [您的名字]
**测试环境**: 
- OS: macOS/Windows/Linux
- Browser: Chrome 120.x
- Screen: 1920x1080

## 测试结果总览
- ✅ 通过: X / Y
- ❌ 失败: 0
- ⚠️ 警告: 0

## 详细测试结果

### 主页测试
| 测试项 | 结果 | 备注 |
|--------|------|------|
| 1.1 页面加载 | ✅ | 加载时间<1秒 |
| 1.2 用户信息 | ✅ | 显示正确 |
| ... | ... | ... |

### 详情页测试
| 测试项 | 结果 | 备注 |
|--------|------|------|
| 2.1 页面跳转 | ✅ | 跳转流畅 |
| ... | ... | ... |

## 发现的问题
1. [如果有] 问题描述
2. ...

## 建议改进
1. [如果有] 改进建议
2. ...

## 测试截图
[附上关键截图]

## 结论
☑️ **测试通过，功能正常，可以进入下一阶段开发**
```

---

## 🎯 下一步行动

测试通过后：
1. ✅ 保存测试报告
2. ✅ 提交测试截图
3. ✅ 继续开发支付页面
4. ✅ 准备真机测试环境

---

**测试完成标志**: 所有测试项都勾选 ✅，Console无红色错误

**预计测试时间**: 30-45分钟

**祝测试顺利！** 🚀
