// ========================================
// SUK Protocol - Firebase Cloud Functions
// 服务器端逻辑和 Web3 集成
// ========================================

const functions = require('firebase-functions');
const admin = require('firebase-admin');
const { ethers } = require('ethers');

// 初始化 Firebase Admin
admin.initializeApp();

const db = admin.firestore();
const auth = admin.auth();

// ========================================
// Web3 钱包认证
// ========================================

/**
 * 验证钱包签名并创建自定义 Token
 * 用于 MetaMask 登录
 */
exports.verifyWalletAndCreateToken = functions
    .region('asia-east1')
    .https.onCall(async (data, context) => {
        const { walletAddress, signature, message } = data;

        try {
            // 1. 验证签名
            const recoveredAddress = ethers.utils.verifyMessage(message, signature);
            
            if (recoveredAddress.toLowerCase() !== walletAddress.toLowerCase()) {
                throw new functions.https.HttpsError(
                    'invalid-argument',
                    '钱包签名验证失败'
                );
            }

            console.log('✅ 钱包签名验证成功:', walletAddress);

            // 2. 查找或创建用户
            const email = `${walletAddress.toLowerCase()}@wallet.suk`;
            let user;

            try {
                // 尝试通过邮箱查找用户
                user = await auth.getUserByEmail(email);
                console.log('找到现有用户:', user.uid);

            } catch (error) {
                if (error.code === 'auth/user-not-found') {
                    // 创建新用户
                    user = await auth.createUser({
                        uid: walletAddress.toLowerCase(),
                        email: email,
                        emailVerified: true,
                        displayName: `User_${walletAddress.slice(0, 8)}`
                    });

                    // 创建用户档案
                    await db.collection('users').doc(user.uid).set({
                        uid: user.uid,
                        walletAddress: walletAddress,
                        username: `User_${walletAddress.slice(0, 8)}`,
                        email: email,
                        createdAt: admin.firestore.FieldValue.serverTimestamp(),
                        loginMethod: 'wallet',
                        role: 'user',
                        verified: true,
                        totalInvested: 0,
                        totalEarnings: 0
                    });

                    console.log('✅ 新用户创建成功:', user.uid);
                } else {
                    throw error;
                }
            }

            // 3. 更新最后登录时间
            await db.collection('users').doc(user.uid).update({
                lastLoginAt: admin.firestore.FieldValue.serverTimestamp(),
                walletAddress: walletAddress  // 更新钱包地址
            });

            // 4. 生成自定义 Token
            const customToken = await auth.createCustomToken(user.uid, {
                walletAddress: walletAddress
            });

            console.log('✅ 自定义 Token 生成成功');

            return {
                customToken: customToken,
                uid: user.uid
            };

        } catch (error) {
            console.error('❌ 钱包认证失败:', error);
            throw new functions.https.HttpsError(
                'internal',
                error.message || '钱包认证失败'
            );
        }
    });

// ========================================
// 区块链事件同步
// ========================================

/**
 * 同步区块链交易到 Firestore
 * 定时任务：每5分钟运行一次
 */
exports.syncBlockchainTransactions = functions
    .region('asia-east1')
    .pubsub.schedule('every 5 minutes')
    .onRun(async (context) => {
        try {
            console.log('开始同步区块链交易...');

            // 配置 Web3 Provider
            const provider = new ethers.providers.JsonRpcProvider(
                functions.config().blockchain.rpc_url || 'https://polygon-rpc.com'
            );

            // 获取合约实例
            const contractAddress = functions.config().blockchain.suk_token_address;
            if (!contractAddress) {
                console.warn('⚠️ 合约地址未配置');
                return null;
            }

            // 简单的 ERC20 ABI（实际使用完整 ABI）
            const contractABI = [
                'event Transfer(address indexed from, address indexed to, uint256 value)',
                'event TokenPurchased(address indexed buyer, uint256 amount, uint256 tokens)',
                'event RewardClaimed(address indexed user, uint256 amount)'
            ];

            const contract = new ethers.Contract(contractAddress, contractABI, provider);

            // 获取最后同步的区块号
            const syncDoc = await db.collection('system').doc('blockchain_sync').get();
            const lastBlock = syncDoc.exists ? syncDoc.data().lastBlock : 0;
            const currentBlock = await provider.getBlockNumber();

            console.log(`同步区块: ${lastBlock} -> ${currentBlock}`);

            // 查询事件（限制范围避免超时）
            const fromBlock = Math.max(lastBlock + 1, currentBlock - 1000);
            const toBlock = currentBlock;

            // 查询 TokenPurchased 事件
            const purchaseFilter = contract.filters.TokenPurchased();
            const purchaseEvents = await contract.queryFilter(purchaseFilter, fromBlock, toBlock);

            for (const event of purchaseEvents) {
                await syncPurchaseEvent(event);
            }

            // 查询 RewardClaimed 事件
            const rewardFilter = contract.filters.RewardClaimed();
            const rewardEvents = await contract.queryFilter(rewardFilter, fromBlock, toBlock);

            for (const event of rewardEvents) {
                await syncRewardEvent(event);
            }

            // 更新同步状态
            await db.collection('system').doc('blockchain_sync').set({
                lastBlock: currentBlock,
                lastSyncAt: admin.firestore.FieldValue.serverTimestamp()
            });

            console.log(`✅ 同步完成: ${purchaseEvents.length} 购买, ${rewardEvents.length} 领取`);

            return {
                synced: purchaseEvents.length + rewardEvents.length,
                lastBlock: currentBlock
            };

        } catch (error) {
            console.error('❌ 同步区块链交易失败:', error);
            return null;
        }
    });

// 同步购买事件
async function syncPurchaseEvent(event) {
    try {
        const txHash = event.transactionHash;
        const buyer = event.args.buyer.toLowerCase();
        const amount = ethers.utils.formatEther(event.args.amount);
        const tokens = ethers.utils.formatEther(event.args.tokens);

        // 检查是否已同步
        const existing = await db.collection('transactions')
            .where('txHash', '==', txHash)
            .get();

        if (!existing.empty) {
            console.log('交易已存在:', txHash);
            return;
        }

        // 添加交易记录
        await db.collection('transactions').add({
            txHash: txHash,
            type: 'buy',
            from: buyer,
            amount: parseFloat(amount),
            tokens: parseFloat(tokens),
            blockNumber: event.blockNumber,
            timestamp: (await event.getBlock()).timestamp * 1000,
            status: 'success',
            syncedAt: admin.firestore.FieldValue.serverTimestamp()
        });

        // 查找用户（通过钱包地址）
        const userQuery = await db.collection('users')
            .where('walletAddress', '==', buyer)
            .limit(1)
            .get();

        if (!userQuery.empty) {
            const userId = userQuery.docs[0].id;
            
            // 更新用户投资记录
            await db.collection('investments').add({
                userId: userId,
                dramaId: event.args.dramaId || 'unknown',
                amount: parseFloat(amount),
                tokens: parseFloat(tokens),
                txHash: txHash,
                createdAt: admin.firestore.FieldValue.serverTimestamp()
            });
        }

        console.log('✅ 购买事件已同步:', txHash);

    } catch (error) {
        console.error('同步购买事件失败:', error);
    }
}

// 同步领取收益事件
async function syncRewardEvent(event) {
    try {
        const txHash = event.transactionHash;
        const user = event.args.user.toLowerCase();
        const amount = ethers.utils.formatEther(event.args.amount);

        // 检查是否已同步
        const existing = await db.collection('transactions')
            .where('txHash', '==', txHash)
            .get();

        if (!existing.empty) {
            return;
        }

        // 添加交易记录
        await db.collection('transactions').add({
            txHash: txHash,
            type: 'reward',
            from: user,
            amount: parseFloat(amount),
            blockNumber: event.blockNumber,
            timestamp: (await event.getBlock()).timestamp * 1000,
            status: 'success',
            syncedAt: admin.firestore.FieldValue.serverTimestamp()
        });

        console.log('✅ 领取收益事件已同步:', txHash);

    } catch (error) {
        console.error('同步领取收益事件失败:', error);
    }
}

// ========================================
// 数据触发器
// ========================================

/**
 * 用户创建时的后续操作
 */
exports.onUserCreated = functions
    .region('asia-east1')
    .auth.user().onCreate(async (user) => {
        try {
            console.log('新用户创建:', user.uid);

            // 创建欢迎通知
            await db.collection('notifications').add({
                userId: user.uid,
                type: 'welcome',
                title: '欢迎来到 SUK Protocol！',
                message: '感谢您的加入，开始探索竖屏短剧版权投资吧！',
                read: false,
                createdAt: admin.firestore.FieldValue.serverTimestamp()
            });

            console.log('✅ 欢迎通知已发送');

        } catch (error) {
            console.error('用户创建后续操作失败:', error);
        }
    });

/**
 * 投资记录创建时更新统计
 */
exports.onInvestmentCreated = functions
    .region('asia-east1')
    .firestore.document('investments/{investmentId}')
    .onCreate(async (snap, context) => {
        try {
            const investment = snap.data();
            const userId = investment.userId;
            const dramaId = investment.dramaId;

            // 更新用户统计
            await db.collection('users').doc(userId).update({
                totalInvested: admin.firestore.FieldValue.increment(investment.amount)
            });

            // 更新短剧统计
            if (dramaId) {
                await db.collection('dramas').doc(dramaId).update({
                    investors: admin.firestore.FieldValue.increment(1),
                    tvl: admin.firestore.FieldValue.increment(investment.amount)
                });
            }

            console.log('✅ 投资统计已更新');

        } catch (error) {
            console.error('更新投资统计失败:', error);
        }
    });

// ========================================
// HTTP 端点
// ========================================

/**
 * 获取短剧统计数据
 */
exports.getDramaStats = functions
    .region('asia-east1')
    .https.onRequest(async (req, res) => {
        // 设置 CORS
        res.set('Access-Control-Allow-Origin', '*');
        
        if (req.method === 'OPTIONS') {
            res.set('Access-Control-Allow-Methods', 'GET');
            res.set('Access-Control-Allow-Headers', 'Content-Type');
            res.status(204).send('');
            return;
        }

        try {
            const dramaId = req.query.dramaId;
            
            if (!dramaId) {
                res.status(400).json({ error: '缺少 dramaId 参数' });
                return;
            }

            // 获取短剧基本信息
            const dramaDoc = await db.collection('dramas').doc(dramaId).get();
            
            if (!dramaDoc.exists) {
                res.status(404).json({ error: '短剧不存在' });
                return;
            }

            const drama = dramaDoc.data();

            // 获取投资者数量
            const investmentsSnapshot = await db.collection('investments')
                .where('dramaId', '==', dramaId)
                .get();

            // 获取总收益
            const revenuesSnapshot = await db.collection('revenues')
                .where('dramaId', '==', dramaId)
                .get();

            let totalRevenue = 0;
            revenuesSnapshot.forEach(doc => {
                totalRevenue += doc.data().amount || 0;
            });

            res.json({
                dramaId: dramaId,
                title: drama.title,
                investors: investmentsSnapshot.size,
                tvl: drama.tvl || 0,
                totalRevenue: totalRevenue,
                apy: drama.apy || 0
            });

        } catch (error) {
            console.error('获取统计失败:', error);
            res.status(500).json({ error: '服务器错误' });
        }
    });

/**
 * 发送推送通知
 */
exports.sendPushNotification = functions
    .region('asia-east1')
    .https.onCall(async (data, context) => {
        // 验证用户登录
        if (!context.auth) {
            throw new functions.https.HttpsError(
                'unauthenticated',
                '用户未登录'
            );
        }

        const { userId, title, body, data: notificationData } = data;

        try {
            // 获取用户的 FCM Token
            const userDoc = await db.collection('users').doc(userId).get();
            
            if (!userDoc.exists) {
                throw new functions.https.HttpsError(
                    'not-found',
                    '用户不存在'
                );
            }

            const fcmToken = userDoc.data().fcmToken;
            
            if (!fcmToken) {
                console.warn('用户未设置 FCM Token');
                return { sent: false };
            }

            // 发送通知
            const message = {
                notification: {
                    title: title,
                    body: body
                },
                data: notificationData || {},
                token: fcmToken
            };

            const response = await admin.messaging().send(message);
            
            console.log('✅ 推送通知已发送:', response);

            return { sent: true, messageId: response };

        } catch (error) {
            console.error('❌ 发送推送通知失败:', error);
            throw new functions.https.HttpsError(
                'internal',
                '发送通知失败'
            );
        }
    });

console.log('🔥 Firebase Cloud Functions 已加载');
