# SUK 空投 V2.0 快速开始

## 🚀 5分钟快速部署

### 步骤 1: 部署合约（2分钟）

```bash
# 编译
npx hardhat compile

# 部署 AirdropV2
npx hardhat run scripts/deploy-airdrop-v2.js --network goerli

# 记录输出的合约地址
# AirdropV2: 0x...
```

### 步骤 2: 转账（1分钟）

```bash
# 转账 5000万 SUK 到空投合约
npx hardhat run scripts/fund-airdrop-v2.js --network goerli
```

### 步骤 3: 生成邀请码（2分钟）

```bash
# 生成 1000 个邀请码并部署
node scripts/generate-invite-codes.js 1000 --network goerli --deploy
```

✅ **完成！空投系统已就绪。**

---

## 📋 快速命令

### 部署命令

```bash
# 完整部署流程（一键执行）
npx hardhat compile && \
npx hardhat run scripts/deploy-airdrop-v2.js --network goerli && \
npx hardhat run scripts/fund-airdrop-v2.js --network goerli && \
node scripts/generate-invite-codes.js 1000 --network goerli --deploy
```

### 邀请码管理

```bash
# 生成邀请码（仅保存文件）
node scripts/generate-invite-codes.js 1000

# 生成并部署
node scripts/generate-invite-codes.js 1000 --network goerli --deploy

# 生成大量邀请码
node scripts/generate-invite-codes.js 10000 --network goerli --deploy
```

### 验证合约

```bash
# 在 Etherscan 上验证
npx hardhat verify --network goerli <AIRDROP_ADDRESS> "<TOKEN_ADDRESS>" <START_TIME> <END_TIME>
```

### 更新前端

```bash
# 更新前端配置
node scripts/update-frontend-config.js goerli <TOKEN_ADDRESS> <AIRDROP_ADDRESS>
```

---

## 🎫 邀请码使用

### 用户端（获取空投）

1. **方式一：邀请码激活**（5,000 SUK）
```
1. 访问: http://localhost:8000/suk-airdrop-v2.html
2. 连接 MetaMask
3. 输入邀请码（例如：ABC123XYZ789）
4. 点击"激活邀请码"
5. 点击"领取 5,000 SUK"
```

2. **方式二：推荐购买**（1,000 SUK）
```
1. 通过推荐链接访问
2. 连接 MetaMask
3. 完成投资
4. 自动获得 1,000 SUK
```

### 管理端（管理邀请码）

```
1. 访问: http://localhost:8000/admin-invite-codes.html
2. 连接管理员钱包
3. 点击"生成邀请码"
4. 导出 CSV 文件
5. 分发给用户
```

---

## 📊 关键参数

```javascript
{
  totalAirdrop: "50,000,000 SUK",      // 5000万总量
  whitelistAmount: "5,000 SUK",        // 邀请码激活奖励
  referralAmount: "1,000 SUK",         // 推荐购买奖励
  inviteCodeLength: 12,                // 邀请码长度
  inviteCodeValidity: "90 days",       // 有效期3个月
  batchSize: 50                        // 批量部署每批数量
}
```

---

## 🔧 故障排查

### 问题：邀请码无效
```bash
# 检查邀请码状态
# 在合约中调用: getInviteCodeInfo("ABC123XYZ789")
```

### 问题：部署失败
```bash
# 检查余额
# 确认有足够的 ETH 支付 Gas
# 查看错误日志
```

### 问题：前端连接失败
```bash
# 检查网络配置
# 确认 MetaMask 在正确的网络
# 清除浏览器缓存
```

---

## 📞 快速链接

- 🎁 [用户空投页面](suk-airdrop-v2.html)
- 🔧 [管理后台](admin-invite-codes.html)
- 📖 [完整升级指南](AIRDROP_V2_UPGRADE_GUIDE.md)
- 📝 [完成总结](AIRDROP_V2_COMPLETE_SUMMARY.md)

---

## ⚡ 快速测试

```bash
# 1. 启动本地服务器
python -m http.server 8000

# 2. 浏览器打开
http://localhost:8000/suk-airdrop-v2.html

# 3. 连接钱包并测试
# - 输入邀请码
# - 激活并领取
```

---

**一切就绪！开始使用 SUK 空投 V2.0 系统吧！** 🎉
