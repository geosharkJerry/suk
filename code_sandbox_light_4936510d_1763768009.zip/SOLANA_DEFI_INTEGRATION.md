# SUK LINK Solana DeFi 集成指南

> 💎 基于 Solana 公链的 SUK 代币认购和交易平台

---

## 📋 目录

- [平台概述](#平台概述)
- [技术架构](#技术架构)
- [智能合约](#智能合约)
- [前端集成](#前端集成)
- [钱包支持](#钱包支持)
- [交易流程](#交易流程)
- [API接口](#api接口)
- [部署指南](#部署指南)

---

## 🎯 平台概述

### APP.SUK.LINK

**访问地址**: [https://app.suk.link](https://app.suk.link)

SUK LINK 基于 **Solana 公链**构建的去中心化金融(DeFi)平台，提供快速、低成本的 SUK 代币认购和交易服务。

### 核心特性

#### 🚀 Solana 公链优势

- **超高性能** - 65,000+ TPS 交易处理能力
- **超低手续费** - 平均交易费用 < $0.00025
- **秒级确认** - 400ms 区块时间
- **环保节能** - PoS 共识机制

#### 💵 DAI 稳定币支付

- **价格稳定** - 1 DAI ≈ 1 USD
- **全球通用** - 支持全球用户
- **即时结算** - 链上自动结算
- **透明可查** - 所有交易可验证

#### 🔗 多钱包支持

- Phantom
- Solflare
- Backpack
- Ledger
- Trust Wallet
- Coinbase Wallet
- Slope
- Glow

---

## 🏗️ 技术架构

### 系统架构图

```
┌─────────────────────────────────────────────────────┐
│              APP.SUK.LINK 架构                        │
└─────────────────────────────────────────────────────┘

┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│   前端应用    │  │  钱包连接层   │  │  Solana RPC  │
│  (Web/App)   │←→│ (Wallet API) │←→│   节点服务    │
└──────┬───────┘  └──────────────┘  └──────┬───────┘
       │                                     │
       └─────────────────┬───────────────────┘
                         │
              ┌──────────▼──────────┐
              │   Solana Program    │
              │   (Smart Contract)  │
              └──────────┬──────────┘
                         │
       ┌─────────────────┼─────────────────┐
       │                 │                 │
┌──────▼───────┐  ┌──────▼──────┐  ┌──────▼───────┐
│  SUK Token   │  │  DAI Token  │  │ Pool Account │
│   (SPL)      │  │   (SPL)     │  │  (资金池)     │
└──────────────┘  └─────────────┘  └──────────────┘
```

### 技术栈

| 层级 | 技术 | 用途 |
|------|------|------|
| **区块链** | Solana | 主链 |
| **智能合约** | Rust + Anchor | 链上程序 |
| **代币标准** | SPL Token | SUK 和 DAI |
| **前端** | HTML5 + JavaScript | 用户界面 |
| **钱包SDK** | @solana/web3.js | 区块链交互 |
| **钱包适配器** | @solana/wallet-adapter | 多钱包支持 |

---

## 📜 智能合约

### Solana Program 架构

#### 1. 程序结构

```rust
// lib.rs - 主程序文件
use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer, Mint};

declare_id!("SUKDeF1P1atf0rmS0lana1nk1234567890abcdefg");

#[program]
pub mod suk_defi {
    use super::*;
    
    // 初始化程序
    pub fn initialize(
        ctx: Context<Initialize>,
        price_per_suk: u64,
    ) -> Result<()> {
        let pool_config = &mut ctx.accounts.pool_config;
        pool_config.authority = ctx.accounts.authority.key();
        pool_config.suk_mint = ctx.accounts.suk_mint.key();
        pool_config.dai_mint = ctx.accounts.dai_mint.key();
        pool_config.price_per_suk = price_per_suk;
        pool_config.total_sold = 0;
        pool_config.bump = *ctx.bumps.get("pool_config").unwrap();
        
        msg!("SUK DeFi Pool Initialized");
        msg!("Price per SUK: {} lamports", price_per_suk);
        
        Ok(())
    }
    
    // 购买 SUK 代币
    pub fn purchase_suk(
        ctx: Context<PurchaseSUK>,
        suk_amount: u64,
    ) -> Result<()> {
        let pool_config = &mut ctx.accounts.pool_config;
        
        // 计算需要支付的 DAI
        let dai_amount = suk_amount
            .checked_mul(pool_config.price_per_suk)
            .ok_or(ErrorCode::Overflow)?
            .checked_div(1_000_000_000) // 9 decimals
            .ok_or(ErrorCode::Overflow)?;
        
        require!(dai_amount > 0, ErrorCode::InvalidAmount);
        
        // 从用户转 DAI 到池子
        let cpi_accounts_dai = Transfer {
            from: ctx.accounts.user_dai_account.to_account_info(),
            to: ctx.accounts.pool_dai_account.to_account_info(),
            authority: ctx.accounts.user.to_account_info(),
        };
        let cpi_program_dai = ctx.accounts.token_program.to_account_info();
        let cpi_ctx_dai = CpiContext::new(cpi_program_dai, cpi_accounts_dai);
        token::transfer(cpi_ctx_dai, dai_amount)?;
        
        // 从池子转 SUK 到用户
        let seeds = &[
            b"pool_config".as_ref(),
            &[pool_config.bump],
        ];
        let signer = &[&seeds[..]];
        
        let cpi_accounts_suk = Transfer {
            from: ctx.accounts.pool_suk_account.to_account_info(),
            to: ctx.accounts.user_suk_account.to_account_info(),
            authority: pool_config.to_account_info(),
        };
        let cpi_program_suk = ctx.accounts.token_program.to_account_info();
        let cpi_ctx_suk = CpiContext::new_with_signer(
            cpi_program_suk,
            cpi_accounts_suk,
            signer
        );
        token::transfer(cpi_ctx_suk, suk_amount)?;
        
        // 更新统计
        pool_config.total_sold = pool_config.total_sold
            .checked_add(suk_amount)
            .ok_or(ErrorCode::Overflow)?;
        
        // 发出事件
        emit!(PurchaseEvent {
            buyer: ctx.accounts.user.key(),
            suk_amount,
            dai_amount,
            timestamp: Clock::get()?.unix_timestamp,
        });
        
        msg!("Purchase completed: {} SUK for {} DAI", suk_amount, dai_amount);
        
        Ok(())
    }
    
    // 更新价格（仅管理员）
    pub fn update_price(
        ctx: Context<UpdatePrice>,
        new_price: u64,
    ) -> Result<()> {
        let pool_config = &mut ctx.accounts.pool_config;
        
        require!(
            ctx.accounts.authority.key() == pool_config.authority,
            ErrorCode::Unauthorized
        );
        
        let old_price = pool_config.price_per_suk;
        pool_config.price_per_suk = new_price;
        
        emit!(PriceUpdateEvent {
            old_price,
            new_price,
            timestamp: Clock::get()?.unix_timestamp,
        });
        
        msg!("Price updated from {} to {}", old_price, new_price);
        
        Ok(())
    }
    
    // 提取资金（仅管理员）
    pub fn withdraw(
        ctx: Context<Withdraw>,
        amount: u64,
    ) -> Result<()> {
        let pool_config = &ctx.accounts.pool_config;
        
        require!(
            ctx.accounts.authority.key() == pool_config.authority,
            ErrorCode::Unauthorized
        );
        
        let seeds = &[
            b"pool_config".as_ref(),
            &[pool_config.bump],
        ];
        let signer = &[&seeds[..]];
        
        let cpi_accounts = Transfer {
            from: ctx.accounts.pool_dai_account.to_account_info(),
            to: ctx.accounts.authority_dai_account.to_account_info(),
            authority: pool_config.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new_with_signer(
            cpi_program,
            cpi_accounts,
            signer
        );
        token::transfer(cpi_ctx, amount)?;
        
        msg!("Withdrawn {} DAI", amount);
        
        Ok(())
    }
}

// ========== 账户结构 ==========

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(
        init,
        payer = authority,
        space = 8 + 32 + 32 + 32 + 8 + 8 + 1,
        seeds = [b"pool_config"],
        bump
    )]
    pub pool_config: Account<'info, PoolConfig>,
    
    pub suk_mint: Account<'info, Mint>,
    pub dai_mint: Account<'info, Mint>,
    
    #[account(mut)]
    pub authority: Signer<'info>,
    
    pub system_program: Program<'info, System>,
    pub token_program: Program<'info, Token>,
    pub rent: Sysvar<'info, Rent>,
}

#[derive(Accounts)]
pub struct PurchaseSUK<'info> {
    #[account(
        mut,
        seeds = [b"pool_config"],
        bump = pool_config.bump
    )]
    pub pool_config: Account<'info, PoolConfig>,
    
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(mut)]
    pub user_dai_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub user_suk_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub pool_dai_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub pool_suk_account: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct UpdatePrice<'info> {
    #[account(
        mut,
        seeds = [b"pool_config"],
        bump = pool_config.bump
    )]
    pub pool_config: Account<'info, PoolConfig>,
    
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct Withdraw<'info> {
    #[account(
        seeds = [b"pool_config"],
        bump = pool_config.bump
    )]
    pub pool_config: Account<'info, PoolConfig>,
    
    #[account(mut)]
    pub pool_dai_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub authority_dai_account: Account<'info, TokenAccount>,
    
    pub authority: Signer<'info>,
    pub token_program: Program<'info, Token>,
}

// ========== 数据结构 ==========

#[account]
pub struct PoolConfig {
    pub authority: Pubkey,
    pub suk_mint: Pubkey,
    pub dai_mint: Pubkey,
    pub price_per_suk: u64,
    pub total_sold: u64,
    pub bump: u8,
}

// ========== 事件 ==========

#[event]
pub struct PurchaseEvent {
    pub buyer: Pubkey,
    pub suk_amount: u64,
    pub dai_amount: u64,
    pub timestamp: i64,
}

#[event]
pub struct PriceUpdateEvent {
    pub old_price: u64,
    pub new_price: u64,
    pub timestamp: i64,
}

// ========== 错误码 ==========

#[error_code]
pub enum ErrorCode {
    #[msg("Overflow in calculation")]
    Overflow,
    
    #[msg("Invalid amount")]
    InvalidAmount,
    
    #[msg("Unauthorized")]
    Unauthorized,
}
```

#### 2. 部署配置

```toml
# Anchor.toml
[features]
seeds = false
skip-lint = false

[programs.mainnet]
suk_defi = "SUKDeF1P1atf0rmS0lana1nk1234567890abcdefg"

[registry]
url = "https://api.apr.dev"

[provider]
cluster = "mainnet"
wallet = "~/.config/solana/id.json"

[scripts]
test = "yarn run ts-mocha -p ./tsconfig.json -t 1000000 tests/**/*.ts"
```

---

## 💻 前端集成

### 1. 安装依赖

```bash
npm install @solana/web3.js @solana/wallet-adapter-react \
  @solana/wallet-adapter-react-ui @solana/wallet-adapter-wallets \
  @solana/spl-token @project-serum/anchor
```

### 2. 钱包适配器配置

```typescript
import { useMemo } from 'react';
import { ConnectionProvider, WalletProvider } from '@solana/wallet-adapter-react';
import { WalletAdapterNetwork } from '@solana/wallet-adapter-base';
import {
    PhantomWalletAdapter,
    SolflareWalletAdapter,
    BackpackWalletAdapter,
} from '@solana/wallet-adapter-wallets';
import { WalletModalProvider } from '@solana/wallet-adapter-react-ui';
import { clusterApiUrl } from '@solana/web3.js';

// 样式
import '@solana/wallet-adapter-react-ui/styles.css';

function App() {
    // 网络配置
    const network = WalletAdapterNetwork.Mainnet;
    const endpoint = useMemo(() => clusterApiUrl(network), [network]);
    
    // 支持的钱包
    const wallets = useMemo(
        () => [
            new PhantomWalletAdapter(),
            new SolflareWalletAdapter(),
            new BackpackWalletAdapter(),
        ],
        []
    );
    
    return (
        <ConnectionProvider endpoint={endpoint}>
            <WalletProvider wallets={wallets} autoConnect>
                <WalletModalProvider>
                    <YourApp />
                </WalletModalProvider>
            </WalletProvider>
        </ConnectionProvider>
    );
}
```

### 3. 购买功能实现

```typescript
import { useConnection, useWallet } from '@solana/wallet-adapter-react';
import { PublicKey, Transaction } from '@solana/web3.js';
import { Program, AnchorProvider, web3 } from '@project-serum/anchor';
import { getAssociatedTokenAddress, createAssociatedTokenAccountInstruction } from '@solana/spl-token';

// SUK DeFi Program IDL
import idl from './idl/suk_defi.json';

const PROGRAM_ID = new PublicKey('SUKDeF1P1atf0rmS0lana1nk1234567890abcdefg');
const SUK_MINT = new PublicKey('YOUR_SUK_MINT_ADDRESS');
const DAI_MINT = new PublicKey('EjmyN6qEC1Tf1JxiG1ae7UTJhUxSwk1TCWNWqxWV4J6o');

export function usePurchaseSUK() {
    const { connection } = useConnection();
    const wallet = useWallet();
    
    const purchaseSUK = async (sukAmount: number) => {
        if (!wallet.publicKey) {
            throw new Error('钱包未连接');
        }
        
        // 创建 Provider
        const provider = new AnchorProvider(
            connection,
            wallet as any,
            { commitment: 'confirmed' }
        );
        
        // 创建 Program
        const program = new Program(idl as any, PROGRAM_ID, provider);
        
        // 获取用户代币账户
        const userDAIAccount = await getAssociatedTokenAddress(
            DAI_MINT,
            wallet.publicKey
        );
        
        const userSUKAccount = await getAssociatedTokenAddress(
            SUK_MINT,
            wallet.publicKey
        );
        
        // 获取池子配置
        const [poolConfig] = PublicKey.findProgramAddressSync(
            [Buffer.from('pool_config')],
            PROGRAM_ID
        );
        
        // 获取池子代币账户
        const poolDAIAccount = await getAssociatedTokenAddress(
            DAI_MINT,
            poolConfig,
            true
        );
        
        const poolSUKAccount = await getAssociatedTokenAddress(
            SUK_MINT,
            poolConfig,
            true
        );
        
        // 检查用户 SUK 账户是否存在
        const sukAccountInfo = await connection.getAccountInfo(userSUKAccount);
        
        const tx = new Transaction();
        
        // 如果 SUK 账户不存在，创建关联账户
        if (!sukAccountInfo) {
            tx.add(
                createAssociatedTokenAccountInstruction(
                    wallet.publicKey,
                    userSUKAccount,
                    wallet.publicKey,
                    SUK_MINT
                )
            );
        }
        
        // 调用购买指令
        const purchaseIx = await program.methods
            .purchaseSuk(new BN(sukAmount * 1e9)) // 转换为最小单位
            .accounts({
                poolConfig,
                user: wallet.publicKey,
                userDaiAccount: userDAIAccount,
                userSukAccount: userSUKAccount,
                poolDaiAccount: poolDAIAccount,
                poolSukAccount: poolSUKAccount,
                tokenProgram: TOKEN_PROGRAM_ID,
            })
            .instruction();
        
        tx.add(purchaseIx);
        
        // 发送交易
        const signature = await wallet.sendTransaction(tx, connection);
        
        // 等待确认
        await connection.confirmTransaction(signature, 'confirmed');
        
        return signature;
    };
    
    return { purchaseSUK };
}
```

### 4. 查询余额

```typescript
export function useTokenBalance() {
    const { connection } = useConnection();
    const wallet = useWallet();
    
    const getBalance = async (mintAddress: PublicKey) => {
        if (!wallet.publicKey) return 0;
        
        try {
            const tokenAccount = await getAssociatedTokenAddress(
                mintAddress,
                wallet.publicKey
            );
            
            const account = await getAccount(connection, tokenAccount);
            return Number(account.amount) / 1e9; // 转换为可读格式
        } catch (error) {
            console.error('获取余额失败:', error);
            return 0;
        }
    };
    
    return { getBalance };
}
```

---

## 🔗 钱包支持

### 支持的钱包列表

| 钱包 | 类型 | 支持平台 | 官网 |
|------|------|---------|------|
| **Phantom** | 浏览器扩展/移动端 | Web/iOS/Android | [phantom.app](https://phantom.app) |
| **Solflare** | 浏览器扩展/移动端 | Web/iOS/Android | [solflare.com](https://solflare.com) |
| **Backpack** | 浏览器扩展 | Web | [backpack.app](https://backpack.app) |
| **Ledger** | 硬件钱包 | 硬件设备 | [ledger.com](https://ledger.com) |
| **Trust Wallet** | 移动端 | iOS/Android | [trustwallet.com](https://trustwallet.com) |
| **Coinbase Wallet** | 浏览器扩展/移动端 | Web/iOS/Android | [wallet.coinbase.com](https://wallet.coinbase.com) |
| **Slope** | 移动端 | iOS/Android | [slope.finance](https://slope.finance) |
| **Glow** | 浏览器扩展 | Web | [glow.app](https://glow.app) |

### 钱包检测

```javascript
// 检测已安装的钱包
function detectWallets() {
    const wallets = [];
    
    if (window.solana && window.solana.isPhantom) {
        wallets.push('Phantom');
    }
    
    if (window.solflare) {
        wallets.push('Solflare');
    }
    
    if (window.backpack) {
        wallets.push('Backpack');
    }
    
    return wallets;
}

// 使用示例
const installedWallets = detectWallets();
console.log('已安装的钱包:', installedWallets);
```

---

## 🔄 交易流程

### 完整购买流程

```
1. 用户访问 app.suk.link
   ↓
2. 点击"连接钱包"
   ↓
3. 选择钱包类型（Phantom/Solflare等）
   ↓
4. 授权连接
   ↓
5. 输入购买数量
   ↓
6. 系统计算需要的 DAI
   ↓
7. 点击"立即购买"
   ↓
8. 钱包弹出交易确认
   ↓
9. 用户确认交易
   ↓
10. 等待交易确认（约1秒）
   ↓
11. SUK 代币到账
   ↓
12. 更新余额显示
```

### 交易监听

```typescript
// 监听交易状态
async function monitorTransaction(signature: string) {
    const connection = new Connection(clusterApiUrl('mainnet-beta'));
    
    // 订阅交易状态
    const subscription = connection.onSignature(
        signature,
        (signatureResult) => {
            if (signatureResult.err) {
                console.error('交易失败:', signatureResult.err);
            } else {
                console.log('交易成功!');
            }
        },
        'confirmed'
    );
    
    // 等待确认
    const latestBlockhash = await connection.getLatestBlockhash();
    await connection.confirmTransaction({
        signature,
        blockhash: latestBlockhash.blockhash,
        lastValidBlockHeight: latestBlockhash.lastValidBlockHeight,
    });
    
    // 取消订阅
    connection.removeSignatureListener(subscription);
}
```

---

## 📡 API 接口

### 价格查询 API

```javascript
// GET /api/price
async function getSUKPrice() {
    const response = await fetch('https://api.suk.link/v1/price');
    const data = await response.json();
    
    /*
    返回数据:
    {
        "suk_dai_price": 0.01,
        "suk_usd_price": 0.01,
        "24h_volume": 125000,
        "market_cap": 10000000,
        "circulation": 500000000
    }
    */
    
    return data;
}
```

### 交易历史 API

```javascript
// GET /api/transactions/:wallet
async function getTransactionHistory(walletAddress) {
    const response = await fetch(
        `https://api.suk.link/v1/transactions/${walletAddress}`
    );
    const data = await response.json();
    
    /*
    返回数据:
    {
        "transactions": [
            {
                "signature": "...",
                "type": "purchase",
                "suk_amount": 1000,
                "dai_amount": 10,
                "timestamp": 1700000000,
                "status": "confirmed"
            }
        ]
    }
    */
    
    return data;
}
```

---

## 🚀 部署指南

### 1. 部署智能合约

```bash
# 安装 Anchor
cargo install --git https://github.com/coral-xyz/anchor avm --locked --force
avm install latest
avm use latest

# 构建程序
anchor build

# 部署到主网
anchor deploy --provider.cluster mainnet
```

### 2. 初始化程序

```bash
# 创建 SUK Token
spl-token create-token --decimals 9

# 创建 Token 账户
spl-token create-account <SUK_MINT>

# 铸造 SUK
spl-token mint <SUK_MINT> 1000000000

# 初始化 DeFi 程序
anchor run initialize
```

### 3. 部署前端

```bash
# 构建前端
npm run build

# 部署到 Vercel/Netlify
vercel --prod

# 或上传到服务器
rsync -avz dist/ user@server:/var/www/app.suk.link/
```

---

## 📚 相关资源

### 官方文档

- 🌐 [Solana 文档](https://docs.solana.com)
- 🔧 [Anchor 框架](https://www.anchor-lang.com)
- 💰 [SPL Token](https://spl.solana.com/token)
- 🔗 [Web3.js](https://solana-labs.github.io/solana-web3.js)

### 开发工具

- 🔍 [Solana Explorer](https://explorer.solana.com)
- 📊 [Solscan](https://solscan.io)
- 🦎 [Gecko Terminal](https://www.geckoterminal.com)
- 📈 [Birdeye](https://birdeye.so)

### 社区支持

- 💬 [Solana Discord](https://discord.gg/solana)
- 🐦 [Solana Twitter](https://twitter.com/solana)
- 📺 [Solana YouTube](https://www.youtube.com/SolanaLabs)

---

**💎 SUK LINK - 基于 Solana 的高性能 DeFi 平台！**

*最后更新: 2024-11-18*
