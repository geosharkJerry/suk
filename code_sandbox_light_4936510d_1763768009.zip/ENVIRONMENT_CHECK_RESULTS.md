# 🔍 环境检查说明

## 如何运行环境检查

由于我们在静态网站构建环境中，无法直接执行系统命令。请在您的本地开发环境中运行以下命令：

### 方式1: Node.js 版本（推荐）✅

```bash
npm run test:quick
```

**优点**:
- ✅ 跨平台支持（Windows/macOS/Linux）
- ✅ 详细的彩色输出
- ✅ 自动检查 12 个关键项
- ✅ 智能建议和错误提示

### 方式2: Bash 版本（仅 Unix 系统）

```bash
chmod +x scripts/quick-test.sh
./scripts/quick-test.sh
```

**优点**:
- ✅ 原生 Shell 脚本
- ✅ 快速执行
- ✅ 适合 CI/CD 集成

---

## 📋 检查项目清单

环境检查脚本会验证以下 12 个关键项：

### 1. Node.js 版本 ✅
- **要求**: >= 18.0.0
- **检查**: `node -v`
- **安装**: https://nodejs.org/

### 2. npm 版本 ✅
- **要求**: >= 9.0.0
- **检查**: `npm -v`
- **说明**: 通常随 Node.js 一起安装

### 3. 项目依赖 📦
- **检查**: `node_modules/` 目录
- **关键依赖**:
  - express
  - mongoose
  - redis
  - dotenv
  - @alicloud/pop-core
- **修复**: `npm install`

### 4. 环境配置文件 ⚙️
- **文件**: `.env`
- **检查配置项**:
  - `TELEGRAM_BOT_TOKEN` - Telegram Bot 令牌
  - `MONGODB_URI` - MongoDB 连接字符串
  - `REDIS_HOST` - Redis 主机地址
  - `ALIYUN_ACCESS_KEY_ID` - 阿里云访问密钥
  - `JWT_SECRET` - JWT 签名密钥
- **修复**: `cp .env.example .env` 并编辑

### 5. MongoDB 数据库 🗄️
- **检查**: `mongod` 命令和进程
- **启动**:
  - macOS: `brew services start mongodb-community`
  - Linux: `sudo systemctl start mongod`
  - Windows: 启动 MongoDB 服务
- **测试**: `npm run test:db`

### 6. Redis 缓存 💾
- **检查**: `redis-server` 命令和进程
- **启动**:
  - macOS: `brew services start redis`
  - Linux: `sudo systemctl start redis`
  - Windows: 启动 Redis 服务
- **测试**: `redis-cli ping` 应返回 `PONG`

### 7. ngrok（HTTPS 隧道）🌐
- **用途**: Telegram Mini App 本地测试
- **要求**: 可选，仅本地测试需要
- **安装**:
  - macOS: `brew install ngrok/ngrok/ngrok`
  - Linux/Windows: https://ngrok.com/download
- **使用**: `ngrok http 3000`

### 8. 项目文件 📁
- **核心文件**:
  - ✅ `server.js` - 服务器主文件
  - ✅ `telegram-app.html` - Telegram Mini App
  - ✅ `package.json` - 项目配置
  - ✅ `backend/middleware/telegram-auth.middleware.js`
  - ✅ `backend/controllers/telegram.controller.js`
  - ✅ `backend/routes/telegram.routes.js`

### 9. 端口占用 🔌
- **默认端口**: 3000
- **检查**:
  - Unix: `lsof -i :3000`
  - Windows: `netstat -ano | findstr :3000`
- **释放**: `kill $(lsof -ti:3000)`

### 10. Git 版本控制 📝
- **检查**: `git --version`
- **仓库**: 检查是否初始化 Git
- **初始化**: `git init`

### 11. 项目文档 📖
- **核心文档**:
  - ✅ `README.md` - 项目总览
  - ✅ `TELEGRAM_QUICK_START.md` - 快速入门
  - ✅ `TESTING_GUIDE.md` - 测试指南
  - ✅ `TELEGRAM_MINI_APP_GUIDE.md` - 完整教程
  - ✅ `CURRENT_STATUS.md` - 项目状态

### 12. NPM 脚本 🚀
- **必需脚本**:
  - ✅ `npm start` - 启动服务器
  - ✅ `npm run dev` - 开发模式
  - ✅ `npm test` - 运行所有测试
  - ✅ `npm run test:quick` - 快速环境检查
  - ✅ `npm run test:env` - 环境变量测试
  - ✅ `npm run test:db` - 数据库测试
  - ✅ `npm run test:telegram` - Telegram Bot 测试

---

## 🎯 预期输出示例

### ✅ 完美配置（所有测试通过）

```
==================================================
  SUK 短剧平台 - Telegram Mini App 快速测试
==================================================
正在检查开发环境配置...

[1/12] 检查 Node.js...
✅ Node.js 已安装: v18.17.0
✅ Node.js 版本满足要求 (>= 18.0.0)

[2/12] 检查 npm...
✅ npm 已安装: v9.8.1

[3/12] 检查依赖...
✅ node_modules 目录存在
✅ 依赖已安装: express
✅ 依赖已安装: mongoose
✅ 依赖已安装: redis
✅ 依赖已安装: dotenv

[4/12] 检查 .env 文件...
✅ .env 文件存在
✅ TELEGRAM_BOT_TOKEN: 已配置
✅ MONGODB_URI: 已配置
✅ REDIS_HOST: 已配置
✅ ALIYUN_ACCESS_KEY_ID: 已配置
✅ JWT_SECRET: 已配置

[5/12] 检查 MongoDB...
✅ MongoDB 已安装
✅ MongoDB 进程正在运行

[6/12] 检查 Redis...
✅ Redis 已安装
✅ Redis 进程正在运行

[7/12] 检查 ngrok...
✅ ngrok 已安装: ngrok version 3.5.0

[8/12] 检查项目文件...
✅ 服务器主文件: server.js
✅ Telegram Mini App: telegram-app.html
✅ 项目配置: package.json
✅ Telegram认证中间件: backend/middleware/telegram-auth.middleware.js
✅ Telegram控制器: backend/controllers/telegram.controller.js
✅ Telegram路由: backend/routes/telegram.routes.js

[9/12] 检查端口占用...
✅ 端口 3000 可用

[10/12] 检查 Git...
✅ Git 已安装: git version 2.39.2
✅ 当前目录是 Git 仓库

[11/12] 检查文档...
✅ 文档存在: README.md
✅ 文档存在: TELEGRAM_QUICK_START.md
✅ 文档存在: TESTING_GUIDE.md
✅ 文档存在: TELEGRAM_MINI_APP_GUIDE.md
✅ 文档存在: CURRENT_STATUS.md

[12/12] 检查 package.json 脚本...
✅ 脚本已定义: npm run start
✅ 脚本已定义: npm run dev
✅ 脚本已定义: npm run test
✅ 脚本已定义: npm run test:env
✅ 脚本已定义: npm run test:db
✅ 脚本已定义: npm run test:telegram

==================================================
测试总结
==================================================
总计: 45
✅ 通过: 45
❌ 失败: 0
⚠️  警告: 0
==================================================

🎉 所有检查通过！环境配置完美！

下一步操作:
1. 启动服务器: npm run dev
2. 新终端启动 ngrok: ngrok http 3000
3. 配置 Telegram Bot (参考 TELEGRAM_QUICK_START.md)
4. 测试完整流程 (参考 TESTING_GUIDE.md)

📖 详细文档:
• 快速开始: TELEGRAM_QUICK_START.md
• 完整指南: TELEGRAM_MINI_APP_GUIDE.md
• 测试指南: TESTING_GUIDE.md
• 命令参考: QUICK_COMMANDS.md
```

---

## ⚠️ 常见问题和解决方案

### 问题 1: MongoDB 未运行

**症状**:
```
❌ MongoDB 进程未运行
```

**解决方案**:
```bash
# macOS
brew services start mongodb-community

# Linux
sudo systemctl start mongod

# 验证
mongosh --eval "db.adminCommand('ping')"
```

---

### 问题 2: Redis 未运行

**症状**:
```
❌ Redis 进程未运行
```

**解决方案**:
```bash
# macOS
brew services start redis

# Linux
sudo systemctl start redis

# 验证
redis-cli ping
```

---

### 问题 3: 依赖未安装

**症状**:
```
⚠️  node_modules 目录不存在
```

**解决方案**:
```bash
npm install
```

---

### 问题 4: .env 文件缺失

**症状**:
```
❌ .env 文件不存在
```

**解决方案**:
```bash
cp .env.example .env
nano .env  # 或使用您喜欢的编辑器
```

---

### 问题 5: 端口 3000 被占用

**症状**:
```
⚠️  端口 3000 已被占用
```

**解决方案**:
```bash
# 查找占用进程
lsof -i :3000

# 停止进程
kill $(lsof -ti:3000)

# 或在 .env 中修改端口
PORT=3001
```

---

### 问题 6: ngrok 未安装

**症状**:
```
⚠️  ngrok 未安装
```

**说明**: ngrok 仅用于本地测试 Telegram Mini App，不是必需的。

**安装方法**:
```bash
# macOS
brew install ngrok/ngrok/ngrok

# Windows (Chocolatey)
choco install ngrok

# 或手动下载
# https://ngrok.com/download
```

---

## 🚀 下一步

环境检查通过后，按以下顺序操作：

### 1️⃣ 启动服务器
```bash
# 开发模式（推荐）
npm run dev

# 或生产模式
npm start
```

### 2️⃣ 测试 API
```bash
# 新终端窗口
curl http://localhost:3000/health
curl http://localhost:3000/api/telegram/health
```

### 3️⃣ 启动 ngrok（用于 Telegram 测试）
```bash
# 新终端窗口
ngrok http 3000

# 记录 HTTPS URL（例如: https://abc123.ngrok.io）
```

### 4️⃣ 配置 Telegram Bot
参考文档: `TELEGRAM_QUICK_START.md`

1. 在 Telegram 找 @BotFather
2. 创建 Bot: `/newbot`
3. 配置菜单按钮: `/setmenubutton`
4. 输入 URL: `https://YOUR_NGROK_URL/telegram-app.html`

### 5️⃣ 测试完整流程
参考文档: `TESTING_GUIDE.md`

---

## 📞 获取帮助

如果遇到问题：

1. **查看完整测试指南**: `cat TESTING_GUIDE.md`
2. **查看快速命令**: `cat QUICK_COMMANDS.md`
3. **运行详细测试**: `npm test`
4. **查看服务器日志**: 检查终端输出

---

## ✅ 总结

运行环境检查可以帮助您：

- ✅ 验证所有必需的软件已安装
- ✅ 确认配置文件正确设置
- ✅ 检查服务是否正在运行
- ✅ 识别潜在问题
- ✅ 获得具体的修复建议

**现在就在您的本地环境运行**: `npm run test:quick`

---

**创建时间**: 2024-11-15  
**版本**: v1.1.0  
**适用于**: SUK 短剧平台 Telegram Mini App
