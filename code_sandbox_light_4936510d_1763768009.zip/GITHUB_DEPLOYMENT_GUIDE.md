# 🚀 SUK Protocol - GitHub + Cloudflare Pages 部署指南

> 将 SUK Protocol 部署到 GitHub 仓库并自动部署到 Cloudflare Pages 生产环境

**目标仓库**: https://github.com/geosharkJerry/suk

---

## 📋 部署流程概览

```
本地项目 → Git推送 → GitHub仓库 → Cloudflare Pages → 生产环境
```

**总耗时**: 约 10-15 分钟

---

## 🎯 第一步：准备 Git 仓库

### 1.1 检查 Git 状态

```bash
# 检查是否已初始化 Git
ls -la | grep .git

# 如果没有 .git 目录，初始化 Git
git init
```

### 1.2 配置 Git 用户信息

```bash
# 配置用户名和邮箱
git config user.name "Your Name"
git config user.email "your-email@example.com"

# 验证配置
git config --list
```

### 1.3 检查 .gitignore 文件

项目已包含 `.gitignore` 文件，确保以下内容已排除：

```gitignore
# 依赖
node_modules/
package-lock.json

# 环境变量
.env
.env.local
.env.development
.env.production

# 日志
*.log
npm-debug.log*

# 构建输出
dist/
build/

# 编辑器
.vscode/
.idea/
*.swp
*.swo

# 操作系统
.DS_Store
Thumbs.db

# 临时文件
*.tmp
*.bak
```

---

## 🎯 第二步：推送代码到 GitHub

### 2.1 添加远程仓库

```bash
# 添加 GitHub 远程仓库
git remote add origin https://github.com/geosharkJerry/suk.git

# 验证远程仓库
git remote -v
```

### 2.2 添加所有文件到 Git

```bash
# 查看当前状态
git status

# 添加所有文件
git add .

# 查看将要提交的文件
git status
```

### 2.3 提交代码

```bash
# 首次提交
git commit -m "🚀 Initial commit: SUK Protocol complete project

- ✅ 完整的前端界面（主页、Dashboard、Staking等）
- ✅ Cloudflare Pages 部署配置
- ✅ X402 协议实现
- ✅ Solana DeFi 集成
- ✅ 多语言支持（中英文）
- ✅ 奖励系统集成
- ✅ 邀请码系统
- ✅ 完整的文档"
```

### 2.4 推送到 GitHub

```bash
# 推送到 main 分支
git push -u origin main

# 如果仓库已有内容，可能需要强制推送（谨慎使用）
# git push -u origin main --force
```

如果遇到认证问题：

```bash
# 使用 GitHub Personal Access Token
# 1. 访问 https://github.com/settings/tokens
# 2. Generate new token (classic)
# 3. 勾选 repo 权限
# 4. 复制 token
# 5. 推送时使用 token 作为密码

# 或者配置 SSH key
ssh-keygen -t ed25519 -C "your-email@example.com"
cat ~/.ssh/id_ed25519.pub  # 复制公钥
# 添加到 GitHub: https://github.com/settings/keys
```

---

## 🎯 第三步：连接 Cloudflare Pages

### 3.1 登录 Cloudflare Dashboard

1. 访问：https://dash.cloudflare.com/
2. 登录您的 Cloudflare 账号
3. 选择左侧菜单 **"Workers & Pages"**

### 3.2 创建 Pages 项目

1. 点击右上角 **"Create application"** 按钮
2. 选择 **"Pages"** 标签
3. 点击 **"Connect to Git"** 按钮

### 3.3 连接 GitHub 仓库

1. 选择 **"GitHub"**
2. 点击 **"Connect GitHub"**（首次需要授权）
3. 授权 Cloudflare 访问您的 GitHub
4. 在仓库列表中找到 **`geosharkJerry/suk`**
5. 点击 **"Begin setup"**

### 3.4 配置构建设置

```
项目名称 (Project name): suk-protocol
生产分支 (Production branch): main
框架预设 (Framework preset): None
构建命令 (Build command): [留空]
构建输出目录 (Build output directory): .
根目录 (Root directory): [留空]
```

**关键配置说明**：
- ✅ **构建命令留空** - 这是纯静态网站，无需构建
- ✅ **输出目录为 `.`** - 部署整个根目录
- ✅ **框架预设为 None** - 不使用任何框架

### 3.5 高级设置（可选）

展开 **"Environment variables"**（如果需要）：

```
NODE_VERSION = 18
```

### 3.6 部署

1. 点击 **"Save and Deploy"** 按钮
2. 等待部署完成（约 1-2 分钟）
3. 部署成功后显示：
   ```
   ✅ Success! Your site is live at:
   https://suk-protocol.pages.dev
   ```

---

## 🎯 第四步：验证部署

### 4.1 访问生产环境

主域名：
- https://suk-protocol.pages.dev

### 4.2 测试核心功能

#### ✅ 基础页面测试
- [ ] 主页：https://suk-protocol.pages.dev/
- [ ] Dashboard：https://suk-protocol.pages.dev/dashboard.html
- [ ] FAQ：https://suk-protocol.pages.dev/faq.html
- [ ] 白皮书：https://suk-protocol.pages.dev/whitepaper.html

#### ✅ 前端功能测试
- [ ] Staking Dashboard：`/frontend/staking-dashboard.html`
- [ ] Investor Dashboard：`/frontend/investor-dashboard.html`
- [ ] Revenue Claim：`/frontend/revenue-claim.html`
- [ ] Investor Subscription：`/frontend/investor-subscription.html`

#### ✅ Telegram 功能测试
- [ ] Telegram App：`/telegram-app.html`
- [ ] Telegram Player：`/telegram-player.html`
- [ ] Reward Center：`/telegram-reward-center.html`

#### ✅ 系统功能测试
- [ ] X402 Player：`/x402-player-demo.html`
- [ ] Airdrop System：`/suk-airdrop-v2.html`
- [ ] User Dashboard：`/user-dashboard-enhanced.html`
- [ ] KYC Portal：`/kyc-submission-portal.html`

#### ✅ 钱包连接测试
- [ ] MetaMask 连接
- [ ] Phantom 连接（Solana）
- [ ] 网络切换（Ethereum/Solana）

### 4.3 性能测试

使用在线工具测试：

- **PageSpeed Insights**: https://pagespeed.web.dev/
- **GTmetrix**: https://gtmetrix.com/
- **WebPageTest**: https://www.webpagetest.org/

---

## 🌐 第五步：配置自定义域名（可选）

### 5.1 添加域名到 Cloudflare Pages

1. 在 Pages 项目页面，选择 **"Custom domains"** 标签
2. 点击 **"Set up a custom domain"**
3. 输入域名：`suk.link`
4. 点击 **"Continue"**

### 5.2 配置 DNS

#### 如果域名在 Cloudflare 托管
- ✅ **自动配置完成！** 无需任何操作

#### 如果域名在其他 DNS 提供商

##### 阿里云 DNS 配置
```
记录类型: CNAME
主机记录: @
记录值: suk-protocol.pages.dev
TTL: 10分钟
```

##### 腾讯云 DNS 配置
```
记录类型: CNAME
主机记录: @
记录值: suk-protocol.pages.dev
TTL: 600
```

##### Namecheap DNS 配置
```
Type: CNAME Record
Host: @
Value: suk-protocol.pages.dev
TTL: Automatic
```

##### GoDaddy DNS 配置
```
Type: CNAME
Name: @
Value: suk-protocol.pages.dev
TTL: 1 Hour
```

### 5.3 配置子域名

如果需要配置子域名（如 `app.suk.link`）：

```
记录类型: CNAME
主机记录: app
记录值: suk-protocol.pages.dev
TTL: 10分钟
```

### 5.4 等待 DNS 生效

- DNS 生效时间：5-30 分钟
- 验证命令：
  ```bash
  # 检查 DNS 解析
  nslookup suk.link
  
  # 或使用 dig
  dig suk.link
  
  # 测试 HTTPS
  curl -I https://suk.link
  ```

### 5.5 SSL 证书

Cloudflare 会自动配置 SSL 证书：
- ✅ 自动颁发
- ✅ 自动续期
- ✅ 强制 HTTPS

---

## 🔄 第六步：设置自动部署

### 6.1 验证自动部署

每次推送代码到 GitHub 后，Cloudflare Pages 会自动：
1. 检测到新的提交
2. 触发自动部署
3. 部署完成后发送通知

### 6.2 测试自动部署

```bash
# 修改任意文件
echo "# Test auto deploy" >> README.md

# 提交并推送
git add .
git commit -m "✅ Test auto deploy"
git push origin main

# 在 Cloudflare Dashboard 查看部署进度
# https://dash.cloudflare.com/ → Workers & Pages → suk-protocol → Deployments
```

### 6.3 配置 GitHub Actions（可选）

如果需要更多控制，可以使用 GitHub Actions：

项目已包含 `.github/workflows/cloudflare-pages-deploy.yml` 配置文件。

**配置步骤**：

1. 获取 Cloudflare API Token：
   - 访问：https://dash.cloudflare.com/profile/api-tokens
   - Create Token → Edit Cloudflare Workers
   - 复制 Token

2. 获取 Account ID：
   - Dashboard 右侧 → Account ID
   - 复制 Account ID

3. 添加 GitHub Secrets：
   - GitHub 仓库 → Settings → Secrets and variables → Actions
   - New repository secret：
     ```
     CLOUDFLARE_API_TOKEN = <your-token>
     CLOUDFLARE_ACCOUNT_ID = <your-account-id>
     ```

4. 推送代码触发 Actions：
   ```bash
   git push origin main
   ```

---

## 📊 第七步：监控和维护

### 7.1 查看部署历史

1. Cloudflare Dashboard → Workers & Pages → suk-protocol
2. 选择 **"Deployments"** 标签
3. 查看所有部署记录和状态

### 7.2 查看实时日志

```bash
# 安装 Wrangler CLI
npm install -g wrangler

# 登录
wrangler login

# 查看实时日志
wrangler pages deployment tail --project-name=suk-protocol
```

### 7.3 启用 Web Analytics

1. Cloudflare Dashboard → Web Analytics
2. 添加站点：`suk-protocol.pages.dev`
3. 获取跟踪代码
4. 添加到 `index.html` 的 `</body>` 前：

```html
<!-- Cloudflare Web Analytics -->
<script defer src='https://static.cloudflareinsights.com/beacon.min.js' 
        data-cf-beacon='{"token": "YOUR_TOKEN"}'></script>
```

### 7.4 启用 Bot Protection

1. Dashboard → Security → Bots
2. Enable **Super Bot Fight Mode**
3. 配置规则

---

## 🚨 常见问题排查

### Q1: Git push 失败

**错误**: `! [rejected] main -> main (fetch first)`

**解决**：
```bash
# 拉取远程更改
git pull origin main --rebase

# 再次推送
git push origin main
```

### Q2: GitHub 认证失败

**错误**: `Authentication failed`

**解决**：
```bash
# 使用 Personal Access Token
# 1. 生成 token: https://github.com/settings/tokens
# 2. 推送时使用 token 作为密码
git push https://YOUR_TOKEN@github.com/geosharkJerry/suk.git main
```

### Q3: Cloudflare 部署失败

**错误**: `Build failed`

**解决**：
1. 检查构建命令是否为空
2. 检查输出目录是否为 `.`
3. 查看部署日志找到具体错误

### Q4: 页面显示 404

**原因**: `_redirects` 文件未生效

**解决**：
```bash
# 确保 _redirects 文件存在并包含：
/* /index.html 200

# 重新部署
git add _redirects
git commit -m "Fix 404 redirect"
git push origin main
```

### Q5: CSS/JS 加载失败

**原因**: 路径错误或缓存问题

**解决**：
```html
<!-- 使用绝对路径 -->
<link rel="stylesheet" href="/css/style.css">
<script src="/js/main.js"></script>

<!-- 清除浏览器缓存 -->
Ctrl + Shift + R
```

### Q6: 自定义域名无法访问

**原因**: DNS 配置错误或未生效

**解决**：
```bash
# 验证 DNS 解析
nslookup suk.link

# 应该显示指向 Cloudflare 的记录
# 如果没有，检查 DNS 配置

# 清除本地 DNS 缓存
# Windows:
ipconfig /flushdns

# macOS:
sudo dscacheutil -flushcache

# Linux:
sudo systemd-resolve --flush-caches
```

---

## 🎉 部署成功检查清单

完成以下所有项目即表示部署成功：

### Git 和 GitHub
- [ ] Git 仓库已初始化
- [ ] 代码已推送到 GitHub
- [ ] GitHub 仓库可正常访问
- [ ] 远程仓库包含所有文件

### Cloudflare Pages
- [ ] Pages 项目已创建
- [ ] GitHub 连接成功
- [ ] 首次部署成功
- [ ] 生产环境可访问

### 功能验证
- [ ] 主页正常显示
- [ ] CSS 样式正确加载
- [ ] JavaScript 功能正常
- [ ] 图片资源正常显示
- [ ] 钱包连接功能正常

### 自动化
- [ ] Git push 触发自动部署
- [ ] 部署完成后可立即访问
- [ ] 部署历史可查看

### 域名配置（可选）
- [ ] 自定义域名已添加
- [ ] DNS 配置正确
- [ ] SSL 证书已启用
- [ ] HTTPS 强制跳转

---

## 📞 获取帮助

- 📖 **Cloudflare Pages 文档**: https://developers.cloudflare.com/pages/
- 💬 **Cloudflare Discord**: https://discord.cloudflare.com/
- 🐛 **GitHub Issues**: https://github.com/geosharkJerry/suk/issues
- 📧 **技术支持**: support@suk.link

---

## 🚀 快速命令速查表

```bash
# ========== Git 基础命令 ==========

# 初始化 Git
git init

# 配置用户
git config user.name "Your Name"
git config user.email "your@email.com"

# 查看状态
git status

# 添加文件
git add .

# 提交
git commit -m "commit message"

# 添加远程仓库
git remote add origin https://github.com/geosharkJerry/suk.git

# 推送
git push -u origin main

# 拉取
git pull origin main

# 查看日志
git log --oneline

# ========== Wrangler CLI 命令 ==========

# 安装 Wrangler
npm install -g wrangler

# 登录
wrangler login

# 查看项目
wrangler pages project list

# 查看部署
wrangler pages deployment list --project-name=suk-protocol

# 查看日志
wrangler pages deployment tail --project-name=suk-protocol

# 手动部署
wrangler pages deploy . --project-name=suk-protocol

# ========== DNS 验证命令 ==========

# nslookup
nslookup suk.link

# dig
dig suk.link

# curl 测试
curl -I https://suk.link

# 测试 SSL
openssl s_client -connect suk.link:443 -servername suk.link
```

---

## 📅 更新日志

- **2024-11-20**: 创建完整的 GitHub + Cloudflare Pages 部署指南
- **目标仓库**: https://github.com/geosharkJerry/suk
- **部署域名**: suk.link

---

**🎉 恭喜！您已成功将 SUK Protocol 部署到生产环境！**

**生产环境访问**:
- 主域名: https://suk-protocol.pages.dev
- 自定义域名: https://suk.link (配置后)

**仓库地址**:
- GitHub: https://github.com/geosharkJerry/suk

---

*最后更新: 2024-11-20*
