# 🚀 SUK Protocol - 快速开始指南

## 📌 欢迎使用 SUK Protocol！

这是一个完整的竖屏短剧版权RWA平台前端项目，包含了用户认证、数据管理、交易历史、Web3钱包集成等功能。

---

## ⚡ 3分钟快速体验

### 步骤 1：启动本地服务器

选择以下任一方式：

**方法 A - Python（推荐）**
```bash
# 在项目根目录打开终端
python -m http.server 8000

# 然后访问
http://localhost:8000
```

**方法 B - Node.js**
```bash
npm install -g http-server
http-server -p 8000
```

**方法 C - VS Code**
```
安装 "Live Server" 扩展
右键 HTML 文件 → Open with Live Server
```

### 步骤 2：浏览页面

**推荐访问顺序：**

1. **测试导航页** → `test-index.html`
   - 查看所有功能模块
   - 快速导航到各个页面

2. **登录/注册** → `auth.html`
   - 注册新账户
   - 或使用 MetaMask 钱包登录

3. **仪表盘** → `dashboard.html`
   - 查看投资组合
   - 查看收益统计

4. **数据管理** → `admin-panel.html`
   - 管理短剧数据
   - 添加/编辑/删除记录

5. **交易历史** → `transactions.html`
   - 查看所有交易记录
   - 筛选交易类型

### 步骤 3：测试钱包连接

1. 安装 MetaMask 浏览器扩展
   - 访问 https://metamask.io/
   - 下载并安装

2. 打开钱包测试工具
   - 访问 `wallet-test.html`
   - 点击"连接钱包"
   - 测试各项功能

---

## 📂 项目文件结构

```
suk-protocol/
├── 📄 HTML 页面 (11个)
│   ├── index.html              # 官网首页
│   ├── drama-detail.html       # 短剧详情页
│   ├── dashboard.html          # 投资仪表盘
│   ├── faq.html               # 常见问题
│   ├── whitepaper.html        # 项目白皮书
│   ├── auth.html              # 登录/注册 ⭐ NEW
│   ├── admin-panel.html       # 数据管理 ⭐ NEW
│   ├── transactions.html      # 交易历史 ⭐ NEW
│   ├── wallet-test.html       # 钱包测试工具
│   └── test-index.html        # 测试导航页
│
├── 🎨 CSS 样式 (4个)
│   ├── css/style.css          # 全局样式
│   ├── css/drama-detail.css   # 短剧详情样式
│   ├── css/dashboard.css      # 仪表盘样式
│   └── css/faq.css           # FAQ样式
│
├── ⚡ JavaScript 模块 (10个)
│   ├── js/script.js           # 全局交互
│   ├── js/drama-detail.js     # 短剧详情交互
│   ├── js/dashboard.js        # 仪表盘交互
│   ├── js/faq.js             # FAQ交互
│   ├── js/web3-wallet.js      # Web3钱包集成
│   ├── js/contract-interact.js # 智能合约交互
│   ├── js/auth.js             # 用户认证 ⭐ NEW
│   ├── js/table-api.js        # 数据管理 ⭐ NEW
│   ├── js/transactions.js     # 交易历史 ⭐ NEW
│   └── js/notifications.js    # 通知系统 ⭐ NEW
│
├── 🔗 智能合约 (2个)
│   ├── contracts/SUKToken.sol              # SUK治理代币
│   └── contracts/DramaCopyrightToken.sol   # 版权代币
│
└── 📚 文档 (10个)
    ├── README.md                           # 项目文档
    ├── DEPLOYMENT_GUIDE.md                 # 部署指南
    ├── WALLET_TEST_GUIDE.md                # 钱包测试指南
    ├── FRONTEND_FEATURES_GUIDE.md          # 前端功能指南 ⭐ NEW
    ├── FRONTEND_COMPLETION_REPORT.md       # 完成报告 ⭐ NEW
    └── QUICK_START.md                      # 本文件 ⭐ NEW
```

---

## 🎯 核心功能一览

### 1. 用户认证系统 🔐
- 邮箱/用户名登录
- 用户注册（密码强度检测）
- MetaMask 钱包一键登录
- 记住登录状态

**文件：** `auth.html`, `js/auth.js`

### 2. 数据管理面板 📊
- 管理4种数据表
- 完整 CRUD 操作
- 实时搜索
- 分页显示

**文件：** `admin-panel.html`, `js/table-api.js`

### 3. 交易历史记录 📝
- 显示所有链上交易
- 5种交易类型筛选
- 交易详情展示
- 复制交易哈希

**文件：** `transactions.html`, `js/transactions.js`

### 4. 浏览器通知系统 🔔
- 页面内 Toast 通知
- 浏览器原生通知
- 4种通知类型
- 通知历史记录

**文件：** `js/notifications.js`

### 5. Web3 钱包集成 💼
- MetaMask 连接
- 多链支持
- 余额查询
- 网络切换

**文件：** `js/web3-wallet.js`

### 6. 智能合约交互 ⛓️
- SUK 代币操作
- 版权代币交易
- 质押/解押
- 收益领取

**文件：** `js/contract-interact.js`

---

## 🔑 关键操作指南

### 用户注册

```
1. 访问 auth.html
2. 点击"注册"标签
3. 填写用户名、邮箱、密码
4. 勾选服务条款
5. 点击"创建账户"
```

### 钱包登录

```
1. 访问 auth.html
2. 点击"MetaMask 登录"
3. 在弹窗中授权连接
4. 自动创建或登录账户
```

### 管理数据

```
1. 登录后访问 admin-panel.html
2. 选择数据表（短剧/投资/收益/用户）
3. 点击"添加数据"创建记录
4. 点击"编辑"修改记录
5. 点击"删除"删除记录
```

### 查看交易

```
1. 登录后访问 transactions.html
2. 查看所有交易记录
3. 使用顶部按钮筛选类型
4. 点击交易哈希查看详情
```

### 测试钱包

```
1. 访问 wallet-test.html
2. 点击"连接钱包"
3. 测试各项功能模块
4. 查看测试日志和结果
```

---

## 💡 常见问题

### Q: 如何清空所有数据？

**A:** 打开浏览器控制台（F12），执行：
```javascript
localStorage.clear();
location.reload();
```

### Q: 为什么登录后刷新页面需要重新登录？

**A:** 这是设计行为。勾选"记住我"可以保持登录状态。

### Q: 数据存储在哪里？

**A:** 所有数据存储在浏览器的 LocalStorage 中（5-10MB 限制）。

### Q: 如何连接真实的后端 API？

**A:** 参考 `FRONTEND_FEATURES_GUIDE.md` 的"API 集成"章节。

### Q: 如何部署到线上？

**A:** 参考 `DEPLOYMENT_GUIDE.md` 的部署步骤。

### Q: 智能合约如何使用？

**A:** 需要先部署合约到测试网，参考 `DEPLOYMENT_GUIDE.md`。

---

## 🛠️ 开发指南

### 添加新功能

1. **创建 HTML 页面**
```html
<!-- 复制现有页面作为模板 -->
<!-- 修改内容和样式 -->
<!-- 添加到导航菜单 -->
```

2. **创建 JavaScript 模块**
```javascript
// 在 js/ 目录创建新文件
// 遵循现有模块的结构
// 使用 showNotification() 提供反馈
```

3. **集成到项目**
```javascript
// 在 HTML 中引入新模块
<script src="js/your-module.js"></script>

// 在导航中添加链接
<a href="your-page.html">新功能</a>
```

### 调试技巧

**1. 查看浏览器控制台**
```
F12 → Console 标签
查看错误信息和日志
```

**2. 查看 LocalStorage**
```
F12 → Application → Local Storage
查看存储的数据
```

**3. 网络请求监控**
```
F12 → Network 标签
查看 API 请求和响应
```

---

## 📚 进一步学习

### 推荐阅读顺序

1. **QUICK_START.md** （本文件）
   - 快速开始使用

2. **README.md**
   - 项目整体介绍
   - 技术栈说明

3. **FRONTEND_FEATURES_GUIDE.md**
   - 详细功能说明
   - 代码示例
   - 集成指南

4. **WALLET_TEST_GUIDE.md**
   - 钱包测试步骤
   - 常见问题排查

5. **DEPLOYMENT_GUIDE.md**
   - 前端部署
   - 智能合约部署
   - 环境配置

6. **FRONTEND_COMPLETION_REPORT.md**
   - 开发完成报告
   - 功能统计
   - 技术特点

---

## 🎓 学习资源

### Web3 开发
- [MetaMask 文档](https://docs.metamask.io/)
- [ethers.js 文档](https://docs.ethers.io/)
- [Polygon 文档](https://docs.polygon.technology/)

### 前端技术
- [MDN Web Docs](https://developer.mozilla.org/)
- [JavaScript.info](https://javascript.info/)
- [CSS-Tricks](https://css-tricks.com/)

### 智能合约
- [Solidity 文档](https://docs.soliditylang.org/)
- [OpenZeppelin](https://docs.openzeppelin.com/)
- [Hardhat](https://hardhat.org/docs)

---

## 📞 获取帮助

### 遇到问题？

1. **查看控制台错误**
   - 打开浏览器开发者工具
   - 查看 Console 和 Network 标签

2. **检查文档**
   - 阅读相关的 .md 文档
   - 查看代码注释

3. **查看示例代码**
   - 参考现有功能的实现
   - 复制和修改示例代码

4. **清空缓存重试**
   - 清空 LocalStorage
   - 刷新页面
   - 重新测试

---

## 🎉 开始探索！

现在您已经了解了基本情况，可以开始探索 SUK Protocol 的各项功能了：

1. ✅ 启动本地服务器
2. ✅ 访问 test-index.html 查看导航
3. ✅ 注册账户并登录
4. ✅ 浏览各个功能页面
5. ✅ 测试钱包连接
6. ✅ 管理数据和查看交易

**祝您使用愉快！** 🚀

---

<div align="center">
  <strong>🎬 SUK Protocol - 竖屏短剧版权RWA平台</strong>
  <br><br>
  <sub>v1.3.0 | 2024-11-15</sub>
  <br><br>
  <a href="./README.md">📚 完整文档</a> |
  <a href="./FRONTEND_FEATURES_GUIDE.md">📖 功能指南</a> |
  <a href="./DEPLOYMENT_GUIDE.md">🚀 部署指南</a>
</div>
