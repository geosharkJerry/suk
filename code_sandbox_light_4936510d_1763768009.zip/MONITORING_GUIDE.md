# 监控系统部署指南
# Monitoring System Deployment Guide

> **Prometheus + Grafana 完整监控方案**

---

## 📋 目录

- [监控架构](#监控架构)
- [快速开始](#快速开始)
- [监控组件](#监控组件)
- [告警配置](#告警配置)
- [Grafana 仪表板](#grafana-仪表板)
- [常见问题](#常见问题)

---

## 监控架构

```
┌─────────────────────────────────────────────────┐
│                   Grafana (可视化)                │
│              http://localhost:3001               │
└──────────────────┬──────────────────────────────┘
                   │
┌──────────────────▼──────────────────────────────┐
│              Prometheus (指标收集)                │
│              http://localhost:9090               │
└──┬───┬───┬────┬────┬────┬────────────────────────┘
   │   │   │    │    │    │
   │   │   │    │    │    └─> App (3000)
   │   │   │    │    └─────> Node Exporter (9100)
   │   │   │    └──────────> MongoDB Exporter (9216)
   │   │   └───────────────> Redis Exporter (9121)
   │   └───────────────────> cAdvisor (8080)
   └───────────────────────> AlertManager (9093)
```

---

## 快速开始

### 1. 启动监控栈

```bash
# 同时启动应用和监控服务
docker-compose -f docker-compose.yml -f docker-compose.monitoring.yml up -d

# 查看服务状态
docker-compose -f docker-compose.yml -f docker-compose.monitoring.yml ps
```

### 2. 访问监控界面

| 服务 | URL | 默认账号 |
|------|-----|---------|
| Grafana | http://localhost:3001 | admin / admin123 |
| Prometheus | http://localhost:9090 | 无需认证 |
| AlertManager | http://localhost:9093 | 无需认证 |
| cAdvisor | http://localhost:8080 | 无需认证 |

### 3. 配置 Grafana

1. 访问 http://localhost:3001
2. 登录（admin / admin123）
3. 数据源已自动配置（Prometheus）
4. 导入仪表板（见下文）

---

## 监控组件

### Prometheus（指标收集）

**功能**：
- 收集应用和系统指标
- 存储时序数据
- 执行告警规则

**配置文件**：
- `monitoring/prometheus.yml` - 主配置
- `monitoring/alerts/*.yml` - 告警规则

**常用查询**：

```promql
# API 请求率
rate(http_requests_total[5m])

# 内存使用
process_resident_memory_bytes / 1024 / 1024

# CPU 使用率
rate(process_cpu_seconds_total[5m]) * 100

# 错误率
rate(http_requests_total{status=~"5.."}[5m])
```

### Grafana（可视化）

**功能**：
- 创建仪表板
- 可视化指标
- 配置告警

**推荐仪表板**：

1. **应用概览**
   - 请求量、错误率、响应时间
   - CPU、内存使用
   - MongoDB、Redis 状态

2. **系统资源**
   - 主机 CPU、内存、磁盘
   - 网络流量
   - 容器资源使用

3. **数据库监控**
   - MongoDB 连接数、查询性能
   - Redis 命中率、内存使用

### Node Exporter（系统指标）

**监控指标**：
- CPU 使用率
- 内存使用
- 磁盘 I/O
- 网络流量
- 文件系统使用

### MongoDB Exporter

**监控指标**：
- 连接数
- 操作统计
- 查询性能
- 复制延迟

### Redis Exporter

**监控指标**：
- 连接数
- 命中率
- 内存使用
- 键统计

### cAdvisor（容器指标）

**监控指标**：
- 容器 CPU 使用
- 容器内存使用
- 容器网络 I/O
- 容器文件系统

---

## 告警配置

### 已配置的告警

| 告警 | 条件 | 级别 | 描述 |
|------|------|------|------|
| AppDown | 应用宕机1分钟 | critical | 应用无法访问 |
| HighMemoryUsage | 内存>1.5GB持续5分钟 | warning | 内存使用过高 |
| MongoDBDown | MongoDB宕机1分钟 | critical | 数据库不可用 |
| RedisDown | Redis宕机1分钟 | critical | 缓存不可用 |
| HighAPIResponseTime | 95%请求>1秒 | warning | API 响应慢 |
| HighErrorRate | 5xx错误率>5% | warning | 错误率过高 |
| HighCPUUsage | CPU>80%持续5分钟 | warning | CPU 使用过高 |
| LowDiskSpace | 磁盘<10% | warning | 磁盘空间不足 |

### 自定义告警

编辑 `monitoring/alerts/drama-platform.yml`：

```yaml
groups:
  - name: custom_alerts
    rules:
      - alert: CustomAlert
        expr: your_metric > threshold
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "告警标题"
          description: "告警描述"
```

重新加载配置：

```bash
# 方式1: 热重载（推荐）
curl -X POST http://localhost:9090/-/reload

# 方式2: 重启服务
docker-compose -f docker-compose.monitoring.yml restart prometheus
```

### AlertManager 配置

创建 `monitoring/alertmanager.yml`：

```yaml
global:
  resolve_timeout: 5m

route:
  receiver: 'default'
  group_by: ['alertname', 'severity']
  group_wait: 10s
  group_interval: 10s
  repeat_interval: 12h

receivers:
  - name: 'default'
    webhook_configs:
      - url: 'http://your-webhook-url'
    # 邮件通知
    email_configs:
      - to: 'admin@example.com'
        from: 'alertmanager@example.com'
        smarthost: 'smtp.gmail.com:587'
        auth_username: 'your-email@gmail.com'
        auth_password: 'your-app-password'
    # Slack 通知
    slack_configs:
      - api_url: 'your-slack-webhook-url'
        channel: '#alerts'
```

---

## Grafana 仪表板

### 导入预置仪表板

1. **Node Exporter Full**
   - ID: 1860
   - 系统资源监控

2. **MongoDB Dashboard**
   - ID: 2583
   - MongoDB 监控

3. **Redis Dashboard**
   - ID: 763
   - Redis 监控

4. **Docker Container & Host Metrics**
   - ID: 179
   - 容器监控

### 导入步骤

1. 登录 Grafana
2. 点击 "+" → "Import"
3. 输入 Dashboard ID
4. 选择 Prometheus 数据源
5. 点击 "Import"

### 自定义仪表板

创建应用专用仪表板：

```json
{
  "dashboard": {
    "title": "Drama Platform Overview",
    "panels": [
      {
        "title": "API 请求率",
        "targets": [{
          "expr": "rate(http_requests_total[5m])"
        }]
      },
      {
        "title": "内存使用",
        "targets": [{
          "expr": "process_resident_memory_bytes / 1024 / 1024"
        }]
      }
    ]
  }
}
```

---

## 常用命令

### 启动/停止

```bash
# 启动监控栈
docker-compose -f docker-compose.yml -f docker-compose.monitoring.yml up -d

# 停止监控栈
docker-compose -f docker-compose.monitoring.yml down

# 查看日志
docker-compose -f docker-compose.monitoring.yml logs -f prometheus
docker-compose -f docker-compose.monitoring.yml logs -f grafana
```

### 数据管理

```bash
# 备份 Grafana 配置
docker exec drama-platform-grafana \
  tar czf /tmp/grafana-backup.tar.gz /var/lib/grafana
docker cp drama-platform-grafana:/tmp/grafana-backup.tar.gz ./

# 备份 Prometheus 数据
docker exec drama-platform-prometheus \
  tar czf /tmp/prometheus-backup.tar.gz /prometheus
docker cp drama-platform-prometheus:/tmp/prometheus-backup.tar.gz ./
```

### 故障排查

```bash
# 检查 Prometheus targets
curl http://localhost:9090/api/v1/targets

# 检查 Prometheus 配置
curl http://localhost:9090/api/v1/status/config

# 检查告警规则
curl http://localhost:9090/api/v1/rules

# 测试告警
curl -X POST http://localhost:9093/api/v1/alerts \
  -H "Content-Type: application/json" \
  -d '[{
    "labels": {"alertname": "TestAlert"},
    "annotations": {"summary": "Test alert"}
  }]'
```

---

## 常见问题

### Q1: Prometheus 无法抓取指标

**解决方案**：

```bash
# 检查 target 状态
curl http://localhost:9090/api/v1/targets

# 检查网络连接
docker-compose exec prometheus ping app

# 查看 Prometheus 日志
docker-compose logs prometheus
```

### Q2: Grafana 数据源连接失败

**解决方案**：

```bash
# 检查 Prometheus 是否运行
docker-compose ps prometheus

# 测试连接
docker-compose exec grafana curl http://prometheus:9090/api/v1/query?query=up

# 检查配置
cat monitoring/grafana/datasources/prometheus.yml
```

### Q3: 告警不工作

**解决方案**：

```bash
# 检查告警规则
curl http://localhost:9090/api/v1/rules

# 检查 AlertManager 状态
curl http://localhost:9093/api/v1/status

# 查看日志
docker-compose logs alertmanager
```

### Q4: 磁盘空间占用过大

**解决方案**：

```bash
# 限制 Prometheus 数据保留时间
# 在 docker-compose.monitoring.yml 中添加:
command:
  - '--storage.tsdb.retention.time=15d'
  - '--storage.tsdb.retention.size=10GB'

# 清理旧数据
docker exec drama-platform-prometheus \
  rm -rf /prometheus/data/01*
```

---

## 生产环境建议

### 1. 数据持久化

确保使用外部 volumes：

```yaml
volumes:
  prometheus-data:
    driver: local
    driver_opts:
      type: none
      device: /data/prometheus
      o: bind
```

### 2. 高可用配置

- 部署多个 Prometheus 实例
- 使用 Thanos 进行长期存储
- 配置 AlertManager 集群

### 3. 安全配置

```yaml
# prometheus.yml
global:
  external_labels:
    cluster: 'production'

# 启用基础认证
basic_auth:
  username: 'admin'
  password: 'secure_password'
```

### 4. 性能优化

- 调整抓取间隔（scrape_interval）
- 限制数据保留时间
- 使用远程存储

---

## 参考资源

- [Prometheus 官方文档](https://prometheus.io/docs/)
- [Grafana 官方文档](https://grafana.com/docs/)
- [PromQL 查询语言](https://prometheus.io/docs/prometheus/latest/querying/basics/)
- [Grafana 仪表板库](https://grafana.com/grafana/dashboards/)

---

**最后更新**: 2024-11-15  
**版本**: v1.0.0
