# 🚀 多语言系统快速开始指南

## 👀 立即查看效果

### 1. 打开首页测试
```bash
# 直接在浏览器中打开
index.html
```

### 2. 打开专用测试页面
```bash
# 查看所有翻译效果
test-i18n.html
```

---

## 🎯 如何使用

### 切换语言（3种方式）

#### 方式1：点击导航栏语言切换器
1. 打开 `index.html` 或 `test-i18n.html`
2. 查看导航栏左侧（logo右边）
3. 点击语言按钮（显示旗帜 + 语言代码）
4. 从下拉菜单选择语言
5. 页面立即翻译！✨

#### 方式2：浏览器自动检测
- 首次访问时，系统自动检测浏览器语言
- 例如：浏览器设置为英语 → 自动显示英文界面

#### 方式3：编程式切换（开发者）
```javascript
// 在浏览器控制台输入
window.i18n.changeLanguage('en'); // 切换到英语
window.i18n.changeLanguage('ja'); // 切换到日语
```

---

## 📋 支持的语言

| 语言 | 代码 | 旗帜 | 示例效果 |
|------|------|------|---------|
| 中文 | `zh` | 🇨🇳 | 关于、工作原理、作品集 |
| 英语 | `en` | 🇺🇸 | About, How It Works, Portfolio |
| 西班牙语 | `es` | 🇪🇸 | Acerca de, Cómo Funciona, Portafolio |
| 泰语 | `th` | 🇹🇭 | เกี่ยวกับ, วิธีการทำงาน, ผลงาน |
| 越南语 | `vi` | 🇻🇳 | Giới Thiệu, Cách Hoạt Động, Danh Mục |
| 日语 | `ja` | 🇯🇵 | について, 仕組み, ポートフォリオ |

---

## 🧪 测试清单

### 在 test-i18n.html 中测试

**导航栏** (7项)
- [ ] 关于 / About / Acerca de / ...
- [ ] 工作原理 / How It Works / ...
- [ ] 作品集 / Portfolio / ...
- [ ] 仪表盘 / Dashboard / ...
- [ ] FAQ
- [ ] 白皮书 / Whitepaper / ...
- [ ] 登录/注册 / Login/Sign Up / ...

**Hero区域** (9项)
- [ ] 徽章文字
- [ ] 主标题（3部分）
- [ ] 副标题（2行）
- [ ] 统计数据标签

**作品集** (14项)
- [ ] 代币价格 / Token Price / ...
- [ ] 年化收益 / Annual Yield / ...
- [ ] 总锁仓 / Total Locked / ...
- [ ] 立即投资 / Invest Now / ...
- [ ] 查看详情 / View Details / ...

**收益说明** (10项)
- [ ] 版权分红 / Copyright Dividends / ...
- [ ] 质押奖励 / Staking Rewards / ...
- [ ] 交易收益 / Trading Profits / ...
- [ ] 社区权益 / Community Benefits / ...

---

## 💡 常见问题

### Q: 为什么我的页面没有语言切换器？

**A**: 确保页面已引入必要的脚本：
```html
<script src="js/i18n-translations.js"></script>
<script src="js/i18n.js"></script>
```

### Q: 如何添加新的翻译文本？

**A**: 
1. 为HTML元素添加 `data-i18n` 属性
   ```html
   <h1 data-i18n="nav.about">关于</h1>
   ```

2. 在 `js/i18n-translations.js` 中为所有6种语言添加翻译
   ```javascript
   zh: { nav: { about: "关于" } },
   en: { nav: { about: "About" } },
   es: { nav: { about: "Acerca de" } },
   th: { nav: { about: "เกี่ยวกับ" } },
   vi: { nav: { about: "Giới Thiệu" } },
   ja: { nav: { about: "について" } }
   ```

### Q: 语言选择会保存吗？

**A**: 是的！用户的语言选择会自动保存到 `localStorage`，下次访问时自动恢复。

### Q: 如何查看当前语言？

**A**: 
```javascript
// 在浏览器控制台
window.i18n.getCurrentLanguage(); // 返回 "zh", "en", "es" 等
```

---

## 🎨 UI展示

### 语言切换器外观

**关闭状态**:
```
┌──────────────┐
│ 🇨🇳 ZH  ▼   │  ← 点击这里
└──────────────┘
```

**展开状态**:
```
┌──────────────┐
│ 🇨🇳 ZH  ▲   │
├──────────────┤
│ 🇨🇳 中文    ✓│  ← 当前语言
│ 🇺🇸 English  │
│ 🇪🇸 Español  │
│ 🇹🇭 ไทย      │
│ 🇻🇳 Tiếng Việt│
│ 🇯🇵 日本語   │
└──────────────┘
```

---

## 📱 移动端测试

### 在手机上测试

1. 打开 `index.html`
2. 语言切换器自动缩小以适应小屏幕
3. 点击测试，确保下拉菜单正常工作
4. 检查所有文本是否正确换行

---

## 🔍 故障排除

### 翻译不生效？

**检查1**: 控制台是否有错误？
```javascript
// 按F12打开开发者工具，查看Console标签
```

**检查2**: 脚本是否正确加载？
```javascript
// 在控制台输入
window.i18n
window.translations
// 应该返回对象，而不是 undefined
```

**检查3**: data-i18n 属性是否正确？
```html
<!-- ✅ 正确 -->
<h1 data-i18n="nav.about">关于</h1>

<!-- ❌ 错误 -->
<h1 data-i18n="about">关于</h1>  <!-- 缺少前缀 -->
<h1 data-118n="nav.about">关于</h1>  <!-- 拼写错误 -->
```

### 语言切换器不显示？

**原因**: 页面结构不符合预期

**解决**: 确保HTML有以下结构：
```html
<nav class="navbar">
    <div class="container">
        <div class="nav-content">
            <div class="logo">...</div>
            <div class="nav-menu">...</div>
        </div>
    </div>
</nav>
```

---

## 📚 进阶文档

- **详细使用指南**: [MULTILINGUAL_SYSTEM_GUIDE.md](MULTILINGUAL_SYSTEM_GUIDE.md)
- **实施报告**: [MULTILINGUAL_IMPLEMENTATION_REPORT.md](MULTILINGUAL_IMPLEMENTATION_REPORT.md)
- **完成总结**: [TASK_COMPLETION_SUMMARY.md](TASK_COMPLETION_SUMMARY.md)

---

## 🎉 开始使用！

现在你已经准备好使用多语言系统了！

**推荐步骤**:
1. ✅ 打开 `test-i18n.html` 查看效果
2. ✅ 测试所有6种语言
3. ✅ 在 `index.html` 中使用
4. ✅ 阅读 [MULTILINGUAL_SYSTEM_GUIDE.md](MULTILINGUAL_SYSTEM_GUIDE.md) 了解更多

**需要帮助？**  
查看完整文档或在项目中搜索 `data-i18n` 查看使用示例。

---

**祝使用愉快！** 🌍✨
