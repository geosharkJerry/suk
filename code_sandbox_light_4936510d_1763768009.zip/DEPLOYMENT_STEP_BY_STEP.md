# 🚀 SUK代币和空投系统 - 完整部署指南

**版本**: 1.0.0  
**日期**: 2024-11-16  
**状态**: 生产就绪

---

## 📋 目录

- [前置准备](#前置准备)
- [步骤1: 安装依赖](#步骤1-安装依赖)
- [步骤2: 配置环境](#步骤2-配置环境)
- [步骤3: 编译合约](#步骤3-编译合约)
- [步骤4: 部署SUK代币](#步骤4-部署suk代币)
- [步骤5: 部署空投合约](#步骤5-部署空投合约)
- [步骤6: 转移代币](#步骤6-转移代币)
- [步骤7: 导入白名单](#步骤7-导入白名单)
- [步骤8: 配置前端](#步骤8-配置前端)
- [步骤9: 测试验证](#步骤9-测试验证)
- [常见问题](#常见问题)

---

## ⚙️ 前置准备

### 必需软件

```bash
# Node.js (v18+)
node --version  # 应该 >= v18.0.0

# npm 或 yarn
npm --version

# Git
git --version
```

### 必需账户

1. **以太坊钱包**
   - MetaMask 或其他钱包
   - 准备足够的ETH用于Gas费
   - 测试网: 至少0.5 ETH
   - 主网: 至少2 ETH (安全起见)

2. **RPC节点**
   - Infura账号 (推荐)
   - Alchemy账号 (备选)
   - 或其他RPC提供商

3. **区块浏览器API**
   - Etherscan API Key (合约验证)
   - 免费账号即可

### 测试网水龙头

**Goerli测试网**:
- https://goerlifaucet.com/
- https://faucet.paradigm.xyz/

**Sepolia测试网**:
- https://sepoliafaucet.com/
- https://faucet.sepolia.dev/

---

## 步骤1: 安装依赖

### 1.1 克隆项目 (如果尚未克隆)

```bash
# 进入项目目录
cd suk-link-platform

# 如果是新项目，先安装package.json中的依赖
npm install
```

### 1.2 安装Hardhat和依赖

```bash
# 安装Hardhat工具包
npm install --save-dev hardhat @nomicfoundation/hardhat-toolbox

# 安装OpenZeppelin合约库
npm install @openzeppelin/contracts

# 安装其他依赖
npm install --save-dev @nomiclabs/hardhat-etherscan
npm install dotenv
npm install csv-parse
```

### 1.3 验证安装

```bash
npx hardhat --version
# 应该显示: 2.x.x

npx hardhat
# 应该显示可用的命令列表
```

---

## 步骤2: 配置环境

### 2.1 创建.env文件

```bash
cp .env.example .env
```

### 2.2 编辑.env文件

```env
# ==================== 网络配置 ====================

# Infura API Key (获取: https://infura.io/)
INFURA_API_KEY=your_infura_api_key_here

# 或者使用自定义RPC
GOERLI_RPC_URL=https://goerli.infura.io/v3/YOUR_API_KEY
SEPOLIA_RPC_URL=https://sepolia.infura.io/v3/YOUR_API_KEY
MAINNET_RPC_URL=https://mainnet.infura.io/v3/YOUR_API_KEY

# ==================== 钱包配置 ====================

# 部署者私钥 (不要包含0x前缀)
PRIVATE_KEY=your_private_key_here

# ⚠️ 警告: 永远不要将包含真实资金的私钥提交到Git!
# ⚠️ 使用测试钱包或硬件钱包进行主网部署!

# ==================== API Keys ====================

# Etherscan API Key (获取: https://etherscan.io/myapikey)
ETHERSCAN_API_KEY=your_etherscan_api_key

# Polygonscan API Key (如果部署到Polygon)
POLYGONSCAN_API_KEY=your_polygonscan_api_key

# BSCScan API Key (如果部署到BSC)
BSCSCAN_API_KEY=your_bscscan_api_key

# ==================== 可选配置 ====================

# Gas报告 (true/false)
REPORT_GAS=false

# CoinMarketCap API (用于Gas报告中的价格)
COINMARKETCAP_API_KEY=your_coinmarketcap_api_key

# ==================== 部署配置 ====================

# 空投时间配置 (Unix时间戳，可选)
# 如果不设置，将使用默认值
# WHITELIST_START_TIME=1700000000
# PUBLIC_START_TIME=1700259200
# END_TIME=1702851200
```

### 2.3 获取私钥

**从MetaMask导出私钥**:

1. 打开MetaMask
2. 点击账户图标 → 账户详情
3. 点击"导出私钥"
4. 输入密码
5. 复制私钥（不包括0x前缀）

⚠️ **安全提示**:
- 使用专门的部署钱包
- 不要使用包含大量资金的钱包
- 不要将.env文件提交到Git
- 主网部署建议使用硬件钱包

### 2.4 验证配置

```bash
# 测试网络连接
npx hardhat console --network goerli

# 在控制台中测试
> await ethers.provider.getBlockNumber()
# 应该返回当前区块号

> .exit
```

---

## 步骤3: 编译合约

### 3.1 编译所有合约

```bash
npx hardhat compile
```

预期输出:
```
Compiling 2 files with 0.8.19
Compilation finished successfully
```

### 3.2 检查编译结果

```bash
ls -la artifacts/contracts/
# 应该看到:
# - SUKToken.sol/
# - SUKAirdrop.sol/
```

### 3.3 运行测试 (可选但推荐)

```bash
# 如果有测试文件
npx hardhat test

# 生成Gas报告
REPORT_GAS=true npx hardhat test
```

---

## 步骤4: 部署SUK代币

### 4.1 选择网络

**测试网部署 (推荐先测试)**:
```bash
# Goerli测试网
NETWORK=goerli

# 或 Sepolia测试网
NETWORK=sepolia
```

**主网部署**:
```bash
NETWORK=mainnet
```

### 4.2 执行部署

```bash
npx hardhat run scripts/1-deploy-suk-token.js --network $NETWORK
```

### 4.3 部署输出示例

```
================================================================================
SUK代币合约部署
================================================================================

📋 部署配置:
--------------------------------------------------------------------------------
网络: goerli
Chain ID: 5
部署者地址: 0x1234...5678
部署者余额: 0.5 ETH

🚀 开始部署 SUK代币合约...
--------------------------------------------------------------------------------
部署中...
✅ SUKToken 已部署!
合约地址: 0xabcd...ef01
交易哈希: 0x1234...5678

⏳ 等待区块确认...
✅ 已确认

🔍 验证部署...
--------------------------------------------------------------------------------
代币名称: SUK Protocol
代币符号: SUK
小数位数: 18
总供应量: 1000000000.0 SUK
部署者持有: 1000000000.0 SUK

✅ 部署验证通过

💾 部署信息已保存: deployment/suk-token-goerli-1700000000000.json

🔍 Etherscan合约验证...
--------------------------------------------------------------------------------
等待 30 秒后开始验证...
✅ 合约验证成功

================================================================================
✅ SUK代币部署完成!
================================================================================

📝 重要信息:
--------------------------------------------------------------------------------
SUK代币地址: 0xabcd...ef01
总供应量: 1000000000.0 SUK
您的持有量: 1000000000.0 SUK

📋 代币分配计划:
--------------------------------------------------------------------------------
空投: 1000000.0 SUK (0.1%)
生态: 300000000.0 SUK (30%)
团队: 150000000.0 SUK (15%)
投资者: 200000000.0 SUK (20%)
流动性: 100000000.0 SUK (10%)
储备: 248000000.0 SUK (24.8%)

📝 后续步骤:
--------------------------------------------------------------------------------

1️⃣  添加代币到MetaMask
   代币地址: 0xabcd...ef01
   符号: SUK
   小数位: 18

2️⃣  转移空投代币
   数量: 1,000,000 SUK
   目标: 空投合约地址 (部署后获得)
   
   使用以下环境变量:
   export SUK_TOKEN_ADDRESS=0xabcd...ef01

3️⃣  部署空投合约
   npx hardhat run scripts/2-deploy-airdrop.js --network goerli
```

### 4.4 保存重要信息

```bash
# 保存SUK代币地址到环境变量
export SUK_TOKEN_ADDRESS=0xabcd...ef01  # 替换为实际地址

# 或添加到.env文件
echo "SUK_TOKEN_ADDRESS=0xabcd...ef01" >> .env
```

### 4.5 添加代币到MetaMask

1. 打开MetaMask
2. 切换到部署的网络 (Goerli/Mainnet)
3. 点击"导入代币"
4. 输入合约地址
5. 确认添加

---

## 步骤5: 部署空投合约

### 5.1 确保已设置SUK_TOKEN_ADDRESS

```bash
echo $SUK_TOKEN_ADDRESS
# 应该显示SUK代币地址
```

### 5.2 执行部署

```bash
npx hardhat run scripts/2-deploy-airdrop.js --network $NETWORK
```

### 5.3 部署输出示例

```
================================================================================
SUK空投合约部署
================================================================================

📋 部署配置:
--------------------------------------------------------------------------------
网络: goerli
SUK代币地址: 0xabcd...ef01
部署者: 0x1234...5678
部署者余额: 0.45 ETH

⏰ 时间配置:
--------------------------------------------------------------------------------
当前时间: 2024-11-16 14:00:00
白名单开始: 2024-11-16 15:00:00
公开开始: 2024-11-19 15:00:00
结束时间: 2024-12-19 15:00:00

🔍 验证SUK代币合约...
--------------------------------------------------------------------------------
代币名称: SUK Protocol
代币符号: SUK
小数位: 18
✅ SUK代币验证通过

🚀 开始部署空投合约...
--------------------------------------------------------------------------------
部署中...
✅ SUKAirdrop 已部署!
合约地址: 0x9876...5432
交易哈希: 0xabcd...ef01

⏳ 等待区块确认...
✅ 已确认

🔍 验证部署...
--------------------------------------------------------------------------------
总空投量: 1000000.0 SUK
白名单额度: 5000.0 SUK
公开额度: 3000.0 SUK
已认领: 0.0 SUK
剩余: 1000000.0 SUK

✅ 部署验证通过

💾 部署信息已保存: deployment/airdrop-goerli-1700000000000.json

================================================================================
✅ 空投合约部署完成!
================================================================================

📝 后续步骤:
--------------------------------------------------------------------------------

1️⃣  转移SUK代币到空投合约
   数量: 1,000,000 SUK
   目标地址: 0x9876...5432
   
   使用以下命令:
   export AIRDROP_ADDRESS=0x9876...5432
   npx hardhat run scripts/3-fund-airdrop.js --network goerli

2️⃣  添加白名单地址
   准备 whitelist.csv 文件
   
   使用以下命令:
   npx hardhat run scripts/import-whitelist.js --network goerli

3️⃣  更新前端配置
   编辑 suk-airdrop.html:
   AIRDROP_CONTRACT_ADDRESS = "0x9876...5432"
   SUK_TOKEN_ADDRESS = "0xabcd...ef01"
```

### 5.4 保存空投合约地址

```bash
export AIRDROP_ADDRESS=0x9876...5432  # 替换为实际地址

# 或添加到.env
echo "AIRDROP_ADDRESS=0x9876...5432" >> .env
```

---

## 步骤6: 转移代币

### 6.1 确认环境变量

```bash
echo $SUK_TOKEN_ADDRESS
echo $AIRDROP_ADDRESS
```

### 6.2 执行转账

```bash
npx hardhat run scripts/3-fund-airdrop.js --network $NETWORK
```

### 6.3 转账输出示例

```
================================================================================
转移SUK代币到空投合约
================================================================================

📋 配置:
--------------------------------------------------------------------------------
网络: goerli
SUK代币: 0xabcd...ef01
空投合约: 0x9876...5432
转移数量: 1000000 SUK
发送者: 0x1234...5678

🔗 连接合约...

💰 检查余额...
--------------------------------------------------------------------------------
您的SUK余额: 1000000000.0 SUK
需要转移: 1000000 SUK
空投合约当前余额: 0.0 SUK

💸 转移SUK代币...
--------------------------------------------------------------------------------
交易哈希: 0x1234...5678
等待确认...
✅ 转账成功!
Gas使用: 65432

🔍 验证转账...
--------------------------------------------------------------------------------
您的新余额: 999000000.0 SUK
空投合约新余额: 1000000.0 SUK

✅ 验证通过

📊 空投合约状态:
--------------------------------------------------------------------------------
合约SUK余额: 1000000.0 SUK
已认领: 0.0 SUK
剩余可认领: 1000000.0 SUK

================================================================================
✅ 转账完成!
================================================================================

📝 后续步骤:
--------------------------------------------------------------------------------
1️⃣  导入白名单
   npx hardhat run scripts/import-whitelist.js --network goerli

2️⃣  更新前端配置
3️⃣  开始空投活动
```

---

## 步骤7: 导入白名单

### 7.1 准备白名单CSV

创建 `whitelist.csv`:

```csv
address,note
0x1234567890123456789012345678901234567890,First RWA Adopter - Alice
0xabcdefabcdefabcdefabcdefabcdefabcdefabcd,Early Investor - Bob
0x1111111111111111111111111111111111111111,Community Leader - Carol
```

### 7.2 执行导入

```bash
npx hardhat run scripts/import-whitelist.js --network $NETWORK
```

### 7.3 导入输出示例

```
================================================================================
SUK空投 - 白名单导入
================================================================================

📋 配置:
--------------------------------------------------------------------------------
合约地址: 0x9876...5432
CSV文件: whitelist.csv
批次大小: 50
模拟运行: 否
网络: goerli

📖 读取CSV文件...
找到 200 条记录

✅ 验证地址格式...
验证结果:
  有效地址: 200
  无效地址: 0
  重复地址: 0

🔗 连接空投合约...
签名者: 0x1234...5678

🔍 检查已存在的白名单...
  已在白名单: 0
  需要添加: 200

📤 开始批量添加...
总数: 200 个地址
批次: 4
每批: 50 个地址

批次 1/4 (50 个地址)...
  交易哈希: 0xabcd...ef01
  ✅ 确认 (Gas: 654321)

批次 2/4 (50 个地址)...
  交易哈希: 0x1234...5678
  ✅ 确认 (Gas: 654321)

批次 3/4 (50 个地址)...
  交易哈希: 0x9876...5432
  ✅ 确认 (Gas: 654321)

批次 4/4 (50 个地址)...
  交易哈希: 0xfedc...ba98
  ✅ 确认 (Gas: 654321)

================================================================================
📊 导入报告
================================================================================

总结:
  成功批次: 4
  失败批次: 0
  总Gas消耗: 2,617,284

💾 报告已保存: whitelist-import-1700000000000.json

✅ 导入完成!
```

---

## 步骤8: 配置前端

### 8.1 更新suk-airdrop.html

编辑 `suk-airdrop.html`，找到以下行：

```javascript
// 合约配置
const AIRDROP_CONTRACT_ADDRESS = '0x...'; // 部署后填入
const SUK_TOKEN_ADDRESS = '0x...'; // SUK代币合约地址
```

替换为实际地址：

```javascript
// 合约配置
const AIRDROP_CONTRACT_ADDRESS = '0x9876...5432'; // 您的空投合约地址
const SUK_TOKEN_ADDRESS = '0xabcd...ef01'; // 您的SUK代币地址
```

### 8.2 更新网络配置 (如果需要)

如果部署到测试网，确保用户知道切换到正确的网络。

---

## 步骤9: 测试验证

### 9.1 功能测试清单

```bash
# 1. 测试代币信息
npx hardhat console --network $NETWORK

> const suk = await ethers.getContractAt("SUKToken", "0xabcd...ef01")
> await suk.name()
> await suk.symbol()
> await suk.totalSupply()

# 2. 测试空投合约
> const airdrop = await ethers.getContractAt("SUKAirdrop", "0x9876...5432")
> await airdrop.getAirdropStats()
> await airdrop.getAirdropStatus()

# 3. 测试白名单
> await airdrop.isWhitelisted("0x1234...")

> .exit
```

### 9.2 前端测试

1. 部署前端到测试环境
2. 打开浏览器访问
3. 连接MetaMask (切换到部署的网络)
4. 测试认领功能
5. 验证代币到账

### 9.3 测试场景

- [ ] 白名单用户可以认领5,000 SUK
- [ ] 非白名单用户在公开期可认领3,000 SUK
- [ ] 重复认领会被拒绝
- [ ] 认领后代币正确到账
- [ ] 统计数据正确更新

---

## ❓ 常见问题

### Q1: 编译失败 "Cannot find module '@openzeppelin/contracts'"

**解决**:
```bash
npm install @openzeppelin/contracts
```

### Q2: 部署失败 "insufficient funds"

**解决**:
- 检查钱包余额是否足够
- 测试网可从水龙头获取ETH
- 主网需要充值真实ETH

### Q3: 合约验证失败

**解决**:
```bash
# 手动验证
npx hardhat verify --network goerli \
  CONTRACT_ADDRESS \
  CONSTRUCTOR_ARG1 \
  CONSTRUCTOR_ARG2
```

### Q4: 白名单导入失败 "Not contract owner"

**解决**:
- 确保使用部署合约的账户
- 检查PRIVATE_KEY是否正确

### Q5: 前端连接失败

**解决**:
- 检查合约地址是否正确
- 确保MetaMask连接到正确的网络
- 检查浏览器控制台错误信息

---

## 📞 获取帮助

- **文档**: SUK_AIRDROP_GUIDE.md
- **技术支持**: tech@suk.link
- **社区**: Discord/Telegram

---

## ✅ 部署检查清单

部署前:
- [ ] 安装所有依赖
- [ ] 配置.env文件
- [ ] 编译通过
- [ ] 测试网充分测试

部署时:
- [ ] SUK代币部署成功
- [ ] 空投合约部署成功
- [ ] 代币转移完成
- [ ] 白名单导入成功
- [ ] 合约验证完成

部署后:
- [ ] 前端配置更新
- [ ] 功能测试通过
- [ ] 监控系统启动
- [ ] 文档更新

---

**祝您部署顺利！** 🚀

---

**版权所有 © 2024 SUK Protocol**  
**最后更新**: 2024-11-16
