# 📋 Telegram Mini App 完整测试指南

## 测试目标

验证SUK短剧平台Telegram Mini App的完整功能流程，包括：
- ✅ 用户认证
- ✅ 剧集列表加载
- ✅ 分类筛选
- ✅ 主题适配
- ✅ UI响应式布局

---

## 🔧 测试前准备

### 1. 环境检查

运行环境检查脚本：
```bash
npm run test:env
```

**预期输出：**
```
✅ 环境变量配置完整
✅ 必需的配置项已设置
✅ TELEGRAM_BOT_TOKEN: 已配置
✅ MONGODB_URI: 已配置
✅ REDIS_HOST: 已配置
```

### 2. 数据库连接测试

测试MongoDB和Redis连接：
```bash
npm run test:db
```

**预期输出：**
```
===== MongoDB连接测试 =====
✅ MongoDB连接成功！
✅ 写入测试数据成功
✅ 读取测试数据成功
✅ 清理测试数据成功

===== Redis连接测试 =====
✅ Redis连接成功！
✅ SET命令测试成功
✅ GET命令测试成功
✅ DEL命令测试成功
```

### 3. 安装依赖

如果还未安装依赖：
```bash
npm install
```

---

## 🚀 启动服务器

### 方式1: 开发模式（推荐用于测试）

```bash
npm run dev
```

**预期输出：**
```
[nodemon] starting `node server.js`
✅ MongoDB连接成功！
✅ Redis连接成功！
🚀 服务器运行在端口: 3000
环境: development
```

### 方式2: 生产模式

```bash
npm start
```

---

## 🧪 API端点测试

### 1. 健康检查

```bash
curl http://localhost:3000/health
```

**预期响应：**
```json
{
  "status": "ok",
  "timestamp": "2024-01-15T10:30:00.000Z",
  "mongodb": true,
  "redis": true
}
```

### 2. Telegram健康检查

```bash
curl http://localhost:3000/api/telegram/health
```

**预期响应：**
```json
{
  "success": true,
  "service": "telegram-mini-app",
  "version": "1.0.0"
}
```

### 3. 获取剧集列表（需要认证）

由于需要Telegram initData进行认证，此步骤在Telegram内测试。

---

## 🌐 使用ngrok创建HTTPS隧道

Telegram Mini App **必须使用HTTPS**，本地开发需要ngrok。

### 1. 安装ngrok

访问 https://ngrok.com/ 注册并下载：

**macOS:**
```bash
brew install ngrok/ngrok/ngrok
```

**Windows:**
下载exe文件：https://ngrok.com/download

**Linux:**
```bash
curl -s https://ngrok-agent.s3.amazonaws.com/ngrok.asc | sudo tee /etc/apt/trusted.gpg.d/ngrok.asc >/dev/null
echo "deb https://ngrok-agent.s3.amazonaws.com buster main" | sudo tee /etc/apt/sources.list.d/ngrok.list
sudo apt update && sudo apt install ngrok
```

### 2. 认证ngrok

```bash
ngrok config add-authtoken YOUR_AUTH_TOKEN
```

### 3. 启动隧道

在**新终端窗口**运行：
```bash
ngrok http 3000
```

**预期输出：**
```
Session Status                online
Account                       your_email@example.com
Version                       3.x.x
Region                        United States (us)
Forwarding                    https://abc123.ngrok.io -> http://localhost:3000
```

**📝 重要：记录HTTPS URL（例如：https://abc123.ngrok.io）**

### 4. 测试ngrok URL

```bash
curl https://abc123.ngrok.io/health
```

---

## 🤖 创建和配置Telegram Bot

### 步骤1: 创建Bot

1. 在Telegram中搜索 **@BotFather**
2. 发送命令: `/newbot`
3. 按提示输入Bot名称（例如：SUK Drama Platform）
4. 输入Bot用户名（例如：SUKDramaPlatformBot）
5. 收到Bot Token（格式：`1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`）

### 步骤2: 保存Bot Token

将Token添加到`.env`文件：
```bash
TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
```

**重启服务器以加载新配置！**

### 步骤3: 设置Bot描述

在@BotFather中：
```
/setdescription
选择你的Bot
输入描述：
```

**建议描述：**
```
🎬 SUK短剧平台 - 精彩短剧随时看

• 海量短剧资源
• 多种支付方式（Stars/TON/SUK代币）
• 观看历史自动保存
• 无缝续播体验

立即开始观看精彩内容！
```

### 步骤4: 设置Bot命令

在@BotFather中：
```
/setcommands
选择你的Bot
输入命令列表：
```

**建议命令：**
```
start - 启动Mini App
help - 获取帮助
wallet - 查看钱包
history - 观看历史
support - 联系客服
```

### 步骤5: 设置Menu Button（关键步骤！）

在@BotFather中：
```
/setmenubutton
选择你的Bot
选择: Configure menu button
输入按钮文字: 🎬 打开剧场
输入URL: https://YOUR_NGROK_URL/telegram-app.html
```

**替换YOUR_NGROK_URL为你的实际ngrok URL！**

例如：`https://abc123.ngrok.io/telegram-app.html`

### 步骤6: 测试Bot配置

运行测试脚本：
```bash
npm run test:telegram
```

**预期输出：**
```
===== Telegram Bot配置测试 =====

[1/3] 测试Bot Token...
✅ Bot Token验证成功！
Bot名称: SUK Drama Platform
Bot用户名: @SUKDramaPlatformBot

[2/3] 测试Webhook配置...
✅ Webhook配置正常
当前Webhook URL: (未设置)

[3/3] 测试Bot命令...
✅ Bot命令配置成功
已配置命令: start, help, wallet, history, support

===== 所有测试通过！ =====
```

---

## 📱 在Telegram中测试Mini App

### 1. 打开Bot

在Telegram中搜索你的Bot用户名（例如：@SUKDramaPlatformBot）

### 2. 启动Bot

点击 **START** 按钮或发送 `/start`

### 3. 打开Mini App

点击底部的 **🎬 打开剧场** 按钮

### 4. 功能测试清单

#### ✅ 用户信息显示
- [ ] 显示用户头像
- [ ] 显示用户名称
- [ ] 显示用户名 (@username)
- [ ] Premium用户显示徽章

#### ✅ 主题适配
- [ ] 切换Telegram到深色模式，Mini App同步变深色
- [ ] 切换Telegram到浅色模式，Mini App同步变浅色
- [ ] 按钮颜色匹配Telegram主题
- [ ] 文字颜色适配主题

#### ✅ 剧集列表
- [ ] 显示剧集卡片网格
- [ ] 每个卡片显示：封面、标题、评分、播放量、价格
- [ ] 价格显示三种货币：SUK代币、Stars、TON
- [ ] 网格响应式布局（手机2列，平板3列，桌面4列）

#### ✅ 分类筛选
- [ ] 显示分类选项：全部、爱情、玄幻、剧情、喜剧、动作
- [ ] 点击分类可以筛选剧集
- [ ] 选中的分类高亮显示
- [ ] 分类标签可横向滚动

#### ✅ 主按钮
- [ ] 底部显示"💰 充值SUK代币"按钮
- [ ] 按钮颜色匹配Telegram主题
- [ ] 点击按钮显示提示弹窗

#### ✅ 交互体验
- [ ] 页面可以全屏显示
- [ ] 关闭时有确认提示
- [ ] 加载状态显示动画
- [ ] 空状态显示友好提示

---

## 🐛 常见问题排查

### 问题1: Mini App无法加载

**症状：** 点击菜单按钮后白屏或加载失败

**排查步骤：**
1. 检查ngrok是否正在运行：
   ```bash
   # 在ngrok终端查看请求日志
   ```

2. 检查服务器是否启动：
   ```bash
   curl http://localhost:3000/health
   ```

3. 检查HTTPS URL是否正确：
   ```bash
   curl https://YOUR_NGROK_URL/telegram-app.html
   ```

4. 在@BotFather中重新设置Menu Button URL

### 问题2: API返回401错误

**症状：** 控制台显示"Telegram认证失败"

**可能原因：**
- Bot Token未配置或错误
- initData签名验证失败
- 时间戳过期（initData有效期5分钟）

**解决方法：**
1. 验证.env中的TELEGRAM_BOT_TOKEN
2. 重启服务器加载新配置
3. 刷新Mini App重新获取initData

### 问题3: 主题颜色未应用

**症状：** Mini App显示白色背景，未适配Telegram主题

**解决方法：**
1. 检查浏览器控制台是否有JavaScript错误
2. 确认Telegram WebApp SDK已加载：
   ```javascript
   console.log(window.Telegram.WebApp);
   ```
3. 检查themeParams是否有值：
   ```javascript
   console.log(window.Telegram.WebApp.themeParams);
   ```

### 问题4: 数据库连接失败

**症状：** 服务器启动时报MongoDB或Redis连接错误

**解决方法：**
1. 确认MongoDB已启动：
   ```bash
   # macOS
   brew services start mongodb-community
   
   # Linux
   sudo systemctl start mongod
   ```

2. 确认Redis已启动：
   ```bash
   # macOS
   brew services start redis
   
   # Linux
   sudo systemctl start redis
   ```

3. 检查连接配置：
   ```bash
   npm run test:db
   ```

### 问题5: ngrok隧道断开

**症状：** Mini App突然无法访问，之前正常

**原因：** ngrok免费版会话有时间限制

**解决方法：**
1. 重启ngrok：
   ```bash
   ngrok http 3000
   ```

2. 复制新的HTTPS URL

3. 在@BotFather更新Menu Button URL

---

## 📊 测试结果记录

### 测试环境

- **日期：** _____________
- **测试人：** _____________
- **ngrok URL：** _____________
- **Bot用户名：** _____________

### 功能测试结果

| 功能模块 | 测试项 | 状态 | 备注 |
|---------|-------|------|------|
| 用户认证 | 用户信息显示 | ⬜ |  |
| 用户认证 | Premium徽章 | ⬜ |  |
| 主题适配 | 深色模式 | ⬜ |  |
| 主题适配 | 浅色模式 | ⬜ |  |
| 剧集列表 | 加载显示 | ⬜ |  |
| 剧集列表 | 响应式布局 | ⬜ |  |
| 分类筛选 | 筛选功能 | ⬜ |  |
| 分类筛选 | 高亮显示 | ⬜ |  |
| 主按钮 | 显示正确 | ⬜ |  |
| 主按钮 | 点击响应 | ⬜ |  |

**状态说明：** ⬜ 未测试 | ✅ 通过 | ❌ 失败

---

## 🎯 下一步开发任务

测试完成后，可以继续开发以下功能：

### 优先级1: 剧集详情页
- 创建`telegram-drama-detail.html`
- 实现购买流程
- 显示剧集列表

### 优先级2: 视频播放器
- 创建`telegram-player.html`
- 集成Aliyun VoD播放器
- 实现续播功能

### 优先级3: 支付功能
- 实现Telegram Stars支付
- 添加支付成功回调处理
- 更新用户购买记录

### 优先级4: 用户中心
- 创建`telegram-wallet.html`
- 显示余额和交易历史
- 实现充值功能

---

## 📞 获取帮助

如果遇到问题：

1. **查看日志：** 检查服务器终端输出
2. **浏览器控制台：** 在Telegram中无法打开开发者工具，建议先在桌面浏览器测试
3. **文档参考：** 查看`TELEGRAM_MINI_APP_GUIDE.md`详细文档
4. **API测试：** 使用Postman或curl测试API端点

---

## ✅ 测试完成检查清单

- [ ] 环境变量配置完整
- [ ] 数据库连接正常
- [ ] 服务器成功启动
- [ ] ngrok隧道已建立
- [ ] Telegram Bot已创建
- [ ] Menu Button已配置
- [ ] Mini App可以打开
- [ ] 用户信息正确显示
- [ ] 主题适配工作正常
- [ ] 剧集列表加载成功
- [ ] 分类筛选功能正常
- [ ] 主按钮显示和响应正常
- [ ] 无控制台错误
- [ ] 响应式布局正常

**全部完成后，基础功能测试通过！🎉**
