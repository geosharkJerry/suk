# 短剧版权质押智能合约部署指南

## 📋 概览

本文档提供 SUK Protocol 短剧版权质押智能合约的完整部署指南。

**核心机制说明**：
- ✅ 质押方只能使用 **SUK 代币**，不发行新的代币品种
- ✅ 版权方质押 SUK 等值代币到合约
- ✅ 投资者用 SUK 代币认购质押份额
- ✅ 收益以 SUK 代币形式分配
- ❌ 不发行短剧专属代币（如 BZ-DT、FQ-DT 等）

---

## 🔗 支持的区块链

### 1. Solana（推荐）⭐
- **优势**：高性能（65,000+ TPS）、低手续费（$0.00025）、快速确认（400ms）
- **合约语言**：Rust + Anchor Framework
- **文件位置**：`contracts/solana/drama_ip_staking/`

### 2. Ethereum
- **优势**：最成熟的智能合约生态、安全性高、工具完善
- **合约语言**：Solidity ^0.8.20
- **文件位置**：`contracts/ethereum/`

---

## 🚀 Solana 合约部署

### 前置条件

```bash
# 安装 Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# 安装 Solana CLI
sh -c "$(curl -sSfL https://release.solana.com/stable/install)"

# 安装 Anchor Framework
cargo install --git https://github.com/coral-xyz/anchor avm --locked --force
avm install latest
avm use latest

# 验证安装
solana --version
anchor --version
```

### 步骤 1: 创建钱包

```bash
# 创建新钱包
solana-keygen new

# 查看钱包地址
solana address

# 切换到开发网
solana config set --url devnet

# 获取测试 SOL
solana airdrop 2
```

### 步骤 2: 构建合约

```bash
cd contracts/solana/drama_ip_staking

# 安装依赖
npm install

# 构建合约
anchor build
```

### 步骤 3: 部署合约

```bash
# 部署到 Devnet
anchor deploy --provider.cluster devnet

# 输出类似：
# Program Id: DramaStakingProgramIDxxxxxxxxxxxxxxxxxxxxxxxxxx
```

### 步骤 4: 初始化质押池

```javascript
const anchor = require("@coral-xyz/anchor");

// 连接到程序
const programId = new anchor.web3.PublicKey("YOUR_PROGRAM_ID");
const program = new anchor.Program(idl, programId, provider);

// 初始化质押池
const [stakingPoolPDA] = await anchor.web3.PublicKey.findProgramAddress(
  [Buffer.from("staking_pool")],
  program.programId
);

await program.methods
  .initializeStakingPool("SUK-DRAMA-POOL-001")
  .accounts({
    stakingPool: stakingPoolPDA,
    authority: provider.wallet.publicKey,
    systemProgram: anchor.web3.SystemProgram.programId,
  })
  .rpc();

console.log("✅ 质押池初始化成功！");
```

### 步骤 5: 运行测试

```bash
# 运行单元测试
anchor test

# 输出应显示所有测试通过 ✅
```

---

## 🔷 Ethereum 合约部署

### 前置条件

```bash
# 安装 Node.js (v18+)
# 推荐使用 nvm
nvm install 18
nvm use 18

# 进入合约目录
cd contracts/ethereum

# 安装依赖
npm install
```

### 步骤 1: 配置环境变量

创建 `.env` 文件：

```bash
# 私钥（不要泄露！）
PRIVATE_KEY=your_private_key_here

# RPC 节点（推荐使用 Infura/Alchemy）
SEPOLIA_RPC_URL=https://sepolia.infura.io/v3/YOUR_PROJECT_ID
MAINNET_RPC_URL=https://mainnet.infura.io/v3/YOUR_PROJECT_ID

# Etherscan API Key（用于验证合约）
ETHERSCAN_API_KEY=your_etherscan_api_key

# SUK Token 地址（需要先部署 SUK ERC20 合约）
SUK_TOKEN_ADDRESS=0x...
```

### 步骤 2: 编译合约

```bash
# 编译合约
npx hardhat compile

# 输出：
# Compiled 1 Solidity file successfully
```

### 步骤 3: 本地测试

```bash
# 启动本地节点
npx hardhat node

# 新终端：运行测试
npx hardhat test

# 输出应显示所有测试通过 ✅
```

### 步骤 4: 部署到测试网（Sepolia）

创建 `scripts/deploy.js`:

```javascript
const hre = require("hardhat");

async function main() {
  console.log("🚀 开始部署 DramaIPStaking 合约...\n");

  // 1. 部署 SUK Token（如果还没部署）
  console.log("1️⃣ 部署 SUK Token...");
  const SUKToken = await hre.ethers.getContractFactory("ERC20Mock");
  const sukToken = await SUKToken.deploy("SUK Token", "SUK");
  await sukToken.waitForDeployment();
  const sukTokenAddress = await sukToken.getAddress();
  console.log(`✅ SUK Token 部署成功: ${sukTokenAddress}\n`);

  // 2. 部署 DramaIPStaking 合约
  console.log("2️⃣ 部署 DramaIPStaking 合约...");
  const DramaIPStaking = await hre.ethers.getContractFactory("DramaIPStaking");
  const dramaIPStaking = await DramaIPStaking.deploy(sukTokenAddress);
  await dramaIPStaking.waitForDeployment();
  const stakingAddress = await dramaIPStaking.getAddress();
  console.log(`✅ DramaIPStaking 部署成功: ${stakingAddress}\n`);

  // 3. 输出部署信息
  console.log("📝 部署信息总结");
  console.log("=".repeat(60));
  console.log(`SUK Token 地址:        ${sukTokenAddress}`);
  console.log(`DramaIPStaking 地址:   ${stakingAddress}`);
  console.log("=".repeat(60));
  
  console.log("\n✅ 部署完成！请保存以上地址用于后续操作。");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
```

执行部署：

```bash
# 部署到 Sepolia 测试网
npx hardhat run scripts/deploy.js --network sepolia

# 等待交易确认...
```

### 步骤 5: 验证合约（可选但推荐）

```bash
# 验证 DramaIPStaking 合约
npx hardhat verify --network sepolia STAKING_CONTRACT_ADDRESS "SUK_TOKEN_ADDRESS"

# 成功后可在 Etherscan 查看源代码
```

### 步骤 6: 部署到主网

```bash
# ⚠️ 确保已充分测试！
npx hardhat run scripts/deploy.js --network mainnet
```

---

## 📊 合约功能说明

### 版权方操作

#### 1. 提交质押申请

```solidity
function submitDramaStaking(
    string memory dramaId,           // 短剧ID，如 "BZ-2024-001"
    string memory dramaTitle,        // 短剧标题
    StakingType stakingType,         // 质押类型（0=版权方，1=出品方，2=AI创作者，3=联合）
    uint256 totalRevenueEstimate,    // 预期总收益（USD）
    uint256 sukAmountToStake,        // 质押SUK数量
    uint8 revenueSharePercentage,    // 收益分配比例（20-60%）
    string memory metadataURI        // 元数据URI（IPFS）
) external
```

**示例调用**：
```javascript
await contract.submitDramaStaking(
  "BZ-2024-001",
  "霸总的替身新娘",
  0, // COPYRIGHT_HOLDER
  1000000, // $1,000,000 预期收益
  ethers.parseUnits("1000000", 18), // 1,000,000 SUK
  60, // 版权方获得60%收益
  "ipfs://QmExampleMetadata..."
);
```

#### 2. KYC审核（管理员）

```solidity
function reviewKYC(
    string memory dramaId,
    bool approved,
    string memory reviewNotes
) external onlyRole(KYC_REVIEWER_ROLE)
```

### 投资者操作

#### 3. 认购投资

```solidity
function investInDrama(
    string memory dramaId,
    uint256 sukAmount
) external
```

**示例**：
```javascript
// 1. 先授权合约使用SUK
await sukToken.approve(stakingContract, ethers.parseUnits("10000", 18));

// 2. 投资
await stakingContract.investInDrama("BZ-2024-001", ethers.parseUnits("10000", 18));
```

#### 4. 领取收益

```solidity
function claimRevenue(string memory dramaId) external
```

### 管理员操作

#### 5. 分发收益

```solidity
function distributeRevenue(
    string memory dramaId,
    uint256 revenueAmountSuk
) external onlyRole(ADMIN_ROLE)
```

#### 6. 紧急暂停

```solidity
function emergencyPauseDrama(string memory dramaId) external onlyRole(ADMIN_ROLE)
function resumeDramaOperations(string memory dramaId) external onlyRole(ADMIN_ROLE)
```

---

## 🔐 安全注意事项

### 1. 权限管理

```solidity
// 管理员角色
bytes32 public constant ADMIN_ROLE = keccak256("ADMIN_ROLE");

// KYC审核员角色
bytes32 public constant KYC_REVIEWER_ROLE = keccak256("KYC_REVIEWER_ROLE");
```

**授予角色**：
```javascript
const ADMIN_ROLE = await contract.ADMIN_ROLE();
await contract.grantRole(ADMIN_ROLE, adminAddress);

const KYC_ROLE = await contract.KYC_REVIEWER_ROLE();
await contract.grantRole(KYC_ROLE, reviewerAddress);
```

### 2. 代币授权

投资者和版权方在使用合约前必须先授权：

```javascript
// 授权合约使用代币
await sukToken.approve(
  stakingContractAddress,
  ethers.MaxUint256 // 或具体数量
);
```

### 3. 重入攻击防护

合约已使用 OpenZeppelin 的 `ReentrancyGuard`：

```solidity
function investInDrama(...) external nonReentrant { ... }
function claimRevenue(...) external nonReentrant { ... }
```

### 4. 暂停机制

紧急情况下可暂停整个合约：

```javascript
// 暂停
await contract.pause();

// 恢复
await contract.unpause();
```

---

## 🧪 测试数据示例

### 测试场景 1: 版权方质押

```javascript
// 短剧信息
const drama = {
  id: "BZ-2024-001",
  title: "霸总的替身新娘",
  type: 0, // COPYRIGHT_HOLDER
  revenue: 1000000, // $1M
  stakeAmount: ethers.parseUnits("1000000", 18), // 1M SUK
  revenueShare: 60 // 60%
};
```

### 测试场景 2: 投资者认购

```javascript
// 投资者1: 10,000 SUK
await contract.connect(investor1).investInDrama(drama.id, ethers.parseUnits("10000", 18));

// 投资者2: 5,000 SUK
await contract.connect(investor2).investInDrama(drama.id, ethers.parseUnits("5000", 18));

// 总投资: 15,000 SUK
```

### 测试场景 3: 收益分配

```javascript
// 短剧产生收益 10,000 SUK
const revenue = ethers.parseUnits("10000", 18);

// 分配：
// - 投资者: 6,000 SUK (60%)
// - 版权方: 3,000 SUK (30%)
// - 平台:     500 SUK (5%)
// - 回购:     500 SUK (5%)

await contract.distributeRevenue(drama.id, revenue);
```

### 测试场景 4: 投资者领取

```javascript
// 投资者1占比: 10,000 / 15,000 = 66.67%
// 应得收益: 6,000 * 66.67% = 4,000 SUK

await contract.connect(investor1).claimRevenue(drama.id);
// 投资者1获得 4,000 SUK ✅

await contract.connect(investor2).claimRevenue(drama.id);
// 投资者2获得 2,000 SUK ✅
```

---

## 📈 收益分配机制

### 分配规则

| 角色 | 比例 | 说明 |
|------|------|------|
| **投资者** | 60% | 所有持有SUK份额的投资者按比例分配 |
| **版权方/出品方** | 30% | 短剧版权拥有者或出品方 |
| **平台运营** | 5% | 平台维护和运营费用 |
| **SUK回购销毁** | 5% | 用于SUK代币通缩机制 |

### 计算公式

```javascript
// 投资者个人应得收益
investorRevenue = totalRevenue * 60% * (investorSUK / totalInvestedSUK)

// 示例：
// 总收益: 10,000 SUK
// 投资者池: 6,000 SUK (60%)
// 投资者1投资: 10,000 SUK (占总投资 15,000 的 66.67%)
// 投资者1应得: 6,000 * 66.67% = 4,000 SUK ✅
```

---

## 🔍 合约查询方法

### 获取短剧详情

```javascript
const drama = await contract.getDramaDetails("BZ-2024-001");

console.log("短剧标题:", drama.dramaTitle);
console.log("质押SUK:", ethers.formatUnits(drama.sukAmountStaked, 18));
console.log("总投资者:", drama.totalInvestors.toString());
console.log("总投资额:", ethers.formatUnits(drama.totalSukInvested, 18));
console.log("KYC状态:", drama.kycStatus); // 0=Pending, 1=Approved, 2=Rejected
console.log("是否激活:", drama.isActive);
```

### 获取投资者信息

```javascript
const investor = await contract.getInvestorInfo("BZ-2024-001", investorAddress);

console.log("投资金额:", ethers.formatUnits(investor.sukAmountInvested, 18));
console.log("已领收益:", ethers.formatUnits(investor.revenueClaimed, 18));
```

### 计算可领取收益

```javascript
const claimable = await contract.calculateClaimableRevenue("BZ-2024-001", investorAddress);

console.log("可领取收益:", ethers.formatUnits(claimable, 18), "SUK");
```

### 获取所有短剧列表

```javascript
const allDramas = await contract.getAllDramaIds();

console.log("已质押短剧数量:", allDramas.length);
console.log("短剧列表:", allDramas);
```

---

## 🛠️ 常见问题

### Q1: 为什么不发行短剧专属代币？

**A**: 为了简化代币经济模型并增强流动性，所有交易和收益都使用统一的 SUK 代币。这样：
- ✅ 减少代币碎片化
- ✅ 提高 SUK 代币使用率
- ✅ 降低投资者学习成本
- ✅ 增强生态统一性

### Q2: KYC 审核需要多久？

**A**: 通常 3-5 个工作日。审核内容包括：
- 版权登记证书
- 版权转让协议或独家授权证明
- 企业营业执照（如适用）
- 历史收益报表

### Q3: 收益如何计算？

**A**: 基于投资比例自动计算：
```
个人收益 = 总收益 * 60% * (个人投资SUK / 总投资SUK)
```

### Q4: 可以随时提取投资本金吗？

**A**: ❌ 不可以。质押期间本金锁定，只能领取收益分红。这确保短剧项目的资金稳定性。

### Q5: 如何监控短剧收益表现？

**A**: 可以通过：
- 合约查询方法 `getDramaDetails()`
- 区块链浏览器（Etherscan/Solscan）
- 前端仪表板（开发中）

---

## 📞 技术支持

- **官方文档**: DOCS.SUK.LINK
- **GitHub**: github.com/suk-protocol
- **Discord**: discord.gg/suk-protocol
- **Email**: dev@suk.link

---

## ⚠️ 免责声明

本智能合约仅供学习和测试使用。在主网部署前请务必：
1. 进行全面的安全审计
2. 购买智能合约保险
3. 遵守当地法律法规
4. 充分测试所有功能

---

**最后更新**: 2025-11-18  
**合约版本**: v1.0.0  
**许可证**: MIT
