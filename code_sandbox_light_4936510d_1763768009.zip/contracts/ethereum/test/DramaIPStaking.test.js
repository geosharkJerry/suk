const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("DramaIPStaking - 短剧版权质押智能合约测试", function () {
  let dramaIPStaking;
  let sukToken;
  let owner, admin, copyrightHolder, investor1, investor2, kycReviewer;

  const DRAMA_ID = "BZ-2024-001";
  const DRAMA_TITLE = "霸总的替身新娘";
  const ONE_MILLION_SUK = ethers.parseUnits("1000000", 18);
  const TEN_THOUSAND_SUK = ethers.parseUnits("10000", 18);
  const FIVE_THOUSAND_SUK = ethers.parseUnits("5000", 18);

  beforeEach(async function () {
    [owner, admin, copyrightHolder, investor1, investor2, kycReviewer] = 
      await ethers.getSigners();

    console.log("\n🔧 初始化测试环境...");

    // 1. 部署 SUK 代币（模拟ERC20）
    const SUKToken = await ethers.getContractFactory("ERC20Mock");
    sukToken = await SUKToken.deploy("SUK Token", "SUK");
    await sukToken.waitForDeployment();
    console.log("✅ SUK Token 部署成功:", await sukToken.getAddress());

    // 2. 部署短剧质押合约
    const DramaIPStaking = await ethers.getContractFactory("DramaIPStaking");
    dramaIPStaking = await DramaIPStaking.deploy(await sukToken.getAddress());
    await dramaIPStaking.waitForDeployment();
    console.log("✅ DramaIPStaking 部署成功:", await dramaIPStaking.getAddress());

    // 3. 铸造SUK代币并分配
    await sukToken.mint(copyrightHolder.address, ONE_MILLION_SUK); // 版权方 100万 SUK
    await sukToken.mint(investor1.address, ethers.parseUnits("100000", 18)); // 投资者1 10万 SUK
    await sukToken.mint(investor2.address, ethers.parseUnits("50000", 18));  // 投资者2 5万 SUK
    console.log("✅ SUK 代币分配完成");

    // 4. 授权合约使用代币
    await sukToken.connect(copyrightHolder).approve(
      await dramaIPStaking.getAddress(),
      ethers.MaxUint256
    );
    await sukToken.connect(investor1).approve(
      await dramaIPStaking.getAddress(),
      ethers.MaxUint256
    );
    await sukToken.connect(investor2).approve(
      await dramaIPStaking.getAddress(),
      ethers.MaxUint256
    );
    console.log("✅ 代币授权完成");

    // 5. 授予KYC审核员角色
    const KYC_REVIEWER_ROLE = await dramaIPStaking.KYC_REVIEWER_ROLE();
    await dramaIPStaking.grantRole(KYC_REVIEWER_ROLE, kycReviewer.address);
    console.log("✅ KYC审核员角色授予完成\n");
  });

  describe("1️⃣ 短剧质押申请", function () {
    it("应该成功提交短剧质押申请", async function () {
      console.log("📝 测试：版权方提交短剧质押申请");

      const tx = await dramaIPStaking.connect(copyrightHolder).submitDramaStaking(
        DRAMA_ID,
        DRAMA_TITLE,
        0, // StakingType.COPYRIGHT_HOLDER
        1000000, // 预期收益 $1,000,000
        ONE_MILLION_SUK,
        60, // 版权方获得60%收益
        "ipfs://QmExampleMetadata123456789"
      );

      await expect(tx)
        .to.emit(dramaIPStaking, "DramaStakingSubmitted")
        .withArgs(DRAMA_ID, copyrightHolder.address, DRAMA_TITLE, ONE_MILLION_SUK, await ethers.provider.getBlock("latest").then(b => b.timestamp));

      const drama = await dramaIPStaking.getDramaDetails(DRAMA_ID);
      expect(drama.dramaTitle).to.equal(DRAMA_TITLE);
      expect(drama.sukAmountStaked).to.equal(ONE_MILLION_SUK);
      expect(drama.kycStatus).to.equal(0); // PENDING
      expect(drama.isActive).to.be.false;

      console.log("✅ 短剧质押申请提交成功");
      console.log(`   短剧ID: ${drama.dramaId}`);
      console.log(`   短剧标题: ${drama.dramaTitle}`);
      console.log(`   质押SUK: ${ethers.formatUnits(drama.sukAmountStaked, 18)}`);
    });

    it("应该拒绝重复的短剧ID", async function () {
      await dramaIPStaking.connect(copyrightHolder).submitDramaStaking(
        DRAMA_ID,
        DRAMA_TITLE,
        0,
        1000000,
        ONE_MILLION_SUK,
        60,
        "ipfs://test"
      );

      await expect(
        dramaIPStaking.connect(copyrightHolder).submitDramaStaking(
          DRAMA_ID,
          "另一部剧",
          0,
          500000,
          ethers.parseUnits("500000", 18),
          50,
          "ipfs://test2"
        )
      ).to.be.revertedWith("Drama ID already exists");
    });

    it("应该拒绝无效的收益分配比例", async function () {
      await expect(
        dramaIPStaking.connect(copyrightHolder).submitDramaStaking(
          "TEST-001",
          "测试短剧",
          0,
          1000000,
          ONE_MILLION_SUK,
          70, // 超过60%
          "ipfs://test"
        )
      ).to.be.revertedWith("Revenue share must be between 20% and 60%");
    });
  });

  describe("2️⃣ KYC审核", function () {
    beforeEach(async function () {
      await dramaIPStaking.connect(copyrightHolder).submitDramaStaking(
        DRAMA_ID,
        DRAMA_TITLE,
        0,
        1000000,
        ONE_MILLION_SUK,
        60,
        "ipfs://test"
      );
    });

    it("应该成功通过KYC审核并锁定SUK", async function () {
      console.log("\n📝 测试：KYC审核通过");

      const balanceBefore = await sukToken.balanceOf(copyrightHolder.address);
      
      await dramaIPStaking.connect(kycReviewer).reviewKYC(
        DRAMA_ID,
        true,
        "版权证明齐全，审核通过"
      );

      const balanceAfter = await sukToken.balanceOf(copyrightHolder.address);
      const drama = await dramaIPStaking.getDramaDetails(DRAMA_ID);

      expect(drama.kycStatus).to.equal(1); // APPROVED
      expect(drama.isActive).to.be.true;
      expect(balanceBefore - balanceAfter).to.equal(ONE_MILLION_SUK);

      console.log("✅ KYC审核通过，SUK已锁定");
      console.log(`   锁定数量: ${ethers.formatUnits(ONE_MILLION_SUK, 18)} SUK`);
    });

    it("应该能够拒绝KYC审核", async function () {
      await dramaIPStaking.connect(kycReviewer).reviewKYC(
        DRAMA_ID,
        false,
        "版权证明不足"
      );

      const drama = await dramaIPStaking.getDramaDetails(DRAMA_ID);
      expect(drama.kycStatus).to.equal(2); // REJECTED
      expect(drama.isActive).to.be.false;
    });
  });

  describe("3️⃣ 投资者认购", function () {
    beforeEach(async function () {
      await dramaIPStaking.connect(copyrightHolder).submitDramaStaking(
        DRAMA_ID,
        DRAMA_TITLE,
        0,
        1000000,
        ONE_MILLION_SUK,
        60,
        "ipfs://test"
      );
      await dramaIPStaking.connect(kycReviewer).reviewKYC(DRAMA_ID, true, "通过");
    });

    it("投资者1应该成功投资10,000 SUK", async function () {
      console.log("\n📝 测试：投资者1投资");

      await dramaIPStaking.connect(investor1).investInDrama(DRAMA_ID, TEN_THOUSAND_SUK);

      const drama = await dramaIPStaking.getDramaDetails(DRAMA_ID);
      const investor = await dramaIPStaking.getInvestorInfo(DRAMA_ID, investor1.address);

      expect(drama.totalInvestors).to.equal(1);
      expect(drama.totalSukInvested).to.equal(TEN_THOUSAND_SUK);
      expect(investor.sukAmountInvested).to.equal(TEN_THOUSAND_SUK);

      console.log("✅ 投资者1投资成功");
      console.log(`   投资金额: ${ethers.formatUnits(TEN_THOUSAND_SUK, 18)} SUK`);
      console.log(`   总投资者: ${drama.totalInvestors}`);
    });

    it("投资者2应该成功投资5,000 SUK", async function () {
      await dramaIPStaking.connect(investor1).investInDrama(DRAMA_ID, TEN_THOUSAND_SUK);
      await dramaIPStaking.connect(investor2).investInDrama(DRAMA_ID, FIVE_THOUSAND_SUK);

      const drama = await dramaIPStaking.getDramaDetails(DRAMA_ID);
      expect(drama.totalInvestors).to.equal(2);
      expect(drama.totalSukInvested).to.equal(TEN_THOUSAND_SUK + FIVE_THOUSAND_SUK);
    });

    it("应该拒绝对未激活短剧的投资", async function () {
      await dramaIPStaking.connect(owner).emergencyPauseDrama(DRAMA_ID);

      await expect(
        dramaIPStaking.connect(investor1).investInDrama(DRAMA_ID, TEN_THOUSAND_SUK)
      ).to.be.revertedWith("Drama is not active");
    });
  });

  describe("4️⃣ 收益分配与领取", function () {
    beforeEach(async function () {
      await dramaIPStaking.connect(copyrightHolder).submitDramaStaking(
        DRAMA_ID,
        DRAMA_TITLE,
        0,
        1000000,
        ONE_MILLION_SUK,
        60,
        "ipfs://test"
      );
      await dramaIPStaking.connect(kycReviewer).reviewKYC(DRAMA_ID, true, "通过");
      await dramaIPStaking.connect(investor1).investInDrama(DRAMA_ID, TEN_THOUSAND_SUK);
      await dramaIPStaking.connect(investor2).investInDrama(DRAMA_ID, FIVE_THOUSAND_SUK);
    });

    it("应该成功分发收益", async function () {
      console.log("\n📝 测试：管理员分发收益");

      const REVENUE = ethers.parseUnits("10000", 18); // 10,000 SUK
      
      // 给合约转入收益（模拟收益来源）
      await sukToken.mint(await dramaIPStaking.getAddress(), REVENUE);

      await dramaIPStaking.connect(owner).distributeRevenue(DRAMA_ID, REVENUE);

      const drama = await dramaIPStaking.getDramaDetails(DRAMA_ID);
      expect(drama.totalRevenueDistributed).to.equal(REVENUE);

      console.log("✅ 收益分配成功");
      console.log(`   总收益: ${ethers.formatUnits(REVENUE, 18)} SUK`);
      console.log(`   投资者获得: ${ethers.formatUnits(REVENUE * 60n / 100n, 18)} SUK (60%)`);
      console.log(`   版权方获得: ${ethers.formatUnits(REVENUE * 30n / 100n, 18)} SUK (30%)`);
    });

    it("投资者应该能够领取收益", async function () {
      console.log("\n📝 测试：投资者领取收益");

      const REVENUE = ethers.parseUnits("10000", 18);
      await sukToken.mint(await dramaIPStaking.getAddress(), REVENUE);
      await dramaIPStaking.connect(owner).distributeRevenue(DRAMA_ID, REVENUE);

      const balanceBefore = await sukToken.balanceOf(investor1.address);
      await dramaIPStaking.connect(investor1).claimRevenue(DRAMA_ID);
      const balanceAfter = await sukToken.balanceOf(investor1.address);

      const claimed = balanceAfter - balanceBefore;
      
      // 投资者1占比: 10000 / 15000 = 66.67%
      // 投资者总收益: 10000 * 60% = 6000 SUK
      // 投资者1应得: 6000 * 66.67% = 4000 SUK
      expect(Number(ethers.formatUnits(claimed, 18))).to.be.closeTo(4000, 10);

      console.log("✅ 投资者1领取收益成功");
      console.log(`   领取金额: ${ethers.formatUnits(claimed, 18)} SUK`);
    });

    it("应该正确计算可领取收益", async function () {
      const REVENUE = ethers.parseUnits("10000", 18);
      await sukToken.mint(await dramaIPStaking.getAddress(), REVENUE);
      await dramaIPStaking.connect(owner).distributeRevenue(DRAMA_ID, REVENUE);

      const claimable = await dramaIPStaking.calculateClaimableRevenue(
        DRAMA_ID,
        investor1.address
      );

      expect(Number(ethers.formatUnits(claimable, 18))).to.be.closeTo(4000, 10);
    });
  });

  describe("5️⃣ 管理功能", function () {
    beforeEach(async function () {
      await dramaIPStaking.connect(copyrightHolder).submitDramaStaking(
        DRAMA_ID,
        DRAMA_TITLE,
        0,
        1000000,
        ONE_MILLION_SUK,
        60,
        "ipfs://test"
      );
      await dramaIPStaking.connect(kycReviewer).reviewKYC(DRAMA_ID, true, "通过");
    });

    it("应该能够暂停单个短剧", async function () {
      await dramaIPStaking.connect(owner).emergencyPauseDrama(DRAMA_ID);
      
      const drama = await dramaIPStaking.getDramaDetails(DRAMA_ID);
      expect(drama.isActive).to.be.false;
    });

    it("应该能够恢复单个短剧", async function () {
      await dramaIPStaking.connect(owner).emergencyPauseDrama(DRAMA_ID);
      await dramaIPStaking.connect(owner).resumeDramaOperations(DRAMA_ID);
      
      const drama = await dramaIPStaking.getDramaDetails(DRAMA_ID);
      expect(drama.isActive).to.be.true;
    });

    it("应该能够更新平台费用", async function () {
      await dramaIPStaking.connect(owner).updatePlatformFee(600); // 6%
      expect(await dramaIPStaking.platformFeeBps()).to.equal(600);
    });
  });

  describe("6️⃣ 完整流程测试", function () {
    it("应该完成完整的质押-投资-分红流程", async function () {
      console.log("\n" + "=".repeat(60));
      console.log("🎬 完整流程测试");
      console.log("=".repeat(60));

      // 1. 提交质押申请
      console.log("\n1️⃣ 版权方提交质押申请...");
      await dramaIPStaking.connect(copyrightHolder).submitDramaStaking(
        DRAMA_ID,
        DRAMA_TITLE,
        0,
        1000000,
        ONE_MILLION_SUK,
        60,
        "ipfs://test"
      );

      // 2. KYC审核
      console.log("2️⃣ KYC审核通过...");
      await dramaIPStaking.connect(kycReviewer).reviewKYC(DRAMA_ID, true, "通过");

      // 3. 投资者投资
      console.log("3️⃣ 投资者开始投资...");
      await dramaIPStaking.connect(investor1).investInDrama(DRAMA_ID, TEN_THOUSAND_SUK);
      await dramaIPStaking.connect(investor2).investInDrama(DRAMA_ID, FIVE_THOUSAND_SUK);

      // 4. 分发收益
      console.log("4️⃣ 分发收益...");
      const REVENUE = ethers.parseUnits("10000", 18);
      await sukToken.mint(await dramaIPStaking.getAddress(), REVENUE);
      await dramaIPStaking.connect(owner).distributeRevenue(DRAMA_ID, REVENUE);

      // 5. 领取收益
      console.log("5️⃣ 投资者领取收益...");
      await dramaIPStaking.connect(investor1).claimRevenue(DRAMA_ID);
      await dramaIPStaking.connect(investor2).claimRevenue(DRAMA_ID);

      // 6. 验证最终状态
      const drama = await dramaIPStaking.getDramaDetails(DRAMA_ID);
      const investor1Info = await dramaIPStaking.getInvestorInfo(DRAMA_ID, investor1.address);
      const investor2Info = await dramaIPStaking.getInvestorInfo(DRAMA_ID, investor2.address);

      console.log("\n" + "=".repeat(60));
      console.log("📊 最终统计");
      console.log("=".repeat(60));
      console.log(`短剧标题: ${drama.dramaTitle}`);
      console.log(`总投资者: ${drama.totalInvestors}`);
      console.log(`总投资额: ${ethers.formatUnits(drama.totalSukInvested, 18)} SUK`);
      console.log(`已分配收益: ${ethers.formatUnits(drama.totalRevenueDistributed, 18)} SUK`);
      console.log(`投资者1已领: ${ethers.formatUnits(investor1Info.revenueClaimed, 18)} SUK`);
      console.log(`投资者2已领: ${ethers.formatUnits(investor2Info.revenueClaimed, 18)} SUK`);
      console.log("\n✅ 完整流程测试通过！");
      console.log("=".repeat(60));

      expect(drama.totalInvestors).to.equal(2);
      expect(drama.totalRevenueDistributed).to.equal(REVENUE);
    });
  });
});

// ERC20Mock 合约用于测试
const ERC20MockContract = `
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";

contract ERC20Mock is ERC20 {
    constructor(string memory name, string memory symbol) ERC20(name, symbol) {}

    function mint(address to, uint256 amount) public {
        _mint(to, amount);
    }
}
`;
