const hre = require("hardhat");
const { ethers } = require("hardhat");

/**
 * SUK Token 部署脚本
 * 
 * 部署参数:
 * - initialSupply: 初始供应量 (默认: 1,000,000,000 SUK)
 * - maxSupply: 最大供应量 (默认: 10,000,000,000 SUK, 0表示无上限)
 */

async function main() {
    console.log("🚀 开始部署 SUK Token...\n");

    // 获取部署账户
    const [deployer] = await ethers.getSigners();
    console.log("📝 部署账户:", deployer.address);
    
    const balance = await ethers.provider.getBalance(deployer.address);
    console.log("💰 账户余额:", ethers.formatEther(balance), "ETH\n");

    // 配置参数
    const INITIAL_SUPPLY = ethers.parseUnits("1000000000", 18); // 10亿 SUK
    const MAX_SUPPLY = ethers.parseUnits("10000000000", 18);     // 100亿 SUK (最大供应量)
    
    console.log("⚙️ 部署参数:");
    console.log("   - 代币名称: SUK Token");
    console.log("   - 代币符号: SUK");
    console.log("   - 小数位数: 18");
    console.log("   - 初始供应量:", ethers.formatUnits(INITIAL_SUPPLY, 18), "SUK");
    console.log("   - 最大供应量:", ethers.formatUnits(MAX_SUPPLY, 18), "SUK");
    console.log("");

    // 部署合约
    console.log("📦 正在部署合约...");
    const SUKToken = await ethers.getContractFactory("SUKToken");
    const sukToken = await SUKToken.deploy(INITIAL_SUPPLY, MAX_SUPPLY);
    
    await sukToken.waitForDeployment();
    const tokenAddress = await sukToken.getAddress();
    
    console.log("✅ SUK Token 部署成功!");
    console.log("📍 合约地址:", tokenAddress);
    console.log("");

    // 验证部署
    console.log("🔍 验证合约信息...");
    const name = await sukToken.name();
    const symbol = await sukToken.symbol();
    const decimals = await sukToken.decimals();
    const totalSupply = await sukToken.totalSupply();
    const maxSupply = await sukToken.maxSupply();
    const deployerBalance = await sukToken.balanceOf(deployer.address);
    
    console.log("   - 名称:", name);
    console.log("   - 符号:", symbol);
    console.log("   - 小数位:", decimals.toString());
    console.log("   - 总供应量:", ethers.formatUnits(totalSupply, 18), "SUK");
    console.log("   - 最大供应量:", ethers.formatUnits(maxSupply, 18), "SUK");
    console.log("   - 部署者余额:", ethers.formatUnits(deployerBalance, 18), "SUK");
    console.log("");

    // 检查角色
    console.log("👥 检查角色权限...");
    const DEFAULT_ADMIN_ROLE = await sukToken.DEFAULT_ADMIN_ROLE();
    const MINTER_ROLE = await sukToken.MINTER_ROLE();
    const PAUSER_ROLE = await sukToken.PAUSER_ROLE();
    const BURNER_ROLE = await sukToken.BURNER_ROLE();
    
    const hasAdminRole = await sukToken.hasRole(DEFAULT_ADMIN_ROLE, deployer.address);
    const hasMinterRole = await sukToken.hasRole(MINTER_ROLE, deployer.address);
    const hasPauserRole = await sukToken.hasRole(PAUSER_ROLE, deployer.address);
    const hasBurnerRole = await sukToken.hasRole(BURNER_ROLE, deployer.address);
    
    console.log("   - 管理员角色:", hasAdminRole ? "✅" : "❌");
    console.log("   - 铸造者角色:", hasMinterRole ? "✅" : "❌");
    console.log("   - 暂停者角色:", hasPauserRole ? "✅" : "❌");
    console.log("   - 销毁者角色:", hasBurnerRole ? "✅" : "❌");
    console.log("");

    // 部署摘要
    console.log("=" + "=".repeat(60));
    console.log("📋 部署摘要");
    console.log("=" + "=".repeat(60));
    console.log("网络:", hre.network.name);
    console.log("合约地址:", tokenAddress);
    console.log("部署者:", deployer.address);
    console.log("交易哈希:", sukToken.deploymentTransaction().hash);
    console.log("区块号:", (await ethers.provider.getBlock("latest")).number);
    console.log("=" + "=".repeat(60));
    console.log("");

    // 保存部署信息
    const deploymentInfo = {
        network: hre.network.name,
        contractAddress: tokenAddress,
        deployer: deployer.address,
        transactionHash: sukToken.deploymentTransaction().hash,
        blockNumber: (await ethers.provider.getBlock("latest")).number,
        timestamp: new Date().toISOString(),
        parameters: {
            name: name,
            symbol: symbol,
            decimals: decimals.toString(),
            initialSupply: ethers.formatUnits(INITIAL_SUPPLY, 18),
            maxSupply: ethers.formatUnits(MAX_SUPPLY, 18)
        }
    };

    console.log("💾 部署信息已保存");
    console.log(JSON.stringify(deploymentInfo, null, 2));
    console.log("");

    // 验证指令
    if (hre.network.name !== "localhost" && hre.network.name !== "hardhat") {
        console.log("📝 验证合约指令:");
        console.log(`npx hardhat verify --network ${hre.network.name} ${tokenAddress} "${INITIAL_SUPPLY}" "${MAX_SUPPLY}"`);
        console.log("");
    }

    // 后续步骤
    console.log("🎯 后续步骤:");
    console.log("1. 验证合约代码 (Etherscan)");
    console.log("2. 授予必要的角色权限");
    console.log("3. 配置前端合约地址");
    console.log("4. 添加流动性池 (Uniswap/Raydium)");
    console.log("5. 监控合约运行状态");
    console.log("");

    console.log("✅ 部署完成!");
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error("❌ 部署失败:", error);
        process.exit(1);
    });
