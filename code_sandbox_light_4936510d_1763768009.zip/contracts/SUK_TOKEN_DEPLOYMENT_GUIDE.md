# SUK Token 部署指南

## 📋 概述

本文档提供 SUK Token 在 Solana 和 Ethereum 两条链上的完整部署指南。

**代币信息**:
- **名称**: SUK Token
- **符号**: SUK
- **Solana 小数位**: 6
- **Ethereum 小数位**: 18
- **初始供应量**: 1,000,000,000 SUK (10亿)
- **最大供应量**: 10,000,000,000 SUK (100亿)

---

## 🔗 支持的区块链

| 区块链 | 标准 | 推荐度 | Gas费 | 速度 |
|--------|------|--------|-------|------|
| **Solana** | SPL Token | ⭐⭐⭐⭐⭐ | $0.00025 | 400ms |
| **Ethereum** | ERC20 | ⭐⭐⭐⭐ | $2-50 | 12-15s |

**建议**: 优先部署到 **Solana**，成本低、速度快。

---

## 🚀 Solana 部署

### 前置条件

```bash
# 安装 Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# 安装 Solana CLI
sh -c "$(curl -sSfL https://release.solana.com/stable/install)"

# 安装 Anchor
cargo install --git https://github.com/coral-xyz/anchor avm --locked --force
avm install latest
avm use latest

# 安装 Node.js 依赖
npm install -g ts-node typescript @types/node
```

### 步骤 1: 创建钱包

```bash
# 创建新钱包
solana-keygen new --outfile ~/.config/solana/id.json

# 查看钱包地址
solana address

# 设置为开发网
solana config set --url devnet

# 获取测试 SOL
solana airdrop 2
```

### 步骤 2: 构建程序

```bash
cd contracts/solana/suk_token

# 构建
anchor build

# 查看程序 ID
solana address -k target/deploy/suk_token-keypair.json
```

### 步骤 3: 部署程序

```bash
# 部署到 Devnet
anchor deploy --provider.cluster devnet

# 部署到 Mainnet
anchor deploy --provider.cluster mainnet
```

### 步骤 4: 初始化代币

```bash
# 运行部署脚本
cd scripts
ts-node deploy.ts
```

### 部署输出示例

```
🚀 开始部署 SUK Token (Solana)...

📝 部署账户: 7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU
💰 账户余额: 2.5 SOL

⚙️ 部署参数:
   - 代币名称: SUK Token
   - 代币符号: SUK
   - 小数位数: 6
   - 初始供应量: 1000000000 SUK

📦 创建 SPL Token Mint...
✅ Mint 创建成功: 8qJSyQprMC57TWKaXAZw2xC3FTk3a4EqMfT2F9VYfPmN

📦 创建权限代币账户...
✅ 代币账户创建成功: 9vMJfxuKxXBoEa7rM1Tu6DQtkVqvDLWXF5qSiPZg3gFv

📦 初始化 Token Info...
✅ Token Info 初始化成功
   交易签名: 2ZE7cxnp...

🔍 验证部署...
   - Token Info PDA: EqtKLw2JqnH...
   - 管理员: 7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU
   - 总供应量: 1000000000 SUK
   - 小数位: 6
   - 是否暂停: false
   - Mint Supply: 1000000000 SUK
   - 权限账户余额: 1000000000 SUK

✅ 部署完成!
```

---

## 🔷 Ethereum 部署

### 前置条件

```bash
# 安装 Node.js
nvm install 18
nvm use 18

# 进入合约目录
cd contracts/ethereum

# 安装依赖
npm install
```

### 步骤 1: 配置环境变量

创建 `.env` 文件:

```bash
# 私钥 (不要泄露!)
PRIVATE_KEY=your_private_key_here

# RPC 节点
SEPOLIA_RPC_URL=https://sepolia.infura.io/v3/YOUR_PROJECT_ID
MAINNET_RPC_URL=https://mainnet.infura.io/v3/YOUR_PROJECT_ID

# Etherscan API Key
ETHERSCAN_API_KEY=your_etherscan_api_key
```

### 步骤 2: 编译合约

```bash
# 编译
npx hardhat compile

# 输出
Compiled 1 Solidity file successfully
```

### 步骤 3: 本地测试

```bash
# 启动本地节点
npx hardhat node

# 新终端: 部署到本地
npx hardhat run scripts/deploy-suk-token.js --network localhost
```

### 步骤 4: 部署到测试网

```bash
# 部署到 Sepolia
npx hardhat run scripts/deploy-suk-token.js --network sepolia
```

### 部署输出示例

```
🚀 开始部署 SUK Token...

📝 部署账户: 0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb
💰 账户余额: 1.5 ETH

⚙️ 部署参数:
   - 代币名称: SUK Token
   - 代币符号: SUK
   - 小数位数: 18
   - 初始供应量: 1000000000 SUK
   - 最大供应量: 10000000000 SUK

📦 正在部署合约...
✅ SUK Token 部署成功!
📍 合约地址: 0x5FbDB2315678afecb367f032d93F642f64180aa3

🔍 验证合约信息...
   - 名称: SUK Token
   - 符号: SUK
   - 小数位: 18
   - 总供应量: 1000000000 SUK
   - 最大供应量: 10000000000 SUK
   - 部署者余额: 1000000000 SUK

👥 检查角色权限...
   - 管理员角色: ✅
   - 铸造者角色: ✅
   - 暂停者角色: ✅
   - 销毁者角色: ✅

═══════════════════════════════════════════════════════
📋 部署摘要
═══════════════════════════════════════════════════════
网络: sepolia
合约地址: 0x5FbDB2315678afecb367f032d93F642f64180aa3
部署者: 0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb
交易哈希: 0x45f8a3b...
区块号: 12345678
═══════════════════════════════════════════════════════

✅ 部署完成!
```

### 步骤 5: 验证合约

```bash
# 验证合约代码
npx hardhat verify --network sepolia \
  0x5FbDB2315678afecb367f032d93F642f64180aa3 \
  "1000000000000000000000000000" \
  "10000000000000000000000000000"
```

---

## 📊 合约功能说明

### Solana SPL Token

#### 初始化
```rust
pub fn initialize(
    ctx: Context<Initialize>,
    decimals: u8,
    initial_supply: u64,
) -> Result<()>
```

#### 铸造
```rust
pub fn mint(
    ctx: Context<MintTokens>,
    amount: u64,
) -> Result<()>
```

#### 销毁
```rust
pub fn burn(
    ctx: Context<BurnTokens>,
    amount: u64,
) -> Result<()>
```

#### 暂停/恢复
```rust
pub fn pause(ctx: Context<PauseToken>) -> Result<()>
pub fn unpause(ctx: Context<UnpauseToken>) -> Result<()>
```

### Ethereum ERC20

#### 铸造
```solidity
function mint(address to, uint256 amount) public onlyRole(MINTER_ROLE)
```

#### 批量铸造
```solidity
function batchMint(
    address[] calldata recipients,
    uint256[] calldata amounts
) external onlyRole(MINTER_ROLE)
```

#### 销毁
```solidity
function burn(uint256 amount) public override
function burnFrom(address account, uint256 amount) public override onlyRole(BURNER_ROLE)
```

#### 暂停/恢复
```solidity
function pause() public onlyRole(PAUSER_ROLE)
function unpause() public onlyRole(PAUSER_ROLE)
```

---

## 🔐 安全配置

### 角色管理

#### Solana
```typescript
// 转移管理员权限
await program.methods
    .transferAuthority(newAuthority)
    .accounts({
        tokenInfo: tokenInfoPDA,
        authority: currentAuthority,
    })
    .rpc();
```

#### Ethereum
```javascript
// 授予角色
const MINTER_ROLE = await token.MINTER_ROLE();
await token.grantRole(MINTER_ROLE, minterAddress);

// 撤销角色
await token.revokeRole(MINTER_ROLE, minterAddress);

// 转移管理员
await token.grantRole(DEFAULT_ADMIN_ROLE, newAdmin);
await token.renounceRole(DEFAULT_ADMIN_ROLE, oldAdmin);
```

### 紧急暂停

#### Solana
```bash
anchor run pause-token
```

#### Ethereum
```javascript
await token.pause();  // 暂停
await token.unpause(); // 恢复
```

---

## 🧪 测试

### Solana 测试

```bash
cd contracts/solana/suk_token
anchor test
```

### Ethereum 测试

```bash
cd contracts/ethereum
npx hardhat test
```

---

## 🌐 前端集成

### Solana 集成

```typescript
import { PublicKey } from "@solana/web3.js";
import { getAccount, getAssociatedTokenAddress } from "@solana/spl-token";

const MINT_ADDRESS = new PublicKey("8qJSyQprMC57TWKaXAZw2xC3FTk3a4EqMfT2F9VYfPmN");

// 获取用户代币账户
const userTokenAccount = await getAssociatedTokenAddress(
    MINT_ADDRESS,
    userWallet.publicKey
);

// 获取余额
const accountInfo = await getAccount(connection, userTokenAccount);
const balance = Number(accountInfo.amount) / Math.pow(10, 6);

console.log("SUK 余额:", balance);
```

### Ethereum 集成

```javascript
import { ethers } from "ethers";

const TOKEN_ADDRESS = "0x5FbDB2315678afecb367f032d93F642f64180aa3";
const TOKEN_ABI = [...]; // SUKToken ABI

const provider = new ethers.providers.Web3Provider(window.ethereum);
const token = new ethers.Contract(TOKEN_ADDRESS, TOKEN_ABI, provider);

// 获取余额
const balance = await token.balanceOf(userAddress);
const formattedBalance = ethers.utils.formatUnits(balance, 18);

console.log("SUK 余额:", formattedBalance);
```

---

## 📈 代币经济

### 供应量管理

| 参数 | 数值 | 说明 |
|------|------|------|
| **初始供应量** | 1,000,000,000 SUK | 10亿 |
| **最大供应量** | 10,000,000,000 SUK | 100亿 |
| **可铸造量** | 9,000,000,000 SUK | 90亿 |

### 通缩机制

- **回购销毁**: 平台收益的 5% 用于回购并销毁 SUK
- **质押销毁**: 短剧质押收益的 5% 销毁
- **目标通缩率**: 每年 2-5%

---

## 🔗 相关链接

### Solana
- Explorer: https://explorer.solana.com
- Token Program: https://spl.solana.com/token
- Metaplex: https://www.metaplex.com

### Ethereum
- Etherscan: https://etherscan.io
- OpenZeppelin: https://docs.openzeppelin.com
- Uniswap: https://uniswap.org

---

## ❓ 常见问题

### Q1: 如何添加流动性？

**Solana**: 使用 Raydium 或 Orca DEX  
**Ethereum**: 使用 Uniswap V3

### Q2: 如何配置代币元数据？

**Solana**: 使用 Metaplex Token Metadata  
**Ethereum**: 部署后自动包含

### Q3: 如何监控代币供应量？

通过合约查询:
```javascript
// Solana
const tokenInfo = await program.account.tokenInfo.fetch(tokenInfoPDA);
console.log("Total Supply:", tokenInfo.totalSupply);

// Ethereum
const totalSupply = await token.totalSupply();
console.log("Total Supply:", ethers.utils.formatUnits(totalSupply, 18));
```

### Q4: 部署成本是多少?

- **Solana Devnet**: 免费 (测试 SOL)
- **Solana Mainnet**: ~0.5 SOL (~$50)
- **Ethereum Sepolia**: 免费 (测试 ETH)
- **Ethereum Mainnet**: 0.05-0.1 ETH ($100-200)

---

## 📞 技术支持

- Email: dev@suk.link
- Discord: discord.gg/suklink
- GitHub: github.com/suklink/suk-protocol

---

**最后更新**: 2025-11-18  
**文档版本**: v1.0.0

© 2025 SUK Protocol. All rights reserved.
