import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { SukToken } from "../target/types/suk_token";
import { 
    TOKEN_PROGRAM_ID,
    createMint,
    getOrCreateAssociatedTokenAccount,
    getMint,
} from "@solana/spl-token";

/**
 * SUK Token Solana 部署脚本
 * 
 * 部署步骤:
 * 1. 创建 SPL Token Mint
 * 2. 部署 Anchor 程序
 * 3. 初始化 Token Info
 * 4. 铸造初始供应量
 */

async function main() {
    console.log("🚀 开始部署 SUK Token (Solana)...\n");

    // 配置提供者
    const provider = anchor.AnchorProvider.env();
    anchor.setProvider(provider);

    const program = anchor.workspace.SukToken as Program<SukToken>;
    const authority = provider.wallet.publicKey;

    console.log("📝 部署账户:", authority.toString());
    const balance = await provider.connection.getBalance(authority);
    console.log("💰 账户余额:", balance / anchor.web3.LAMPORTS_PER_SOL, "SOL\n");

    // 配置参数
    const DECIMALS = 6; // Solana 通常使用 6 位小数
    const INITIAL_SUPPLY = 1_000_000_000 * Math.pow(10, DECIMALS); // 10亿 SUK
    
    console.log("⚙️ 部署参数:");
    console.log("   - 代币名称: SUK Token");
    console.log("   - 代币符号: SUK");
    console.log("   - 小数位数:", DECIMALS);
    console.log("   - 初始供应量:", INITIAL_SUPPLY / Math.pow(10, DECIMALS), "SUK");
    console.log("");

    // 1. 创建 Mint
    console.log("📦 创建 SPL Token Mint...");
    const mint = await createMint(
        provider.connection,
        provider.wallet.payer,
        authority,
        authority, // freeze authority
        DECIMALS
    );
    console.log("✅ Mint 创建成功:", mint.toString());
    console.log("");

    // 2. 创建权限账户的代币账户
    console.log("📦 创建权限代币账户...");
    const authorityTokenAccount = await getOrCreateAssociatedTokenAccount(
        provider.connection,
        provider.wallet.payer,
        mint,
        authority
    );
    console.log("✅ 代币账户创建成功:", authorityTokenAccount.address.toString());
    console.log("");

    // 3. 初始化 Token Info
    console.log("📦 初始化 Token Info...");
    const [tokenInfoPDA] = await anchor.web3.PublicKey.findProgramAddress(
        [Buffer.from("token_info")],
        program.programId
    );

    try {
        const tx = await program.methods
            .initialize(DECIMALS, new anchor.BN(INITIAL_SUPPLY))
            .accounts({
                tokenInfo: tokenInfoPDA,
                mint: mint,
                authority: authority,
                authorityTokenAccount: authorityTokenAccount.address,
                tokenProgram: TOKEN_PROGRAM_ID,
                systemProgram: anchor.web3.SystemProgram.programId,
                rent: anchor.web3.SYSVAR_RENT_PUBKEY,
            })
            .rpc();

        console.log("✅ Token Info 初始化成功");
        console.log("   交易签名:", tx);
        console.log("");
    } catch (error) {
        console.error("❌ 初始化失败:", error);
        throw error;
    }

    // 4. 验证部署
    console.log("🔍 验证部署...");
    const tokenInfo = await program.account.tokenInfo.fetch(tokenInfoPDA);
    const mintInfo = await getMint(provider.connection, mint);

    console.log("   - Token Info PDA:", tokenInfoPDA.toString());
    console.log("   - 管理员:", tokenInfo.authority.toString());
    console.log("   - 总供应量:", tokenInfo.totalSupply.toNumber() / Math.pow(10, DECIMALS), "SUK");
    console.log("   - 小数位:", tokenInfo.decimals);
    console.log("   - 是否暂停:", tokenInfo.isPaused);
    console.log("   - Mint Supply:", Number(mintInfo.supply) / Math.pow(10, DECIMALS), "SUK");
    console.log("");

    // 检查权限账户余额
    const authorityBalance = await provider.connection.getTokenAccountBalance(
        authorityTokenAccount.address
    );
    console.log("   - 权限账户余额:", 
        Number(authorityBalance.value.amount) / Math.pow(10, DECIMALS), "SUK");
    console.log("");

    // 部署摘要
    console.log("=" + "=".repeat(60));
    console.log("📋 部署摘要");
    console.log("=" + "=".repeat(60));
    console.log("网络:", provider.connection.rpcEndpoint);
    console.log("程序 ID:", program.programId.toString());
    console.log("Mint 地址:", mint.toString());
    console.log("Token Info PDA:", tokenInfoPDA.toString());
    console.log("部署者:", authority.toString());
    console.log("权限代币账户:", authorityTokenAccount.address.toString());
    console.log("=" + "=".repeat(60));
    console.log("");

    // 保存部署信息
    const deploymentInfo = {
        network: provider.connection.rpcEndpoint,
        programId: program.programId.toString(),
        mintAddress: mint.toString(),
        tokenInfoPDA: tokenInfoPDA.toString(),
        authority: authority.toString(),
        authorityTokenAccount: authorityTokenAccount.address.toString(),
        timestamp: new Date().toISOString(),
        parameters: {
            decimals: DECIMALS,
            initialSupply: INITIAL_SUPPLY / Math.pow(10, DECIMALS),
        }
    };

    console.log("💾 部署信息:");
    console.log(JSON.stringify(deploymentInfo, null, 2));
    console.log("");

    // 后续步骤
    console.log("🎯 后续步骤:");
    console.log("1. 将 Mint 地址配置到前端");
    console.log("2. 添加流动性池 (Raydium/Orca)");
    console.log("3. 配置代币元数据 (Metaplex)");
    console.log("4. 监控合约运行状态");
    console.log("");

    console.log("✅ 部署完成!");
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error("❌ 部署失败:", error);
        process.exit(1);
    });
