use anchor_lang::prelude::*;
use anchor_spl::token::{self, Mint, Token, TokenAccount, MintTo, Burn, Transfer};

declare_id!("SUKTokenProgramIDxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");

#[program]
pub mod suk_token {
    use super::*;

    /// 初始化 SUK 代币
    pub fn initialize(
        ctx: Context<Initialize>,
        decimals: u8,
        initial_supply: u64,
    ) -> Result<()> {
        let token_info = &mut ctx.accounts.token_info;
        token_info.authority = ctx.accounts.authority.key();
        token_info.total_supply = initial_supply;
        token_info.decimals = decimals;
        token_info.is_paused = false;
        token_info.created_at = Clock::get()?.unix_timestamp;
        
        // 铸造初始供应量到权限账户
        if initial_supply > 0 {
            let cpi_accounts = MintTo {
                mint: ctx.accounts.mint.to_account_info(),
                to: ctx.accounts.authority_token_account.to_account_info(),
                authority: ctx.accounts.authority.to_account_info(),
            };
            let cpi_program = ctx.accounts.token_program.to_account_info();
            let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
            
            token::mint_to(cpi_ctx, initial_supply)?;
        }
        
        msg!("✅ SUK Token 初始化成功");
        msg!("📊 小数位数: {}", decimals);
        msg!("💰 初始供应量: {}", initial_supply);
        
        Ok(())
    }

    /// 铸造新的 SUK 代币（仅管理员）
    pub fn mint(
        ctx: Context<MintTokens>,
        amount: u64,
    ) -> Result<()> {
        let token_info = &mut ctx.accounts.token_info;
        
        require!(!token_info.is_paused, ErrorCode::TokenPaused);
        
        let cpi_accounts = MintTo {
            mint: ctx.accounts.mint.to_account_info(),
            to: ctx.accounts.to.to_account_info(),
            authority: ctx.accounts.authority.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        
        token::mint_to(cpi_ctx, amount)?;
        
        token_info.total_supply += amount;
        
        msg!("✅ 铸造 SUK 代币成功");
        msg!("💰 数量: {}", amount);
        msg!("📊 总供应量: {}", token_info.total_supply);
        
        Ok(())
    }

    /// 销毁 SUK 代币（回购销毁机制）
    pub fn burn(
        ctx: Context<BurnTokens>,
        amount: u64,
    ) -> Result<()> {
        let token_info = &mut ctx.accounts.token_info;
        
        let cpi_accounts = Burn {
            mint: ctx.accounts.mint.to_account_info(),
            from: ctx.accounts.from.to_account_info(),
            authority: ctx.accounts.authority.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        
        token::burn(cpi_ctx, amount)?;
        
        token_info.total_supply -= amount;
        
        msg!("🔥 销毁 SUK 代币成功");
        msg!("💰 数量: {}", amount);
        msg!("📊 剩余供应量: {}", token_info.total_supply);
        
        Ok(())
    }

    /// 暂停代币转账（紧急情况）
    pub fn pause(ctx: Context<PauseToken>) -> Result<()> {
        let token_info = &mut ctx.accounts.token_info;
        token_info.is_paused = true;
        
        msg!("⏸️ SUK Token 已暂停");
        Ok(())
    }

    /// 恢复代币转账
    pub fn unpause(ctx: Context<UnpauseToken>) -> Result<()> {
        let token_info = &mut ctx.accounts.token_info;
        token_info.is_paused = false;
        
        msg!("▶️ SUK Token 已恢复");
        Ok(())
    }

    /// 转移管理员权限
    pub fn transfer_authority(
        ctx: Context<TransferAuthority>,
        new_authority: Pubkey,
    ) -> Result<()> {
        let token_info = &mut ctx.accounts.token_info;
        token_info.authority = new_authority;
        
        msg!("🔄 管理员权限已转移");
        msg!("新管理员: {}", new_authority);
        
        Ok(())
    }
}

// ==================== 数据结构 ====================

#[account]
pub struct TokenInfo {
    pub authority: Pubkey,      // 管理员地址
    pub total_supply: u64,      // 总供应量
    pub decimals: u8,           // 小数位数
    pub is_paused: bool,        // 是否暂停
    pub created_at: i64,        // 创建时间
}

// ==================== Context 定义 ====================

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(
        init,
        payer = authority,
        space = 8 + 32 + 8 + 1 + 1 + 8,
        seeds = [b"token_info"],
        bump
    )]
    pub token_info: Account<'info, TokenInfo>,
    
    #[account(mut)]
    pub mint: Account<'info, Mint>,
    
    #[account(mut)]
    pub authority: Signer<'info>,
    
    #[account(mut)]
    pub authority_token_account: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

#[derive(Accounts)]
pub struct MintTokens<'info> {
    #[account(
        mut,
        seeds = [b"token_info"],
        bump,
        has_one = authority
    )]
    pub token_info: Account<'info, TokenInfo>,
    
    #[account(mut)]
    pub mint: Account<'info, Mint>,
    
    #[account(mut)]
    pub to: Account<'info, TokenAccount>,
    
    pub authority: Signer<'info>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct BurnTokens<'info> {
    #[account(
        mut,
        seeds = [b"token_info"],
        bump,
        has_one = authority
    )]
    pub token_info: Account<'info, TokenInfo>,
    
    #[account(mut)]
    pub mint: Account<'info, Mint>,
    
    #[account(mut)]
    pub from: Account<'info, TokenAccount>,
    
    pub authority: Signer<'info>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct PauseToken<'info> {
    #[account(
        mut,
        seeds = [b"token_info"],
        bump,
        has_one = authority
    )]
    pub token_info: Account<'info, TokenInfo>,
    
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct UnpauseToken<'info> {
    #[account(
        mut,
        seeds = [b"token_info"],
        bump,
        has_one = authority
    )]
    pub token_info: Account<'info, TokenInfo>,
    
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct TransferAuthority<'info> {
    #[account(
        mut,
        seeds = [b"token_info"],
        bump,
        has_one = authority
    )]
    pub token_info: Account<'info, TokenInfo>,
    
    pub authority: Signer<'info>,
}

// ==================== 错误代码 ====================

#[error_code]
pub enum ErrorCode {
    #[msg("代币已暂停")]
    TokenPaused,
}
