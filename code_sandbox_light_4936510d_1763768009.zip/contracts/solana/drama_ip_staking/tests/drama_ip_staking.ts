import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { DramaIpStaking } from "../target/types/drama_ip_staking";
import { expect } from "chai";
import { 
  TOKEN_PROGRAM_ID,
  createMint,
  createAccount,
  mintTo,
  getAccount,
} from "@solana/spl-token";

describe("Drama IP Staking - 短剧版权质押智能合约测试", () => {
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  const program = anchor.workspace.DramaIpStaking as Program<DramaIpStaking>;
  
  let sukMint: anchor.web3.PublicKey;
  let ownerSukAccount: anchor.web3.PublicKey;
  let investor1SukAccount: anchor.web3.PublicKey;
  let investor2SukAccount: anchor.web3.PublicKey;
  let vaultSukAccount: anchor.web3.PublicKey;
  
  const authority = provider.wallet.publicKey;
  const owner = anchor.web3.Keypair.generate();
  const investor1 = anchor.web3.Keypair.generate();
  const investor2 = anchor.web3.Keypair.generate();

  const DRAMA_ID = "BZ-2024-001";
  const DRAMA_TITLE = "霸总的替身新娘";

  before(async () => {
    console.log("🔧 初始化测试环境...");

    // 创建 SUK 代币 Mint
    sukMint = await createMint(
      provider.connection,
      provider.wallet.payer,
      authority,
      null,
      6 // 6位小数
    );
    console.log("✅ SUK Mint 创建成功:", sukMint.toString());

    // 为版权方创建 SUK 账户并铸造代币
    ownerSukAccount = await createAccount(
      provider.connection,
      provider.wallet.payer,
      sukMint,
      owner.publicKey
    );
    await mintTo(
      provider.connection,
      provider.wallet.payer,
      sukMint,
      ownerSukAccount,
      authority,
      1000000 * 1e6 // 100万 SUK
    );
    console.log("✅ 版权方 SUK 账户余额: 1,000,000 SUK");

    // 为投资者1创建账户并铸造代币
    investor1SukAccount = await createAccount(
      provider.connection,
      provider.wallet.payer,
      sukMint,
      investor1.publicKey
    );
    await mintTo(
      provider.connection,
      provider.wallet.payer,
      sukMint,
      investor1SukAccount,
      authority,
      100000 * 1e6 // 10万 SUK
    );
    console.log("✅ 投资者1 SUK 账户余额: 100,000 SUK");

    // 为投资者2创建账户并铸造代币
    investor2SukAccount = await createAccount(
      provider.connection,
      provider.wallet.payer,
      sukMint,
      investor2.publicKey
    );
    await mintTo(
      provider.connection,
      provider.wallet.payer,
      sukMint,
      investor2SukAccount,
      authority,
      50000 * 1e6 // 5万 SUK
    );
    console.log("✅ 投资者2 SUK 账户余额: 50,000 SUK");

    // 创建合约金库账户
    vaultSukAccount = await createAccount(
      provider.connection,
      provider.wallet.payer,
      sukMint,
      authority // 由合约PDA控制
    );
    console.log("✅ 合约金库账户创建成功");

    // 给测试账户空投 SOL
    await provider.connection.confirmTransaction(
      await provider.connection.requestAirdrop(owner.publicKey, 2 * anchor.web3.LAMPORTS_PER_SOL)
    );
    await provider.connection.confirmTransaction(
      await provider.connection.requestAirdrop(investor1.publicKey, 2 * anchor.web3.LAMPORTS_PER_SOL)
    );
    await provider.connection.confirmTransaction(
      await provider.connection.requestAirdrop(investor2.publicKey, 2 * anchor.web3.LAMPORTS_PER_SOL)
    );
    console.log("✅ SOL 空投完成\n");
  });

  it("1️⃣ 初始化质押池", async () => {
    console.log("\n📝 测试：初始化质押池");
    
    const [stakingPoolPDA] = await anchor.web3.PublicKey.findProgramAddress(
      [Buffer.from("staking_pool")],
      program.programId
    );

    await program.methods
      .initializeStakingPool("SUK-DRAMA-POOL-001")
      .accounts({
        stakingPool: stakingPoolPDA,
        authority: authority,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .rpc();

    const stakingPool = await program.account.stakingPool.fetch(stakingPoolPDA);
    expect(stakingPool.authority.toString()).to.equal(authority.toString());
    expect(stakingPool.totalDramas).to.equal(0);
    
    console.log("✅ 质押池初始化成功");
    console.log(`   池子ID: ${stakingPool.poolId}`);
    console.log(`   管理员: ${stakingPool.authority.toString()}`);
  });

  it("2️⃣ 版权方提交短剧质押申请", async () => {
    console.log("\n📝 测试：版权方提交短剧质押申请");

    const [dramaStakingPDA] = await anchor.web3.PublicKey.findProgramAddress(
      [Buffer.from("drama_staking"), Buffer.from(DRAMA_ID)],
      program.programId
    );

    await program.methods
      .submitDramaStaking(
        DRAMA_ID,
        DRAMA_TITLE,
        { copyrightHolder: {} }, // StakingType::CopyrightHolder
        new anchor.BN(1000000), // 预期收益 $1,000,000
        new anchor.BN(1000000 * 1e6), // 质押 1,000,000 SUK
        60, // 版权方获得60%收益
        "ipfs://QmExampleMetadata123456789"
      )
      .accounts({
        dramaStaking: dramaStakingPDA,
        owner: owner.publicKey,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .signers([owner])
      .rpc();

    const dramaStaking = await program.account.dramaStaking.fetch(dramaStakingPDA);
    expect(dramaStaking.dramaTitle).to.equal(DRAMA_TITLE);
    expect(dramaStaking.sukAmountStaked.toNumber()).to.equal(1000000 * 1e6);
    expect(dramaStaking.kycStatus).to.deep.equal({ pending: {} });
    expect(dramaStaking.isActive).to.be.false;

    console.log("✅ 短剧质押申请提交成功");
    console.log(`   短剧ID: ${dramaStaking.dramaId}`);
    console.log(`   短剧标题: ${dramaStaking.dramaTitle}`);
    console.log(`   质押SUK: ${dramaStaking.sukAmountStaked.toNumber() / 1e6}`);
    console.log(`   预期收益: $${dramaStaking.totalRevenueEstimate.toNumber()}`);
    console.log(`   KYC状态: 待审核`);
  });

  it("3️⃣ 管理员KYC审核（审核通过）", async () => {
    console.log("\n📝 测试：管理员KYC审核");

    const [dramaStakingPDA] = await anchor.web3.PublicKey.findProgramAddress(
      [Buffer.from("drama_staking"), Buffer.from(DRAMA_ID)],
      program.programId
    );

    await program.methods
      .reviewKyc(true, "版权证明齐全，审核通过")
      .accounts({
        dramaStaking: dramaStakingPDA,
        owner: owner.publicKey,
        ownerSukAccount: ownerSukAccount,
        vaultSukAccount: vaultSukAccount,
        authority: authority,
        tokenProgram: TOKEN_PROGRAM_ID,
      })
      .signers([owner])
      .rpc();

    const dramaStaking = await program.account.dramaStaking.fetch(dramaStakingPDA);
    expect(dramaStaking.kycStatus).to.deep.equal({ approved: {} });
    expect(dramaStaking.isActive).to.be.true;

    // 检查金库余额
    const vaultAccount = await getAccount(provider.connection, vaultSukAccount);
    expect(Number(vaultAccount.amount)).to.equal(1000000 * 1e6);

    console.log("✅ KYC审核通过，SUK已锁定");
    console.log(`   金库余额: ${Number(vaultAccount.amount) / 1e6} SUK`);
    console.log(`   短剧状态: 激活，可接受投资`);
  });

  it("4️⃣ 投资者1投资 10,000 SUK", async () => {
    console.log("\n📝 测试：投资者1投资");

    const [dramaStakingPDA] = await anchor.web3.PublicKey.findProgramAddress(
      [Buffer.from("drama_staking"), Buffer.from(DRAMA_ID)],
      program.programId
    );

    const [investorPDA] = await anchor.web3.PublicKey.findProgramAddress(
      [
        Buffer.from("investor"),
        dramaStakingPDA.toBuffer(),
        investor1.publicKey.toBuffer(),
      ],
      program.programId
    );

    await program.methods
      .investInDrama(new anchor.BN(10000 * 1e6))
      .accounts({
        dramaStaking: dramaStakingPDA,
        investor: investorPDA,
        investorAuthority: investor1.publicKey,
        investorSukAccount: investor1SukAccount,
        vaultSukAccount: vaultSukAccount,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .signers([investor1])
      .rpc();

    const dramaStaking = await program.account.dramaStaking.fetch(dramaStakingPDA);
    const investor = await program.account.investor.fetch(investorPDA);

    expect(investor.sukAmountInvested.toNumber()).to.equal(10000 * 1e6);
    expect(dramaStaking.totalInvestors).to.equal(1);
    expect(dramaStaking.totalSukInvested.toNumber()).to.equal(10000 * 1e6);

    console.log("✅ 投资者1投资成功");
    console.log(`   投资金额: ${investor.sukAmountInvested.toNumber() / 1e6} SUK`);
    console.log(`   当前总投资者: ${dramaStaking.totalInvestors}`);
    console.log(`   总投资额: ${dramaStaking.totalSukInvested.toNumber() / 1e6} SUK`);
  });

  it("5️⃣ 投资者2投资 5,000 SUK", async () => {
    console.log("\n📝 测试：投资者2投资");

    const [dramaStakingPDA] = await anchor.web3.PublicKey.findProgramAddress(
      [Buffer.from("drama_staking"), Buffer.from(DRAMA_ID)],
      program.programId
    );

    const [investorPDA] = await anchor.web3.PublicKey.findProgramAddress(
      [
        Buffer.from("investor"),
        dramaStakingPDA.toBuffer(),
        investor2.publicKey.toBuffer(),
      ],
      program.programId
    );

    await program.methods
      .investInDrama(new anchor.BN(5000 * 1e6))
      .accounts({
        dramaStaking: dramaStakingPDA,
        investor: investorPDA,
        investorAuthority: investor2.publicKey,
        investorSukAccount: investor2SukAccount,
        vaultSukAccount: vaultSukAccount,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: anchor.web3.SystemProgram.programId,
      })
      .signers([investor2])
      .rpc();

    const dramaStaking = await program.account.dramaStaking.fetch(dramaStakingPDA);
    expect(dramaStaking.totalInvestors).to.equal(2);
    expect(dramaStaking.totalSukInvested.toNumber()).to.equal(15000 * 1e6);

    console.log("✅ 投资者2投资成功");
    console.log(`   当前总投资者: ${dramaStaking.totalInvestors}`);
    console.log(`   总投资额: ${dramaStaking.totalSukInvested.toNumber() / 1e6} SUK`);
  });

  it("6️⃣ 管理员分发收益（10,000 SUK）", async () => {
    console.log("\n📝 测试：管理员分发收益");

    const [dramaStakingPDA] = await anchor.web3.PublicKey.findProgramAddress(
      [Buffer.from("drama_staking"), Buffer.from(DRAMA_ID)],
      program.programId
    );

    await program.methods
      .distributeRevenue(new anchor.BN(10000 * 1e6)) // 分发 10,000 SUK 收益
      .accounts({
        dramaStaking: dramaStakingPDA,
        authority: authority,
      })
      .rpc();

    const dramaStaking = await program.account.dramaStaking.fetch(dramaStakingPDA);
    expect(dramaStaking.totalRevenueDistributed.toNumber()).to.equal(10000 * 1e6);

    console.log("✅ 收益分配成功");
    console.log(`   总收益: ${dramaStaking.totalRevenueDistributed.toNumber() / 1e6} SUK`);
    console.log(`   投资者获得: ${(10000 * 0.6)} SUK (60%)`);
    console.log(`   版权方获得: ${(10000 * 0.3)} SUK (30%)`);
    console.log(`   平台获得: ${(10000 * 0.05)} SUK (5%)`);
    console.log(`   回购销毁: ${(10000 * 0.05)} SUK (5%)`);
  });

  it("7️⃣ 投资者1领取收益", async () => {
    console.log("\n📝 测试：投资者1领取收益");

    const [dramaStakingPDA] = await anchor.web3.PublicKey.findProgramAddress(
      [Buffer.from("drama_staking"), Buffer.from(DRAMA_ID)],
      program.programId
    );

    const [investorPDA] = await anchor.web3.PublicKey.findProgramAddress(
      [
        Buffer.from("investor"),
        dramaStakingPDA.toBuffer(),
        investor1.publicKey.toBuffer(),
      ],
      program.programId
    );

    const balanceBefore = await getAccount(provider.connection, investor1SukAccount);
    
    await program.methods
      .claimRevenue()
      .accounts({
        dramaStaking: dramaStakingPDA,
        investor: investorPDA,
        investorAuthority: investor1.publicKey,
        investorSukAccount: investor1SukAccount,
        vaultSukAccount: vaultSukAccount,
        tokenProgram: TOKEN_PROGRAM_ID,
      })
      .signers([investor1])
      .rpc();

    const balanceAfter = await getAccount(provider.connection, investor1SukAccount);
    const investor = await program.account.investor.fetch(investorPDA);

    const claimedAmount = Number(balanceAfter.amount) - Number(balanceBefore.amount);
    
    // 投资者1占比: 10000 / 15000 = 66.67%
    // 投资者总收益: 10000 * 60% = 6000 SUK
    // 投资者1应得: 6000 * 66.67% = 4000 SUK
    expect(claimedAmount / 1e6).to.be.closeTo(4000, 10);

    console.log("✅ 投资者1领取收益成功");
    console.log(`   领取金额: ${claimedAmount / 1e6} SUK`);
    console.log(`   累计已领: ${investor.revenueClaimed.toNumber() / 1e6} SUK`);
  });

  it("8️⃣ 紧急暂停功能", async () => {
    console.log("\n📝 测试：紧急暂停功能");

    const [dramaStakingPDA] = await anchor.web3.PublicKey.findProgramAddress(
      [Buffer.from("drama_staking"), Buffer.from(DRAMA_ID)],
      program.programId
    );

    await program.methods
      .emergencyPause()
      .accounts({
        dramaStaking: dramaStakingPDA,
        authority: authority,
      })
      .rpc();

    const dramaStaking = await program.account.dramaStaking.fetch(dramaStakingPDA);
    expect(dramaStaking.isActive).to.be.false;

    console.log("✅ 短剧质押已暂停");
  });

  it("9️⃣ 恢复运营功能", async () => {
    console.log("\n📝 测试：恢复运营功能");

    const [dramaStakingPDA] = await anchor.web3.PublicKey.findProgramAddress(
      [Buffer.from("drama_staking"), Buffer.from(DRAMA_ID)],
      program.programId
    );

    await program.methods
      .resumeOperations()
      .accounts({
        dramaStaking: dramaStakingPDA,
        authority: authority,
      })
      .rpc();

    const dramaStaking = await program.account.dramaStaking.fetch(dramaStakingPDA);
    expect(dramaStaking.isActive).to.be.true;

    console.log("✅ 短剧质押已恢复运营");
  });

  it("🎬 完整流程总结", async () => {
    console.log("\n" + "=".repeat(60));
    console.log("🎬 完整测试流程总结");
    console.log("=".repeat(60));

    const [dramaStakingPDA] = await anchor.web3.PublicKey.findProgramAddress(
      [Buffer.from("drama_staking"), Buffer.from(DRAMA_ID)],
      program.programId
    );

    const dramaStaking = await program.account.dramaStaking.fetch(dramaStakingPDA);

    console.log(`\n📺 短剧信息:`);
    console.log(`   标题: ${dramaStaking.dramaTitle}`);
    console.log(`   ID: ${dramaStaking.dramaId}`);
    console.log(`   版权方质押: ${dramaStaking.sukAmountStaked.toNumber() / 1e6} SUK`);
    
    console.log(`\n💰 投资数据:`);
    console.log(`   总投资者: ${dramaStaking.totalInvestors}`);
    console.log(`   总投资额: ${dramaStaking.totalSukInvested.toNumber() / 1e6} SUK`);
    console.log(`   已分配收益: ${dramaStaking.totalRevenueDistributed.toNumber() / 1e6} SUK`);
    
    console.log(`\n✅ 测试结论:`);
    console.log(`   ✓ 质押方仅使用 SUK 代币，未发行新代币`);
    console.log(`   ✓ KYC审核流程正常`);
    console.log(`   ✓ 投资认购功能正常`);
    console.log(`   ✓ 收益分配计算准确`);
    console.log(`   ✓ 领取收益功能正常`);
    console.log(`   ✓ 紧急暂停/恢复功能正常`);
    
    console.log("\n" + "=".repeat(60));
  });
});
