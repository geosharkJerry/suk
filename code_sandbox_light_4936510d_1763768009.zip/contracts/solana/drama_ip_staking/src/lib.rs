use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};

declare_id!("DramaStakingProgramIDxxxxxxxxxxxxxxxxxxxxxxxxxx");

#[program]
pub mod drama_ip_staking {
    use super::*;

    /// 初始化质押池（管理员操作）
    pub fn initialize_staking_pool(
        ctx: Context<InitializeStakingPool>,
        pool_id: String,
    ) -> Result<()> {
        let staking_pool = &mut ctx.accounts.staking_pool;
        staking_pool.authority = ctx.accounts.authority.key();
        staking_pool.pool_id = pool_id;
        staking_pool.total_staked_suk = 0;
        staking_pool.total_dramas = 0;
        staking_pool.created_at = Clock::get()?.unix_timestamp;
        
        msg!("✅ SUK质押池初始化成功");
        Ok(())
    }

    /// 提交短剧质押申请（版权方操作）
    /// 注意：质押方不发行新代币，而是获得SUK等值权益
    pub fn submit_drama_staking(
        ctx: Context<SubmitDramaStaking>,
        drama_id: String,
        drama_title: String,
        staking_type: StakingType,
        total_revenue_estimate: u64,  // 预期总收益（单位：美元）
        suk_amount_to_stake: u64,     // 质押的SUK数量（等值于预期收益）
        revenue_share_percentage: u8,  // 收益分配百分比
        metadata_uri: String,          // IPFS上的短剧元数据（海报、预告片、版权证明等）
    ) -> Result<()> {
        require!(
            revenue_share_percentage >= 20 && revenue_share_percentage <= 60,
            ErrorCode::InvalidRevenueShare
        );

        let drama_staking = &mut ctx.accounts.drama_staking;
        drama_staking.owner = ctx.accounts.owner.key();
        drama_staking.drama_id = drama_id;
        drama_staking.drama_title = drama_title;
        drama_staking.staking_type = staking_type;
        drama_staking.total_revenue_estimate = total_revenue_estimate;
        drama_staking.suk_amount_staked = suk_amount_to_stake;
        drama_staking.revenue_share_percentage = revenue_share_percentage;
        drama_staking.metadata_uri = metadata_uri;
        drama_staking.kyc_status = KYCStatus::Pending;
        drama_staking.is_active = false;
        drama_staking.total_investors = 0;
        drama_staking.total_suk_invested = 0;
        drama_staking.total_revenue_distributed = 0;
        drama_staking.submitted_at = Clock::get()?.unix_timestamp;
        drama_staking.approved_at = 0;

        msg!("📝 短剧质押申请已提交：{}", drama_staking.drama_title);
        msg!("💰 预期收益：${}", total_revenue_estimate);
        msg!("🪙 质押SUK数量：{}", suk_amount_to_stake);
        
        Ok(())
    }

    /// KYC审核（管理员操作）
    pub fn review_kyc(
        ctx: Context<ReviewKYC>,
        approved: bool,
        review_notes: String,
    ) -> Result<()> {
        let drama_staking = &mut ctx.accounts.drama_staking;
        
        require!(
            drama_staking.kyc_status == KYCStatus::Pending,
            ErrorCode::KYCAlreadyReviewed
        );

        if approved {
            drama_staking.kyc_status = KYCStatus::Approved;
            drama_staking.is_active = true;
            drama_staking.approved_at = Clock::get()?.unix_timestamp;
            
            // 将版权方的SUK代币锁定到合约中
            let cpi_accounts = Transfer {
                from: ctx.accounts.owner_suk_account.to_account_info(),
                to: ctx.accounts.vault_suk_account.to_account_info(),
                authority: ctx.accounts.owner.to_account_info(),
            };
            let cpi_program = ctx.accounts.token_program.to_account_info();
            let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
            
            token::transfer(cpi_ctx, drama_staking.suk_amount_staked)?;

            msg!("✅ KYC审核通过，SUK已锁定到质押池");
            msg!("🎬 短剧《{}》现在可以接受投资", drama_staking.drama_title);
        } else {
            drama_staking.kyc_status = KYCStatus::Rejected;
            msg!("❌ KYC审核未通过：{}", review_notes);
        }

        Ok(())
    }

    /// 投资者认购（购买SUK权益份额）
    /// 投资者用USDT/DAI购买SUK，然后投入到指定短剧
    pub fn invest_in_drama(
        ctx: Context<InvestInDrama>,
        suk_amount: u64,
    ) -> Result<()> {
        let drama_staking = &mut ctx.accounts.drama_staking;
        
        require!(drama_staking.is_active, ErrorCode::DramaNotActive);
        require!(
            drama_staking.kyc_status == KYCStatus::Approved,
            ErrorCode::KYCNotApproved
        );

        // 检查投资者是否已存在
        let investor = &mut ctx.accounts.investor;
        let is_new_investor = investor.suk_amount_invested == 0;
        
        // 将投资者的SUK转入合约金库
        let cpi_accounts = Transfer {
            from: ctx.accounts.investor_suk_account.to_account_info(),
            to: ctx.accounts.vault_suk_account.to_account_info(),
            authority: ctx.accounts.investor_authority.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        
        token::transfer(cpi_ctx, suk_amount)?;

        // 更新投资者数据
        investor.investor = ctx.accounts.investor_authority.key();
        investor.drama_staking = ctx.accounts.drama_staking.key();
        investor.suk_amount_invested += suk_amount;
        investor.revenue_claimed = 0;
        investor.invested_at = Clock::get()?.unix_timestamp;

        // 更新短剧质押数据
        drama_staking.total_suk_invested += suk_amount;
        if is_new_investor {
            drama_staking.total_investors += 1;
        }

        msg!("💰 投资成功！");
        msg!("🎬 短剧：{}", drama_staking.drama_title);
        msg!("🪙 投资SUK：{}", suk_amount);
        msg!("👥 当前总投资者：{}", drama_staking.total_investors);

        Ok(())
    }

    /// 分发收益（管理员定期操作）
    /// 将短剧产生的收益（以SUK形式）分配给所有投资者
    pub fn distribute_revenue(
        ctx: Context<DistributeRevenue>,
        revenue_amount_suk: u64,  // 本次分配的SUK收益
    ) -> Result<()> {
        let drama_staking = &mut ctx.accounts.drama_staking;
        
        require!(drama_staking.is_active, ErrorCode::DramaNotActive);
        require!(
            drama_staking.total_suk_invested > 0,
            ErrorCode::NoInvestors
        );

        // 计算收益分配
        // 60% 给投资者
        // 30% 给版权方/出品方
        // 5% 平台运营
        // 5% SUK回购销毁
        
        let investor_share = revenue_amount_suk * 60 / 100;
        let copyright_share = revenue_amount_suk * 30 / 100;
        let platform_share = revenue_amount_suk * 5 / 100;
        let buyback_share = revenue_amount_suk * 5 / 100;

        drama_staking.total_revenue_distributed += revenue_amount_suk;
        drama_staking.last_distribution_at = Clock::get()?.unix_timestamp;

        msg!("💸 收益分配完成");
        msg!("📊 总收益：{} SUK", revenue_amount_suk);
        msg!("👥 投资者获得：{} SUK (60%)", investor_share);
        msg!("©️ 版权方获得：{} SUK (30%)", copyright_share);
        msg!("🏢 平台获得：{} SUK (5%)", platform_share);
        msg!("🔥 回购销毁：{} SUK (5%)", buyback_share);

        Ok(())
    }

    /// 投资者领取收益
    pub fn claim_revenue(ctx: Context<ClaimRevenue>) -> Result<()> {
        let drama_staking = &ctx.accounts.drama_staking;
        let investor = &mut ctx.accounts.investor;

        // 计算投资者应得收益
        let investor_share_percentage = (investor.suk_amount_invested as u128 * 10000 
            / drama_staking.total_suk_invested as u128) as u64; // 保留4位小数
        
        let total_investor_revenue = drama_staking.total_revenue_distributed * 60 / 100;
        let investor_revenue = total_investor_revenue * investor_share_percentage / 10000;
        let claimable_revenue = investor_revenue - investor.revenue_claimed;

        require!(claimable_revenue > 0, ErrorCode::NoRevenueToClaim);

        // 从金库转SUK给投资者
        let seeds = &[
            b"drama_staking",
            drama_staking.drama_id.as_bytes(),
            &[ctx.bumps.drama_staking],
        ];
        let signer = &[&seeds[..]];

        let cpi_accounts = Transfer {
            from: ctx.accounts.vault_suk_account.to_account_info(),
            to: ctx.accounts.investor_suk_account.to_account_info(),
            authority: ctx.accounts.drama_staking.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new_with_signer(cpi_program, cpi_accounts, signer);
        
        token::transfer(cpi_ctx, claimable_revenue)?;

        investor.revenue_claimed += claimable_revenue;
        investor.last_claim_at = Clock::get()?.unix_timestamp;

        msg!("💰 收益领取成功！");
        msg!("🪙 领取数量：{} SUK", claimable_revenue);

        Ok(())
    }

    /// 紧急暂停（管理员操作）
    pub fn emergency_pause(ctx: Context<EmergencyPause>) -> Result<()> {
        let drama_staking = &mut ctx.accounts.drama_staking;
        drama_staking.is_active = false;
        
        msg!("⚠️ 短剧质押已暂停");
        Ok(())
    }

    /// 恢复运营（管理员操作）
    pub fn resume_operations(ctx: Context<ResumeOperations>) -> Result<()> {
        let drama_staking = &mut ctx.accounts.drama_staking;
        require!(
            drama_staking.kyc_status == KYCStatus::Approved,
            ErrorCode::KYCNotApproved
        );
        
        drama_staking.is_active = true;
        msg!("✅ 短剧质押已恢复");
        Ok(())
    }
}

// ==================== 数据结构 ====================

#[account]
pub struct StakingPool {
    pub authority: Pubkey,           // 管理员地址
    pub pool_id: String,             // 池子ID
    pub total_staked_suk: u64,       // 总质押SUK数量
    pub total_dramas: u32,           // 总短剧数量
    pub created_at: i64,             // 创建时间
}

#[account]
pub struct DramaStaking {
    pub owner: Pubkey,                      // 版权方地址
    pub drama_id: String,                   // 短剧唯一ID
    pub drama_title: String,                // 短剧标题
    pub staking_type: StakingType,          // 质押类型
    pub total_revenue_estimate: u64,        // 预期总收益（美元）
    pub suk_amount_staked: u64,             // 版权方质押的SUK数量
    pub revenue_share_percentage: u8,       // 版权方收益分配比例（20%-60%）
    pub metadata_uri: String,               // 元数据URI（IPFS）
    pub kyc_status: KYCStatus,              // KYC状态
    pub is_active: bool,                    // 是否激活
    pub total_investors: u32,               // 总投资者数量
    pub total_suk_invested: u64,            // 投资者总投资SUK数量
    pub total_revenue_distributed: u64,     // 已分配总收益（SUK）
    pub submitted_at: i64,                  // 提交时间
    pub approved_at: i64,                   // 审核通过时间
    pub last_distribution_at: i64,          // 最后分配时间
}

#[account]
pub struct Investor {
    pub investor: Pubkey,            // 投资者地址
    pub drama_staking: Pubkey,       // 所属短剧质押账户
    pub suk_amount_invested: u64,    // 投资的SUK数量
    pub revenue_claimed: u64,        // 已领取收益（SUK）
    pub invested_at: i64,            // 投资时间
    pub last_claim_at: i64,          // 最后领取时间
}

// ==================== 枚举类型 ====================

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq, Eq)]
pub enum StakingType {
    CopyrightHolder,    // 版权方质押（60%收益）
    Producer,           // 出品方质押（30%收益）
    AICreator,          // AI创作者质押（20%收益）
    JointStaking,       // 联合质押（协议分配）
}

#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq, Eq)]
pub enum KYCStatus {
    Pending,    // 待审核
    Approved,   // 已通过
    Rejected,   // 已拒绝
}

// ==================== Context 定义 ====================

#[derive(Accounts)]
pub struct InitializeStakingPool<'info> {
    #[account(
        init,
        payer = authority,
        space = 8 + 32 + 64 + 8 + 4 + 8,
        seeds = [b"staking_pool"],
        bump
    )]
    pub staking_pool: Account<'info, StakingPool>,
    
    #[account(mut)]
    pub authority: Signer<'info>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(drama_id: String)]
pub struct SubmitDramaStaking<'info> {
    #[account(
        init,
        payer = owner,
        space = 8 + 32 + 128 + 256 + 1 + 8 + 8 + 1 + 256 + 1 + 1 + 4 + 8 + 8 + 8 + 8 + 8,
        seeds = [b"drama_staking", drama_id.as_bytes()],
        bump
    )]
    pub drama_staking: Account<'info, DramaStaking>,
    
    #[account(mut)]
    pub owner: Signer<'info>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct ReviewKYC<'info> {
    #[account(
        mut,
        seeds = [b"drama_staking", drama_staking.drama_id.as_bytes()],
        bump
    )]
    pub drama_staking: Account<'info, DramaStaking>,
    
    #[account(mut)]
    pub owner: Signer<'info>,
    
    #[account(mut)]
    pub owner_suk_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub vault_suk_account: Account<'info, TokenAccount>,
    
    pub authority: Signer<'info>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct InvestInDrama<'info> {
    #[account(
        mut,
        seeds = [b"drama_staking", drama_staking.drama_id.as_bytes()],
        bump
    )]
    pub drama_staking: Account<'info, DramaStaking>,
    
    #[account(
        init_if_needed,
        payer = investor_authority,
        space = 8 + 32 + 32 + 8 + 8 + 8 + 8,
        seeds = [b"investor", drama_staking.key().as_ref(), investor_authority.key().as_ref()],
        bump
    )]
    pub investor: Account<'info, Investor>,
    
    #[account(mut)]
    pub investor_authority: Signer<'info>,
    
    #[account(mut)]
    pub investor_suk_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub vault_suk_account: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct DistributeRevenue<'info> {
    #[account(
        mut,
        seeds = [b"drama_staking", drama_staking.drama_id.as_bytes()],
        bump
    )]
    pub drama_staking: Account<'info, DramaStaking>,
    
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct ClaimRevenue<'info> {
    #[account(
        seeds = [b"drama_staking", drama_staking.drama_id.as_bytes()],
        bump
    )]
    pub drama_staking: Account<'info, DramaStaking>,
    
    #[account(
        mut,
        seeds = [b"investor", drama_staking.key().as_ref(), investor_authority.key().as_ref()],
        bump
    )]
    pub investor: Account<'info, Investor>,
    
    pub investor_authority: Signer<'info>,
    
    #[account(mut)]
    pub investor_suk_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub vault_suk_account: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct EmergencyPause<'info> {
    #[account(
        mut,
        seeds = [b"drama_staking", drama_staking.drama_id.as_bytes()],
        bump
    )]
    pub drama_staking: Account<'info, DramaStaking>,
    
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct ResumeOperations<'info> {
    #[account(
        mut,
        seeds = [b"drama_staking", drama_staking.drama_id.as_bytes()],
        bump
    )]
    pub drama_staking: Account<'info, DramaStaking>,
    
    pub authority: Signer<'info>,
}

// ==================== 错误代码 ====================

#[error_code]
pub enum ErrorCode {
    #[msg("收益分配比例必须在20%-60%之间")]
    InvalidRevenueShare,
    
    #[msg("KYC已经审核过")]
    KYCAlreadyReviewed,
    
    #[msg("短剧未激活")]
    DramaNotActive,
    
    #[msg("KYC未通过")]
    KYCNotApproved,
    
    #[msg("没有投资者")]
    NoInvestors,
    
    #[msg("没有可领取的收益")]
    NoRevenueToClaim,
}
