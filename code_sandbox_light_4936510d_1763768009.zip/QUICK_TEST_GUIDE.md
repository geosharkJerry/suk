# SUK奖励系统 - 快速测试指南

## 🚀 5分钟快速测试

### 前置条件
- ✅ 后端服务已启动（`pm2 start server.js`）
- ✅ MongoDB已运行
- ✅ 奖励系统后端已部署

---

## 测试1: 观看奖励（2分钟）

### 操作步骤
1. 打开播放器页面：`http://localhost:3000/telegram-player-optimized.html?dramaId=xxx&episodeId=1`
2. 播放视频至少5秒
3. 等待视频结束或刷新页面

### 预期结果
✅ 看到奖励Toast提示：
```
┌─────────────────────┐
│  🎁  观看奖励        │
│      +0.XXXX SUK     │
└─────────────────────┘
```

### 验证方法
**浏览器控制台：**
```javascript
// 应该看到日志
✅ 观看奖励记录成功: { rewardAmount: 0.792, status: 'pending' }
```

**后端验证：**
```bash
# 查看数据库
mongosh
use suk_platform
db.watchrewards.find().limit(1).pretty()

# 预期输出
{
  userId: "123456789",
  dramaId: ObjectId("..."),
  episodeId: "ep001",
  watchDuration: 240,
  totalDuration: 300,
  rewardAmount: 0.792,
  status: "pending"
}
```

---

## 测试2: 奖励中心入口（1分钟）

### 操作步骤
1. 打开主页：`http://localhost:3000/telegram-app.html`
2. 找到用户卡片
3. 点击"💰 我的奖励"按钮

### 预期结果
✅ 页面跳转到奖励中心
✅ URL变为：`http://localhost:3000/telegram-reward-center.html`
✅ 显示用户奖励统计

---

## 测试3: 邀请功能（2分钟）

### 操作步骤
1. 在主页点击"🎁 邀请好友"按钮
2. 如果提示"请先绑定钱包"，先调用绑定API（见下方）
3. 再次点击按钮

### 预期结果（已绑定钱包）
✅ 打开Telegram分享窗口
✅ 链接格式：`https://your-domain.com/telegram-app.html?inviteCode=SUKXXXXX`

### 绑定钱包（如需要）
```bash
curl -X POST http://localhost:3000/api/rewards/bind-wallet \
  -H "Content-Type: application/json" \
  -H "X-Telegram-Init-Data: user=%7B%22id%22%3A123456789%7D" \
  -d '{"walletAddress":"0x1234567890abcdef1234567890abcdef12345678"}'
```

---

## 测试4: 邀请码使用（1分钟）

### 操作步骤
1. 复制邀请链接：`http://localhost:3000/telegram-app.html?inviteCode=SUKABC12`
2. 在新隐身窗口打开链接
3. 观察页面弹窗

### 预期结果
✅ 显示欢迎弹窗：
```
🎉 欢迎加入！
您已成功使用邀请码注册！
购买短剧时，邀请人将获得7%奖励。
```
✅ URL自动清理为：`http://localhost:3000/telegram-app.html`

### 验证方法
```bash
# 查询邀请关系
mongosh
use suk_platform
db.inviterelations.find().pretty()

# 预期输出
{
  inviterId: "123456789",
  inviteeId: "987654321",
  inviteCode: "SUKABC12",
  status: "registered"
}
```

---

## 🐛 问题排查速查表

| 问题 | 可能原因 | 解决方案 |
|------|----------|----------|
| 奖励Toast不显示 | 观看时长<5秒 | 播放更长时间 |
| API 404错误 | 路由未注册 | 检查server.js是否添加了`app.use('/api/rewards', rewardRoutes)` |
| 邀请按钮无反应 | 未绑定钱包 | 先调用绑定钱包API |
| 邀请码无效 | 重复使用 | 每个用户只能使用一次邀请码 |
| Telegram分享打不开 | 非Telegram环境 | 在Telegram Mini App中测试 |

---

## 📊 完整测试命令集

### 1. 测试观看奖励API
```bash
curl -X POST http://localhost:3000/api/rewards/watch \
  -H "Content-Type: application/json" \
  -H "X-Telegram-Init-Data: user=%7B%22id%22%3A123456789%7D" \
  -d '{
    "dramaId": "64a1b2c3d4e5f6",
    "episodeId": "ep001",
    "watchDuration": 240,
    "totalDuration": 300
  }'

# 预期响应
{
  "success": true,
  "data": {
    "rewardAmount": 0.792,
    "status": "pending",
    "validationScore": 100
  }
}
```

### 2. 测试生成邀请码
```bash
curl -X POST http://localhost:3000/api/rewards/invite/code \
  -H "X-Telegram-Init-Data: user=%7B%22id%22%3A123456789%7D"

# 预期响应
{
  "success": true,
  "data": {
    "inviteCode": "SUKABC12",
    "inviteLink": "http://localhost:3000/telegram-app.html?inviteCode=SUKABC12"
  }
}
```

### 3. 测试使用邀请码
```bash
curl -X POST http://localhost:3000/api/rewards/invite/use \
  -H "Content-Type: application/json" \
  -H "X-Telegram-Init-Data: user=%7B%22id%22%3A987654321%7D" \
  -d '{"inviteCode":"SUKABC12"}'

# 预期响应
{
  "success": true,
  "data": {
    "inviterId": "123456789",
    "inviteeId": "987654321",
    "inviteCode": "SUKABC12"
  }
}
```

### 4. 测试获取用户奖励统计
```bash
curl -X GET http://localhost:3000/api/rewards/stats \
  -H "X-Telegram-Init-Data: user=%7B%22id%22%3A123456789%7D"

# 预期响应
{
  "success": true,
  "data": {
    "totalEarned": 10.584,
    "totalPending": 3.256,
    "totalPaid": 7.328,
    "watchRewards": {
      "total": 3.920,
      "pending": 1.256,
      "paid": 2.664,
      "count": 8
    },
    "inviteRewards": {
      "total": 6.664,
      "pending": 2.000,
      "paid": 4.664,
      "count": 4
    }
  }
}
```

---

## 🔍 数据库查询速查

### 查看最新观看奖励
```javascript
db.watchrewards.find().sort({createdAt: -1}).limit(5).pretty()
```

### 查看邀请关系
```javascript
db.inviterelations.find().pretty()
```

### 查看用户奖励统计
```javascript
db.userrewardstats.find({userId: "123456789"}).pretty()
```

### 统计奖励总额
```javascript
db.watchrewards.aggregate([
  { $group: {
    _id: "$status",
    count: { $sum: 1 },
    total: { $sum: "$rewardAmount" }
  }}
])
```

---

## ✅ 测试完成检查清单

完成以下所有测试项目：

### 基础功能
- [ ] 观看奖励记录成功
- [ ] 奖励Toast显示正常
- [ ] 奖励中心按钮跳转正常
- [ ] 邀请按钮功能正常

### API测试
- [ ] POST /api/rewards/watch 返回200
- [ ] POST /api/rewards/invite/code 返回200
- [ ] POST /api/rewards/invite/use 返回200
- [ ] GET /api/rewards/stats 返回200

### 数据库验证
- [ ] WatchReward记录已创建
- [ ] InviteRelation记录已创建
- [ ] UserRewardStats已更新

### 用户体验
- [ ] 奖励Toast动画流畅
- [ ] 按钮触觉反馈正常
- [ ] Telegram分享窗口正常打开
- [ ] 邀请码自动处理成功

---

## 🚨 如果所有测试都失败

### 检查步骤：

1. **确认服务运行**
```bash
pm2 status
# 应该看到 server 状态为 online
```

2. **检查MongoDB连接**
```bash
mongosh
show dbs
# 应该看到 suk_platform 数据库
```

3. **检查路由注册**
```bash
# 在 server.js 中确认
const rewardRoutes = require('./backend/routes/reward.routes');
app.use('/api/rewards', rewardRoutes);
```

4. **查看详细日志**
```bash
pm2 logs server --lines 50
```

5. **重启服务**
```bash
pm2 restart server
pm2 logs server
```

---

## 📞 获取帮助

如果测试遇到问题，请提供：
1. 错误截图或日志
2. 浏览器控制台输出
3. 后端日志（`pm2 logs`）
4. 具体操作步骤

---

**文档版本**: 1.0  
**测试时长**: 约5分钟  
**难度**: ⭐⭐☆☆☆ 简单
