# SUK 前端配置指南

## 📋 概述

本指南将帮助您完成 SUK 智能合约部署后的前端配置工作，让您的网站能够与区块链上的智能合约进行交互。

## 🎯 配置步骤

### 第一步：部署智能合约

在配置前端之前，您需要先部署智能合约。请参考 `DEPLOYMENT_STEP_BY_STEP.md` 完成合约部署。

部署完成后，您将获得：
- ✅ SUKToken 合约地址
- ✅ SUKAirdrop 合约地址
- ✅ 部署网络信息（Goerli/Sepolia/Mainnet）

### 第二步：更新合约配置

#### 方法 1：通过代码更新（推荐）

在您的 HTML 页面中添加以下代码：

```html
<!DOCTYPE html>
<html>
<head>
    <title>SUK Airdrop</title>
    <!-- 引入 ethers.js -->
    <script src="https://cdn.jsdelivr.net/npm/ethers@5.7.2/dist/ethers.umd.min.js"></script>
    
    <!-- 引入配置文件 -->
    <script src="js/contract-config.js"></script>
    
    <!-- 引入 Web3 交互工具 -->
    <script src="js/web3-contract.js"></script>
</head>
<body>
    <script>
        // 步骤 1: 更新合约地址（部署后执行一次即可）
        ContractConfig.updateAllAddresses('goerli', {
            SUKToken: '0x你的SUKToken合约地址',
            SUKAirdrop: '0x你的SUKAirdrop合约地址'
        });
        
        // 步骤 2: 创建 Web3 合约实例
        const web3Contract = new SUKWeb3Contract('goerli');
        
        // 步骤 3: 连接钱包
        async function connectWallet() {
            try {
                const address = await web3Contract.connectWallet();
                console.log('✅ 钱包已连接:', address);
                
                // 获取 SUK 余额
                const balance = await web3Contract.getSUKBalance();
                console.log('💰 SUK 余额:', balance);
                
                // 检查是否可以领取空投
                const canClaim = await web3Contract.canClaimAirdrop();
                console.log('🎁 可以领取空投:', canClaim);
                
            } catch (error) {
                console.error('❌ 连接失败:', error);
            }
        }
        
        // 步骤 4: 领取空投
        async function claimAirdrop() {
            try {
                const receipt = await web3Contract.claimAirdrop();
                console.log('🎉 领取成功!', receipt);
            } catch (error) {
                console.error('❌ 领取失败:', error);
            }
        }
    </script>
    
    <button onclick="connectWallet()">连接钱包</button>
    <button onclick="claimAirdrop()">领取空投</button>
</body>
</html>
```

#### 方法 2：直接修改配置文件

打开 `js/contract-config.js` 文件，找到对应网络的配置部分，更新合约地址：

```javascript
networks: {
    goerli: {
        chainId: '0x5',
        chainName: 'Goerli Testnet',
        // ... 其他配置 ...
        contracts: {
            SUKToken: '0x你的SUKToken合约地址',      // ← 更新这里
            SUKAirdrop: '0x你的SUKAirdrop合约地址'   // ← 更新这里
        }
    }
}
```

### 第三步：更新空投页面

#### 更新 `suk-airdrop.html`

在文件顶部的 `<script>` 标签中，添加新的配置文件引用：

```html
<!-- 原有引用 -->
<script src="https://cdn.jsdelivr.net/npm/ethers@5.7.2/dist/ethers.umd.min.js"></script>

<!-- 新增引用 -->
<script src="js/contract-config.js"></script>
<script src="js/web3-contract.js"></script>
```

然后更新 JavaScript 代码部分：

```javascript
// 旧代码（删除或注释掉）
// const AIRDROP_CONTRACT_ADDRESS = '0x...';
// const AIRDROP_ABI = [...];

// 新代码
let web3Contract;
let userAddress;

async function connectWallet() {
    try {
        // 使用新的 Web3 工具类
        web3Contract = new SUKWeb3Contract('goerli'); // 或 'mainnet'
        userAddress = await web3Contract.connectWallet();
        
        // 更新 UI
        document.getElementById('wallet-address').textContent = 
            web3Contract.formatAddress(userAddress);
        document.getElementById('wallet-status').textContent = '已连接';
        
        // 加载数据
        await loadAirdropData();
        await loadUserData();
        
    } catch (error) {
        console.error('连接失败:', error);
        alert('连接钱包失败: ' + error.message);
    }
}

async function loadAirdropData() {
    // 获取空投统计信息
    const stats = await web3Contract.getAirdropStats();
    
    document.getElementById('whitelist-amount').textContent = stats.whitelistAmount;
    document.getElementById('public-amount').textContent = stats.publicAmount;
    document.getElementById('total-claimed').textContent = stats.totalClaimed;
    
    // ... 其他 UI 更新 ...
}

async function loadUserData() {
    // 检查是否已领取
    const hasClaimed = await web3Contract.hasClaimedAirdrop();
    
    if (hasClaimed) {
        // 显示已领取状态
        document.getElementById('claimed-status').style.display = 'block';
    } else {
        // 显示可领取金额
        const claimable = await web3Contract.getClaimableAmount();
        document.getElementById('claimable-amount').textContent = claimable;
    }
}

async function claimAirdrop() {
    try {
        const receipt = await web3Contract.claimAirdrop();
        
        // 显示成功消息
        alert('🎉 领取成功！交易哈希: ' + receipt.transactionHash);
        
        // 刷新页面数据
        await loadAirdropData();
        await loadUserData();
        
    } catch (error) {
        console.error('领取失败:', error);
        alert('领取失败: ' + error.message);
    }
}
```

### 第四步：更新短剧播放器（X402 协议）

#### 更新 `js/x402-player.js`

在文件顶部添加配置引用：

```javascript
// 引入配置（如果在 HTML 中已引入，则无需重复）
// <script src="js/contract-config.js"></script>
// <script src="js/web3-contract.js"></script>

class X402Player {
    constructor(videoElement, dramaId) {
        this.video = videoElement;
        this.dramaId = dramaId;
        this.web3Contract = null;
        this.billingInterval = null;
        
        // X402 协议配置
        this.ratePerSecond = 0.01; // 1秒 = 0.01 SUK
        this.billingIntervalSeconds = 10; // 每10秒计费一次
        this.platformAddress = '0x平台收款地址'; // 需要配置
    }
    
    async init() {
        // 初始化 Web3 合约
        this.web3Contract = new SUKWeb3Contract('goerli');
        await this.web3Contract.connectWallet();
        
        // 启动计费
        this.startBilling();
    }
    
    startBilling() {
        this.billingInterval = setInterval(async () => {
            if (this.video.paused) return;
            
            try {
                // 计算应付金额
                const watchTime = this.billingIntervalSeconds;
                const amount = (watchTime * this.ratePerSecond).toFixed(2);
                
                // 检查余额
                const balance = await this.web3Contract.getSUKBalance();
                if (parseFloat(balance) < parseFloat(amount)) {
                    this.video.pause();
                    alert('SUK 余额不足，请充值后继续观看');
                    return;
                }
                
                // 执行支付
                await this.web3Contract.transferSUK(this.platformAddress, amount);
                console.log(`✅ X402计费: ${watchTime}秒, 支付 ${amount} SUK`);
                
            } catch (error) {
                console.error('计费失败:', error);
                this.video.pause();
            }
            
        }, this.billingIntervalSeconds * 1000);
    }
    
    stopBilling() {
        if (this.billingInterval) {
            clearInterval(this.billingInterval);
            this.billingInterval = null;
        }
    }
}
```

### 第五步：配置网络参数

根据您的部署环境，选择合适的网络：

#### 测试网络（推荐先在测试网测试）

**Goerli 测试网**：
```javascript
ContractConfig.setDefaultNetwork('goerli');
```

**Sepolia 测试网**：
```javascript
ContractConfig.setDefaultNetwork('sepolia');
```

#### 主网（生产环境）

**Ethereum 主网**：
```javascript
ContractConfig.setDefaultNetwork('mainnet');
```

**Polygon 主网**（低 Gas 费）：
```javascript
ContractConfig.setDefaultNetwork('polygon');
```

**BSC 主网**（低 Gas 费）：
```javascript
ContractConfig.setDefaultNetwork('bsc');
```

### 第六步：配置平台收款地址

在需要收款的页面中配置平台地址：

```javascript
// X402 播放器中
const PLATFORM_WALLET = '0x你的平台钱包地址';

// 在 x402-player.js 或相关文件中更新
this.platformAddress = PLATFORM_WALLET;
```

## 🔧 完整页面更新示例

### 更新后的 `suk-airdrop.html` 完整引用部分

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SUK代币空投 - SUK Protocol</title>
    
    <!-- 步骤 1: 引入 ethers.js -->
    <script src="https://cdn.jsdelivr.net/npm/ethers@5.7.2/dist/ethers.umd.min.js"></script>
    
    <!-- 步骤 2: 引入配置文件 -->
    <script src="js/contract-config.js"></script>
    
    <!-- 步骤 3: 引入 Web3 工具类 -->
    <script src="js/web3-contract.js"></script>
    
    <!-- 原有样式 -->
    <style>
        /* ... 保持原有样式 ... */
    </style>
</head>
<body>
    <!-- HTML 内容保持不变 -->
    
    <script>
        // ========================================
        // 配置部分 - 部署后更新这里
        // ========================================
        
        // 设置网络（goerli/sepolia/mainnet/polygon/bsc）
        const NETWORK = 'goerli';
        
        // 更新合约地址（部署后执行一次）
        ContractConfig.updateAllAddresses(NETWORK, {
            SUKToken: '0x你的SUKToken合约地址',
            SUKAirdrop: '0x你的SUKAirdrop合约地址'
        });
        
        // ========================================
        // 应用逻辑（保持不变或使用新 API）
        // ========================================
        
        let web3Contract;
        let userAddress;
        
        // 连接钱包
        async function connectWallet() {
            try {
                web3Contract = new SUKWeb3Contract(NETWORK);
                userAddress = await web3Contract.connectWallet();
                
                // 更新 UI
                updateWalletUI();
                
                // 加载数据
                await loadAirdropData();
                await loadUserData();
                
            } catch (error) {
                console.error('连接失败:', error);
                showError('连接钱包失败: ' + error.message);
            }
        }
        
        // 领取空投
        async function claimAirdrop() {
            try {
                const receipt = await web3Contract.claimAirdrop();
                showSuccess('🎉 领取成功！');
                
                // 刷新数据
                await loadAirdropData();
                await loadUserData();
                
            } catch (error) {
                console.error('领取失败:', error);
                showError('领取失败: ' + error.message);
            }
        }
        
        // ... 其他函数 ...
    </script>
</body>
</html>
```

## ✅ 配置清单

完成以下检查确保配置正确：

### 1. 文件引用
- [ ] `js/contract-config.js` 已创建
- [ ] `js/web3-contract.js` 已创建
- [ ] HTML 页面已正确引入上述文件

### 2. 合约地址
- [ ] SUKToken 合约地址已更新
- [ ] SUKAirdrop 合约地址已更新
- [ ] 网络配置正确（测试网/主网）

### 3. 平台配置
- [ ] 平台收款地址已配置
- [ ] X402 计费参数已配置（费率、间隔等）

### 4. 功能测试
- [ ] 钱包连接正常
- [ ] 余额查询正常
- [ ] 空投领取功能正常
- [ ] X402 计费功能正常

## 🧪 测试指南

### 本地测试步骤

1. **启动本地服务器**
```bash
# 使用 Python
python -m http.server 8000

# 或使用 Node.js
npx http-server -p 8000
```

2. **打开浏览器**
访问 `http://localhost:8000/suk-airdrop.html`

3. **连接 MetaMask**
- 确保 MetaMask 已切换到正确的网络
- 点击"连接钱包"按钮
- 授权连接

4. **测试功能**
- 查看余额
- 查看空投信息
- 尝试领取（如果符合条件）

### 常见问题排查

#### 问题 1: 连接钱包失败
```javascript
// 检查 MetaMask 是否已安装
if (!window.ethereum) {
    alert('请先安装 MetaMask 钱包');
}
```

#### 问题 2: 网络不匹配
```javascript
// 检查当前网络
const chainId = await window.ethereum.request({ method: 'eth_chainId' });
console.log('当前网络 Chain ID:', chainId);
```

#### 问题 3: 合约调用失败
```javascript
// 检查合约地址是否正确
console.log('SUKToken 地址:', ContractConfig.getConfig('goerli').contracts.SUKToken);
console.log('SUKAirdrop 地址:', ContractConfig.getConfig('goerli').contracts.SUKAirdrop);

// 验证合约是否已配置
if (!ContractConfig.isConfigured('goerli')) {
    console.error('❌ 合约地址尚未配置！');
}
```

## 📱 移动端配置

### MetaMask 移动端

在移动端浏览器中使用 MetaMask：

1. 安装 MetaMask 移动应用
2. 在应用内打开浏览器
3. 访问您的网站 URL
4. 连接钱包并使用

### WalletConnect 集成（可选）

如需支持更多钱包，可以集成 WalletConnect：

```html
<script src="https://cdn.jsdelivr.net/npm/@walletconnect/web3-provider@1.8.0/dist/umd/index.min.js"></script>
```

## 🚀 部署上线

### 更新 README.md

在 `README.md` 中添加合约地址信息：

```markdown
## 🔗 智能合约地址

### Goerli 测试网
- SUKToken: `0x你的合约地址`
- SUKAirdrop: `0x你的合约地址`
- 区块浏览器: [Goerli Etherscan](https://goerli.etherscan.io/address/0x...)

### Ethereum 主网
- SUKToken: `0x你的合约地址`
- SUKAirdrop: `0x你的合约地址`
- 区块浏览器: [Etherscan](https://etherscan.io/address/0x...)
```

### 环境变量配置（生产环境）

创建 `.env.production` 文件：

```bash
# 主网配置
NETWORK=mainnet
SUK_TOKEN_ADDRESS=0x你的SUKToken合约地址
SUK_AIRDROP_ADDRESS=0x你的SUKAirdrop合约地址
PLATFORM_WALLET=0x你的平台钱包地址

# Infura API Key (用于后端服务)
INFURA_API_KEY=your_infura_api_key
```

## 📞 技术支持

如果在配置过程中遇到问题：

1. 查看浏览器控制台错误信息
2. 检查 MetaMask 网络设置
3. 验证合约地址是否正确
4. 确认合约已成功部署并验证

---

**配置完成后，您的前端将能够：**
- ✅ 连接 MetaMask 钱包
- ✅ 查询 SUK 余额
- ✅ 领取空投代币
- ✅ 使用 X402 协议观看短剧
- ✅ 查看交易历史
- ✅ 管理代币授权

祝您配置顺利！🎉
