# SUK Protocol - Cloudflare Pages 部署指南

> 🚀 将 SUK Protocol 静态网站部署到 Cloudflare Pages 生产环境的完整指南

---

## 📋 目录

1. [部署概览](#部署概览)
2. [前置准备](#前置准备)
3. [方式一：通过 Git 连接自动部署（推荐）](#方式一通过-git-连接自动部署推荐)
4. [方式二：使用 Wrangler CLI 手动部署](#方式二使用-wrangler-cli-手动部署)
5. [方式三：通过 GitHub Actions 自动部署](#方式三通过-github-actions-自动部署)
6. [自定义域名配置](#自定义域名配置)
7. [环境变量配置](#环境变量配置)
8. [部署验证](#部署验证)
9. [常见问题](#常见问题)
10. [最佳实践](#最佳实践)

---

## 部署概览

### 🌟 为什么选择 Cloudflare Pages?

- ✅ **完全免费** - 无限带宽和请求数
- ⚡ **全球 CDN** - 超过 300+ 边缘节点
- 🔒 **自动 HTTPS** - 免费 SSL 证书
- 🚀 **秒级部署** - Git push 自动触发部署
- 💰 **零运营成本** - 无需管理服务器
- 📊 **Web Analytics** - 免费的分析工具

### 项目信息

```
项目名称: SUK Protocol
项目类型: 静态网站 (HTML/CSS/JavaScript)
框架: Vanilla JS (无框架依赖)
构建要求: 无需构建步骤
```

---

## 前置准备

### 1. Cloudflare 账号

1. 访问 [Cloudflare Dashboard](https://dash.cloudflare.com/)
2. 注册免费账号（如果还没有）
3. 完成邮箱验证

### 2. Git 仓库

确保您的代码已推送到以下平台之一：
- GitHub
- GitLab
- Bitbucket

### 3. 项目文件检查

确认项目根目录包含以下文件：
- ✅ `index.html` - 主页文件
- ✅ `_headers` - HTTP 头配置
- ✅ `_redirects` - 重定向规则配置
- ✅ `cloudflare-pages.json` - Cloudflare Pages 配置（可选）

---

## 方式一：通过 Git 连接自动部署（推荐）

这是**最简单、最推荐**的部署方式，适合团队协作和持续部署。

### 步骤 1: 登录 Cloudflare Dashboard

1. 访问 [Cloudflare Pages](https://dash.cloudflare.com/?to=/:account/pages)
2. 点击 **"Create a project"** 按钮

### 步骤 2: 连接 Git 仓库

1. 选择 **"Connect to Git"**
2. 选择您的 Git 提供商：
   - GitHub
   - GitLab
   - Bitbucket
3. 授权 Cloudflare 访问您的仓库
4. 选择 `suk-protocol` 仓库

### 步骤 3: 配置构建设置

```
项目名称:        suk-protocol
生产分支:        main (或 master)
构建命令:        (留空)
构建输出目录:     .
根目录:          /
Node.js 版本:    18
```

**重要说明**：
- ✅ SUK Protocol 是纯静态网站，**不需要构建步骤**
- ✅ 构建命令留空即可
- ✅ 构建输出目录设为 `.` (当前目录)

### 步骤 4: 点击部署

1. 点击 **"Save and Deploy"**
2. Cloudflare 会自动：
   - 克隆您的仓库
   - 部署所有静态文件
   - 分配一个 `.pages.dev` 域名
3. 部署完成后，您会看到：

```
✅ Deployment successful!
🌐 Production URL: https://suk-protocol.pages.dev
⏱️  Deployment time: ~30 seconds
```

### 步骤 5: 验证部署

访问您的网站：
```bash
https://suk-protocol.pages.dev
```

检查以下页面是否正常：
- [ ] https://suk-protocol.pages.dev/ (主页)
- [ ] https://suk-protocol.pages.dev/staking-dashboard.html
- [ ] https://suk-protocol.pages.dev/investor-dashboard.html
- [ ] https://suk-protocol.pages.dev/revenue-claim.html
- [ ] https://suk-protocol.pages.dev/investor-subscription.html

---

## 方式二：使用 Wrangler CLI 手动部署

适合本地快速测试和手动部署场景。

### 步骤 1: 安装 Wrangler CLI

```bash
# 使用 npm 全局安装
npm install -g wrangler

# 或使用 yarn
yarn global add wrangler

# 验证安装
wrangler --version
```

### 步骤 2: 登录 Cloudflare

```bash
wrangler login
```

这会打开浏览器窗口，完成 OAuth 认证。

### 步骤 3: 创建 Pages 项目（首次部署）

```bash
# 在项目根目录执行
wrangler pages project create suk-protocol

# 选择生产分支
? Production branch: main
```

### 步骤 4: 部署到 Cloudflare Pages

```bash
# 部署当前目录所有文件
wrangler pages deploy . --project-name=suk-protocol

# 或指定特定分支
wrangler pages deploy . --project-name=suk-protocol --branch=main
```

### 步骤 5: 查看部署状态

```bash
# 查看部署历史
wrangler pages deployment list --project-name=suk-protocol

# 查看项目详情
wrangler pages project list
```

### 部署输出示例

```
✨ Compiled Worker successfully
✨ Uploading...
✨ Deployment complete! Take a peek over at https://abc123.suk-protocol.pages.dev
```

---

## 方式三：通过 GitHub Actions 自动部署

实现真正的 CI/CD 自动化部署流程。

### 步骤 1: 获取 Cloudflare API Token

1. 访问 [Cloudflare API Tokens](https://dash.cloudflare.com/profile/api-tokens)
2. 点击 **"Create Token"**
3. 选择 **"Edit Cloudflare Workers"** 模板
4. 修改权限：
   - **Account** → **Cloudflare Pages** → **Edit**
5. 点击 **"Continue to summary"** → **"Create Token"**
6. **保存 Token**（只显示一次！）

### 步骤 2: 获取 Cloudflare Account ID

1. 访问 [Cloudflare Dashboard](https://dash.cloudflare.com/)
2. 选择任意域名
3. 在右侧栏找到 **"Account ID"**
4. 复制 Account ID

### 步骤 3: 配置 GitHub Secrets

1. 进入您的 GitHub 仓库
2. 点击 **Settings** → **Secrets and variables** → **Actions**
3. 点击 **"New repository secret"**，添加以下 secrets：

```
Name: CLOUDFLARE_API_TOKEN
Value: <您的 API Token>

Name: CLOUDFLARE_ACCOUNT_ID
Value: <您的 Account ID>
```

### 步骤 4: 创建 GitHub Actions 工作流

工作流文件已自动创建在：`.github/workflows/cloudflare-pages-deploy.yml`

### 步骤 5: 触发自动部署

```bash
# 方法 1: 推送代码到主分支
git add .
git commit -m "Deploy to Cloudflare Pages"
git push origin main

# 方法 2: 手动触发（在 GitHub Actions 页面）
# Actions → Deploy to Cloudflare Pages → Run workflow
```

### 部署流程

```
1. 代码推送到 GitHub
   ↓
2. GitHub Actions 自动触发
   ↓
3. 运行工作流：
   - Checkout 代码
   - 安装依赖（如果需要）
   - 构建项目（如果需要）
   - 部署到 Cloudflare Pages
   ↓
4. 部署完成
   ↓
5. 网站自动更新
```

---

## 自定义域名配置

将您的自定义域名（如 `suk.link`）连接到 Cloudflare Pages。

### 步骤 1: 添加自定义域名

1. 进入 [Cloudflare Pages](https://dash.cloudflare.com/?to=/:account/pages)
2. 选择 `suk-protocol` 项目
3. 点击 **"Custom domains"** 标签
4. 点击 **"Set up a custom domain"**
5. 输入您的域名（例如：`suk.link` 或 `www.suk.link`）
6. 点击 **"Continue"**

### 步骤 2: 配置 DNS 记录

Cloudflare 会自动检测并配置 DNS：

#### 如果域名在 Cloudflare 托管：
- ✅ DNS 记录会自动创建
- ✅ SSL 证书会自动配置

#### 如果域名在其他 DNS 提供商：
1. 登录您的 DNS 提供商
2. 添加以下 CNAME 记录：

```
类型:   CNAME
名称:   @ (或 www)
值:     suk-protocol.pages.dev
TTL:    Auto
代理:   是（推荐）
```

### 步骤 3: 等待 DNS 传播

- DNS 传播通常需要 **5-10 分钟**
- 最长可能需要 **48 小时**

### 步骤 4: 验证域名

访问您的自定义域名：
```
https://suk.link
https://www.suk.link
```

### 多域名配置示例

您可以添加多个自定义域名：

```
主域名:           suk.link
子域名:           app.suk.link
测试域名:         staging.suk.link
```

---

## 环境变量配置

Cloudflare Pages 支持环境变量，用于存储敏感配置。

### 步骤 1: 添加环境变量

1. 进入项目设置：**Settings** → **Environment variables**
2. 点击 **"Add variable"**
3. 添加变量：

```javascript
// 生产环境变量
变量名: API_BASE_URL
值: https://api.suk.link
环境: Production

变量名: SOLANA_RPC_URL
值: https://api.mainnet-beta.solana.com
环境: Production

变量名: ETHEREUM_NETWORK
值: mainnet
环境: Production
```

### 步骤 2: 在代码中使用

```javascript
// 在前端代码中访问环境变量（如果使用构建工具）
const API_URL = process.env.API_BASE_URL || 'https://api.suk.link';

// 纯静态网站建议使用配置文件
// config.js
const config = {
    apiBaseUrl: 'https://api.suk.link',
    solanaRpcUrl: 'https://api.mainnet-beta.solana.com',
    ethereumNetwork: 'mainnet'
};
```

---

## 部署验证

### 1. 功能检查清单

部署完成后，逐一验证以下功能：

#### 基础功能
- [ ] 主页加载正常
- [ ] CSS 样式加载正常
- [ ] JavaScript 脚本执行正常
- [ ] 图片和静态资源加载正常

#### 核心页面
- [ ] Staking Dashboard (质押方控制面板)
- [ ] Investor Dashboard (投资者控制面板)
- [ ] Revenue Claim (收益领取)
- [ ] Investor Subscription (短剧投资)

#### 钱包集成
- [ ] MetaMask 钱包连接正常
- [ ] Phantom 钱包连接正常
- [ ] 网络切换功能正常
- [ ] 合约交互正常

#### 区块链功能
- [ ] Solana 交易正常
- [ ] Ethereum 交易正常
- [ ] 合约读取功能正常
- [ ] 合约写入功能正常

### 2. 性能检查

使用 [PageSpeed Insights](https://pagespeed.web.dev/) 检查：

```
目标指标:
- Performance: > 90
- Accessibility: > 90
- Best Practices: > 90
- SEO: > 90
```

### 3. 浏览器兼容性测试

测试以下浏览器：
- [ ] Chrome (最新版)
- [ ] Firefox (最新版)
- [ ] Safari (最新版)
- [ ] Edge (最新版)
- [ ] 移动端 Safari
- [ ] 移动端 Chrome

### 4. 安全检查

```bash
# 检查 HTTP 安全头
curl -I https://suk.link

# 应该包含:
# X-Content-Type-Options: nosniff
# X-Frame-Options: DENY
# X-XSS-Protection: 1; mode=block
# Content-Security-Policy: ...
```

---

## 常见问题

### Q1: 部署后页面显示 404

**原因**: 文件路径不正确或 `_redirects` 配置错误

**解决方案**:
```bash
# 检查 _redirects 文件
cat _redirects

# 确认 SPA 回退规则
/* /index.html 200

# 重新部署
wrangler pages deploy .
```

### Q2: 部署成功但样式丢失

**原因**: CSS 文件路径错误或被缓存

**解决方案**:
```html
<!-- 使用绝对路径 -->
<link rel="stylesheet" href="/css/style.css">

<!-- 清除浏览器缓存 -->
Ctrl + Shift + R (Windows)
Cmd + Shift + R (Mac)
```

### Q3: 钱包连接失败

**原因**: CSP (Content Security Policy) 阻止了外部脚本

**解决方案**:
```bash
# 检查 _headers 文件中的 CSP 配置
# 确保包含钱包相关域名:
# script-src 'self' 'unsafe-inline' https://*.solana.com https://*.ethereum.org
```

### Q4: 部署时间过长

**原因**: 文件数量过多或文件体积过大

**解决方案**:
```bash
# 排除不必要的文件
echo "node_modules/" >> .cfignore
echo ".git/" >> .cfignore
echo "*.md" >> .cfignore

# 或创建 .cfignore 文件
cat > .cfignore << EOF
node_modules/
.git/
*.md
.env*
*.log
EOF
```

### Q5: 环境变量不生效

**原因**: 纯静态网站无法直接使用服务器端环境变量

**解决方案**:
```javascript
// 使用配置文件代替环境变量
// config.production.js
const config = {
    apiUrl: 'https://api.suk.link',
    environment: 'production'
};

export default config;
```

### Q6: 自定义域名不工作

**原因**: DNS 配置错误或尚未传播

**解决方案**:
```bash
# 检查 DNS 记录
nslookup suk.link
dig suk.link

# 等待 DNS 传播（最多 48 小时）
# 或使用 https://dnschecker.org/ 检查全球 DNS 状态
```

---

## 最佳实践

### 1. 使用 Preview 部署测试

```bash
# 为每个 PR 创建预览部署
# Cloudflare 会自动为每个分支/PR 创建预览 URL
# 例如: https://abc123.suk-protocol.pages.dev
```

**好处**:
- ✅ 在合并前测试更改
- ✅ 不影响生产环境
- ✅ 团队成员可以预览功能

### 2. 使用版本回滚

```bash
# 如果新版本有问题，可以快速回滚到上一个版本
# 在 Cloudflare Dashboard:
# Pages → suk-protocol → Deployments → View deployment → Rollback to this deployment
```

### 3. 配置 Web Analytics

```bash
# 在 Cloudflare Dashboard 启用 Web Analytics
# Settings → Analytics → Enable Web Analytics
```

**提供的指标**:
- 页面浏览量
- 独立访客数
- 访问时长
- 流量来源
- 设备类型

### 4. 启用 Bot Protection

```bash
# 在 Cloudflare Dashboard 启用 Bot 防护
# Security → Bots → Configure Super Bot Fight Mode
```

### 5. 使用构建缓存

```yaml
# 在 GitHub Actions 中启用缓存
- name: Cache Dependencies
  uses: actions/cache@v3
  with:
    path: ~/.npm
    key: ${{ runner.os }}-node-${{ hashFiles('**/package-lock.json') }}
```

### 6. 监控部署状态

```bash
# 使用 Cloudflare API 监控部署
curl -X GET "https://api.cloudflare.com/client/v4/accounts/:account_id/pages/projects/suk-protocol/deployments" \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN"
```

### 7. 设置告警通知

```bash
# 在 Cloudflare Dashboard 配置告警
# Account → Notifications → Add
# 可监控:
# - 部署失败
# - 流量异常
# - 错误率上升
```

---

## 总结

### 快速部署命令

```bash
# 方法 1: Git 连接（推荐）
1. 登录 Cloudflare Dashboard
2. Connect to Git
3. 选择仓库
4. 点击 Deploy

# 方法 2: Wrangler CLI
wrangler login
wrangler pages project create suk-protocol
wrangler pages deploy . --project-name=suk-protocol

# 方法 3: GitHub Actions
git push origin main
# (自动触发部署)
```

### 关键配置文件

```
项目根目录/
├── _headers              # HTTP 安全头配置
├── _redirects            # URL 重定向规则
├── cloudflare-pages.json # Cloudflare Pages 配置
└── .github/
    └── workflows/
        └── cloudflare-pages-deploy.yml  # CI/CD 工作流
```

### 有用链接

- 📖 [Cloudflare Pages 官方文档](https://developers.cloudflare.com/pages/)
- 🎯 [Cloudflare Dashboard](https://dash.cloudflare.com/)
- 💬 [Cloudflare Discord 社区](https://discord.cloudflare.com/)
- 🐛 [问题反馈](https://github.com/cloudflare/pages-action/issues)

---

## 下一步

部署完成后，您可以：

1. ✅ 配置自定义域名
2. ✅ 启用 Web Analytics
3. ✅ 设置 Bot Protection
4. ✅ 配置 CI/CD 自动化
5. ✅ 监控网站性能和流量

---

**🎉 恭喜！您已成功将 SUK Protocol 部署到 Cloudflare Pages 生产环境！**

*最后更新：2024-11-18*
