# ⚡ Cloudflare 部署命令速查

## 🚀 快速开始（3步）

```bash
# 1. 安装 Wrangler
npm install -g wrangler

# 2. 登录 Cloudflare
wrangler login

# 3. 部署项目
wrangler pages publish . --project-name=suk-link
```

---

## 📦 安装和登录

```bash
# 安装 Wrangler（全局）
npm install -g wrangler

# 或使用 yarn
yarn global add wrangler

# 或使用 pnpm
pnpm add -g wrangler

# 检查版本
wrangler --version

# 登录 Cloudflare
wrangler login

# 登出
wrangler logout

# 检查登录状态
wrangler whoami
```

---

## 🚀 部署命令

```bash
# 部署到测试环境
wrangler pages publish . \
  --project-name=suk-link \
  --branch=test

# 部署到生产环境
wrangler pages publish . \
  --project-name=suk-link \
  --branch=main

# 部署并跳过缓存
wrangler pages publish . \
  --project-name=suk-link \
  --skip-caching

# 部署特定目录
wrangler pages publish ./dist \
  --project-name=suk-link

# 部署时设置环境变量
wrangler pages publish . \
  --project-name=suk-link \
  --env production
```

---

## 📋 项目管理

```bash
# 列出所有项目
wrangler pages project list

# 创建新项目
wrangler pages project create suk-link

# 查看项目详情
wrangler pages project show suk-link

# 删除项目
wrangler pages project delete suk-link
```

---

## 📊 部署管理

```bash
# 查看部署列表
wrangler pages deployment list \
  --project-name=suk-link

# 查看最近10次部署
wrangler pages deployment list \
  --project-name=suk-link \
  --limit=10

# 查看特定部署详情
wrangler pages deployment show <deployment-id> \
  --project-name=suk-link

# 查看实时日志
wrangler pages deployment tail \
  --project-name=suk-link

# 重新部署
wrangler pages deployment retry <deployment-id> \
  --project-name=suk-link
```

---

## 🌐 域名管理

```bash
# 添加自定义域名
wrangler pages domain add suk-link suk.link

# 添加子域名
wrangler pages domain add suk-link www.suk.link

# 列出所有域名
wrangler pages domain list suk-link

# 删除域名
wrangler pages domain remove suk-link suk.link
```

---

## 🔐 密钥管理

```bash
# 添加环境变量
wrangler pages secret put API_KEY \
  --project-name=suk-link

# 列出所有密钥
wrangler pages secret list \
  --project-name=suk-link

# 删除密钥
wrangler pages secret delete API_KEY \
  --project-name=suk-link
```

---

## 📝 常用组合命令

```bash
# 清理 + 重新部署
rm -rf .wrangler && \
wrangler pages publish . --project-name=suk-link

# 部署 + 查看日志
wrangler pages publish . --project-name=suk-link && \
wrangler pages deployment tail --project-name=suk-link

# 部署 + 查看列表
wrangler pages publish . --project-name=suk-link && \
wrangler pages deployment list --project-name=suk-link --limit=1

# 快速查看最新部署URL
wrangler pages deployment list --project-name=suk-link --limit=1 | grep "https://"
```

---

## 🧪 开发和测试

```bash
# 本地开发预览
wrangler pages dev .

# 指定端口
wrangler pages dev . --port=8080

# 使用本地环境变量
wrangler pages dev . --local-protocol=http

# 测试特定部署
wrangler pages deployment show <deployment-id> \
  --project-name=suk-link
```

---

## 🔍 诊断命令

```bash
# 查看帮助
wrangler --help
wrangler pages --help
wrangler pages publish --help

# 详细输出（调试用）
wrangler pages publish . \
  --project-name=suk-link \
  --verbose

# 检查配置文件
cat wrangler.toml

# 检查忽略文件
cat .cloudflare-ignore

# 检查重定向规则
cat _redirects

# 检查头配置
cat _headers
```

---

## 📊 性能测试

```bash
# 测试网站速度
curl -o /dev/null -s -w "Time: %{time_total}s\n" https://suk.link

# 测试 TTFB
curl -o /dev/null -s -w "TTFB: %{time_starttransfer}s\n" https://suk.link

# 测试 DNS 解析
dig suk.link
nslookup suk.link

# 测试 SSL 连接
openssl s_client -connect suk.link:443 -servername suk.link

# 测试 HTTP 头
curl -I https://suk.link

# 测试重定向
curl -I https://suk.link/api/health
```

---

## 🔧 故障排查

```bash
# 清理本地缓存
rm -rf .wrangler
rm -rf node_modules/.cache

# 重新安装 Wrangler
npm uninstall -g wrangler
npm install -g wrangler

# 检查网络连接
ping cloudflare.com
curl -I https://api.cloudflare.com

# 验证 Cloudflare 登录
wrangler whoami

# 检查项目配置
wrangler pages project show suk-link

# 查看错误日志
wrangler pages deployment list --project-name=suk-link
# 找到失败的部署，查看详情
```

---

## 📦 Git 集成

```bash
# 连接 GitHub 仓库（通过 Dashboard）
# 1. 访问 https://dash.cloudflare.com
# 2. Workers & Pages → Create → Connect to Git
# 3. 选择仓库
# 4. 配置构建设置
# 5. 自动部署

# 自动部署触发
git add .
git commit -m "Update website"
git push origin main
# Cloudflare 自动检测并部署
```

---

## 🌍 环境变量

```bash
# 生产环境
wrangler pages publish . \
  --project-name=suk-link \
  --env production

# 开发环境
wrangler pages publish . \
  --project-name=suk-link \
  --env development

# 查看环境配置
cat wrangler.toml
```

---

## 📋 完整部署流程

```bash
#!/bin/bash
# 完整部署脚本

echo "🚀 开始部署到 Cloudflare Pages"

# 1. 检查 Wrangler
if ! command -v wrangler &> /dev/null; then
    echo "❌ Wrangler 未安装"
    echo "📦 正在安装..."
    npm install -g wrangler
fi

# 2. 检查登录状态
echo "🔐 检查登录状态..."
if ! wrangler whoami &> /dev/null; then
    echo "❌ 未登录"
    echo "🔑 请登录..."
    wrangler login
fi

# 3. 部署
echo "🚀 开始部署..."
wrangler pages publish . \
  --project-name=suk-link \
  --branch=main

# 4. 验证
echo "✅ 部署完成"
echo "📊 查看部署列表："
wrangler pages deployment list \
  --project-name=suk-link \
  --limit=1

echo "🎉 部署成功！"
```

保存为 `deploy.sh`，然后：
```bash
chmod +x deploy.sh
./deploy.sh
```

---

## 🔄 持续部署

```bash
# 监听文件变化自动部署
while true; do
  inotifywait -r -e modify,create,delete .
  echo "🔄 检测到变化，重新部署..."
  wrangler pages publish . --project-name=suk-link
done
```

---

## 📞 获取帮助

```bash
# 查看完整命令列表
wrangler pages --help

# 查看特定命令帮助
wrangler pages publish --help
wrangler pages domain --help

# 在线文档
# https://developers.cloudflare.com/pages/

# 社区支持
# https://community.cloudflare.com/
```

---

## ✅ 快速检查清单

```bash
# 部署前检查
□ wrangler --version  # 已安装
□ wrangler whoami      # 已登录
□ cat wrangler.toml    # 配置正确
□ ls *.html            # 文件存在

# 部署
□ wrangler pages publish . --project-name=suk-link

# 部署后检查
□ curl -I https://suk.link  # 200 OK
□ dig suk.link              # DNS 正确
□ 浏览器访问测试              # 功能正常
```

---

**创建时间**: 2025-11-16  
**适用项目**: SUK LINK  
**用途**: 快速命令参考

💡 **提示**: 收藏此文件，部署时随时查阅！
