# 🚀 快速命令参考卡

> SUK短剧平台 - 常用命令速查表

---

## 📦 安装和初始化

```bash
# 克隆项目
git clone <repository-url>
cd drama-platform

# 安装依赖
npm install

# 配置环境变量
cp .env.example .env
nano .env  # 编辑配置

# 初始化数据库
node scripts/init-db.js
```

---

## 🧪 测试命令

```bash
# 一键快速测试（推荐首次运行）
chmod +x scripts/quick-test.sh
./scripts/quick-test.sh

# 环境配置测试
npm run test:env

# 数据库连接测试
npm run test:db

# 阿里云VoD连接测试
npm run test:vod

# Telegram Bot配置测试
npm run test:telegram

# 运行所有测试
npm test
```

---

## 🚀 启动服务

```bash
# 开发模式（自动重启）
npm run dev

# 生产模式
npm start

# 使用PM2（推荐生产环境）
pm2 start ecosystem.config.js --env production
pm2 status
pm2 logs drama-platform
pm2 stop drama-platform
pm2 restart drama-platform
```

---

## 🌐 Telegram Mini App 本地测试

```bash
# 步骤1: 启动服务器（终端1）
npm run dev

# 步骤2: 启动ngrok隧道（终端2）
ngrok http 3000
# 记录HTTPS URL：https://xxxxx.ngrok.io

# 步骤3: 配置Telegram Bot
# 1. 在Telegram找 @BotFather
# 2. 发送: /newbot
# 3. 发送: /setmenubutton
# 4. 输入URL: https://xxxxx.ngrok.io/telegram-app.html

# 步骤4: 测试Bot
# 在Telegram搜索你的Bot → START → 点击菜单按钮
```

---

## 🗄️ 数据库管理

```bash
# MongoDB
mongosh "mongodb://localhost:27017/short_drama_platform"
show collections
db.watch_histories.find().pretty()

# Redis
redis-cli
AUTH your_password
KEYS *
GET key_name

# 数据库备份
./scripts/backup-db.sh

# 清空测试数据
db.watch_histories.deleteMany({})
```

---

## 🔧 系统服务管理

```bash
# MongoDB
# macOS
brew services start mongodb-community
brew services stop mongodb-community
brew services restart mongodb-community

# Linux
sudo systemctl start mongod
sudo systemctl stop mongod
sudo systemctl restart mongod
sudo systemctl status mongod

# Redis
# macOS
brew services start redis
brew services stop redis

# Linux
sudo systemctl start redis
sudo systemctl stop redis
```

---

## 📊 监控和日志

```bash
# PM2日志
pm2 logs drama-platform
pm2 logs drama-platform --lines 100
pm2 logs drama-platform --err  # 只看错误日志

# 服务器日志（手动启动）
npm start 2>&1 | tee logs/server.log

# 实时监控
pm2 monit

# ngrok日志
# 访问: http://localhost:4040
```

---

## 🔍 调试命令

```bash
# 检查端口占用
lsof -i :3000
netstat -an | grep 3000

# 杀死占用端口的进程
kill $(lsof -ti:3000)

# 查看进程
ps aux | grep node
ps aux | grep mongod
ps aux | grep redis

# 检查防火墙
# macOS
sudo pfctl -sa

# Linux
sudo ufw status
sudo firewall-cmd --list-all

# 测试API端点
curl http://localhost:3000/health
curl http://localhost:3000/api/telegram/health
curl https://your-ngrok-url.ngrok.io/health
```

---

## 📝 Git工作流

```bash
# 查看状态
git status

# 添加更改
git add .

# 提交
git commit -m "feat: add telegram mini app"

# 推送
git push origin main

# 创建分支
git checkout -b feature/telegram-payments
git push origin feature/telegram-payments
```

---

## 🚢 部署命令

```bash
# 生产环境部署
npm install --production
node scripts/init-db.js
pm2 start ecosystem.config.js --env production
pm2 save
pm2 startup

# Nginx配置测试
sudo nginx -t
sudo systemctl reload nginx

# SSL证书（Let's Encrypt）
sudo certbot --nginx -d yourdomain.com
sudo certbot renew --dry-run
```

---

## 📱 Telegram Bot管理

```bash
# 使用@BotFather命令
/newbot                    # 创建新Bot
/mybots                    # 管理Bot
/setdescription            # 设置描述
/setabouttext              # 设置关于文本
/setuserpic                # 设置头像
/setcommands               # 设置命令菜单
/setmenubutton             # 设置菜单按钮（Mini App入口）
/deletebot                 # 删除Bot

# 测试Bot API
curl "https://api.telegram.org/bot<BOT_TOKEN>/getMe"
curl "https://api.telegram.org/bot<BOT_TOKEN>/getWebhookInfo"
```

---

## 🛠️ 实用工具

```bash
# 生成强随机密钥
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"

# 检查Node.js版本
node -v
npm -v

# 更新依赖
npm update
npm outdated  # 查看过期包

# 清理缓存
npm cache clean --force
rm -rf node_modules package-lock.json
npm install

# 查看包信息
npm list
npm list --depth=0  # 只看顶级依赖
```

---

## 📖 文档快速访问

| 文档 | 用途 | 命令 |
|------|------|------|
| README.md | 项目总览 | `cat README.md` |
| TELEGRAM_QUICK_START.md | 3步快速部署 | `cat TELEGRAM_QUICK_START.md` |
| TESTING_GUIDE.md | 完整测试流程 | `cat TESTING_GUIDE.md` |
| TELEGRAM_MINI_APP_GUIDE.md | 10章深度教程 | `cat TELEGRAM_MINI_APP_GUIDE.md` |
| CURRENT_STATUS.md | 项目状态（85%） | `cat CURRENT_STATUS.md` |
| ALIYUN_VOD_SETUP_GUIDE.md | 阿里云VoD配置 | `cat ALIYUN_VOD_SETUP_GUIDE.md` |
| DEPLOYMENT_GUIDE.md | 生产部署指南 | `cat DEPLOYMENT_GUIDE.md` |

---

## 🆘 紧急问题处理

```bash
# 服务器无响应
pm2 restart drama-platform
pm2 logs drama-platform --err

# 数据库连接失败
sudo systemctl restart mongod
sudo systemctl restart redis
npm run test:db

# Telegram Mini App加载失败
# 1. 检查ngrok是否运行
curl https://your-ngrok-url.ngrok.io/health
# 2. 检查Bot Token
npm run test:telegram
# 3. 重新配置Menu Button URL

# 视频播放失败
npm run test:vod
# 检查VoD AccessKey配置
# 查看浏览器控制台错误

# 端口冲突
lsof -ti:3000 | xargs kill
npm start
```

---

## 💡 提示

- **首次使用**：运行 `./scripts/quick-test.sh` 进行环境检查
- **本地测试**：使用 `npm run dev` 而不是 `npm start`（自动重启）
- **Telegram测试**：必须使用 ngrok 创建HTTPS隧道
- **生产环境**：始终使用 PM2 进行进程管理
- **查看日志**：遇到问题先查看 `pm2 logs`

---

## 📞 获取帮助

```bash
# 查看npm脚本
npm run

# 查看环境配置帮助
node scripts/test-env.js --help

# 查看PM2帮助
pm2 --help
pm2 start --help

# 查看测试脚本输出
./scripts/quick-test.sh
```

---

**最后更新**: 2024-11-15  
**版本**: v1.1.0
