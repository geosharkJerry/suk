# 🎬 Telegram 视频播放器使用指南

## 📋 概述

`telegram-player.html` 是 SUK 短剧平台 Telegram Mini App 的视频播放器页面，集成了阿里云 VoD Prism Player，提供流畅的视频播放体验和自动续播功能。

---

## ✨ 核心功能

### 1️⃣ 视频播放

#### 阿里云 VoD 集成
- ✅ Aliyun Prism Player
- ✅ HLS 加密视频支持
- ✅ PlayAuth 授权方式
- ✅ 自适应码率
- ✅ 多清晰度切换（480P/720P/1080P）

#### 播放控制
- ✅ 播放/暂停
- ✅ 进度条拖拽
- ✅ 音量调节
- ✅ 全屏播放
- ✅ 倍速播放

---

### 2️⃣ 观看历史与续播

#### 自动保存进度
```javascript
保存时机:
- 每 10 秒自动保存
- 播放暂停时保存
- 播放完成时保存
- 页面关闭前保存
- 切换剧集时保存
```

#### 续播对话框
**触发条件**:
- 观看进度 > 5%
- 观看进度 < 95%
- 有观看历史记录

**用户选项**:
- **继续播放**: 从上次位置开始
- **重新播放**: 从头开始观看

**对话框信息**:
- 观看进度百分比
- 进度条可视化
- 观看时间显示（已看/总时长）

---

### 3️⃣ 剧集切换

#### 横向剧集列表
- 显示所有剧集号
- 当前剧集高亮
- 免费集正常显示
- 锁定集显示 🔒
- 横向滚动查看

#### 切换功能
```javascript
点击剧集号:
- 免费集: 直接切换
- 已购买: 直接切换
- 未购买: 提示购买
```

---

### 4️⃣ 播放完成

#### 完成对话框
**显示内容**:
- ✅ 完成图标
- "本集已看完"标题
- 观看进度已保存提示

**操作选项**:
- **播放下一集**: 自动切换（如果已购买）
- **返回详情页**: 返回剧集详情

#### 自动播放下一集
```javascript
条件检查:
- 是否有下一集
- 下一集是否可播放（免费或已购买）
- 自动跳转播放
```

---

### 5️⃣ 界面元素

#### 顶部信息栏
- 剧集标题
- 当前集数
- 关闭按钮（返回详情页）

#### 底部剧集选择器
- 剧集列表
- 滚动查看
- 快速切换

#### 播放器控制栏
- 播放/暂停按钮
- 时间显示
- 进度条
- 音量控制
- 全屏按钮

---

## 🎨 UI/UX 特性

### 沉浸式体验

#### 全屏设计
```css
背景: 纯黑色 (#000000)
尺寸: 100vw × 100vh
播放器: 铺满整个屏幕
```

#### 自动隐藏控制栏
- 播放 5 秒后自动隐藏信息栏
- 点击屏幕重新显示
- 暂停时保持显示

#### 渐变叠加
```css
顶部: 黑色渐变到透明
底部: 黑色渐变到透明
增强文字可读性
```

---

### Telegram 集成

#### 返回按钮
```javascript
tg.BackButton.show();
tg.BackButton.onClick(closePlayer);
```

#### 触觉反馈
```javascript
播放开始: tg.HapticFeedback.impactOccurred('light');
剧集切换: tg.HapticFeedback.impactOccurred('medium');
```

#### 主题适配
```javascript
按钮颜色: 使用 Telegram 主题色
文字颜色: 白色（黑色背景）
```

---

### 动画效果

#### 对话框动画
```css
淡入效果: fadeIn 0.3s
滑入效果: slideUp 0.3s
按钮点击: scale(0.98)
```

#### 加载动画
```css
Spinner 旋转: 无限循环
加载文字: 半透明白色
进度提示: 动态更新
```

---

## 📡 API 集成

### 1. 获取剧集详情
```http
GET /api/telegram/dramas/:dramaId
Headers: {
    'X-Telegram-Init-Data': '{telegram_init_data}'
}

Response: {
    success: true,
    data: {
        id: 'drama_001',
        title: '霸道总裁爱上我',
        episodes: [...],
        hasPurchased: false
    }
}
```

### 2. 获取播放授权
```http
GET /api/telegram/play-auth/:episodeId
Headers: {
    'X-Telegram-Init-Data': '{telegram_init_data}'
}

Response: {
    success: true,
    playAuth: 'eyJTZWN1cml0eVRva2VuIjoi...',
    videoId: 'aliyun_video_123',
    expiresIn: 1800,
    watchHistory: {
        watchProgress: 65,
        totalDuration: 120,
        progressPercent: 54,
        isCompleted: false
    }
}
```

### 3. 保存观看进度
```http
POST /api/telegram/watch-progress
Headers: {
    'Content-Type': 'application/json',
    'X-Telegram-Init-Data': '{telegram_init_data}'
}
Body: {
    dramaId: 'drama_001',
    episodeId: 'ep_001',
    videoId: 'aliyun_video_123',
    watchProgress: 65,
    totalDuration: 120,
    isCompleted: false
}

Response: {
    success: true,
    data: {
        historyId: '...',
        progressPercent: 54,
        isCompleted: false
    }
}
```

---

## 🔒 权限验证

### 播放权限检查

#### 服务器端验证
```javascript
GET /api/telegram/play-auth/:episodeId

验证流程:
1. 验证 Telegram initData
2. 检查是否是第1集（免费）
3. 检查用户是否购买该剧集
4. 检查用户是否购买全集
5. 生成播放授权
```

#### 前端验证
```javascript
切换剧集时检查:
- 第1集: 允许播放
- 其他集 + 未购买: 显示购买提示
- 其他集 + 已购买: 允许播放
```

---

## 🎯 用户流程

### 场景 1: 首次观看
```
1. 从详情页点击"第1集"
2. 跳转到播放器页面
3. 加载视频信息
4. 获取播放授权
5. 初始化播放器
6. 自动开始播放
7. 每10秒保存进度
```

### 场景 2: 续播
```
1. 从详情页点击"第2集"
2. 跳转到播放器页面
3. 检测到观看历史（已看54%）
4. 显示续播对话框
5. 用户选择"继续播放"
6. 自动跳转到上次位置（00:65）
7. 继续观看
8. 定时保存进度
```

### 场景 3: 连续观看
```
1. 观看第1集
2. 播放完成，显示完成对话框
3. 点击"播放下一集"
4. 自动切换到第2集
5. 检查购买状态
6. 第2集已购买，继续播放
7. 重复流程直到看完全集
```

### 场景 4: 切换剧集
```
1. 正在观看第3集
2. 点击底部剧集列表
3. 选择第5集
4. 保存第3集进度
5. 跳转到第5集播放器
6. 开始播放第5集
```

---

## 🚀 性能优化

### 视频加载优化
```javascript
预加载: preload: true
自适应码率: 自动选择最佳清晰度
HLS 分片: 边下载边播放
缓存策略: 浏览器缓存视频片段
```

### 进度保存优化
```javascript
防抖处理: 10秒保存一次
批量请求: 避免频繁API调用
异步保存: 不阻塞播放
本地缓存: 失败时重试
```

### 内存管理
```javascript
播放器销毁: 切换剧集时释放资源
事件清理: 移除所有事件监听器
定时器清理: 停止自动保存定时器
```

---

## 🐛 错误处理

### 加载错误
```
症状: 视频无法加载
原因: 
- 网络问题
- 授权过期
- 视频文件损坏

处理:
- 显示错误页面
- 提供重试按钮
- 提供返回按钮
```

### 播放错误
```
症状: 播放中断或卡顿
原因:
- 网络波动
- 解码错误
- 格式不支持

处理:
- 捕获 player.on('error')
- 显示错误提示
- 尝试自动重连
- 降低清晰度
```

### 权限错误
```
症状: 无法获取播放授权
原因:
- 用户未购买
- 授权已过期
- 认证失败

处理:
- 显示购买提示
- 跳转到详情页
- 引导用户购买
```

---

## 🧪 测试要点

### 功能测试
- [ ] 视频正常加载
- [ ] 播放控制正常（播放/暂停/进度/音量）
- [ ] 续播功能正常
- [ ] 进度保存正常
- [ ] 剧集切换正常
- [ ] 自动播放下一集
- [ ] 完成对话框显示
- [ ] 返回按钮正常

### 权限测试
- [ ] 免费集可以播放
- [ ] 未购买集显示提示
- [ ] 已购买集可以播放
- [ ] 播放授权验证正常

### 性能测试
- [ ] 视频加载速度
- [ ] 播放流畅度
- [ ] 进度保存及时性
- [ ] 内存使用合理

### 兼容性测试
- [ ] iOS Telegram
- [ ] Android Telegram
- [ ] Telegram Web
- [ ] 不同网络环境

---

## 📝 TODO 列表

### 高优先级
- [ ] 实现真实的播放授权验证
- [ ] 优化视频加载速度
- [ ] 添加播放失败自动重试
- [ ] 实现断点续传

### 中优先级
- [ ] 添加倍速播放选项
- [ ] 添加清晰度手动切换
- [ ] 添加字幕支持
- [ ] 实现投屏功能

### 低优先级
- [ ] 添加弹幕功能
- [ ] 添加截图功能
- [ ] 添加分享功能
- [ ] 实现下载功能

---

## 🔗 相关文件

### 前端文件
- `telegram-player.html` - 视频播放器（本文件）
- `telegram-app.html` - 剧集列表页
- `telegram-drama-detail.html` - 剧集详情页

### 后端文件
- `backend/controllers/telegram.controller.js` - API 控制器
- `backend/services/aliyun-vod.service.js` - 阿里云 VoD 服务
- `backend/services/watch-history.service.js` - 观看历史服务
- `backend/models/WatchHistory.js` - MongoDB Schema

### 参考文件
- `drama-player-aliyun.html` - 原始播放器页面
- `DRAMA_PLAYBACK_BACKEND_API.md` - API 文档

---

## 💡 使用建议

### 开发环境测试
```bash
# 1. 启动服务器
npm run dev

# 2. 在浏览器中测试
http://localhost:3000/telegram-player.html?dramaId=drama_001&episodeId=ep_001

# 3. 在 Telegram 中测试
# 使用 ngrok 创建 HTTPS 隧道
ngrok http 3000
```

### 调试技巧
```javascript
// 浏览器控制台
console.log('播放器实例:', player);
console.log('当前时间:', player.getCurrentTime());
console.log('视频时长:', player.getDuration());
console.log('播放状态:', player.paused());

// 模拟续播
watchHistory = {
    watchProgress: 30,
    totalDuration: 120,
    progressPercent: 25
};
showResumeDialog(watchHistory);
```

---

## 📞 获取帮助

### 查看日志
```javascript
// 播放器日志
player.on('error', console.error);
player.on('waiting', () => console.log('缓冲中...'));
player.on('canplay', () => console.log('可以播放'));
```

### 常见问题
1. **视频加载慢**: 检查网络连接，尝试降低清晰度
2. **续播不工作**: 检查 API 是否正常返回观看历史
3. **进度不保存**: 检查自动保存定时器是否启动
4. **切换剧集失败**: 检查购买状态和权限验证

---

## ✅ 总结

`telegram-player.html` 提供了完整的视频播放功能，包括：

- ✅ 流畅的视频播放（Aliyun Prism Player）
- ✅ 智能续播系统
- ✅ 自动保存观看进度
- ✅ 剧集快速切换
- ✅ 自动播放下一集
- ✅ 沉浸式全屏体验
- ✅ Telegram 原生集成
- ✅ 完善的错误处理

**文件大小**: 34.7 KB  
**创建时间**: 2024-11-15  
**版本**: v1.0.0  
**状态**: ✅ 开发完成，待测试
