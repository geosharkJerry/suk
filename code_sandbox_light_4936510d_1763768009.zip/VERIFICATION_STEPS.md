# SUK奖励系统 - 功能验证步骤

**验证工具**: `reward-system-test.html`  
**预计时间**: 15-20分钟  
**前置条件**: 后端服务运行中

---

## 🚀 快速开始

### 1. 启动后端服务

```bash
# 方式1: 开发模式
npm run dev

# 方式2: 生产模式
npm start

# 方式3: PM2
pm2 start ecosystem.config.js --env production
```

### 2. 打开验证工具

```bash
# 浏览器访问
http://localhost:3000/reward-system-test.html
```

---

## ✅ 验证清单

### 准备工作（1分钟）

- [ ] **启动后端服务**
  ```bash
  npm start
  # 确认输出: Server running on port 3000
  ```

- [ ] **检查MongoDB连接**
  ```bash
  # 查看控制台日志
  # 确认: ✅ MongoDB connected successfully
  ```

- [ ] **检查Redis连接**（可选）
  ```bash
  redis-cli
  PING
  # 返回: PONG
  ```

- [ ] **打开验证工具**
  - 访问: http://localhost:3000/reward-system-test.html

---

### 测试1: 奖励中心入口验证（2分钟）

**目标**: 验证主页的奖励中心按钮功能

**步骤**:
1. 点击"开始测试"按钮
2. 查看验证结果
3. 点击"直接打开奖励中心"
4. 确认跳转到 telegram-reward-center.html

**预期结果**:
- ✅ 显示"奖励中心功能验证"成功信息
- ✅ 奖励中心页面正常打开
- ✅ 页面显示三个标签：观看奖励、邀请奖励、我的邀请

**验证文件**:
- telegram-app.html 第399-405行（按钮UI）
- telegram-app.html 第889-897行（openRewardCenter函数）

**故障排除**:
- 如果奖励中心无法打开，检查文件是否存在：`telegram-reward-center.html`

---

### 测试2: 邀请分享功能验证（3分钟）

**目标**: 验证邀请码生成和使用API

#### 2.1 生成邀请码

**步骤**:
1. 点击"测试生成邀请码"按钮
2. 查看API响应

**预期结果**:

**情况A**: 用户已绑定钱包
```json
✅ 成功
{
  "success": true,
  "data": {
    "inviteCode": "SUK3F2A1",
    "inviteLink": "http://localhost:3000/telegram-app.html?inviteCode=SUK3F2A1"
  }
}
```

**情况B**: 用户未绑定钱包
```json
⚠️ 预期行为
{
  "success": false,
  "message": "请先绑定钱包地址"
}
```

**验证文件**:
- telegram-app.html 第908-915行（API调用）
- backend/controllers/reward.controller.js（API处理）

#### 2.2 使用邀请码

**步骤**:
1. 点击"测试使用邀请码"按钮
2. 查看API响应

**预期结果**:

**情况A**: 首次使用
```json
✅ 成功
{
  "success": true,
  "data": {
    "inviterId": "123456789",
    "inviteeId": "123456790"
  }
}
```

**情况B**: 重复使用
```json
⚠️ 预期行为
{
  "success": false,
  "message": "邀请码已使用或无效"
}
```

**验证文件**:
- telegram-app.html 第953-960行（API调用）
- backend/models/Reward.js（InviteRelation模型）

---

### 测试3: 观看奖励记录验证（3分钟）

**目标**: 验证观看奖励计算和记录API

#### 3.1 正常时长测试（240秒/300秒）

**步骤**:
1. 点击"测试记录奖励 (240s/300s)"按钮
2. 查看奖励计算结果

**预期结果**:
```json
✅ 成功
{
  "success": true,
  "data": {
    "rewardAmount": 0.792,
    "status": "pending",
    "validationScore": 100,
    "watchDuration": 240,
    "totalDuration": 300,
    "watchPercent": 80
  }
}
```

**计算验证**:
```
奖励 = (240 / 300) × 99 × 0.01
     = 0.8 × 99 × 0.01
     = 0.792 SUK ✅
```

**验证文件**:
- telegram-player-optimized.html 第1471-1515行（recordWatchReward函数）
- backend/services/reward.service.js（奖励计算逻辑）

#### 3.2 短时长测试（3秒/300秒）

**步骤**:
1. 点击"测试短时长 (3s/300s)"按钮
2. 查看处理结果

**预期行为**:
- ⚠️ 前端应该阻止 <5秒 的请求
- ⚠️ 如果到达后端，后端应该验证并可能拒绝

**验证文件**:
- telegram-player-optimized.html 第1478行（最小时长检查）

---

### 测试4: 奖励统计查询验证（3分钟）

**目标**: 验证奖励统计和记录查询API

#### 4.1 获取奖励统计

**步骤**:
1. 点击"获取奖励统计"按钮
2. 查看统计数据

**预期结果**:
```json
✅ 成功
{
  "success": true,
  "data": {
    "userId": "123456789",
    "watchRewards": {
      "total": 5.23,
      "pending": 2.31,
      "paid": 2.92,
      "count": 12
    },
    "inviteRewards": {
      "total": 45.67,
      "pending": 12.34,
      "paid": 33.33,
      "count": 5
    },
    "totalEarned": 50.90,
    "totalPending": 14.65,
    "totalPaid": 36.25
  }
}
```

**验证文件**:
- backend/controllers/reward.controller.js（getRewardStats方法）
- backend/services/reward.service.js（统计计算）

#### 4.2 获取奖励记录

**步骤**:
1. 点击"获取奖励记录"按钮
2. 查看记录列表

**预期结果**:
```json
✅ 成功
{
  "success": true,
  "data": [
    {
      "_id": "...",
      "userId": "123456789",
      "dramaId": "...",
      "episodeId": "ep001",
      "rewardAmount": 0.792,
      "status": "pending",
      "createdAt": "2024-11-16T05:00:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 5,
    "total": 12
  }
}
```

**验证文件**:
- backend/controllers/reward.controller.js（getRewardRecords方法）

---

### 测试5: 页面集成验证（5分钟）

**目标**: 在实际页面中验证功能

#### 5.1 主页集成验证

**步骤**:
1. 点击"打开主页测试"按钮
2. 在新标签页中执行以下操作：

**检查项**:
- [ ] 页面正常加载
- [ ] 用户卡片显示正常
- [ ] "💰 我的奖励"按钮存在
- [ ] "👥 邀请好友"按钮存在
- [ ] 点击"我的奖励"跳转到奖励中心
- [ ] 点击"邀请好友"触发分享（或显示提示）

#### 5.2 邀请码链接测试

**步骤**:
1. 点击"测试邀请码链接"按钮
2. 观察页面行为

**预期行为**:
- ✅ 页面加载时自动检测 `?inviteCode=SUKTEST1`
- ✅ 调用 checkAndUseInviteCode() 函数
- ✅ 显示欢迎弹窗（如果是首次使用）
- ✅ URL参数被清除（使用 window.history.replaceState）

**验证代码**:
```javascript
// telegram-app.html 第944-986行
async function checkAndUseInviteCode() {
    const urlParams = new URLSearchParams(window.location.search);
    const inviteCode = urlParams.get('inviteCode');
    if (!inviteCode) return;
    // ... 调用API
}
```

#### 5.3 播放器集成验证

**步骤**:
1. 点击"打开播放器测试"按钮
2. 在新标签页中执行以下操作：

**检查项**:
- [ ] 播放器正常加载
- [ ] 视频可以播放
- [ ] 观看一段时间（建议30秒以上）
- [ ] 关闭页面或等待视频结束
- [ ] 检查是否触发了 recordWatchReward()

**验证方法**:
```javascript
// 在播放器页面打开浏览器控制台
// 查找日志：
// ✅ 观看奖励记录成功: {rewardAmount: 0.xxx, status: "pending"}
```

**验证代码**:
```javascript
// telegram-player-optimized.html

// 第1111-1113行: 视频结束触发
player.on('ended', () => {
    handleVideoEnded();
});

// 第1386行: 记录奖励
function handleVideoEnded() {
    recordWatchReward();
    // ...
}

// 第1595-1598行: 页面离开触发
window.addEventListener('beforeunload', () => {
    saveWatchProgress();
    recordWatchReward();
});
```

---

## 📊 验证结果记录表

| 测试项 | 状态 | 备注 |
|--------|------|------|
| 1. 奖励中心入口 | ⬜️ | |
| 2.1 生成邀请码 | ⬜️ | |
| 2.2 使用邀请码 | ⬜️ | |
| 3.1 记录观看奖励 | ⬜️ | |
| 3.2 短时长验证 | ⬜️ | |
| 4.1 奖励统计 | ⬜️ | |
| 4.2 奖励记录 | ⬜️ | |
| 5.1 主页集成 | ⬜️ | |
| 5.2 邀请码链接 | ⬜️ | |
| 5.3 播放器集成 | ⬜️ | |

**状态标记**:
- ✅ 通过
- ❌ 失败
- ⚠️ 部分通过
- ⬜️ 未测试

---

## 🔍 常见问题排查

### Q1: API调用返回404

**原因**: 路由未注册或路径错误

**解决**:
```javascript
// 检查 server.js
const rewardRoutes = require('./backend/routes/reward.routes');
app.use('/api/rewards', rewardRoutes);
```

### Q2: API调用返回401/403

**原因**: Telegram认证失败

**解决**:
- 检查 X-Telegram-Init-Data header
- 验证 telegram-auth.middleware.js
- 开发环境可以临时跳过验证

### Q3: 邀请码生成失败（400）

**原因**: 用户未绑定钱包

**说明**: 这是正常的安全检查

**解决**:
```javascript
// 需要先调用绑定钱包API
POST /api/rewards/bind-wallet
Body: { walletAddress: "0x..." }
```

### Q4: 观看奖励不记录

**原因**: 可能的原因有多个

**检查清单**:
- [ ] 观看时长是否 ≥ 5秒
- [ ] player 对象是否已初始化
- [ ] dramaId 和 episodeId 是否有效
- [ ] 网络请求是否成功
- [ ] 后端MongoDB连接是否正常

### Q5: Toast提示不显示

**原因**: 条件不满足或函数未调用

**检查**:
```javascript
// 条件检查
if (rewardAmount > 0 && status === 'pending') {
    showRewardToast(rewardAmount);
}

// 查看控制台是否有错误
console.log('✅ 观看奖励记录成功:', result.data);
```

---

## 📝 验证报告模板

### 验证信息

- **验证日期**: ___________
- **验证人**: ___________
- **环境**: □ 本地开发  □ 测试服务器  □ 生产环境
- **Node版本**: ___________
- **MongoDB版本**: ___________

### 测试结果

**总体通过率**: _____ / 10

**详细结果**:
1. 奖励中心入口: □ 通过  □ 失败
2. 生成邀请码: □ 通过  □ 失败
3. 使用邀请码: □ 通过  □ 失败
4. 记录观看奖励: □ 通过  □ 失败
5. 短时长验证: □ 通过  □ 失败
6. 奖励统计: □ 通过  □ 失败
7. 奖励记录: □ 通过  □ 失败
8. 主页集成: □ 通过  □ 失败
9. 邀请码链接: □ 通过  □ 失败
10. 播放器集成: □ 通过  □ 失败

### 发现的问题

1. ___________________________________________
2. ___________________________________________
3. ___________________________________________

### 建议

1. ___________________________________________
2. ___________________________________________
3. ___________________________________________

### 结论

□ **系统可以上线**  
□ **需要修复后再验证**  
□ **需要重大调整**

---

## 🎯 下一步

### 验证通过后：

1. **部署到测试环境**
   ```bash
   # 使用PM2部署
   pm2 start ecosystem.config.js --env production
   ```

2. **邀请内部用户测试**
   - 收集反馈
   - 记录问题
   - 优化体验

3. **监控数据**
   - 查看奖励记录数量
   - 监控API成功率
   - 分析用户行为

4. **准备上线**
   - 配置生产环境
   - 备份数据库
   - 准备回滚方案

---

**工具文件**: `reward-system-test.html`  
**文档日期**: 2024-11-16  
**预计验证时间**: 15-20分钟
