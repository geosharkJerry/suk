# SUK.WTF Firebase 项目官网完整配置指南
# Complete Firebase Setup Guide for suk.link Official Website

> **🔥 使用 Firebase Hosting 部署项目官网**  
> 域名：suk.link  
> 平台：Firebase Hosting + Analytics

---

## 📋 目录

- [Firebase 简介](#firebase-简介)
- [准备工作](#准备工作)
- [创建 Firebase 项目](#创建-firebase-项目)
- [配置 Firebase Hosting](#配置-firebase-hosting)
- [部署官网](#部署官网)
- [配置自定义域名](#配置自定义域名)
- [配置 Analytics](#配置-analytics)
- [持续部署](#持续部署)

---

## 🔥 Firebase 简介

### 为什么选择 Firebase Hosting？

**优势**：
- ✅ **免费套餐**：每月 10GB 存储，每月 360MB/天传输
- ✅ **全球 CDN**：自动分发到全球边缘节点
- ✅ **免费 SSL**：自动 HTTPS，Let's Encrypt 证书
- ✅ **快速部署**：一条命令完成部署
- ✅ **版本回滚**：支持一键回滚到历史版本
- ✅ **自定义域名**：支持绑定 suk.link
- ✅ **CI/CD 集成**：GitHub Actions 自动部署

**适用场景**：
- ✅ 项目官网（index.html、about.html 等）
- ✅ 文档站点
- ✅ 营销落地页
- ✅ 静态资源托管

**不适用场景**：
- ❌ 后端 API（Node.js 服务器应该部署到云服务器）
- ❌ WebSocket 长连接
- ❌ 数据库服务

### 架构规划

```
suk.link 官网架构：
┌─────────────────────────────────────────┐
│           suk.link 域名分配              │
├─────────────────────────────────────────┤
│                                         │
│  suk.link (主域名)                       │
│  └─→ Firebase Hosting                  │
│      ├─ index.html (官网首页)          │
│      ├─ about.html (关于页面)          │
│      ├─ whitepaper.html (白皮书)       │
│      ├─ faq.html (FAQ)                 │
│      └─ css/, js/, images/            │
│                                         │
│  api.suk.link (API 域名)                │
│  └─→ 云服务器 (Node.js + Express)      │
│      ├─ /api/telegram/*                │
│      ├─ /api/video/*                   │
│      └─ /api/health                    │
│                                         │
│  monitor.suk.link (监控域名)            │
│  └─→ 云服务器 (Grafana)                │
│                                         │
└─────────────────────────────────────────┘
```

---

## 🛠 准备工作

### 1. 安装 Node.js 和 npm

```bash
# 检查是否已安装
node --version  # 应该是 v18+
npm --version   # 应该是 9+

# Ubuntu/Debian 安装
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# macOS 安装
brew install node
```

### 2. 安装 Firebase CLI

```bash
# 全局安装 Firebase CLI
npm install -g firebase-tools

# 验证安装
firebase --version

# 预期输出：13.0.0 或更高版本
```

### 3. 准备 Google 账号

- ✅ 注册 Google 账号（如果还没有）
- ✅ 访问 Firebase 控制台：https://console.firebase.google.com/

---

## 🔥 创建 Firebase 项目

### 步骤 1：登录 Firebase

```bash
# 在终端登录 Firebase
firebase login

# 会打开浏览器，选择 Google 账号登录
# 授权 Firebase CLI 访问您的账号
```

**预期输出**：
```
✔ Success! Logged in as your-email@gmail.com
```

### 步骤 2：在 Firebase 控制台创建项目

1. 访问：https://console.firebase.google.com/
2. 点击 **添加项目** / **Add project**
3. 输入项目名称：`suk-wtf-official` 或 `suk-drama-platform`
4. 点击 **继续**
5. 启用 Google Analytics（推荐）
6. 选择或创建 Analytics 账号
7. 点击 **创建项目**

**等待 1-2 分钟项目创建完成**

### 步骤 3：初始化 Firebase 项目

```bash
# 进入项目目录
cd /path/to/suk-platform

# 初始化 Firebase
firebase init
```

**交互式配置**：

1. **Which Firebase features do you want to set up?**
   - 选择：`Hosting: Configure files for Firebase Hosting` (空格选择)
   - 按回车确认

2. **Please select an option:**
   - 选择：`Use an existing project`
   - 按回车

3. **Select a default Firebase project:**
   - 选择您刚创建的项目（如：`suk-wtf-official`）
   - 按回车

4. **What do you want to use as your public directory?**
   - 输入：`public` 或 `.`（如果静态文件在根目录）
   - 推荐：创建 `public` 目录存放官网文件
   - 按回车

5. **Configure as a single-page app (rewrite all urls to /index.html)?**
   - 输入：`N`（官网是多页面应用）
   - 按回车

6. **Set up automatic builds and deploys with GitHub?**
   - 输入：`Y`（如果想配置自动部署）
   - 或输入：`N`（稍后手动配置）
   - 按回车

7. **File public/index.html already exists. Overwrite?**
   - 输入：`N`（不覆盖现有文件）
   - 按回车

**完成后会生成**：
- `firebase.json` - Firebase 配置文件
- `.firebaserc` - 项目别名配置
- `public/` - 托管文件目录（如果不存在）

---

## 📁 组织项目文件结构

### 推荐的目录结构

```
suk-platform/
├── public/                      ← Firebase Hosting 根目录
│   ├── index.html              ← 官网首页
│   ├── about.html              ← 关于页面
│   ├── whitepaper.html         ← 白皮书
│   ├── faq.html                ← FAQ
│   ├── dashboard.html          ← 控制台
│   ├── drama-detail.html       ← 短剧详情
│   ├── telegram-app.html       ← Telegram Mini App（重要）
│   ├── css/                    ← 样式文件
│   │   ├── style.css
│   │   └── responsive.css
│   ├── js/                     ← JavaScript 文件
│   │   ├── main.js
│   │   ├── i18n.js
│   │   └── i18n-translations.js
│   ├── images/                 ← 图片资源
│   │   └── logo.png
│   └── 404.html                ← 404 页面
│
├── backend/                     ← 后端代码（不部署到 Firebase）
│   ├── controllers/
│   ├── models/
│   └── services/
│
├── firebase.json               ← Firebase 配置
├── .firebaserc                 ← 项目别名
├── .env                        ← 环境变量（不上传）
└── README.md
```

### 移动文件到 public 目录

```bash
# 创建 public 目录
mkdir -p public

# 移动官网相关文件
mv index.html public/
mv about.html public/
mv whitepaper.html public/
mv faq.html public/
mv dashboard.html public/
mv drama-detail.html public/
mv telegram-app.html public/

# 移动资源文件
mv css public/
mv js public/
mv images public/

# 保持后端代码在根目录
# backend/ 目录不需要移动
```

---

## ⚙️ 配置 firebase.json

创建或编辑 `firebase.json`：

```json
{
  "hosting": {
    "public": "public",
    "ignore": [
      "firebase.json",
      "**/.*",
      "**/node_modules/**"
    ],
    "rewrites": [
      {
        "source": "/api/**",
        "function": "api"
      }
    ],
    "redirects": [
      {
        "source": "/old-page",
        "destination": "/new-page",
        "type": 301
      }
    ],
    "headers": [
      {
        "source": "**/*.@(jpg|jpeg|gif|png|svg|webp)",
        "headers": [
          {
            "key": "Cache-Control",
            "value": "max-age=31536000"
          }
        ]
      },
      {
        "source": "**/*.@(css|js)",
        "headers": [
          {
            "key": "Cache-Control",
            "value": "max-age=86400"
          }
        ]
      },
      {
        "source": "**/*.html",
        "headers": [
          {
            "key": "Cache-Control",
            "value": "max-age=3600"
          }
        ]
      }
    ],
    "cleanUrls": true,
    "trailingSlash": false
  }
}
```

**配置说明**：
- `public`: 指定托管文件根目录
- `ignore`: 忽略上传的文件
- `rewrites`: URL 重写规则（预留给后端 API）
- `redirects`: 301/302 重定向
- `headers`: 自定义响应头（缓存控制）
- `cleanUrls`: 移除 .html 后缀（/about.html → /about）
- `trailingSlash`: 禁用尾部斜杠

---

## 🚀 部署官网

### 第一次部署

```bash
# 构建并部署
firebase deploy

# 或只部署 Hosting
firebase deploy --only hosting
```

**部署过程**：
```
=== Deploying to 'suk-wtf-official'...

i  deploying hosting
i  hosting[suk-wtf-official]: beginning deploy...
i  hosting[suk-wtf-official]: found 15 files in public
✔  hosting[suk-wtf-official]: file upload complete
i  hosting[suk-wtf-official]: finalizing version...
✔  hosting[suk-wtf-official]: version finalized
i  hosting[suk-wtf-official]: releasing new version...
✔  hosting[suk-wtf-official]: release complete

✔  Deploy complete!

Project Console: https://console.firebase.google.com/project/suk-wtf-official/overview
Hosting URL: https://suk-wtf-official.web.app
```

### 访问官网

部署成功后，您会获得两个默认域名：

1. **web.app 域名**：`https://suk-wtf-official.web.app`
2. **firebaseapp.com 域名**：`https://suk-wtf-official.firebaseapp.com`

**立即访问测试**：
```bash
# 在浏览器打开
open https://suk-wtf-official.web.app

# 或
firefox https://suk-wtf-official.web.app
```

---

## 🌐 配置自定义域名（suk.link）

### 步骤 1：在 Firebase 控制台添加域名

1. 访问 Firebase 控制台：https://console.firebase.google.com/
2. 选择您的项目：`suk-wtf-official`
3. 点击左侧菜单：**Hosting**
4. 点击 **添加自定义域名** / **Add custom domain**
5. 输入：`suk.link`
6. 点击 **继续**

### 步骤 2：验证域名所有权

Firebase 会要求您验证域名所有权：

**选项 A：TXT 记录验证（推荐）**

1. Firebase 会提供一个 TXT 记录值，类似：
   ```
   名称: suk.link
   类型: TXT
   值: firebase=suk-wtf-official-abc123def456
   ```

2. 登录 GoDaddy：https://dcc.godaddy.com/manage/suk.link/dns

3. 添加 TXT 记录：
   ```
   类型: TXT
   名称: @
   值: firebase=suk-wtf-official-abc123def456
   TTL: 600
   ```

4. 保存配置，等待 5-10 分钟 DNS 生效

5. 在 Firebase 控制台点击 **验证**

### 步骤 3：配置 A 记录

验证成功后，Firebase 会提供 A 记录 IP 地址：

**Firebase Hosting IP 地址**（这些是固定的）：
```
151.101.1.195
151.101.65.195
```

**在 GoDaddy 配置**：

1. 登录 GoDaddy DNS 管理
2. 修改或添加 A 记录：
   ```
   类型: A
   名称: @
   值: 151.101.1.195
   TTL: 600
   
   类型: A
   名称: @
   值: 151.101.65.195
   TTL: 600
   ```

3. 如果需要支持 www.suk.link：
   ```
   类型: CNAME
   名称: www
   值: suk.link
   TTL: 600
   ```

### 步骤 4：等待 SSL 证书生成

- Firebase 会自动为您的域名申请 Let's Encrypt SSL 证书
- 通常需要 **24-48 小时**
- 期间可以使用默认域名访问

### 步骤 5：验证自定义域名

```bash
# 检查 DNS 解析
nslookup suk.link

# 检查 HTTPS
curl -I https://suk.link

# 预期：HTTP/2 200
```

---

## 📊 配置 Firebase Analytics

### 步骤 1：启用 Analytics

1. Firebase 控制台 → 项目设置
2. 集成 → Google Analytics
3. 启用 Analytics

### 步骤 2：添加 Analytics 代码

在 `public/index.html` 中添加：

```html
<!-- Firebase SDK -->
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-analytics-compat.js"></script>

<script>
  // Firebase 配置
  const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "suk-wtf-official.firebaseapp.com",
    projectId: "suk-wtf-official",
    storageBucket: "suk-wtf-official.appspot.com",
    messagingSenderId: "123456789",
    appId: "1:123456789:web:abc123def456",
    measurementId: "G-XXXXXXXXXX"
  };

  // 初始化 Firebase
  firebase.initializeApp(firebaseConfig);
  const analytics = firebase.analytics();

  // 记录页面浏览
  analytics.logEvent('page_view', {
    page_title: document.title,
    page_location: window.location.href,
    page_path: window.location.pathname
  });
</script>
```

**获取 Firebase 配置**：
1. Firebase 控制台 → 项目设置
2. 您的应用 → Web 应用
3. 复制配置代码

---

## 🔄 持续部署（CI/CD）

### 选项 A：GitHub Actions 自动部署

创建 `.github/workflows/firebase-hosting.yml`：

```yaml
name: Deploy to Firebase Hosting

on:
  push:
    branches:
      - main
    paths:
      - 'public/**'
      - 'firebase.json'

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install Firebase CLI
        run: npm install -g firebase-tools
      
      - name: Deploy to Firebase
        env:
          FIREBASE_TOKEN: ${{ secrets.FIREBASE_TOKEN }}
        run: |
          firebase deploy --only hosting --token $FIREBASE_TOKEN
```

**配置步骤**：

1. **生成 Firebase Token**：
```bash
firebase login:ci

# 复制输出的 Token
```

2. **添加到 GitHub Secrets**：
   - GitHub 仓库 → Settings → Secrets and variables → Actions
   - 点击 **New repository secret**
   - Name: `FIREBASE_TOKEN`
   - Value: 粘贴刚才复制的 Token
   - 点击 **Add secret**

3. **推送代码触发部署**：
```bash
git add .
git commit -m "Update website"
git push origin main

# GitHub Actions 会自动部署到 Firebase
```

### 选项 B：手动部署脚本

创建 `scripts/deploy-firebase.sh`：

```bash
#!/bin/bash

echo "🔥 开始部署 SUK.WTF 官网到 Firebase Hosting..."

# 检查 Firebase CLI
if ! command -v firebase &> /dev/null; then
    echo "❌ Firebase CLI 未安装"
    echo "请运行: npm install -g firebase-tools"
    exit 1
fi

# 检查是否登录
if ! firebase projects:list &> /dev/null; then
    echo "❌ 未登录 Firebase"
    echo "请运行: firebase login"
    exit 1
fi

# 清理旧文件
echo "🧹 清理旧文件..."
rm -rf public/.DS_Store
rm -rf public/**/.DS_Store

# 部署到 Firebase
echo "🚀 部署中..."
firebase deploy --only hosting

# 检查部署结果
if [ $? -eq 0 ]; then
    echo "✅ 部署成功！"
    echo "🌐 访问: https://suk.link"
    echo "🔥 Firebase: https://suk-wtf-official.web.app"
else
    echo "❌ 部署失败"
    exit 1
fi
```

**使用方法**：
```bash
chmod +x scripts/deploy-firebase.sh
./scripts/deploy-firebase.sh
```

---

## 📝 常用命令

### 部署命令

```bash
# 完整部署
firebase deploy

# 只部署 Hosting
firebase deploy --only hosting

# 预览部署（不实际发布）
firebase hosting:channel:deploy preview

# 部署到特定项目
firebase deploy --project suk-wtf-official
```

### 管理命令

```bash
# 查看项目列表
firebase projects:list

# 查看部署历史
firebase hosting:clone

# 回滚到上一个版本
firebase hosting:rollback

# 查看使用情况
firebase projects:analytics

# 本地预览
firebase serve

# 本地预览指定端口
firebase serve --port 8080
```

### 调试命令

```bash
# 查看部署日志
firebase deploy --debug

# 查看 Hosting 配置
firebase hosting:config:get

# 测试重写规则
firebase serve --only hosting
```

---

## ✅ 部署检查清单

### 部署前检查

- [ ] 所有静态文件在 `public/` 目录
- [ ] `firebase.json` 配置正确
- [ ] 图片已优化压缩
- [ ] JavaScript 和 CSS 已压缩
- [ ] 测试所有页面链接
- [ ] 检查移动端响应式
- [ ] 配置 404 页面

### 部署后验证

- [ ] 访问默认域名：`https://suk-wtf-official.web.app`
- [ ] 访问自定义域名：`https://suk.link`
- [ ] 检查 HTTPS 证书
- [ ] 测试所有页面加载
- [ ] 检查图片加载
- [ ] 测试 Telegram Mini App
- [ ] 查看 Analytics 数据

---

## 🔍 故障排查

### 问题 1：部署失败

**错误**: `Error: HTTP Error: 403, Permission denied`

**解决方案**：
```bash
# 重新登录
firebase logout
firebase login

# 重新部署
firebase deploy --only hosting
```

### 问题 2：自定义域名无法访问

**检查清单**：
1. DNS 记录是否正确配置
2. 等待 24-48 小时 SSL 证书生成
3. 清除浏览器缓存

```bash
# 检查 DNS
nslookup suk.link

# 检查 SSL
curl -I https://suk.link
```

### 问题 3：页面 404

**原因**：文件路径不正确

**解决方案**：
1. 确认文件在 `public/` 目录
2. 检查 `firebase.json` 中的 `public` 配置
3. 重新部署

---

## 📚 相关资源

- 📖 Firebase Hosting 文档：https://firebase.google.com/docs/hosting
- 📖 Firebase CLI 参考：https://firebase.google.com/docs/cli
- 📖 自定义域名配置：https://firebase.google.com/docs/hosting/custom-domain

---

## 🎉 总结

### 完成步骤

1. ✅ 安装 Firebase CLI
2. ✅ 创建 Firebase 项目
3. ✅ 初始化 Firebase
4. ✅ 组织文件结构
5. ✅ 配置 firebase.json
6. ✅ 部署官网
7. ✅ 配置自定义域名
8. ✅ 配置 Analytics
9. ✅ 设置 CI/CD

### 域名架构

- 🌐 `suk.link` → Firebase Hosting（官网）
- 🔌 `api.suk.link` → 云服务器（后端 API）
- 📊 `monitor.suk.link` → 云服务器（监控面板）

---

**配置完成时间**: 2024-11-16  
**官网域名**: suk.link  
**Firebase 项目**: suk-wtf-official  
**状态**: ✅ 配置就绪

🎊 **Firebase 官网部署指南完成！** 🎊
