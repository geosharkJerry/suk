# Telegram Mini App 快速启动指南
# Telegram Mini App Quick Start Guide

> ⚡ 30分钟快速部署SUK短剧平台到Telegram

---

## 🚀 快速开始（3步完成）

### Step 1: 创建Telegram Bot (5分钟)

1. 在Telegram中找到 `@BotFather`
2. 发送命令创建Bot：

```
/newbot

Bot名称: SUK Drama Platform
Bot用户名: SUKDramaBot

保存返回的Token: 1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
```

3. 配置Bot信息：

```
/setdescription
🎬 SUK短剧平台 - 区块链版权RWA
海量竖屏短剧，SUK代币支付

/setcommands
start - 启动短剧平台
dramas - 浏览短剧
profile - 我的账户
help - 帮助

/setuserpic
[上传512x512的图标]
```

### Step 2: 配置环境 (10分钟)

```bash
# 1. 添加Telegram配置到.env
echo "TELEGRAM_BOT_TOKEN=你的Bot_Token" >> .env
echo "TON_WALLET_ADDRESS=你的TON钱包地址" >> .env

# 2. 安装依赖
npm install node-telegram-bot-api @twa-dev/sdk

# 3. 测试连接
node scripts/test-telegram-bot.js
```

### Step 3: 部署Mini App (15分钟)

#### 选项A: 使用ngrok（开发测试）

```bash
# 1. 安装ngrok
npm install -g ngrok

# 2. 启动后端服务
npm start

# 3. 启动ngrok隧道
ngrok http 3000

# 4. 获得临时URL: https://abc123.ngrok.io

# 5. 配置Bot菜单按钮
# 向 @BotFather 发送:
/mybots → SUKDramaBot → Bot Settings → Menu Button
URL: https://abc123.ngrok.io/telegram-app.html
按钮文字: 🎬 打开短剧平台
```

#### 选项B: 生产部署（推荐）

```bash
# 1. 准备HTTPS域名
domain="app.sukplatform.com"

# 2. 安装SSL证书
sudo certbot --nginx -d $domain

# 3. 部署代码
git pull origin main
npm install --production
pm2 restart drama-platform

# 4. 配置Bot菜单按钮
# 向 @BotFather 发送:
/mybots → SUKDramaBot → Bot Settings → Menu Button
URL: https://app.sukplatform.com/telegram-app.html
按钮文字: 🎬 打开短剧平台
```

---

## 🧪 测试流程

### 1. 测试Bot连接

```bash
node scripts/test-telegram-bot.js
```

预期输出：
```
✅ Bot Token验证成功
✅ Bot信息: SUKDramaBot (@SUKDramaBot)
✅ Webhook状态: 未设置（开发环境正常）
```

### 2. 测试Mini App访问

1. 在Telegram中找到你的Bot
2. 点击 `/start` 命令
3. 点击菜单按钮（底部）
4. 应该看到短剧平台界面

### 3. 测试API认证

在浏览器开发者工具Console中：

```javascript
// 检查Telegram WebApp对象
console.log(window.Telegram.WebApp);

// 检查用户数据
console.log(window.Telegram.WebApp.initDataUnsafe.user);

// 测试API调用
fetch('/api/telegram/dramas', {
    headers: {
        'X-Telegram-Init-Data': window.Telegram.WebApp.initData
    }
}).then(r => r.json()).then(console.log);
```

---

## 📦 项目文件结构

```
drama-platform/
├── telegram-app.html              # Mini App入口页面
├── telegram-drama-detail.html     # 短剧详情页
├── telegram-player.html           # 视频播放器
├── telegram-wallet.html           # 钱包页面
├── telegram-profile.html          # 用户资料页
│
├── backend/
│   ├── middleware/
│   │   └── telegram-auth.middleware.js  # Telegram认证
│   ├── controllers/
│   │   └── telegram.controller.js       # Telegram控制器
│   └── routes/
│       └── telegram.routes.js           # Telegram路由
│
├── scripts/
│   └── test-telegram-bot.js       # Bot测试脚本
│
└── .env
    TELEGRAM_BOT_TOKEN=...         # Bot Token
    TON_WALLET_ADDRESS=...         # TON钱包地址
```

---

## 🔧 常用命令

```bash
# 开发环境
npm run dev                        # 启动开发服务器
ngrok http 3000                    # 创建HTTPS隧道
npm run test:telegram              # 测试Telegram集成

# 生产环境
pm2 start ecosystem.config.js      # 启动服务
pm2 logs drama-platform            # 查看日志
sudo nginx -t && sudo nginx -s reload  # 重载Nginx

# Bot管理
node scripts/set-webhook.js        # 设置Webhook
node scripts/delete-webhook.js     # 删除Webhook
node scripts/get-bot-info.js       # 获取Bot信息
```

---

## 💰 支付集成优先级

### 阶段1: Telegram Stars（最快）

```javascript
// 优点: Telegram原生支付，无需额外集成
// 适用: 小额支付，快速上线

bot.sendInvoice(userId, {
    title: '购买短剧',
    description: '霸道总裁爱上我',
    payload: 'drama_001',
    currency: 'XTR',
    prices: [{ label: '短剧价格', amount: 100 }] // 100 Stars
});
```

### 阶段2: TON支付（推荐）

```javascript
// 优点: Telegram生态，低手续费
// 适用: 加密货币支付用户

const paymentLink = `ton://transfer/${wallet}?amount=${amount}&text=drama_001`;
```

### 阶段3: SUK Token（完整生态）

```javascript
// 优点: 完整的SUK生态闭环
// 适用: SUK持有者

// 需要MetaMask或其他Web3钱包
const tx = await sukToken.transfer(platform, amount);
```

---

## 🎯 功能路线图

### MVP (最小可行产品) - 1周

- [x] Telegram Bot创建
- [x] Mini App基础页面
- [x] 用户认证
- [x] 短剧列表展示
- [ ] Telegram Stars支付
- [ ] 基础播放功能

### V1.0 - 2周

- [ ] TON钱包集成
- [ ] 完整播放器（含续播）
- [ ] 观看历史
- [ ] 用户资料页
- [ ] 推荐系统

### V2.0 - 1个月

- [ ] SUK Token支付
- [ ] 社交分享
- [ ] 评论系统
- [ ] 推荐佣金
- [ ] 管理后台

---

## ❓ 常见问题

### Q: Mini App无法加载怎么办？

**检查清单**：
1. 是否使用HTTPS？（必需）
2. Bot菜单按钮URL是否正确？
3. 服务器是否正常运行？
4. Nginx配置是否正确？

```bash
# 检查HTTPS
curl -I https://app.sukplatform.com

# 检查服务器
pm2 status

# 测试Nginx配置
sudo nginx -t
```

### Q: 用户认证失败？

**可能原因**：
- Bot Token配置错误
- initData验证逻辑有误

```bash
# 检查Token
echo $TELEGRAM_BOT_TOKEN

# 查看日志
pm2 logs drama-platform --lines 50
```

### Q: 如何调试Mini App？

**方法1: 使用Telegram Desktop**

1. 下载Telegram Desktop
2. 启用开发者工具: 右键 → Inspect Element
3. 在Console中查看日志和网络请求

**方法2: 使用Eruda调试工具**

在HTML中添加：

```html
<script src="https://cdn.jsdelivr.net/npm/eruda"></script>
<script>eruda.init();</script>
```

---

## 📞 获取帮助

- **官方文档**: https://core.telegram.org/bots/webapps
- **示例项目**: https://github.com/Telegram-Mini-Apps
- **社区支持**: Telegram开发者群组

---

## ✅ 快速启动检查清单

部署前确认：

- [ ] 已创建Telegram Bot并获取Token
- [ ] 已配置环境变量（.env文件）
- [ ] 已安装所有依赖 (`npm install`)
- [ ] 已测试Bot连接 (`npm run test:telegram`)
- [ ] 已准备HTTPS域名（生产环境）
- [ ] 已配置Nginx和SSL证书
- [ ] 已在@BotFather设置菜单按钮URL
- [ ] 已测试Mini App加载
- [ ] 已测试用户认证
- [ ] 已测试短剧列表显示

**完成所有检查后，您的Telegram Mini App即可上线！🎉**

---

*最后更新时间：2024-11-15*
*文档版本：v1.0*
