# Telegram Stars 支付快速启动指南
# Payment System Quick Start Guide

> 🚀 5分钟快速测试 Telegram Stars 支付功能

## 前置条件 / Prerequisites

✅ 已完成环境检查（运行过 `./scripts/quick-test.sh`）  
✅ MongoDB 和 Redis 正常运行  
✅ 已创建 Telegram Bot（通过 @BotFather）  
✅ 已安装 ngrok

## 步骤 1: 配置环境变量 (1分钟)

编辑 `.env` 文件，确保以下配置正确：

```bash
# Telegram Bot Token (必需)
TELEGRAM_BOT_TOKEN=123456789:ABCdefGHIjklMNOpqrsTUVwxyz

# MongoDB (必需)
MONGODB_URI=mongodb://localhost:27017/telegram-drama-dev

# 服务器端口
PORT=3000

# Web App URL (启动 ngrok 后更新)
WEB_APP_URL=https://your-ngrok-url.ngrok.io

# TON 钱包地址 (可选)
TON_WALLET_ADDRESS=UQxxxxx...

# SUK Token 合约 (可选)
SUK_TOKEN_CONTRACT=0x1234...5678
```

## 步骤 2: 启动服务 (1分钟)

### 终端 1: 启动后端服务

```bash
cd backend
npm install
npm run dev
```

等待看到：
```
✓ MongoDB 连接成功
✓ Redis 连接成功
✓ 服务器运行在 http://localhost:3000
```

### 终端 2: 启动 ngrok

```bash
ngrok http 3000
```

复制 ngrok 提供的 HTTPS URL（例如：`https://abc123.ngrok.io`）

## 步骤 3: 设置 Webhook (1分钟)

### 方法 1: 使用 curl

```bash
# 替换 <YOUR_BOT_TOKEN> 和 <YOUR_NGROK_URL>
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://abc123.ngrok.io/api/telegram/webhook",
    "allowed_updates": ["message", "pre_checkout_query"]
  }'
```

### 方法 2: 在浏览器打开

```
https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook?url=https://abc123.ngrok.io/api/telegram/webhook
```

**验证 webhook 设置:**
```bash
curl "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getWebhookInfo"
```

应该看到：
```json
{
  "ok": true,
  "result": {
    "url": "https://abc123.ngrok.io/api/telegram/webhook",
    "has_custom_certificate": false,
    "pending_update_count": 0
  }
}
```

## 步骤 4: 配置 Mini App (1分钟)

1. 在 Telegram 中找到 @BotFather
2. 发送命令：`/mybots`
3. 选择你的 Bot
4. 点击 "Bot Settings" → "Menu Button"
5. 选择 "Configure Menu Button"
6. 设置：
   - **URL**: `https://abc123.ngrok.io/telegram-app.html`
   - **Button text**: "🎬 观看剧集"

或使用命令：
```bash
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setChatMenuButton" \
  -H "Content-Type: application/json" \
  -d '{
    "menu_button": {
      "type": "web_app",
      "text": "🎬 观看剧集",
      "web_app": {
        "url": "https://abc123.ngrok.io/telegram-app.html"
      }
    }
  }'
```

## 步骤 5: 测试支付流程 (1分钟)

### 5.1 打开 Mini App

1. 在 Telegram 中打开与你的 Bot 的聊天
2. 点击底部菜单按钮 "🎬 观看剧集"
3. 应该看到剧集列表页面

### 5.2 选择剧集

1. 点击任意剧集卡片
2. 进入剧集详情页
3. 查看剧集信息、演员列表、评论等

### 5.3 购买剧集（Telegram Stars）

1. 点击 "购买全集" 按钮
2. 在弹出的对话框中选择 "Telegram Stars ⭐"
3. 点击 "确认购买"
4. **重要**: 返回与 Bot 的聊天窗口
5. 应该看到发票消息
6. 点击 "Pay ⭐100 Stars" 按钮
7. 确认支付

### 5.4 验证购买成功

支付成功后应该收到：
1. Bot 发送的成功消息："🎉 支付成功！"
2. "📺 立即观看" 按钮

点击按钮返回剧集详情页，应该看到：
- ✅ "已购买" 标记
- 所有剧集都可以点击播放

### 5.5 测试播放授权

1. 点击任意剧集（例如第2集）
2. 进入视频播放器页面
3. 应该能正常加载播放器（虽然是 mock 数据）
4. **不会**看到 "需要购买" 的提示

## 步骤 6: 验证数据库 (可选)

```bash
# 连接 MongoDB
mongosh "mongodb://localhost:27017/telegram-drama-dev"

# 查看订单
db.orders.find({}).pretty()

# 应该看到一条订单记录：
# {
#   orderId: "ORDER_...",
#   status: "completed",
#   paymentMethod: "stars",
#   amount: 100,
#   currency: "XTR"
# }

# 查看购买记录
db.purchases.find({}).pretty()

# 应该看到购买记录：
# {
#   userId: "123456789",
#   dramaId: "drama_001",
#   purchaseType: "full",
#   isValid: true
# }
```

## 常见问题 / Troubleshooting

### Q1: 点击支付按钮后没有收到发票消息

**检查:**
1. Webhook 是否正确设置？
   ```bash
   curl "https://api.telegram.org/bot<TOKEN>/getWebhookInfo"
   ```
2. ngrok 是否正常运行？
3. 后端服务是否运行？检查终端日志

**解决:**
```bash
# 重新设置 webhook
curl -X POST "https://api.telegram.org/bot<TOKEN>/deleteWebhook"
curl -X POST "https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://your-ngrok.ngrok.io/api/telegram/webhook"
```

### Q2: 支付后没有收到成功消息

**检查后端日志:**
```bash
# 应该看到类似日志
收到 Telegram webhook:
处理支付成功回调:
订单状态更新成功: ORDER_...
购买记录创建成功: ORDER_...
```

**如果没有看到日志:**
- Webhook URL 可能不正确
- ngrok 可能已过期（免费版 2小时后需要重启）
- 检查防火墙设置

### Q3: 播放器显示 "您尚未购买此剧集"

**原因:** 购买记录未正确创建

**检查数据库:**
```javascript
db.purchases.find({ 
  userId: "YOUR_TELEGRAM_ID",
  dramaId: "drama_001" 
})
```

**如果没有记录:**
- 查看 webhook 日志
- 确认支付回调是否被正确处理
- 检查 MongoDB 连接

### Q4: Pre-checkout query 超时

**错误信息:** "Payment failed. Try again later"

**原因:** 后端响应时间超过 10 秒

**解决:**
1. 检查 MongoDB 连接
2. 确保数据库索引已创建
3. 查看后端响应时间日志

### Q5: ngrok URL 改变后怎么办？

每次重启 ngrok 都会获得新的 URL，需要：

1. **更新 .env 文件:**
   ```bash
   WEB_APP_URL=https://new-url.ngrok.io
   ```

2. **重启后端服务** (Ctrl+C 然后 `npm run dev`)

3. **重新设置 webhook:**
   ```bash
   curl -X POST "https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://new-url.ngrok.io/api/telegram/webhook"
   ```

4. **更新 Mini App URL** (在 @BotFather 中)

**提示:** 使用 ngrok 付费版可以获得固定域名

## 测试其他支付方式

### TON Coin 测试 (待完善)

```javascript
// 前端选择 TON 支付
// 会生成 TON 深链接
// ton://transfer/UQxxxxx...?amount=3000000000&text=Order%3A...

// 需要安装 TON 钱包才能测试
// 当前版本：生成链接但不验证交易
```

### SUK Token 测试 (待完善)

```javascript
// 前端选择 SUK Token 支付
// 需要 MetaMask 或 WalletConnect
// 用户完成转账后提交 transaction hash

// 当前版本：创建订单但不验证区块链交易
```

## 下一步

✅ 支付系统核心功能已完成 (90%)  
⏳ 待完成功能：

1. **TON 交易监控** - 实现区块链交易查询和验证
2. **SUK Token 验证** - 集成 ethers.js 验证 ERC-20 转账
3. **阿里云 VoD 集成** - 替换 mock 播放授权为真实授权
4. **钱包管理页** - 显示余额和交易历史

详细信息请参考：
- 📖 [完整支付系统文档](PAYMENT_SYSTEM.md)
- 📖 [API 文档](DRAMA_PLAYBACK_BACKEND_API.md)

## 生产环境部署

**重要提示:** 生产环境需要：

1. **固定域名** (不能使用 ngrok)
2. **SSL 证书** (Telegram 要求 HTTPS)
3. **环境变量安全** (使用密钥管理服务)
4. **监控和日志** (PM2 + 日志系统)

参考：[部署指南](DEPLOYMENT_GUIDE.md)

---

**🎉 恭喜！你已经成功测试了 Telegram Stars 支付功能！**

有任何问题，请查看：
- [完整文档](PAYMENT_SYSTEM.md#常见问题--faq)
- [项目 Issues](https://github.com/your-repo/issues)

*最后更新：2024-01-15*
