# 支付流程测试指南
# Payment Flow Test Guide

> 🧪 完整测试 Telegram Stars 支付流程的详细指南

---

## 📋 测试前准备

### 1. 环境要求

✅ 后端服务已启动（`npm run dev`）  
✅ MongoDB 正常运行  
✅ Redis 正常运行  
✅ 已配置 `TELEGRAM_BOT_TOKEN` 环境变量

### 2. 快速检查

```bash
# 检查后端服务
curl http://localhost:3000/api/health

# 检查 MongoDB
mongosh "mongodb://localhost:27017/telegram-drama-dev"

# 检查 Redis
redis-cli ping
```

---

## 🚀 测试方法

我们提供了 **两种测试方式**：

### 方法 1: 可视化网页测试 (推荐)

**优点**: 直观、易用、实时反馈

**步骤**:

1. **打开测试页面**
   ```bash
   # 在浏览器中打开
   open payment-flow-test.html
   # 或
   open http://localhost:3000/payment-flow-test.html
   ```

2. **配置测试参数**
   - API URL: `http://localhost:3000`
   - 测试用户 ID: `123456789` (或你的 Telegram ID)
   - 测试剧集 ID: `drama_001`
   - 测试剧集编号: `ep_002`

3. **点击 "🚀 开始完整测试"**

4. **观察测试过程**
   - 每个测试步骤会实时显示状态
   - ✅ 绿色表示通过
   - ❌ 红色表示失败
   - ⏳ 蓝色表示正在运行

5. **查看测试结果**
   - 测试完成后会显示总结
   - 包括通过率和详细结果
   - 提供 MongoDB 验证命令

---

### 方法 2: 命令行测试

**优点**: 自动化、适合 CI/CD

**步骤**:

1. **设置环境变量**
   ```bash
   export TELEGRAM_BOT_TOKEN="your_bot_token"
   export TEST_USER_ID="123456789"
   ```

2. **运行测试脚本**
   ```bash
   npm run test:payment
   ```

3. **查看测试输出**
   ```
   ╔════════════════════════════════════════════════════════════╗
   ║                                                            ║
   ║          🧪 Telegram 支付流程完整测试                      ║
   ║          Payment Flow Complete Test                       ║
   ║                                                            ║
   ╚════════════════════════════════════════════════════════════╝
   
   📋 测试配置:
      API URL: http://localhost:3000
      测试用户 ID: 123456789
      测试剧集 ID: drama_001
      测试剧集编号: ep_002
   
   ============================================================
     测试 1: 获取剧集详情（购买前）
   ============================================================
   
   📡 GET /api/telegram/dramas/drama_001
   ✅ 状态码: 200
   📦 响应: {...}
   
   ✅ [PASSED] 购买状态应为 false，实际为: false
   
   ...
   ```

---

## 📊 测试用例说明

### 测试 1: 获取剧集详情（购买前）

**目的**: 验证未购买时的状态

**预期结果**:
- API 返回 200
- `hasPurchased` 字段为 `false`

**验证**:
```javascript
const response = await fetch('/api/telegram/dramas/drama_001');
const data = await response.json();
assert(data.data.hasPurchased === false);
```

---

### 测试 2: 尝试播放付费剧集

**目的**: 验证权限拦截

**预期结果**:
- API 返回 403 Forbidden
- 提示 "您尚未购买此剧集"

**验证**:
```javascript
const response = await fetch('/api/telegram/play-auth/ep_002?dramaId=drama_001');
assert(response.status === 403);
```

---

### 测试 3: 创建 Telegram Stars 发票

**目的**: 测试订单创建

**预期结果**:
- API 返回 200
- 返回有效的 `orderId`
- MongoDB 中创建订单记录

**请求体**:
```json
{
    "dramaId": "drama_001",
    "paymentMethod": "stars",
    "purchaseType": "full"
}
```

**验证**:
```bash
# MongoDB 查询
db.orders.findOne({ orderId: "ORDER_XXX" })

# 期望输出
{
    orderId: "ORDER_L3X2H8K_A7F9D2",
    status: "pending",
    paymentMethod: "stars",
    amount: 100,
    currency: "XTR",
    expiresAt: ISODate("2024-01-15T...")
}
```

---

### 测试 4: 模拟支付成功回调

**目的**: 测试 Webhook 处理

**预期结果**:
- Webhook 返回 200
- 订单状态更新为 `completed`
- 购买记录已创建

**Webhook 数据**:
```json
{
    "update_id": 123456,
    "message": {
        "message_id": 1234,
        "from": { "id": 123456789, "first_name": "Test User" },
        "chat": { "id": 123456789, "type": "private" },
        "successful_payment": {
            "currency": "XTR",
            "total_amount": 100,
            "invoice_payload": "{\"orderId\":\"ORDER_XXX\", ...}",
            "telegram_payment_charge_id": "tch_xxx..."
        }
    }
}
```

**验证**:
```bash
# 1. 检查订单状态
db.orders.findOne({ orderId: "ORDER_XXX" })
# status 应为 "completed"

# 2. 检查购买记录
db.purchases.findOne({ orderId: "ORDER_XXX" })
# 应该找到记录
```

---

### 测试 5-6: 验证数据库记录

**目的**: 确认数据持久化

**验证步骤**:

1. **检查订单更新**:
   ```javascript
   db.orders.findOne({ orderId: "ORDER_XXX" })
   ```
   期望:
   - `status: "completed"`
   - `paymentId` 已设置
   - `completedAt` 已设置

2. **检查购买记录**:
   ```javascript
   db.purchases.findOne({ 
       userId: "123456789",
       dramaId: "drama_001",
       isValid: true
   })
   ```
   期望:
   - 记录存在
   - `purchaseType: "full"`
   - `paymentMethod: "stars"`

---

### 测试 7: 获取剧集详情（购买后）

**目的**: 验证购买状态更新

**预期结果**:
- API 返回 200
- `hasPurchased` 字段为 `true`

**验证**:
```javascript
const response = await fetch('/api/telegram/dramas/drama_001');
const data = await response.json();
assert(data.data.hasPurchased === true);
```

---

### 测试 8: 尝试播放付费剧集（购买后）

**目的**: 验证播放授权

**预期结果**:
- API 返回 200
- 返回有效的播放授权信息

**验证**:
```javascript
const response = await fetch('/api/telegram/play-auth/ep_002?dramaId=drama_001');
assert(response.status === 200);

const data = await response.json();
assert(data.success === true);
assert(data.playAuth !== null);
```

---

### 测试 9: 测试免费剧集播放

**目的**: 验证免费内容访问

**预期结果**:
- API 返回 200
- 无需购买即可播放第1集

**验证**:
```javascript
// 即使用户未购买，第1集也应该能播放
const response = await fetch('/api/telegram/play-auth/ep_001?dramaId=drama_001');
assert(response.status === 200);
```

---

## 🔍 问题排查

### Q1: 测试失败 - "订单不存在"

**原因**: MongoDB 连接问题或订单未创建

**解决**:
```bash
# 1. 检查 MongoDB 连接
mongosh "mongodb://localhost:27017/telegram-drama-dev"

# 2. 查看所有订单
db.orders.find({}).pretty()

# 3. 检查后端日志
tail -f backend/logs/error.log
```

---

### Q2: Webhook 返回 404

**原因**: 路由未正确注册

**解决**:
```bash
# 1. 检查路由配置
grep -r "webhook" backend/routes/

# 2. 重启后端服务
npm run dev

# 3. 测试 webhook 端点
curl -X POST http://localhost:3000/api/telegram/webhook \
  -H "Content-Type: application/json" \
  -d '{"update_id": 1}'
```

---

### Q3: 购买状态未更新

**原因**: 购买记录未正确创建

**解决**:
```bash
# 1. 检查购买记录
db.purchases.find({ 
    userId: "123456789",
    dramaId: "drama_001"
}).pretty()

# 2. 检查索引
db.purchases.getIndexes()

# 3. 查看后端日志
grep "创建购买记录" backend/logs/combined.log
```

---

### Q4: 权限验证失败

**原因**: checkPurchaseStatus 逻辑问题

**解决**:
```javascript
// 手动测试购买状态检查
const TelegramPaymentService = require('./backend/services/telegram-payment.service');

const result = await TelegramPaymentService.checkPurchaseStatus(
    '123456789',
    'drama_001',
    'ep_002'
);

console.log(result);
// 期望: { purchased: true, type: 'full', purchase: {...} }
```

---

## 📝 测试报告

测试完成后，生成测试报告：

### 自动生成（网页版）

测试页面会自动显示：
- 总测试数
- 通过数
- 失败数
- 通过率
- 详细结果

### 手动记录（命令行版）

```bash
# 运行测试并保存输出
npm run test:payment | tee test-results.log

# 查看结果
cat test-results.log | grep "PASSED\|FAILED"
```

### MongoDB 数据快照

```bash
# 导出测试数据
mongoexport --db=telegram-drama-dev --collection=orders \
  --out=test-orders.json

mongoexport --db=telegram-drama-dev --collection=purchases \
  --out=test-purchases.json
```

---

## 🧹 清理测试数据

测试完成后，清理测试数据：

### 删除测试订单

```javascript
// MongoDB Shell
db.orders.deleteMany({ 
    userId: "123456789",
    dramaId: "drama_001"
});
```

### 删除测试购买记录

```javascript
db.purchases.deleteMany({ 
    userId: "123456789",
    dramaId: "drama_001"
});
```

### 完整清理脚本

```javascript
// clean-test-data.js
const testUserId = "123456789";
const testDramaId = "drama_001";

db.orders.deleteMany({ userId: testUserId, dramaId: testDramaId });
db.purchases.deleteMany({ userId: testUserId, dramaId: testDramaId });

print("✅ 测试数据已清理");
```

运行:
```bash
mongosh "mongodb://localhost:27017/telegram-drama-dev" clean-test-data.js
```

---

## ✅ 验收标准

测试通过的标准：

- [ ] 所有 9 个测试用例通过
- [ ] 通过率 ≥ 90%
- [ ] MongoDB 数据正确存储
- [ ] 订单状态正确转换（pending → completed）
- [ ] 购买记录正确创建
- [ ] 权限验证正常工作
- [ ] 免费剧集无需购买可播放
- [ ] 无异常日志或错误

---

## 📚 相关文档

- 📖 [支付系统完整文档](PAYMENT_SYSTEM.md)
- 📖 [5分钟快速测试](PAYMENT_QUICK_START.md)
- 📖 [实现总结](IMPLEMENTATION_SUMMARY.md)
- 📖 [API 文档](DRAMA_PLAYBACK_BACKEND_API.md)

---

## 💡 最佳实践

### 1. 定期测试

```bash
# 每次修改代码后运行
npm run test:payment

# 或使用 watch 模式
nodemon --exec "npm run test:payment" --watch backend/
```

### 2. 自动化测试

将测试脚本集成到 CI/CD 流程：

```yaml
# .github/workflows/test.yml
name: Payment Flow Test

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Setup Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '18'
      - name: Install dependencies
        run: npm install
      - name: Start MongoDB
        run: docker run -d -p 27017:27017 mongo:6
      - name: Start Redis
        run: docker run -d -p 6379:6379 redis:6
      - name: Run tests
        run: npm run test:payment
```

### 3. 性能测试

测试高并发场景：

```javascript
// 并发创建 100 个订单
const promises = [];
for (let i = 0; i < 100; i++) {
    promises.push(createStarsInvoice());
}
await Promise.all(promises);
```

---

**🎉 测试完成！如果所有测试通过，支付系统已经可以投入使用！**

*最后更新: 2024-01-15*
