// ==================== Web3钱包集成模块 ====================

// 全局Web3状态
const Web3State = {
    provider: null,
    signer: null,
    address: null,
    chainId: null,
    isConnected: false,
    balance: '0'
};

// 支持的区块链网络
const SUPPORTED_CHAINS = {
    137: {
        name: 'Polygon Mainnet',
        rpcUrl: 'https://polygon-rpc.com',
        explorer: 'https://polygonscan.com',
        currency: 'MATIC'
    },
    80001: {
        name: 'Polygon Mumbai Testnet',
        rpcUrl: 'https://rpc-mumbai.maticvigil.com',
        explorer: 'https://mumbai.polygonscan.com',
        currency: 'MATIC'
    },
    1: {
        name: 'Ethereum Mainnet',
        rpcUrl: 'https://eth.llamarpc.com',
        explorer: 'https://etherscan.io',
        currency: 'ETH'
    }
};

// ==================== 钱包连接功能 ====================

/**
 * 检测MetaMask是否安装
 */
function isMetaMaskInstalled() {
    return typeof window.ethereum !== 'undefined' && window.ethereum.isMetaMask;
}

/**
 * 连接钱包
 */
async function connectWallet() {
    if (!isMetaMaskInstalled()) {
        showWalletModal('请先安装MetaMask钱包', 'error');
        setTimeout(() => {
            window.open('https://metamask.io/download/', '_blank');
        }, 2000);
        return false;
    }

    try {
        // 请求账户访问权限
        const accounts = await window.ethereum.request({
            method: 'eth_requestAccounts'
        });

        if (accounts.length === 0) {
            showWalletModal('未找到账户', 'error');
            return false;
        }

        Web3State.address = accounts[0];
        Web3State.isConnected = true;

        // 获取链ID
        const chainId = await window.ethereum.request({
            method: 'eth_chainId'
        });
        Web3State.chainId = parseInt(chainId, 16);

        // 获取余额
        await updateBalance();

        // 更新UI
        updateWalletUI();
        
        // 监听账户和网络变化
        setupWalletListeners();

        showWalletModal('钱包连接成功！', 'success');
        
        // 触发自定义事件
        window.dispatchEvent(new CustomEvent('walletConnected', {
            detail: { address: Web3State.address }
        }));

        return true;
    } catch (error) {
        console.error('连接钱包失败:', error);
        
        if (error.code === 4001) {
            showWalletModal('用户拒绝连接钱包', 'warning');
        } else {
            showWalletModal('连接钱包失败: ' + error.message, 'error');
        }
        
        return false;
    }
}

/**
 * 断开钱包连接
 */
function disconnectWallet() {
    Web3State.provider = null;
    Web3State.signer = null;
    Web3State.address = null;
    Web3State.chainId = null;
    Web3State.isConnected = false;
    Web3State.balance = '0';
    
    updateWalletUI();
    showWalletModal('钱包已断开连接', 'info');
    
    // 触发自定义事件
    window.dispatchEvent(new Event('walletDisconnected'));
}

/**
 * 更新余额
 */
async function updateBalance() {
    if (!Web3State.isConnected || !Web3State.address) return;
    
    try {
        const balance = await window.ethereum.request({
            method: 'eth_getBalance',
            params: [Web3State.address, 'latest']
        });
        
        // 将Wei转换为ETH/MATIC
        Web3State.balance = (parseInt(balance, 16) / 1e18).toFixed(4);
    } catch (error) {
        console.error('获取余额失败:', error);
    }
}

/**
 * 切换网络
 */
async function switchNetwork(chainId) {
    if (!isMetaMaskInstalled()) {
        showWalletModal('请先安装MetaMask', 'error');
        return false;
    }

    const chainConfig = SUPPORTED_CHAINS[chainId];
    if (!chainConfig) {
        showWalletModal('不支持的网络', 'error');
        return false;
    }

    try {
        // 尝试切换到指定网络
        await window.ethereum.request({
            method: 'wallet_switchEthereumChain',
            params: [{ chainId: '0x' + chainId.toString(16) }]
        });
        
        Web3State.chainId = chainId;
        showWalletModal(`已切换到 ${chainConfig.name}`, 'success');
        return true;
    } catch (error) {
        // 如果网络不存在，尝试添加
        if (error.code === 4902) {
            try {
                await window.ethereum.request({
                    method: 'wallet_addEthereumChain',
                    params: [{
                        chainId: '0x' + chainId.toString(16),
                        chainName: chainConfig.name,
                        rpcUrls: [chainConfig.rpcUrl],
                        nativeCurrency: {
                            name: chainConfig.currency,
                            symbol: chainConfig.currency,
                            decimals: 18
                        },
                        blockExplorerUrls: [chainConfig.explorer]
                    }]
                });
                
                Web3State.chainId = chainId;
                showWalletModal(`已添加并切换到 ${chainConfig.name}`, 'success');
                return true;
            } catch (addError) {
                console.error('添加网络失败:', addError);
                showWalletModal('添加网络失败', 'error');
                return false;
            }
        }
        
        console.error('切换网络失败:', error);
        showWalletModal('切换网络失败', 'error');
        return false;
    }
}

/**
 * 监听钱包事件
 */
function setupWalletListeners() {
    if (!window.ethereum) return;

    // 监听账户变化
    window.ethereum.on('accountsChanged', async (accounts) => {
        if (accounts.length === 0) {
            disconnectWallet();
        } else {
            Web3State.address = accounts[0];
            await updateBalance();
            updateWalletUI();
            showWalletModal('账户已切换', 'info');
        }
    });

    // 监听网络变化
    window.ethereum.on('chainChanged', (chainId) => {
        Web3State.chainId = parseInt(chainId, 16);
        updateWalletUI();
        showWalletModal('网络已切换', 'info');
        // 重新加载页面以确保状态同步
        window.location.reload();
    });

    // 监听连接状态
    window.ethereum.on('connect', (connectInfo) => {
        console.log('钱包已连接:', connectInfo);
    });

    // 监听断开连接
    window.ethereum.on('disconnect', (error) => {
        console.log('钱包已断开:', error);
        disconnectWallet();
    });
}

/**
 * 更新UI显示
 */
function updateWalletUI() {
    const connectBtn = document.getElementById('connectWalletBtn');
    if (!connectBtn) return;

    if (Web3State.isConnected && Web3State.address) {
        // 显示简短地址
        const shortAddress = Web3State.address.substring(0, 6) + '...' + Web3State.address.substring(38);
        connectBtn.innerHTML = `
            <i class="fas fa-wallet"></i>
            ${shortAddress}
        `;
        connectBtn.classList.add('connected');
        
        // 添加点击事件显示钱包详情
        connectBtn.onclick = showWalletDetails;
    } else {
        connectBtn.innerHTML = '连接钱包';
        connectBtn.classList.remove('connected');
        connectBtn.onclick = connectWallet;
    }
}

/**
 * 显示钱包详情
 */
function showWalletDetails() {
    const chainConfig = SUPPORTED_CHAINS[Web3State.chainId];
    const chainName = chainConfig ? chainConfig.name : '未知网络';
    const currency = chainConfig ? chainConfig.currency : 'ETH';

    const modal = document.createElement('div');
    modal.className = 'wallet-details-modal';
    modal.innerHTML = `
        <div class="modal-overlay"></div>
        <div class="modal-content">
            <div class="modal-header">
                <h3>钱包详情</h3>
                <button class="modal-close"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <div class="wallet-info">
                    <div class="info-row">
                        <span class="label">地址</span>
                        <span class="value address">${Web3State.address}</span>
                        <button class="btn-copy" data-copy="${Web3State.address}">
                            <i class="fas fa-copy"></i>
                        </button>
                    </div>
                    <div class="info-row">
                        <span class="label">网络</span>
                        <span class="value">${chainName}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">余额</span>
                        <span class="value">${Web3State.balance} ${currency}</span>
                    </div>
                </div>
                <div class="wallet-actions">
                    <button class="btn-action" onclick="switchNetwork(137)">
                        <i class="fas fa-exchange-alt"></i>
                        切换到Polygon
                    </button>
                    <button class="btn-action" onclick="viewOnExplorer()">
                        <i class="fas fa-external-link-alt"></i>
                        在浏览器中查看
                    </button>
                    <button class="btn-action disconnect" onclick="disconnectWallet(); closeModal()">
                        <i class="fas fa-sign-out-alt"></i>
                        断开连接
                    </button>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    // 添加样式
    if (!document.querySelector('#wallet-modal-styles')) {
        const style = document.createElement('style');
        style.id = 'wallet-modal-styles';
        style.textContent = `
            .wallet-details-modal {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                z-index: 10000;
                display: flex;
                align-items: center;
                justify-content: center;
                animation: fadeIn 0.3s ease;
            }
            
            .wallet-info {
                background: rgba(139, 92, 246, 0.05);
                border-radius: var(--radius-md);
                padding: 1.5rem;
                margin-bottom: 1.5rem;
            }
            
            .info-row {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 1rem 0;
                border-bottom: 1px solid rgba(139, 92, 246, 0.1);
            }
            
            .info-row:last-child {
                border-bottom: none;
            }
            
            .info-row .label {
                color: var(--text-muted);
                font-size: 0.9rem;
            }
            
            .info-row .value {
                font-weight: 600;
                color: var(--text-primary);
            }
            
            .info-row .value.address {
                font-family: monospace;
                font-size: 0.85rem;
                max-width: 200px;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            
            .btn-copy {
                padding: 0.5rem;
                background: rgba(139, 92, 246, 0.2);
                border: none;
                border-radius: var(--radius-sm);
                color: var(--color-primary);
                cursor: pointer;
                transition: var(--transition-fast);
            }
            
            .btn-copy:hover {
                background: var(--color-primary);
                color: white;
            }
            
            .wallet-actions {
                display: flex;
                flex-direction: column;
                gap: 0.75rem;
            }
            
            .btn-action {
                width: 100%;
                padding: 1rem;
                background: transparent;
                border: 1px solid rgba(139, 92, 246, 0.3);
                border-radius: var(--radius-sm);
                color: var(--text-primary);
                font-weight: 600;
                cursor: pointer;
                transition: var(--transition-normal);
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 0.75rem;
            }
            
            .btn-action:hover {
                background: rgba(139, 92, 246, 0.1);
                border-color: var(--color-primary);
            }
            
            .btn-action.disconnect {
                color: var(--error);
                border-color: rgba(239, 68, 68, 0.3);
            }
            
            .btn-action.disconnect:hover {
                background: rgba(239, 68, 68, 0.1);
                border-color: var(--error);
            }
            
            .btn-primary.connected {
                background: var(--gradient-primary);
            }
        `;
        document.head.appendChild(style);
    }

    // 关闭模态框
    const closeBtn = modal.querySelector('.modal-close');
    const overlay = modal.querySelector('.modal-overlay');
    
    const closeModal = () => {
        modal.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => modal.remove(), 300);
    };
    
    closeBtn.addEventListener('click', closeModal);
    overlay.addEventListener('click', closeModal);

    // 复制地址
    const copyBtn = modal.querySelector('.btn-copy');
    copyBtn.addEventListener('click', function() {
        const address = this.dataset.copy;
        navigator.clipboard.writeText(address).then(() => {
            showWalletModal('地址已复制', 'success');
        });
    });
}

/**
 * 在区块链浏览器中查看
 */
function viewOnExplorer() {
    const chainConfig = SUPPORTED_CHAINS[Web3State.chainId];
    if (chainConfig && Web3State.address) {
        window.open(`${chainConfig.explorer}/address/${Web3State.address}`, '_blank');
    }
}

/**
 * 关闭模态框（全局函数）
 */
function closeModal() {
    const modal = document.querySelector('.wallet-details-modal');
    if (modal) {
        modal.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => modal.remove(), 300);
    }
}

/**
 * 显示钱包消息
 */
function showWalletModal(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `wallet-notification wallet-${type}`;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    notification.innerHTML = `
        <i class="fas ${icons[type]}"></i>
        <span>${message}</span>
    `;
    
    // 添加样式
    if (!document.querySelector('#wallet-notification-styles')) {
        const style = document.createElement('style');
        style.id = 'wallet-notification-styles';
        style.textContent = `
            .wallet-notification {
                position: fixed;
                top: 100px;
                right: 2rem;
                padding: 1rem 1.5rem;
                background: var(--bg-card);
                border: 2px solid;
                border-radius: var(--radius-sm);
                color: var(--text-primary);
                display: flex;
                align-items: center;
                gap: 0.75rem;
                z-index: 10001;
                animation: slideInRight 0.3s ease, slideOutRight 0.3s ease 2.7s;
                box-shadow: var(--shadow-lg);
                min-width: 300px;
            }
            
            .wallet-success { border-color: var(--success); }
            .wallet-error { border-color: var(--error); }
            .wallet-warning { border-color: var(--warning); }
            .wallet-info { border-color: var(--color-primary); }
            
            .wallet-notification i {
                font-size: 1.2rem;
            }
            
            .wallet-success i { color: var(--success); }
            .wallet-error i { color: var(--error); }
            .wallet-warning i { color: var(--warning); }
            .wallet-info i { color: var(--color-primary); }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
}

// ==================== 初始化 ====================
document.addEventListener('DOMContentLoaded', function() {
    const connectBtn = document.getElementById('connectWalletBtn');
    
    if (connectBtn) {
        connectBtn.addEventListener('click', connectWallet);
    }
    
    // 检查是否已经连接
    if (isMetaMaskInstalled()) {
        window.ethereum.request({ method: 'eth_accounts' })
            .then(accounts => {
                if (accounts.length > 0) {
                    // 自动重新连接
                    connectWallet();
                }
            });
    }
});

// 导出给其他模块使用
window.Web3Wallet = {
    connect: connectWallet,
    disconnect: disconnectWallet,
    getState: () => Web3State,
    switchNetwork: switchNetwork,
    isConnected: () => Web3State.isConnected
};