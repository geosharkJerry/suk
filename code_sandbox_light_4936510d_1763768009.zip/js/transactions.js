// ========================================
// SUK Protocol - 交易历史管理器
// 从区块链读取交易数据或使用模拟数据
// ========================================

const TransactionManager = {
    transactions: [],
    filteredTransactions: [],
    currentFilter: 'all',
    displayCount: 10,
    page: 1,

    // 初始化
    init() {
        this.loadTransactions();
        this.updateStats();
        this.renderTransactions();

        // 检查用户登录
        if (!AuthManager.isLoggedIn()) {
            showNotification('请先登录查看交易记录', 'warning');
            setTimeout(() => {
                window.location.href = 'auth.html';
            }, 2000);
        }
    },

    // 加载交易数据
    async loadTransactions() {
        try {
            const user = AuthManager.getCurrentUser();
            
            // 尝试从区块链读取（如果已连接钱包）
            if (window.ethereum && user?.walletAddress) {
                await this.loadFromBlockchain(user.walletAddress);
            } else {
                // 使用模拟数据
                this.transactions = this.loadMockTransactions();
            }

            this.filteredTransactions = [...this.transactions];
            
        } catch (error) {
            console.error('❌ 加载交易失败:', error);
            this.transactions = this.loadMockTransactions();
            this.filteredTransactions = [...this.transactions];
        }
    },

    // 从区块链加载交易（示例）
    async loadFromBlockchain(address) {
        try {
            // ⚠️ 这是示例代码，实际需要配置 ethers.js 和 provider
            // const provider = new ethers.providers.Web3Provider(window.ethereum);
            // const blockNumber = await provider.getBlockNumber();
            // 
            // // 获取最近的交易
            // for (let i = 0; i < 100; i++) {
            //     const block = await provider.getBlockWithTransactions(blockNumber - i);
            //     block.transactions.forEach(tx => {
            //         if (tx.from.toLowerCase() === address.toLowerCase() || 
            //             tx.to?.toLowerCase() === address.toLowerCase()) {
            //             this.transactions.push(this.parseTransaction(tx));
            //         }
            //     });
            // }

            console.log('⚠️ 区块链交易读取功能需要部署合约后才能使用');
            console.log('💡 当前使用模拟数据进行展示');
            
            // 暂时使用模拟数据
            this.transactions = this.loadMockTransactions();
            
        } catch (error) {
            console.error('❌ 从区块链加载失败:', error);
            throw error;
        }
    },

    // 解析区块链交易
    parseTransaction(tx) {
        return {
            id: tx.hash,
            type: this.detectTransactionType(tx),
            from: tx.from,
            to: tx.to,
            value: tx.value,
            timestamp: tx.timestamp,
            status: tx.blockNumber ? 'success' : 'pending',
            gasUsed: tx.gasUsed,
            blockNumber: tx.blockNumber
        };
    },

    // 检测交易类型
    detectTransactionType(tx) {
        // 根据交易数据判断类型
        // 这里需要根据实际合约接口来判断
        return 'unknown';
    },

    // 加载模拟交易数据
    loadMockTransactions() {
        const types = ['buy', 'sell', 'reward', 'stake', 'unstake'];
        const statuses = ['success', 'success', 'success', 'success', 'pending'];
        const dramas = ['都市霸总', '穿越时空', '悬疑追凶', '古装宫廷'];
        
        const transactions = [];
        const count = 25;

        for (let i = 0; i < count; i++) {
            const type = types[Math.floor(Math.random() * types.length)];
            const amount = (Math.random() * 50000 + 1000).toFixed(2);
            const tokens = Math.floor(Math.random() * 5000) + 100;
            const timestamp = Date.now() - (Math.random() * 30 * 24 * 60 * 60 * 1000);
            const status = statuses[Math.floor(Math.random() * statuses.length)];
            const drama = dramas[Math.floor(Math.random() * dramas.length)];

            transactions.push({
                id: `0x${Math.random().toString(16).substr(2, 64)}`,
                type: type,
                drama: drama,
                amount: parseFloat(amount),
                tokens: tokens,
                price: (amount / tokens).toFixed(2),
                timestamp: timestamp,
                status: status,
                gasUsed: Math.floor(Math.random() * 100000) + 50000,
                gasPrice: (Math.random() * 50 + 10).toFixed(2),
                blockNumber: Math.floor(Math.random() * 1000000) + 40000000,
                from: `0x${Math.random().toString(16).substr(2, 40)}`,
                to: `0x${Math.random().toString(16).substr(2, 40)}`
            });
        }

        // 按时间倒序排列
        return transactions.sort((a, b) => b.timestamp - a.timestamp);
    },

    // 筛选交易
    filterBy(type) {
        this.currentFilter = type;
        this.page = 1;

        if (type === 'all') {
            this.filteredTransactions = [...this.transactions];
        } else {
            this.filteredTransactions = this.transactions.filter(tx => tx.type === type);
        }

        this.updateStats();
        this.renderTransactions();
    },

    // 更新统计数据
    updateStats() {
        const total = this.transactions.length;
        const totalAmount = this.transactions.reduce((sum, tx) => sum + tx.amount, 0);
        const success = this.transactions.filter(tx => tx.status === 'success').length;
        const pending = this.transactions.filter(tx => tx.status === 'pending').length;

        document.getElementById('total-tx-count').textContent = total;
        document.getElementById('total-tx-amount').textContent = `¥${totalAmount.toLocaleString('zh-CN')}`;
        document.getElementById('success-tx-count').textContent = success;
        document.getElementById('pending-tx-count').textContent = pending;
    },

    // 渲染交易列表
    renderTransactions() {
        const txList = document.getElementById('tx-list');
        const displayTx = this.filteredTransactions.slice(0, this.page * this.displayCount);

        if (displayTx.length === 0) {
            txList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-receipt"></i>
                    <h3>暂无交易记录</h3>
                    <p>您还没有进行任何交易</p>
                </div>
            `;
            document.getElementById('load-more-btn').style.display = 'none';
            return;
        }

        let html = '';
        displayTx.forEach(tx => {
            html += this.renderTransactionCard(tx);
        });

        txList.innerHTML = html;

        // 显示/隐藏加载更多按钮
        if (displayTx.length >= this.filteredTransactions.length) {
            document.getElementById('load-more-btn').style.display = 'none';
        } else {
            document.getElementById('load-more-btn').style.display = 'block';
        }
    },

    // 渲染单个交易卡片
    renderTransactionCard(tx) {
        const typeConfig = this.getTypeConfig(tx.type);
        const shortHash = `${tx.id.slice(0, 10)}...${tx.id.slice(-8)}`;
        const date = new Date(tx.timestamp).toLocaleString('zh-CN');

        return `
            <div class="tx-card">
                <div class="tx-card-header">
                    <div class="tx-type">
                        <div class="tx-icon ${tx.type}">
                            <i class="${typeConfig.icon}"></i>
                        </div>
                        <div class="tx-info">
                            <h3>${typeConfig.title} - ${tx.drama}</h3>
                            <p>${date}</p>
                        </div>
                    </div>
                    <div class="tx-status ${tx.status}">
                        <i class="fas ${tx.status === 'success' ? 'fa-check-circle' : 'fa-clock'}"></i>
                        ${tx.status === 'success' ? '成功' : '处理中'}
                    </div>
                </div>

                <div class="tx-details">
                    <div class="tx-detail-item">
                        <div class="tx-detail-label">交易金额</div>
                        <div class="tx-detail-value ${tx.type === 'sell' || tx.type === 'reward' ? 'positive' : 'negative'}">
                            ${tx.type === 'sell' || tx.type === 'reward' ? '+' : '-'}¥${tx.amount.toLocaleString('zh-CN')}
                        </div>
                    </div>

                    <div class="tx-detail-item">
                        <div class="tx-detail-label">代币数量</div>
                        <div class="tx-detail-value">${tx.tokens.toLocaleString('zh-CN')}</div>
                    </div>

                    <div class="tx-detail-item">
                        <div class="tx-detail-label">代币单价</div>
                        <div class="tx-detail-value">¥${tx.price}</div>
                    </div>

                    <div class="tx-detail-item">
                        <div class="tx-detail-label">Gas 费用</div>
                        <div class="tx-detail-value">${tx.gasPrice} Gwei</div>
                    </div>

                    <div class="tx-detail-item">
                        <div class="tx-detail-label">区块高度</div>
                        <div class="tx-detail-value">${tx.blockNumber?.toLocaleString() || '-'}</div>
                    </div>

                    <div class="tx-detail-item">
                        <div class="tx-detail-label">交易哈希</div>
                        <div class="tx-hash">
                            <a href="#" class="tx-hash-link" onclick="viewOnExplorer('${tx.id}'); return false;">
                                ${shortHash}
                            </a>
                            <button class="copy-btn" onclick="copyToClipboard('${tx.id}')">
                                <i class="fas fa-copy"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

    // 获取交易类型配置
    getTypeConfig(type) {
        const configs = {
            buy: {
                title: '购买代币',
                icon: 'fas fa-shopping-cart'
            },
            sell: {
                title: '出售代币',
                icon: 'fas fa-hand-holding-usd'
            },
            reward: {
                title: '领取收益',
                icon: 'fas fa-gift'
            },
            stake: {
                title: '质押代币',
                icon: 'fas fa-lock'
            },
            unstake: {
                title: '解除质押',
                icon: 'fas fa-unlock'
            }
        };

        return configs[type] || {
            title: '未知交易',
            icon: 'fas fa-question-circle'
        };
    },

    // 加载更多
    loadMore() {
        this.page++;
        this.renderTransactions();
    }
};

// 筛选交易
function filterTransactions(type) {
    document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
    event.target.closest('.filter-btn').classList.add('active');
    
    TransactionManager.filterBy(type);
}

// 加载更多交易
function loadMoreTransactions() {
    TransactionManager.loadMore();
}

// 在区块浏览器中查看
function viewOnExplorer(txHash) {
    // ⚠️ 需要根据实际网络配置区块浏览器链接
    const explorerUrls = {
        1: 'https://etherscan.io/tx/',
        137: 'https://polygonscan.com/tx/',
        80001: 'https://mumbai.polygonscan.com/tx/'
    };

    // 默认使用 Polygon
    const url = explorerUrls[137] + txHash;
    window.open(url, '_blank');
    
    showNotification('在浏览器中打开交易详情', 'info');
}

// 复制到剪贴板
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showNotification('交易哈希已复制', 'success');
    }).catch(err => {
        console.error('❌ 复制失败:', err);
        showNotification('复制失败', 'error');
    });
}

// 页面加载时初始化
window.addEventListener('DOMContentLoaded', () => {
    TransactionManager.init();
});
