/**
 * SUK代币支付系统
 * 支持用户使用SUK代币购买和观看剧集
 * 
 * @version 1.0.0
 * @author SUK Protocol
 */

class SUKPayment {
    constructor(options) {
        this.sukTokenAddress = options.sukTokenAddress;
        this.dramaContractAddress = options.dramaContractAddress;
        this.provider = null;
        this.signer = null;
        this.sukToken = null;
        this.dramaContract = null;
        this.userAddress = null;
        
        // 回调函数
        this.onPaymentSuccess = options.onPaymentSuccess || (() => {});
        this.onPaymentFailed = options.onPaymentFailed || (() => {});
        this.onBalanceUpdate = options.onBalanceUpdate || (() => {});
        
        this.init();
    }
    
    /**
     * 初始化
     */
    async init() {
        if (typeof window.ethereum === 'undefined') {
            throw new Error('请安装MetaMask钱包');
        }
        
        this.provider = new ethers.providers.Web3Provider(window.ethereum);
        this.signer = this.provider.getSigner();
        this.userAddress = await this.signer.getAddress();
        
        // ERC20 ABI (简化版)
        const ERC20_ABI = [
            "function balanceOf(address owner) view returns (uint256)",
            "function decimals() view returns (uint8)",
            "function approve(address spender, uint256 amount) returns (bool)",
            "function allowance(address owner, address spender) view returns (uint256)",
            "function transfer(address to, uint256 amount) returns (bool)"
        ];
        
        this.sukToken = new ethers.Contract(
            this.sukTokenAddress,
            ERC20_ABI,
            this.signer
        );
        
        console.log('✅ SUK支付系统初始化成功');
    }
    
    /**
     * 获取SUK余额
     */
    async getBalance() {
        try {
            const balance = await this.sukToken.balanceOf(this.userAddress);
            const decimals = await this.sukToken.decimals();
            const formatted = ethers.utils.formatUnits(balance, decimals);
            
            this.onBalanceUpdate(parseFloat(formatted));
            return parseFloat(formatted);
        } catch (error) {
            console.error('获取余额失败:', error);
            return 0;
        }
    }
    
    /**
     * 购买剧集 (整部)
     * @param {string} dramaId 剧集ID
     * @param {number} price 价格 (SUK)
     */
    async purchaseDrama(dramaId, price) {
        try {
            console.log(`购买剧集 ${dramaId}, 价格: ${price} SUK`);
            
            // 1. 检查余额
            const balance = await this.getBalance();
            if (balance < price) {
                throw new Error(`余额不足。需要: ${price} SUK, 当前: ${balance} SUK`);
            }
            
            // 2. 授权合约使用SUK
            const amount = ethers.utils.parseEther(price.toString());
            
            console.log('授权合约使用SUK...');
            const approveTx = await this.sukToken.approve(
                this.dramaContractAddress,
                amount
            );
            await approveTx.wait();
            console.log('✅ 授权成功');
            
            // 3. 调用购买接口（这里使用API，实际可能是智能合约）
            const response = await fetch('/api/dramas/purchase', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    dramaId: dramaId,
                    userAddress: this.userAddress,
                    paymentToken: 'SUK',
                    amount: price
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                // 4. 执行转账
                const transferTx = await this.sukToken.transfer(
                    result.recipientAddress || this.dramaContractAddress,
                    amount
                );
                
                console.log('等待交易确认...');
                const receipt = await transferTx.wait();
                console.log('✅ 支付成功:', receipt.transactionHash);
                
                // 5. 更新余额
                await this.getBalance();
                
                // 6. 触发成功回调
                this.onPaymentSuccess({
                    dramaId,
                    price,
                    txHash: receipt.transactionHash
                });
                
                return {
                    success: true,
                    txHash: receipt.transactionHash
                };
            } else {
                throw new Error(result.error || '购买失败');
            }
            
        } catch (error) {
            console.error('购买失败:', error);
            this.onPaymentFailed({
                dramaId,
                error: error.message
            });
            throw error;
        }
    }
    
    /**
     * X402按时间点计费 - 预充值
     * @param {number} amount 充值金额 (SUK)
     */
    async depositForX402(amount) {
        try {
            console.log(`充值 ${amount} SUK 用于X402计费`);
            
            // 1. 检查余额
            const balance = await this.getBalance();
            if (balance < amount) {
                throw new Error(`余额不足。需要: ${amount} SUK, 当前: ${balance} SUK`);
            }
            
            // 2. 授权
            const amountWei = ethers.utils.parseEther(amount.toString());
            const approveTx = await this.sukToken.approve(
                this.dramaContractAddress,
                amountWei
            );
            await approveTx.wait();
            
            // 3. 调用充值API
            const response = await fetch('/api/x402/deposit', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    userAddress: this.userAddress,
                    amount: amount
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                // 4. 执行转账
                const transferTx = await this.sukToken.transfer(
                    result.depositAddress,
                    amountWei
                );
                
                const receipt = await transferTx.wait();
                console.log('✅ 充值成功:', receipt.transactionHash);
                
                await this.getBalance();
                
                return {
                    success: true,
                    txHash: receipt.transactionHash,
                    balance: result.newBalance
                };
            } else {
                throw new Error(result.error || '充值失败');
            }
            
        } catch (error) {
            console.error('充值失败:', error);
            throw error;
        }
    }
    
    /**
     * 检查是否已购买剧集
     * @param {string} dramaId 剧集ID
     */
    async checkPurchaseStatus(dramaId) {
        try {
            const response = await fetch(
                `/api/dramas/${dramaId}/purchase-status?address=${this.userAddress}`
            );
            const result = await response.json();
            return result.purchased || false;
        } catch (error) {
            console.error('检查购买状态失败:', error);
            return false;
        }
    }
    
    /**
     * 获取X402账户余额
     */
    async getX402Balance() {
        try {
            const response = await fetch(
                `/api/x402/balance?address=${this.userAddress}`
            );
            const result = await response.json();
            return result.balance || 0;
        } catch (error) {
            console.error('获取X402余额失败:', error);
            return 0;
        }
    }
}

// 导出
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SUKPayment;
}

// ==================== 使用示例 ====================

/**
 * 示例1: 购买整部剧集
 */
async function example1_PurchaseDrama() {
    const payment = new SUKPayment({
        sukTokenAddress: '0x...',
        dramaContractAddress: '0x...',
        
        onPaymentSuccess: (data) => {
            alert(`支付成功！剧集ID: ${data.dramaId}`);
            // 跳转到播放页面
            window.location.href = `/drama-player.html?id=${data.dramaId}`;
        },
        
        onPaymentFailed: (data) => {
            alert(`支付失败: ${data.error}`);
        },
        
        onBalanceUpdate: (balance) => {
            document.getElementById('suk-balance').textContent = 
                balance.toFixed(2) + ' SUK';
        }
    });
    
    // 购买剧集
    await payment.purchaseDrama('1', 125); // 125 SUK
}

/**
 * 示例2: X402按时间点计费
 */
async function example2_X402Payment() {
    const payment = new SUKPayment({
        sukTokenAddress: '0x...',
        dramaContractAddress: '0x...'
    });
    
    // 充值100 SUK用于观看
    await payment.depositForX402(100);
    
    // 初始化X402播放器
    const player = new X402Player({
        videoElement: document.getElementById('video'),
        dramaId: '1',
        userId: payment.userAddress,
        paymentToken: 'SUK'
    });
}

/**
 * 示例3: 检查购买状态并播放
 */
async function example3_CheckAndPlay(dramaId) {
    const payment = new SUKPayment({
        sukTokenAddress: '0x...',
        dramaContractAddress: '0x...'
    });
    
    // 检查是否已购买
    const purchased = await payment.checkPurchaseStatus(dramaId);
    
    if (purchased) {
        // 已购买，直接播放
        playDrama(dramaId);
    } else {
        // 未购买，显示购买按钮
        showPurchaseDialog(dramaId);
    }
}

/**
 * 示例4: 完整的购买流程UI
 */
function example4_CompleteUI() {
    const html = `
        <div class="purchase-dialog">
            <h2>购买剧集</h2>
            <p class="drama-title" id="drama-title">--</p>
            <p class="drama-price" id="drama-price">--</p>
            
            <div class="balance-info">
                <span>您的SUK余额:</span>
                <span id="suk-balance">--</span>
            </div>
            
            <button class="btn-purchase" onclick="handlePurchase()">
                使用SUK代币购买
            </button>
            
            <p class="tip">
                没有SUK代币？<a href="suk-airdrop.html">领取空投</a>
            </p>
        </div>
    `;
    
    // 处理购买
    window.handlePurchase = async function() {
        const dramaId = getCurrentDramaId();
        const price = getCurrentDramaPrice();
        
        try {
            const payment = new SUKPayment({
                sukTokenAddress: '0x...',
                dramaContractAddress: '0x...',
                onPaymentSuccess: (data) => {
                    alert('购买成功！即将开始播放...');
                    window.location.reload();
                }
            });
            
            await payment.purchaseDrama(dramaId, price);
        } catch (error) {
            alert('购买失败: ' + error.message);
        }
    };
}
