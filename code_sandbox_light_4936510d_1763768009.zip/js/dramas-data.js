/**
 * SUK Protocol - 剧集数据
 * 包含所有短剧的详细信息
 * 代币计价: 1 SUK = $0.01 USD
 */

const dramasData = {
    // 剧集1: 霸总的心尖宠
    "1": {
        id: 1,
        title: "霸总的心尖宠",
        englishTitle: "CEO's Beloved",
        genre: "现代浪漫",
        tags: ["都市", "爱情", "商战", "甜宠"],
        rating: 9.2,
        
        // 视频信息
        videoUrl: "https://www.genspark.ai/api/files/s/KgsCMF4L",
        coverImage: "https://www.genspark.ai/api/files/s/7gmSkmG7?cache_control=3600",
        
        // 剧集基本信息
        description: "商业精英与平凡女孩的浪漫邂逅，讲述冷酷霸总如何一步步沦陷于真爱的温暖故事。精彩的商战情节与甜蜜的爱情故事完美交织，打造现代都市爱情新标杆。",
        episodes: 80,
        duration: "每集5分钟",
        releaseDate: "2024-09",
        status: "连载中",
        
        // 创作团队
        director: "张艺凡",
        screenwriter: "李雪莹",
        cast: ["陈星宇", "林晓雪", "王建国"],
        production: "星光影视",
        
        // 代币经济数据 (SUK)
        tokenPrice: 125, // SUK
        tokenPriceUSD: 1.25, // USD
        initialPrice: 100, // SUK
        totalSupply: 10000000, // 1000万 SUK
        circulatingSupply: 6800000, // 680万 SUK
        tvl: 85000000, // 8500万 SUK
        tvlUSD: 850000, // $850,000 USD
        
        // 收益数据
        apy: 15.8,
        monthlyReturn: 1.32,
        totalRevenue: 12500000, // 1250万 SUK
        revenuePerToken: 1.84, // SUK
        
        // 播放数据
        views: 580000000, // 5.8亿
        likes: 45200000, // 4520万
        comments: 3680000, // 368万
        shares: 12500000, // 1250万
        
        // 收益来源
        revenueStreams: [
            { source: "平台分成", percentage: 45, amount: 5625000 },
            { source: "广告收入", percentage: 30, amount: 3750000 },
            { source: "付费观看", percentage: 15, amount: 1875000 },
            { source: "衍生授权", percentage: 10, amount: 1250000 }
        ],
        
        // 持有者分布
        holders: [
            { rank: 1, address: "0x1a2b...3c4d", percentage: 12.5, amount: 1250000 },
            { rank: 2, address: "0x5e6f...7g8h", percentage: 8.3, amount: 830000 },
            { rank: 3, address: "0x9i0j...1k2l", percentage: 6.2, amount: 620000 },
            { rank: 4, address: "0x3m4n...5o6p", percentage: 4.8, amount: 480000 },
            { rank: 5, address: "0x7q8r...9s0t", percentage: 3.7, amount: 370000 }
        ],
        
        // 历史收益记录
        earningsHistory: [
            { date: "2024-11", amount: 385000, perToken: 0.0385, status: "pending" },
            { date: "2024-10", amount: 420000, perToken: 0.042, status: "claimed" },
            { date: "2024-09", amount: 395000, perToken: 0.0395, status: "claimed" }
        ],
        
        // 价格历史 (近30天)
        priceHistory: [
            { date: "2024-10-15", price: 100 },
            { date: "2024-10-22", price: 105 },
            { date: "2024-10-29", price: 110 },
            { date: "2024-11-05", price: 115 },
            { date: "2024-11-12", price: 120 },
            { date: "2024-11-15", price: 125 }
        ]
    },
    
    // 剧集2: 暗夜复仇者
    "2": {
        id: 2,
        title: "暗夜复仇者",
        englishTitle: "Night Avenger",
        genre: "悬疑复仇",
        tags: ["悬疑", "复仇", "烧脑", "惊悚"],
        rating: 9.5,
        
        // 视频信息
        videoUrl: "https://www.genspark.ai/api/files/s/968B7Jqd",
        coverImage: "https://www.genspark.ai/api/files/s/o4Dxy1BJ?cache_control=3600",
        
        // 剧集基本信息
        description: "一个神秘女子为家族复仇的惊心动魄故事。层层反转的剧情，精心设计的谜团，带你进入一个充满阴谋与真相的世界。每一集都有意想不到的惊喜。",
        episodes: 60,
        duration: "每集6分钟",
        releaseDate: "2024-10",
        status: "完结",
        
        // 创作团队
        director: "赵明轩",
        screenwriter: "王思远",
        cast: ["江晓月", "孙浩然", "李慧敏"],
        production: "暗影传媒",
        
        // 代币经济数据 (SUK)
        tokenPrice: 98, // SUK
        tokenPriceUSD: 0.98, // USD
        initialPrice: 80, // SUK
        totalSupply: 8000000, // 800万 SUK
        circulatingSupply: 6320000, // 632万 SUK
        tvl: 62000000, // 6200万 SUK
        tvlUSD: 620000, // $620,000 USD
        
        // 收益数据
        apy: 18.5,
        monthlyReturn: 1.54,
        totalRevenue: 9800000, // 980万 SUK
        revenuePerToken: 1.55, // SUK
        
        // 播放数据
        views: 420000000, // 4.2亿
        likes: 38500000, // 3850万
        comments: 4200000, // 420万
        shares: 8900000, // 890万
        
        // 收益来源
        revenueStreams: [
            { source: "平台分成", percentage: 40, amount: 3920000 },
            { source: "广告收入", percentage: 35, amount: 3430000 },
            { source: "付费观看", percentage: 18, amount: 1764000 },
            { source: "衍生授权", percentage: 7, amount: 686000 }
        ],
        
        // 持有者分布
        holders: [
            { rank: 1, address: "0xa1b2...c3d4", percentage: 15.2, amount: 960640 },
            { rank: 2, address: "0xe5f6...g7h8", percentage: 10.8, amount: 682560 },
            { rank: 3, address: "0xi9j0...k1l2", percentage: 7.5, amount: 474000 },
            { rank: 4, address: "0xm3n4...o5p6", percentage: 5.6, amount: 353920 },
            { rank: 5, address: "0xq7r8...s9t0", percentage: 4.2, amount: 265440 }
        ],
        
        // 历史收益记录
        earningsHistory: [
            { date: "2024-11", amount: 295000, perToken: 0.0467, status: "pending" },
            { date: "2024-10", amount: 325000, perToken: 0.0514, status: "claimed" },
            { date: "2024-09", amount: 280000, perToken: 0.0443, status: "claimed" }
        ],
        
        // 价格历史 (近30天)
        priceHistory: [
            { date: "2024-10-15", price: 80 },
            { date: "2024-10-22", price: 84 },
            { date: "2024-10-29", price: 88 },
            { date: "2024-11-05", price: 92 },
            { date: "2024-11-12", price: 95 },
            { date: "2024-11-15", price: 98 }
        ]
    },
    
    // 剧集3: 校园时光机
    "3": {
        id: 3,
        title: "校园时光机",
        englishTitle: "Campus Time Machine",
        genre: "青春校园",
        tags: ["校园", "青春", "爱情", "治愈"],
        rating: 9.0,
        
        // 视频信息
        videoUrl: "https://www.genspark.ai/api/files/s/rp4UdsdX",
        coverImage: "https://www.genspark.ai/api/files/s/48U4HBgx?cache_control=3600",
        
        // 剧集基本信息
        description: "回到青春校园时光，重温那些纯真美好的瞬间。暗恋、友情、梦想，每一个青春元素都被温柔诠释。治愈系甜宠剧，带你找回最初的心动。",
        episodes: 50,
        duration: "每集5分钟",
        releaseDate: "2024-11",
        status: "连载中",
        
        // 创作团队
        director: "周雨晴",
        screenwriter: "陈思涵",
        cast: ["刘诗诗", "张若昀", "赵丽颖"],
        production: "青春映画",
        
        // 代币经济数据 (SUK)
        tokenPrice: 76, // SUK
        tokenPriceUSD: 0.76, // USD
        initialPrice: 65, // SUK
        totalSupply: 6000000, // 600万 SUK
        circulatingSupply: 4800000, // 480万 SUK
        tvl: 48000000, // 4800万 SUK
        tvlUSD: 480000, // $480,000 USD
        
        // 收益数据
        apy: 14.2,
        monthlyReturn: 1.18,
        totalRevenue: 7200000, // 720万 SUK
        revenuePerToken: 1.5, // SUK
        
        // 播放数据
        views: 350000000, // 3.5亿
        likes: 32000000, // 3200万
        comments: 2800000, // 280万
        shares: 6500000, // 650万
        
        // 收益来源
        revenueStreams: [
            { source: "平台分成", percentage: 50, amount: 3600000 },
            { source: "广告收入", percentage: 25, amount: 1800000 },
            { source: "付费观看", percentage: 15, amount: 1080000 },
            { source: "衍生授权", percentage: 10, amount: 720000 }
        ],
        
        // 持有者分布
        holders: [
            { rank: 1, address: "0x1u2v...3w4x", percentage: 11.5, amount: 552000 },
            { rank: 2, address: "0x5y6z...7a8b", percentage: 9.2, amount: 441600 },
            { rank: 3, address: "0x9c0d...1e2f", percentage: 7.8, amount: 374400 },
            { rank: 4, address: "0x3g4h...5i6j", percentage: 6.3, amount: 302400 },
            { rank: 5, address: "0x7k8l...9m0n", percentage: 5.1, amount: 244800 }
        ],
        
        // 历史收益记录
        earningsHistory: [
            { date: "2024-11", amount: 215000, perToken: 0.0448, status: "pending" },
            { date: "2024-10", amount: 190000, perToken: 0.0396, status: "claimed" }
        ],
        
        // 价格历史 (近30天)
        priceHistory: [
            { date: "2024-10-15", price: 65 },
            { date: "2024-10-22", price: 68 },
            { date: "2024-10-29", price: 70 },
            { date: "2024-11-05", price: 72 },
            { date: "2024-11-12", price: 74 },
            { date: "2024-11-15", price: 76 }
        ]
    }
};

// 获取剧集数据
function getDramaData(id) {
    return dramasData[id] || null;
}

// 获取所有剧集列表
function getAllDramas() {
    return Object.values(dramasData);
}

// 计算总TVL (SUK)
function getTotalTVL() {
    return getAllDramas().reduce((sum, drama) => sum + drama.tvl, 0);
}

// 计算平均APY
function getAverageAPY() {
    const dramas = getAllDramas();
    const totalAPY = dramas.reduce((sum, drama) => sum + drama.apy, 0);
    return (totalAPY / dramas.length).toFixed(1);
}

// 导出数据
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { dramasData, getDramaData, getAllDramas, getTotalTVL, getAverageAPY };
}
