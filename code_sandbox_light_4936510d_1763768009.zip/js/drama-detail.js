// ==================== 短剧详情页交互逻辑 ====================

document.addEventListener('DOMContentLoaded', function() {
    
    // ==================== 价格走势图表 ====================
    const priceCtx = document.getElementById('priceChart');
    if (priceCtx) {
        // 生成模拟价格数据
        const generatePriceData = (days) => {
            const data = [];
            const labels = [];
            let price = 11.8;
            
            for (let i = days; i >= 0; i--) {
                const date = new Date();
                date.setDate(date.getDate() - i);
                labels.push(date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' }));
                
                // 随机波动
                price += (Math.random() - 0.45) * 0.3;
                price = Math.max(10, Math.min(15, price)); // 限制范围
                data.push(price.toFixed(2));
            }
            
            return { labels, data };
        };
        
        const priceData = generatePriceData(30);
        
        const priceChart = new Chart(priceCtx, {
            type: 'line',
            data: {
                labels: priceData.labels,
                datasets: [{
                    label: '代币价格 (¥)',
                    data: priceData.data,
                    borderColor: 'rgb(139, 92, 246)',
                    backgroundColor: 'rgba(139, 92, 246, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0,
                    pointHoverRadius: 6,
                    pointHoverBackgroundColor: 'rgb(139, 92, 246)',
                    pointHoverBorderColor: '#fff',
                    pointHoverBorderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: 'rgba(10, 10, 15, 0.9)',
                        titleColor: '#fff',
                        bodyColor: '#b8b8d1',
                        borderColor: 'rgba(139, 92, 246, 0.5)',
                        borderWidth: 1,
                        padding: 12,
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                return '¥' + context.parsed.y;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(139, 92, 246, 0.1)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#7a7a9e',
                            maxRotation: 0,
                            autoSkip: true,
                            maxTicksLimit: 8
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(139, 92, 246, 0.1)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#7a7a9e',
                            callback: function(value) {
                                return '¥' + value;
                            }
                        }
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                }
            }
        });
        
        // 时间范围切换
        const timeButtons = document.querySelectorAll('.time-range button');
        timeButtons.forEach(button => {
            button.addEventListener('click', function() {
                timeButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
                
                const range = this.textContent;
                let days;
                switch(range) {
                    case '24H': days = 1; break;
                    case '7D': days = 7; break;
                    case '30D': days = 30; break;
                    case '全部': days = 90; break;
                    default: days = 30;
                }
                
                const newData = generatePriceData(days);
                priceChart.data.labels = newData.labels;
                priceChart.data.datasets[0].data = newData.data;
                priceChart.update();
            });
        });
    }
    
    // ==================== 收益分配饼图 ====================
    const revenueCtx = document.getElementById('revenueChart');
    if (revenueCtx) {
        const revenueChart = new Chart(revenueCtx, {
            type: 'doughnut',
            data: {
                labels: ['平台播放', '广告植入', '授权使用', '海外版权'],
                datasets: [{
                    data: [42, 25, 20, 13],
                    backgroundColor: [
                        'rgb(139, 92, 246)',
                        'rgb(255, 107, 157)',
                        'rgb(255, 165, 0)',
                        'rgb(255, 215, 0)'
                    ],
                    borderWidth: 0,
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#b8b8d1',
                            padding: 20,
                            font: {
                                size: 12,
                                family: "'Inter', sans-serif"
                            },
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(10, 10, 15, 0.9)',
                        titleColor: '#fff',
                        bodyColor: '#b8b8d1',
                        borderColor: 'rgba(139, 92, 246, 0.5)',
                        borderWidth: 1,
                        padding: 12,
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed || 0;
                                return label + ': ' + value + '%';
                            }
                        }
                    }
                },
                cutout: '65%'
            }
        });
    }
    
    // ==================== 持有者分布图表 ====================
    const distributionCtx = document.getElementById('distributionChart');
    if (distributionCtx) {
        const distributionChart = new Chart(distributionCtx, {
            type: 'bar',
            data: {
                labels: ['0-100', '100-500', '500-1K', '1K-5K', '5K-10K', '10K+'],
                datasets: [{
                    label: '持有人数',
                    data: [385, 412, 268, 156, 45, 19],
                    backgroundColor: 'rgba(139, 92, 246, 0.8)',
                    borderColor: 'rgb(139, 92, 246)',
                    borderWidth: 2,
                    borderRadius: 8,
                    hoverBackgroundColor: 'rgb(139, 92, 246)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(10, 10, 15, 0.9)',
                        titleColor: '#fff',
                        bodyColor: '#b8b8d1',
                        borderColor: 'rgba(139, 92, 246, 0.5)',
                        borderWidth: 1,
                        padding: 12,
                        callbacks: {
                            title: function(context) {
                                return '持有量: ' + context[0].label + ' 代币';
                            },
                            label: function(context) {
                                return '人数: ' + context.parsed.y;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#7a7a9e',
                            font: {
                                size: 11
                            }
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(139, 92, 246, 0.1)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#7a7a9e',
                            stepSize: 100
                        },
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // ==================== 投资按钮交互 ====================
    const investButton = document.querySelector('.btn-invest-large');
    if (investButton) {
        investButton.addEventListener('click', function() {
            // 创建投资模态框
            showInvestmentModal();
        });
    }
    
    // ==================== 关注按钮交互 ====================
    const watchlistButton = document.querySelector('.btn-add-watchlist');
    if (watchlistButton) {
        let isWatched = false;
        
        watchlistButton.addEventListener('click', function() {
            isWatched = !isWatched;
            
            if (isWatched) {
                this.innerHTML = '<i class="fas fa-check"></i> 已关注';
                this.style.background = 'rgba(139, 92, 246, 0.2)';
                this.style.borderColor = 'var(--color-primary)';
                showNotification('已添加到关注列表', 'success');
            } else {
                this.innerHTML = '<i class="fas fa-star"></i> 加入关注';
                this.style.background = 'transparent';
                this.style.borderColor = 'rgba(139, 92, 246, 0.5)';
                showNotification('已取消关注', 'info');
            }
        });
    }
    
    // ==================== 播放按钮 ====================
    const playButton = document.querySelector('.play-button');
    if (playButton) {
        playButton.addEventListener('click', function(e) {
            e.stopPropagation();
            showVideoPlayer();
        });
    }
    
    // ==================== 相关推荐卡片点击 ====================
    const relatedCards = document.querySelectorAll('.related-card');
    relatedCards.forEach(card => {
        card.addEventListener('click', function() {
            const dramaTitle = this.querySelector('h4').textContent;
            showNotification(`即将跳转到《${dramaTitle}》详情页...`, 'info');
            setTimeout(() => {
                // window.location.href = 'drama-detail.html?id=xxx';
            }, 1000);
        });
    });
    
});

// ==================== 投资模态框 ====================
function showInvestmentModal() {
    const modal = document.createElement('div');
    modal.className = 'investment-modal';
    modal.innerHTML = `
        <div class="modal-overlay"></div>
        <div class="modal-content">
            <div class="modal-header">
                <h3>投资《都市霸总》</h3>
                <button class="modal-close"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <div class="investment-form">
                    <div class="form-group">
                        <label>投资金额 (¥)</label>
                        <input type="number" id="investAmount" placeholder="输入投资金额" min="100" value="1000">
                        <div class="quick-amounts">
                            <button class="quick-btn" data-amount="500">¥500</button>
                            <button class="quick-btn" data-amount="1000">¥1,000</button>
                            <button class="quick-btn" data-amount="5000">¥5,000</button>
                            <button class="quick-btn" data-amount="10000">¥10,000</button>
                        </div>
                    </div>
                    <div class="investment-summary">
                        <div class="summary-row">
                            <span>代币价格</span>
                            <span>¥12.50</span>
                        </div>
                        <div class="summary-row">
                            <span>可获得代币</span>
                            <span id="tokenAmount">80</span>
                        </div>
                        <div class="summary-row">
                            <span>预期年收益</span>
                            <span class="highlight" id="expectedEarnings">¥85</span>
                        </div>
                        <div class="summary-row total">
                            <span>总计</span>
                            <span id="totalAmount">¥1,000</span>
                        </div>
                    </div>
                    <button class="btn-confirm-investment">
                        <i class="fas fa-wallet"></i>
                        确认投资
                    </button>
                    <p class="disclaimer">
                        <i class="fas fa-info-circle"></i>
                        投资有风险，请谨慎决策。版权收益受市场因素影响，实际收益可能与预期不符。
                    </p>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // 添加模态框样式
    const style = document.createElement('style');
    style.textContent = `
        .investment-modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 10000;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease;
        }
        
        .modal-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(5px);
        }
        
        .modal-content {
            position: relative;
            background: var(--bg-card);
            border: 2px solid rgba(139, 92, 246, 0.3);
            border-radius: var(--radius-lg);
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(139, 92, 246, 0.3);
            animation: slideUp 0.3s ease;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 2rem;
            border-bottom: 1px solid rgba(139, 92, 246, 0.2);
        }
        
        .modal-header h3 {
            font-size: 1.5rem;
            margin: 0;
        }
        
        .modal-close {
            background: none;
            border: none;
            color: var(--text-secondary);
            font-size: 1.5rem;
            cursor: pointer;
            transition: var(--transition-fast);
        }
        
        .modal-close:hover {
            color: var(--text-primary);
        }
        
        .modal-body {
            padding: 2rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.75rem;
            font-weight: 600;
            color: var(--text-secondary);
        }
        
        .form-group input {
            width: 100%;
            padding: 1rem;
            background: rgba(139, 92, 246, 0.1);
            border: 1px solid rgba(139, 92, 246, 0.3);
            border-radius: var(--radius-sm);
            color: var(--text-primary);
            font-size: 1.2rem;
            font-weight: 600;
            transition: var(--transition-fast);
        }
        
        .form-group input:focus {
            outline: none;
            border-color: var(--color-primary);
            background: rgba(139, 92, 246, 0.15);
        }
        
        .quick-amounts {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 0.5rem;
            margin-top: 0.75rem;
        }
        
        .quick-btn {
            padding: 0.75rem;
            background: transparent;
            border: 1px solid rgba(139, 92, 246, 0.3);
            border-radius: var(--radius-sm);
            color: var(--text-secondary);
            font-size: 0.9rem;
            cursor: pointer;
            transition: var(--transition-fast);
        }
        
        .quick-btn:hover {
            background: rgba(139, 92, 246, 0.2);
            border-color: var(--color-primary);
            color: var(--text-primary);
        }
        
        .investment-summary {
            background: rgba(139, 92, 246, 0.05);
            border-radius: var(--radius-sm);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.75rem;
            color: var(--text-secondary);
        }
        
        .summary-row.total {
            margin-top: 0.75rem;
            padding-top: 0.75rem;
            border-top: 1px solid rgba(139, 92, 246, 0.2);
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--text-primary);
        }
        
        .summary-row .highlight {
            color: var(--success);
            font-weight: 600;
        }
        
        .btn-confirm-investment {
            width: 100%;
            padding: 1.25rem;
            background: linear-gradient(135deg, #FFD700 0%, #FFA500 25%, #FF6B9D 50%, #C471ED 75%, #8B5CF6 100%);
            border: none;
            border-radius: var(--radius-sm);
            color: white;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition-normal);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.75rem;
        }
        
        .btn-confirm-investment:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 32px rgba(139, 92, 246, 0.4);
        }
        
        .disclaimer {
            margin-top: 1rem;
            font-size: 0.85rem;
            color: var(--text-muted);
            text-align: center;
            line-height: 1.6;
        }
        
        .disclaimer i {
            margin-right: 0.5rem;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    `;
    document.head.appendChild(style);
    
    // 关闭模态框
    const closeModal = () => {
        modal.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => modal.remove(), 300);
    };
    
    modal.querySelector('.modal-close').addEventListener('click', closeModal);
    modal.querySelector('.modal-overlay').addEventListener('click', closeModal);
    
    // 快捷金额按钮
    const quickBtns = modal.querySelectorAll('.quick-btn');
    const amountInput = modal.querySelector('#investAmount');
    
    quickBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const amount = this.dataset.amount;
            amountInput.value = amount;
            updateInvestmentSummary(amount);
        });
    });
    
    // 输入金额变化
    amountInput.addEventListener('input', function() {
        updateInvestmentSummary(this.value);
    });
    
    // 更新投资摘要
    function updateInvestmentSummary(amount) {
        const tokenPrice = 12.50;
        const apy = 0.085;
        
        const tokens = Math.floor(amount / tokenPrice);
        const expectedEarnings = Math.floor(amount * apy);
        
        modal.querySelector('#tokenAmount').textContent = tokens;
        modal.querySelector('#expectedEarnings').textContent = '¥' + expectedEarnings;
        modal.querySelector('#totalAmount').textContent = '¥' + parseInt(amount).toLocaleString();
    }
    
    // 确认投资
    modal.querySelector('.btn-confirm-investment').addEventListener('click', function() {
        const amount = amountInput.value;
        if (amount < 100) {
            showNotification('最低投资金额为 ¥100', 'warning');
            return;
        }
        
        closeModal();
        showNotification('投资功能即将上线，敬请期待！', 'info');
    });
    
    // 初始化
    updateInvestmentSummary(1000);
}

// ==================== 视频播放器 ====================
function showVideoPlayer() {
    showNotification('视频播放器功能开发中...', 'info');
}

// ==================== 通知系统 ====================
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    notification.innerHTML = `
        <i class="fas ${icons[type]}"></i>
        <span>${message}</span>
    `;
    
    // 添加通知样式
    if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification {
                position: fixed;
                top: 100px;
                right: 2rem;
                padding: 1rem 1.5rem;
                background: var(--bg-card);
                border: 2px solid;
                border-radius: var(--radius-sm);
                color: var(--text-primary);
                display: flex;
                align-items: center;
                gap: 0.75rem;
                z-index: 10001;
                animation: slideInRight 0.3s ease, slideOutRight 0.3s ease 2.7s;
                box-shadow: var(--shadow-lg);
                min-width: 300px;
            }
            
            .notification-success { border-color: var(--success); }
            .notification-error { border-color: var(--error); }
            .notification-warning { border-color: var(--warning); }
            .notification-info { border-color: var(--color-primary); }
            
            .notification i {
                font-size: 1.2rem;
            }
            
            .notification-success i { color: var(--success); }
            .notification-error i { color: var(--error); }
            .notification-warning i { color: var(--warning); }
            .notification-info i { color: var(--color-primary); }
            
            @keyframes slideInRight {
                from {
                    opacity: 0;
                    transform: translateX(100%);
                }
                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }
            
            @keyframes slideOutRight {
                from {
                    opacity: 1;
                    transform: translateX(0);
                }
                to {
                    opacity: 0;
                    transform: translateX(100%);
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    setTimeout(() => notification.remove(), 3000);
}