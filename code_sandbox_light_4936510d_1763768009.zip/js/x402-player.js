/**
 * X402 Player SDK
 * 按播放时间点计费的革命性视频播放器
 * 
 * @version 1.0.0
 * @author SUK Protocol
 * @license MIT
 */

class X402Player {
    constructor(options) {
        // 必需参数
        this.videoElement = options.videoElement;
        this.dramaId = options.dramaId;
        this.userId = options.userId;
        this.apiEndpoint = options.apiEndpoint || '/api';
        
        // 计费配置
        this.billingInterval = options.billingInterval || 10; // 每10秒计费一次
        this.freeDuration = options.freeDuration || 180; // 前3分钟免费
        
        // 状态变量
        this.sessionId = null;
        this.isInitialized = false;
        this.isActive = false;
        
        // 计费数据
        this.pricePerSecond = 0;
        this.totalCost = 0;
        this.lastBilledTime = 0;
        this.currentTime = 0;
        this.userBalance = 0;
        
        // 剧集信息
        this.dramaInfo = null;
        this.totalDuration = 0;
        
        // 回调函数
        this.onBillingSuccess = options.onBillingSuccess || (() => {});
        this.onBalanceWarning = options.onBalanceWarning || (() => {});
        this.onInsufficientBalance = options.onInsufficientBalance || (() => {});
        this.onSessionStart = options.onSessionStart || (() => {});
        this.onSessionEnd = options.onSessionEnd || (() => {});
        this.onError = options.onError || ((error) => console.error('X402 Error:', error));
        
        // 防刷验证
        this.lastHeartbeat = Date.now();
        this.playStartTime = null;
        
        // 初始化
        this.init();
    }
    
    /**
     * 初始化播放器
     */
    async init() {
        try {
            // 1. 获取剧集信息
            await this.fetchDramaInfo();
            
            // 2. 计算每秒价格
            this.calculatePricing();
            
            // 3. 绑定事件监听
            this.bindEvents();
            
            // 4. 标记为已初始化
            this.isInitialized = true;
            
            console.log('✅ X402 Player initialized successfully');
        } catch (error) {
            this.onError(error);
            throw error;
        }
    }
    
    /**
     * 获取剧集信息
     */
    async fetchDramaInfo() {
        try {
            const response = await fetch(`${this.apiEndpoint}/dramas/${this.dramaId}`);
            const data = await response.json();
            
            if (data.success) {
                this.dramaInfo = data.data;
                this.totalDuration = this.dramaInfo.episodes * this.dramaInfo.episodeDuration || 
                                    (this.dramaInfo.episodes * 300); // 默认5分钟/集
                
                console.log('📺 Drama info loaded:', this.dramaInfo.title);
            } else {
                throw new Error('Failed to fetch drama info');
            }
        } catch (error) {
            console.error('❌ Error fetching drama info:', error);
            throw error;
        }
    }
    
    /**
     * 计算定价
     */
    calculatePricing() {
        const totalPrice = this.dramaInfo.tokenPrice || 125; // SUK
        this.pricePerSecond = totalPrice / this.totalDuration;
        
        console.log('💰 Pricing calculated:', {
            totalPrice: totalPrice + ' SUK',
            totalDuration: this.totalDuration + ' seconds',
            pricePerSecond: this.pricePerSecond.toFixed(8) + ' SUK/sec',
            pricePerMinute: (this.pricePerSecond * 60).toFixed(4) + ' SUK/min'
        });
    }
    
    /**
     * 绑定视频事件
     */
    bindEvents() {
        // 播放事件
        this.videoElement.addEventListener('play', () => this.handlePlay());
        
        // 暂停事件
        this.videoElement.addEventListener('pause', () => this.handlePause());
        
        // 时间更新事件（核心计费触发）
        this.videoElement.addEventListener('timeupdate', () => this.handleTimeUpdate());
        
        // 结束事件
        this.videoElement.addEventListener('ended', () => this.handleEnded());
        
        // 页面卸载事件
        window.addEventListener('beforeunload', () => this.handleBeforeUnload());
    }
    
    /**
     * 播放处理
     */
    async handlePlay() {
        console.log('▶️ Play started');
        
        if (!this.isActive) {
            // 开始新会话
            await this.startSession();
        }
        
        this.playStartTime = Date.now();
    }
    
    /**
     * 暂停处理
     */
    handlePause() {
        console.log('⏸️ Paused');
        
        // 暂停时立即处理计费
        if (this.isActive && this.currentTime > this.lastBilledTime) {
            this.processBilling();
        }
    }
    
    /**
     * 时间更新处理（核心计费逻辑）
     */
    handleTimeUpdate() {
        this.currentTime = Math.floor(this.videoElement.currentTime);
        
        // 检查是否需要计费
        if (this.shouldBill()) {
            this.processBilling();
        }
        
        // 更新心跳
        this.lastHeartbeat = Date.now();
    }
    
    /**
     * 结束处理
     */
    async handleEnded() {
        console.log('🏁 Playback ended');
        
        // 最后一次计费
        if (this.isActive) {
            await this.processBilling();
            await this.endSession('completed');
        }
    }
    
    /**
     * 页面卸载处理
     */
    handleBeforeUnload() {
        if (this.isActive) {
            // 同步结束会话（使用 sendBeacon）
            this.endSessionSync();
        }
    }
    
    /**
     * 判断是否需要计费
     */
    shouldBill() {
        // 条件1: 会话已激活
        if (!this.isActive) return false;
        
        // 条件2: 不在免费时长内
        if (this.currentTime < this.freeDuration) return false;
        
        // 条件3: 达到计费间隔
        const timeSinceLastBilling = this.currentTime - this.lastBilledTime;
        if (timeSinceLastBilling < this.billingInterval) return false;
        
        return true;
    }
    
    /**
     * 开始观看会话
     */
    async startSession() {
        try {
            const response = await fetch(`${this.apiEndpoint}/x402/session/start`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    userId: this.userId,
                    dramaId: this.dramaId,
                    startTime: Math.floor(this.videoElement.currentTime)
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.sessionId = data.data.sessionId;
                this.userBalance = data.data.userBalance;
                this.isActive = true;
                
                console.log('🎬 Session started:', this.sessionId);
                
                this.onSessionStart(data.data);
            } else {
                throw new Error(data.error || 'Failed to start session');
            }
        } catch (error) {
            console.error('❌ Error starting session:', error);
            this.onError(error);
        }
    }
    
    /**
     * 处理计费
     */
    async processBilling() {
        // 防止重复计费
        if (this.isBillingInProgress) return;
        this.isBillingInProgress = true;
        
        try {
            const startTime = this.lastBilledTime;
            const endTime = this.currentTime;
            const watchedDuration = endTime - startTime;
            
            // 计算费用
            const cost = this.calculateCost(startTime, endTime);
            
            // 验证播放速度（防刷）
            if (!this.validatePlaybackSpeed(watchedDuration)) {
                console.warn('⚠️ Suspicious playback speed detected');
                this.isBillingInProgress = false;
                return;
            }
            
            // 提交计费请求
            const response = await fetch(`${this.apiEndpoint}/x402/billing/charge`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    sessionId: this.sessionId,
                    dramaId: this.dramaId,
                    startTime: startTime,
                    endTime: endTime,
                    cost: cost,
                    clientTimestamp: Date.now()
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                // 更新状态
                this.lastBilledTime = endTime;
                this.totalCost = data.data.totalCost;
                this.userBalance = data.data.remainingBalance;
                
                console.log('✅ Billing success:', {
                    charged: data.data.charged + ' SUK',
                    totalCost: this.totalCost + ' SUK',
                    balance: this.userBalance + ' SUK'
                });
                
                // 触发回调
                this.onBillingSuccess({
                    charged: data.data.charged,
                    totalCost: this.totalCost,
                    balance: this.userBalance,
                    progress: data.data.progress
                });
                
                // 检查余额警告
                this.checkBalanceWarning();
                
            } else {
                throw new Error(data.error || 'Billing failed');
            }
            
        } catch (error) {
            console.error('❌ Billing error:', error);
            
            // 处理余额不足
            if (error.message.includes('Insufficient balance')) {
                this.handleInsufficientBalance();
            } else {
                this.onError(error);
            }
            
        } finally {
            this.isBillingInProgress = false;
        }
    }
    
    /**
     * 计算费用
     */
    calculateCost(startTime, endTime) {
        const duration = endTime - startTime;
        let cost = duration * this.pricePerSecond;
        
        // 应用折扣（如果有）
        const discount = this.getDiscount();
        if (discount < 1.0) {
            cost = cost * discount;
        }
        
        // 保留小数点后4位
        return Math.round(cost * 10000) / 10000;
    }
    
    /**
     * 获取折扣率
     */
    getDiscount() {
        // 基于观看进度的累计折扣
        const progress = this.currentTime / this.totalDuration;
        
        if (progress >= 0.8) return 0.85; // 85折
        if (progress >= 0.5) return 0.90; // 90折
        if (progress >= 0.2) return 0.95; // 95折
        
        return 1.0; // 原价
    }
    
    /**
     * 验证播放速度（防刷）
     */
    validatePlaybackSpeed(watchedDuration) {
        if (!this.playStartTime) return true;
        
        const realTimePassed = (Date.now() - this.playStartTime) / 1000;
        const speedRatio = realTimePassed / watchedDuration;
        
        // 允许0.8-1.2倍速播放
        return speedRatio >= 0.8 && speedRatio <= 1.2;
    }
    
    /**
     * 检查余额警告
     */
    checkBalanceWarning() {
        const remainingMinutes = this.userBalance / (this.pricePerSecond * 60);
        
        if (remainingMinutes < 5) {
            this.onBalanceWarning({
                level: 'critical',
                message: '余额不足5分钟观看时长，请充值',
                remainingMinutes: remainingMinutes
            });
        } else if (remainingMinutes < 15) {
            this.onBalanceWarning({
                level: 'warning',
                message: '余额较低，建议充值',
                remainingMinutes: remainingMinutes
            });
        }
    }
    
    /**
     * 处理余额不足
     */
    handleInsufficientBalance() {
        console.warn('⚠️ Insufficient balance');
        
        // 暂停播放
        this.videoElement.pause();
        
        // 触发回调
        this.onInsufficientBalance({
            totalCost: this.totalCost,
            balance: this.userBalance,
            deficit: this.totalCost - this.userBalance
        });
    }
    
    /**
     * 结束会话
     */
    async endSession(reason = 'user_stopped') {
        if (!this.isActive) return;
        
        try {
            const response = await fetch(`${this.apiEndpoint}/x402/session/end`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    sessionId: this.sessionId,
                    finalTime: this.currentTime,
                    reason: reason
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                console.log('🏁 Session ended:', data.data.sessionSummary);
                
                this.isActive = false;
                this.onSessionEnd(data.data);
            }
        } catch (error) {
            console.error('❌ Error ending session:', error);
        }
    }
    
    /**
     * 同步结束会话（用于页面卸载）
     */
    endSessionSync() {
        const data = JSON.stringify({
            sessionId: this.sessionId,
            finalTime: this.currentTime,
            reason: 'page_unload'
        });
        
        navigator.sendBeacon(
            `${this.apiEndpoint}/x402/session/end`,
            new Blob([data], { type: 'application/json' })
        );
    }
    
    /**
     * 获取当前状态
     */
    getStatus() {
        return {
            isActive: this.isActive,
            currentTime: this.currentTime,
            totalCost: this.totalCost,
            userBalance: this.userBalance,
            progress: this.currentTime / this.totalDuration,
            remainingCost: this.estimateRemainingCost(),
            estimatedFullCost: this.totalDuration * this.pricePerSecond
        };
    }
    
    /**
     * 估算剩余费用
     */
    estimateRemainingCost() {
        const remainingDuration = this.totalDuration - this.currentTime;
        return remainingDuration * this.pricePerSecond;
    }
    
    /**
     * 充值余额
     */
    async recharge(amount) {
        try {
            const response = await fetch(`${this.apiEndpoint}/x402/balance/recharge`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    userId: this.userId,
                    amount: amount
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.userBalance = data.data.newBalance;
                console.log('✅ Recharge success:', this.userBalance + ' SUK');
                
                // 如果之前因余额不足暂停，现在可以继续播放
                if (this.videoElement.paused) {
                    this.videoElement.play();
                }
            }
        } catch (error) {
            console.error('❌ Recharge error:', error);
            this.onError(error);
        }
    }
    
    /**
     * 销毁播放器
     */
    destroy() {
        // 结束会话
        if (this.isActive) {
            this.endSessionSync();
        }
        
        // 移除事件监听
        this.videoElement.removeEventListener('play', this.handlePlay);
        this.videoElement.removeEventListener('pause', this.handlePause);
        this.videoElement.removeEventListener('timeupdate', this.handleTimeUpdate);
        this.videoElement.removeEventListener('ended', this.handleEnded);
        window.removeEventListener('beforeunload', this.handleBeforeUnload);
        
        console.log('🗑️ X402 Player destroyed');
    }
}

// 导出
if (typeof module !== 'undefined' && module.exports) {
    module.exports = X402Player;
}
