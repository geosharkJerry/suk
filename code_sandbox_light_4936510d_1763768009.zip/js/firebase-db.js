// ========================================
// SUK Protocol - Firestore Database
// 数据库操作模块
// ========================================

const FirebaseDB = {
    db: null,

    // 初始化
    init() {
        this.db = FirebaseConfig.getDb();
        
        if (!this.db) {
            console.warn('⚠️ Firestore 未初始化');
            return false;
        }

        console.log('✅ Firestore 数据库模块初始化成功');
        return true;
    },

    // ========================================
    // 短剧数据管理
    // ========================================

    // 添加短剧
    async addDrama(dramaData) {
        try {
            const user = FirebaseAuthManager.getCurrentUser();
            if (!user) {
                throw new Error('用户未登录');
            }

            const docRef = await this.db.collection('dramas').add({
                ...dramaData,
                createdBy: user.uid,
                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
                status: dramaData.status || 'active',
                views: 0,
                likes: 0,
                investors: 0
            });

            console.log('✅ 短剧添加成功:', docRef.id);
            showNotification('短剧添加成功', 'success');

            return { id: docRef.id };

        } catch (error) {
            console.error('❌ 添加短剧失败:', error);
            showNotification('添加失败', 'error');
            throw error;
        }
    },

    // 获取短剧列表
    async getDramas(options = {}) {
        try {
            let query = this.db.collection('dramas');

            // 筛选条件
            if (options.category) {
                query = query.where('category', '==', options.category);
            }
            if (options.status) {
                query = query.where('status', '==', options.status);
            }

            // 排序
            if (options.orderBy) {
                query = query.orderBy(options.orderBy, options.order || 'desc');
            } else {
                query = query.orderBy('createdAt', 'desc');
            }

            // 分页
            if (options.limit) {
                query = query.limit(options.limit);
            }
            if (options.startAfter) {
                query = query.startAfter(options.startAfter);
            }

            const snapshot = await query.get();
            
            const dramas = [];
            snapshot.forEach(doc => {
                dramas.push({
                    id: doc.id,
                    ...doc.data()
                });
            });

            return {
                data: dramas,
                total: dramas.length,
                lastDoc: snapshot.docs[snapshot.docs.length - 1]
            };

        } catch (error) {
            console.error('❌ 获取短剧列表失败:', error);
            throw error;
        }
    },

    // 获取单个短剧
    async getDrama(dramaId) {
        try {
            const doc = await this.db.collection('dramas').doc(dramaId).get();
            
            if (doc.exists) {
                return {
                    id: doc.id,
                    ...doc.data()
                };
            } else {
                throw new Error('短剧不存在');
            }

        } catch (error) {
            console.error('❌ 获取短剧失败:', error);
            throw error;
        }
    },

    // 更新短剧
    async updateDrama(dramaId, updates) {
        try {
            await this.db.collection('dramas').doc(dramaId).update({
                ...updates,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            console.log('✅ 短剧更新成功');
            showNotification('更新成功', 'success');

        } catch (error) {
            console.error('❌ 更新短剧失败:', error);
            showNotification('更新失败', 'error');
            throw error;
        }
    },

    // 删除短剧（软删除）
    async deleteDrama(dramaId) {
        try {
            await this.db.collection('dramas').doc(dramaId).update({
                status: 'deleted',
                deletedAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            console.log('✅ 短剧删除成功');
            showNotification('删除成功', 'success');

        } catch (error) {
            console.error('❌ 删除短剧失败:', error);
            showNotification('删除失败', 'error');
            throw error;
        }
    },

    // ========================================
    // 投资记录管理
    // ========================================

    // 添加投资记录
    async addInvestment(investmentData) {
        try {
            const user = FirebaseAuthManager.getCurrentUser();
            if (!user) {
                throw new Error('用户未登录');
            }

            const docRef = await this.db.collection('investments').add({
                userId: user.uid,
                ...investmentData,
                status: 'completed',
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            // 更新用户总投资额
            await this.db.collection('users').doc(user.uid).update({
                totalInvested: firebase.firestore.FieldValue.increment(investmentData.amount)
            });

            console.log('✅ 投资记录添加成功:', docRef.id);
            showNotification('投资记录已保存', 'success');

            return { id: docRef.id };

        } catch (error) {
            console.error('❌ 添加投资记录失败:', error);
            showNotification('保存失败', 'error');
            throw error;
        }
    },

    // 获取用户投资记录
    async getUserInvestments(userId, options = {}) {
        try {
            let query = this.db.collection('investments')
                .where('userId', '==', userId);

            if (options.dramaId) {
                query = query.where('dramaId', '==', options.dramaId);
            }

            query = query.orderBy('createdAt', 'desc');

            if (options.limit) {
                query = query.limit(options.limit);
            }

            const snapshot = await query.get();
            
            const investments = [];
            snapshot.forEach(doc => {
                investments.push({
                    id: doc.id,
                    ...doc.data()
                });
            });

            return investments;

        } catch (error) {
            console.error('❌ 获取投资记录失败:', error);
            throw error;
        }
    },

    // ========================================
    // 收益记录管理
    // ========================================

    // 添加收益记录
    async addRevenue(revenueData) {
        try {
            const docRef = await this.db.collection('revenues').add({
                ...revenueData,
                distributed: false,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            console.log('✅ 收益记录添加成功:', docRef.id);

            return { id: docRef.id };

        } catch (error) {
            console.error('❌ 添加收益记录失败:', error);
            throw error;
        }
    },

    // 获取短剧收益记录
    async getDramaRevenues(dramaId, options = {}) {
        try {
            let query = this.db.collection('revenues')
                .where('dramaId', '==', dramaId);

            if (options.distributed !== undefined) {
                query = query.where('distributed', '==', options.distributed);
            }

            query = query.orderBy('date', 'desc');

            if (options.limit) {
                query = query.limit(options.limit);
            }

            const snapshot = await query.get();
            
            const revenues = [];
            snapshot.forEach(doc => {
                revenues.push({
                    id: doc.id,
                    ...doc.data()
                });
            });

            return revenues;

        } catch (error) {
            console.error('❌ 获取收益记录失败:', error);
            throw error;
        }
    },

    // 标记收益已分配
    async markRevenueDistributed(revenueId) {
        try {
            await this.db.collection('revenues').doc(revenueId).update({
                distributed: true,
                distributedAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            console.log('✅ 收益标记为已分配');

        } catch (error) {
            console.error('❌ 标记失败:', error);
            throw error;
        }
    },

    // ========================================
    // 用户收益管理
    // ========================================

    // 添加用户收益
    async addUserEarning(userId, earningData) {
        try {
            const docRef = await this.db.collection('earnings').add({
                userId: userId,
                ...earningData,
                claimed: false,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            // 更新用户总收益
            await this.db.collection('users').doc(userId).update({
                totalEarnings: firebase.firestore.FieldValue.increment(earningData.amount)
            });

            console.log('✅ 用户收益添加成功:', docRef.id);

            return { id: docRef.id };

        } catch (error) {
            console.error('❌ 添加用户收益失败:', error);
            throw error;
        }
    },

    // 获取用户收益记录
    async getUserEarnings(userId, options = {}) {
        try {
            let query = this.db.collection('earnings')
                .where('userId', '==', userId);

            if (options.claimed !== undefined) {
                query = query.where('claimed', '==', options.claimed);
            }

            query = query.orderBy('createdAt', 'desc');

            if (options.limit) {
                query = query.limit(options.limit);
            }

            const snapshot = await query.get();
            
            const earnings = [];
            snapshot.forEach(doc => {
                earnings.push({
                    id: doc.id,
                    ...doc.data()
                });
            });

            return earnings;

        } catch (error) {
            console.error('❌ 获取收益记录失败:', error);
            throw error;
        }
    },

    // 领取收益
    async claimEarning(earningId) {
        try {
            await this.db.collection('earnings').doc(earningId).update({
                claimed: true,
                claimedAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            console.log('✅ 收益领取成功');
            showNotification('收益已领取', 'success');

        } catch (error) {
            console.error('❌ 领取收益失败:', error);
            showNotification('领取失败', 'error');
            throw error;
        }
    },

    // ========================================
    // 交易记录管理
    // ========================================

    // 添加交易记录
    async addTransaction(txData) {
        try {
            const user = FirebaseAuthManager.getCurrentUser();
            
            const docRef = await this.db.collection('transactions').add({
                userId: user?.uid || 'anonymous',
                ...txData,
                syncedFromChain: true,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            console.log('✅ 交易记录添加成功:', docRef.id);

            return { id: docRef.id };

        } catch (error) {
            console.error('❌ 添加交易记录失败:', error);
            throw error;
        }
    },

    // 获取用户交易记录
    async getUserTransactions(userId, options = {}) {
        try {
            let query = this.db.collection('transactions')
                .where('userId', '==', userId);

            if (options.type) {
                query = query.where('type', '==', options.type);
            }

            if (options.status) {
                query = query.where('status', '==', options.status);
            }

            query = query.orderBy('timestamp', 'desc');

            if (options.limit) {
                query = query.limit(options.limit);
            }

            const snapshot = await query.get();
            
            const transactions = [];
            snapshot.forEach(doc => {
                transactions.push({
                    id: doc.id,
                    ...doc.data()
                });
            });

            return transactions;

        } catch (error) {
            console.error('❌ 获取交易记录失败:', error);
            throw error;
        }
    },

    // ========================================
    // 实时监听
    // ========================================

    // 监听短剧更新
    watchDrama(dramaId, callback) {
        return this.db.collection('dramas').doc(dramaId)
            .onSnapshot((doc) => {
                if (doc.exists) {
                    callback({
                        id: doc.id,
                        ...doc.data()
                    });
                }
            }, (error) => {
                console.error('❌ 监听短剧失败:', error);
            });
    },

    // 监听用户收益
    watchUserEarnings(userId, callback) {
        return this.db.collection('earnings')
            .where('userId', '==', userId)
            .where('claimed', '==', false)
            .onSnapshot((snapshot) => {
                const earnings = [];
                snapshot.forEach(doc => {
                    earnings.push({
                        id: doc.id,
                        ...doc.data()
                    });
                });
                callback(earnings);
            }, (error) => {
                console.error('❌ 监听收益失败:', error);
            });
    },

    // ========================================
    // 批量操作
    // ========================================

    // 批量写入
    async batchWrite(operations) {
        try {
            const batch = this.db.batch();

            operations.forEach(op => {
                const docRef = this.db.collection(op.collection).doc(op.id);
                
                switch (op.type) {
                    case 'set':
                        batch.set(docRef, op.data);
                        break;
                    case 'update':
                        batch.update(docRef, op.data);
                        break;
                    case 'delete':
                        batch.delete(docRef);
                        break;
                }
            });

            await batch.commit();
            console.log('✅ 批量操作成功');

        } catch (error) {
            console.error('❌ 批量操作失败:', error);
            throw error;
        }
    },

    // ========================================
    // 搜索和查询
    // ========================================

    // 全文搜索（需要配置 Algolia 或使用 Cloud Function）
    async searchDramas(keyword) {
        try {
            // 简单的标题搜索（生产环境建议使用 Algolia）
            const snapshot = await this.db.collection('dramas')
                .where('title', '>=', keyword)
                .where('title', '<=', keyword + '\uf8ff')
                .limit(20)
                .get();

            const results = [];
            snapshot.forEach(doc => {
                results.push({
                    id: doc.id,
                    ...doc.data()
                });
            });

            return results;

        } catch (error) {
            console.error('❌ 搜索失败:', error);
            throw error;
        }
    },

    // ========================================
    // 统计数据
    // ========================================

    // 获取用户统计
    async getUserStats(userId) {
        try {
            // 获取投资总数
            const investmentsSnapshot = await this.db.collection('investments')
                .where('userId', '==', userId)
                .get();

            // 获取待领取收益
            const earningsSnapshot = await this.db.collection('earnings')
                .where('userId', '==', userId)
                .where('claimed', '==', false)
                .get();

            let pendingEarnings = 0;
            earningsSnapshot.forEach(doc => {
                pendingEarnings += doc.data().amount || 0;
            });

            return {
                totalInvestments: investmentsSnapshot.size,
                pendingEarnings: pendingEarnings
            };

        } catch (error) {
            console.error('❌ 获取统计失败:', error);
            return {
                totalInvestments: 0,
                pendingEarnings: 0
            };
        }
    }
};

// 页面加载时初始化
window.addEventListener('DOMContentLoaded', () => {
    FirebaseDB.init();
});

// 导出到全局
window.FirebaseDB = FirebaseDB;

console.log('💾 Firestore 数据库模块已加载');
