// ==================== 仪表盘页面交互逻辑 ====================

document.addEventListener('DOMContentLoaded', function() {
    
    // ==================== 资产分布饼图 ====================
    const assetDistributionCtx = document.getElementById('assetDistributionChart');
    if (assetDistributionCtx) {
        const assetDistributionChart = new Chart(assetDistributionCtx, {
            type: 'doughnut',
            data: {
                labels: ['都市霸总', '穿越时空', '悬疑追凶'],
                datasets: [{
                    data: [40000, 22000, 17358],
                    backgroundColor: [
                        'rgb(139, 92, 246)',
                        'rgb(255, 107, 157)',
                        'rgb(255, 165, 0)'
                    ],
                    borderWidth: 0,
                    hoverOffset: 15
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#b8b8d1',
                            padding: 20,
                            font: {
                                size: 13,
                                family: "'Inter', sans-serif"
                            },
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(10, 10, 15, 0.95)',
                        titleColor: '#fff',
                        bodyColor: '#b8b8d1',
                        borderColor: 'rgba(139, 92, 246, 0.5)',
                        borderWidth: 1,
                        padding: 15,
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return label + ': ¥' + value.toLocaleString() + ' (' + percentage + '%)';
                            }
                        }
                    }
                },
                cutout: '70%'
            }
        });
    }
    
    // ==================== 收益趋势折线图 ====================
    const earningsTrendCtx = document.getElementById('earningsTrendChart');
    if (earningsTrendCtx) {
        // 生成模拟收益数据
        const generateEarningsData = (days) => {
            const data = [];
            const labels = [];
            let earnings = 5000;
            
            for (let i = days; i >= 0; i--) {
                const date = new Date();
                date.setDate(date.getDate() - i);
                labels.push(date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' }));
                
                // 累计增长
                earnings += Math.random() * 150 + 50;
                data.push(earnings.toFixed(0));
            }
            
            return { labels, data };
        };
        
        const earningsData = generateEarningsData(7);
        
        const earningsTrendChart = new Chart(earningsTrendCtx, {
            type: 'line',
            data: {
                labels: earningsData.labels,
                datasets: [{
                    label: '累计收益 (¥)',
                    data: earningsData.data,
                    borderColor: 'rgb(16, 185, 129)',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 4,
                    pointBackgroundColor: 'rgb(16, 185, 129)',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: 'rgba(10, 10, 15, 0.95)',
                        titleColor: '#fff',
                        bodyColor: '#b8b8d1',
                        borderColor: 'rgba(16, 185, 129, 0.5)',
                        borderWidth: 1,
                        padding: 12,
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                return '¥' + parseInt(context.parsed.y).toLocaleString();
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(139, 92, 246, 0.1)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#7a7a9e'
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(139, 92, 246, 0.1)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#7a7a9e',
                            callback: function(value) {
                                return '¥' + (value / 1000).toFixed(1) + 'K';
                            }
                        }
                    }
                }
            }
        });
        
        // 时间范围切换
        const timeButtons = document.querySelectorAll('.time-range button');
        timeButtons.forEach(button => {
            button.addEventListener('click', function() {
                timeButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
                
                const range = this.textContent;
                let days;
                switch(range) {
                    case '7D': days = 7; break;
                    case '30D': days = 30; break;
                    case '90D': days = 90; break;
                    case '全部': days = 180; break;
                    default: days = 7;
                }
                
                const newData = generateEarningsData(days);
                earningsTrendChart.data.labels = newData.labels;
                earningsTrendChart.data.datasets[0].data = newData.data;
                earningsTrendChart.update();
            });
        });
    }
    
    // ==================== 刷新按钮 ====================
    const refreshBtn = document.querySelector('.refresh-btn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            this.style.animation = 'spin 0.5s ease';
            setTimeout(() => {
                this.style.animation = '';
                showNotification('数据已更新', 'success');
            }, 500);
        });
    }
    
    // ==================== 领取收益按钮 ====================
    const claimBtn = document.querySelector('.btn-claim');
    if (claimBtn) {
        claimBtn.addEventListener('click', function() {
            showClaimModal();
        });
    }
    
    // ==================== 投资组合过滤 ====================
    const filterBtns = document.querySelectorAll('.filter-btn');
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const filter = this.textContent;
            filterPortfolio(filter);
        });
    });
    
    // ==================== 表格操作按钮 ====================
    const viewButtons = document.querySelectorAll('.btn-action');
    viewButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const row = this.closest('tr');
            const dramaName = row.querySelector('.drama-name strong').textContent;
            const icon = this.querySelector('i');
            
            if (icon.classList.contains('fa-eye')) {
                window.location.href = 'drama-detail.html';
            } else if (icon.classList.contains('fa-exchange-alt')) {
                showTradeModal(dramaName);
            }
        });
    });
    
    // ==================== 导出报表按钮 ====================
    const exportBtn = document.querySelector('.btn-export');
    if (exportBtn) {
        exportBtn.addEventListener('click', function() {
            showNotification('报表导出功能开发中...', 'info');
        });
    }
    
    // ==================== 加载更多按钮 ====================
    const loadMoreBtn = document.querySelector('.btn-load-more');
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 加载中...';
            
            setTimeout(() => {
                this.innerHTML = '加载更多 <i class="fas fa-chevron-down"></i>';
                showNotification('已加载全部收益记录', 'info');
            }, 1000);
        });
    }
    
});

// ==================== 投资组合过滤函数 ====================
function filterPortfolio(filter) {
    const rows = document.querySelectorAll('.portfolio-table tbody tr');
    
    rows.forEach(row => {
        const category = row.querySelector('.drama-name span').textContent;
        
        if (filter === '全部') {
            row.style.display = '';
        } else if (category.includes(filter)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// ==================== 领取收益模态框 ====================
function showClaimModal() {
    const modal = document.createElement('div');
    modal.className = 'claim-modal';
    modal.innerHTML = `
        <div class="modal-overlay"></div>
        <div class="modal-content">
            <div class="modal-header">
                <h3>领取收益</h3>
                <button class="modal-close"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <div class="claim-summary">
                    <div class="claim-icon">
                        <i class="fas fa-coins"></i>
                    </div>
                    <div class="claim-amount">¥3,180.50</div>
                    <p>可领取收益</p>
                </div>
                <div class="claim-breakdown">
                    <h4>收益明细</h4>
                    <div class="breakdown-list">
                        <div class="breakdown-row">
                            <span>悬疑追凶 · 月度分红</span>
                            <span>¥1,336.00</span>
                        </div>
                        <div class="breakdown-row">
                            <span>穿越时空 · 月度分红</span>
                            <span>¥1,844.50</span>
                        </div>
                    </div>
                </div>
                <button class="btn-confirm-claim">
                    <i class="fas fa-hand-holding-usd"></i>
                    确认领取
                </button>
                <p class="gas-fee">预计Gas费用: ≈¥8.50</p>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // 添加样式
    if (!document.querySelector('#claim-modal-styles')) {
        const style = document.createElement('style');
        style.id = 'claim-modal-styles';
        style.textContent = `
            .claim-modal {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                z-index: 10000;
                display: flex;
                align-items: center;
                justify-content: center;
                animation: fadeIn 0.3s ease;
            }
            
            .claim-summary {
                text-align: center;
                padding: 2rem;
                margin-bottom: 1.5rem;
            }
            
            .claim-icon {
                width: 80px;
                height: 80px;
                margin: 0 auto 1.5rem;
                background: var(--gradient-primary);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 2.5rem;
                color: white;
                animation: pulse 2s infinite;
            }
            
            .claim-amount {
                font-size: 3rem;
                font-weight: 800;
                background: var(--gradient-primary);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
                margin-bottom: 0.5rem;
            }
            
            .claim-breakdown {
                background: rgba(139, 92, 246, 0.05);
                border-radius: var(--radius-sm);
                padding: 1.5rem;
                margin-bottom: 1.5rem;
            }
            
            .claim-breakdown h4 {
                margin-bottom: 1rem;
                font-size: 1rem;
                color: var(--text-secondary);
            }
            
            .breakdown-list {
                display: flex;
                flex-direction: column;
                gap: 0.75rem;
            }
            
            .breakdown-row {
                display: flex;
                justify-content: space-between;
                padding: 0.75rem;
                background: var(--bg-card);
                border-radius: var(--radius-sm);
            }
            
            .breakdown-row span:last-child {
                font-weight: 700;
                color: var(--success);
            }
            
            .btn-confirm-claim {
                width: 100%;
                padding: 1.25rem;
                background: var(--gradient-primary);
                border: none;
                border-radius: var(--radius-sm);
                color: white;
                font-size: 1.1rem;
                font-weight: 700;
                cursor: pointer;
                transition: var(--transition-normal);
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 0.75rem;
            }
            
            .btn-confirm-claim:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 32px rgba(139, 92, 246, 0.4);
            }
            
            .gas-fee {
                text-align: center;
                margin-top: 1rem;
                font-size: 0.85rem;
                color: var(--text-muted);
            }
            
            @keyframes pulse {
                0%, 100% {
                    box-shadow: 0 0 0 0 rgba(139, 92, 246, 0.7);
                }
                50% {
                    box-shadow: 0 0 0 20px rgba(139, 92, 246, 0);
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    // 关闭模态框
    const closeModal = () => {
        modal.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => modal.remove(), 300);
    };
    
    modal.querySelector('.modal-close').addEventListener('click', closeModal);
    modal.querySelector('.modal-overlay').addEventListener('click', closeModal);
    
    // 确认领取
    modal.querySelector('.btn-confirm-claim').addEventListener('click', function() {
        closeModal();
        showNotification('收益领取成功！', 'success');
        
        // 更新页面数据
        setTimeout(() => {
            document.querySelector('.card-value.success').textContent = '¥11,426.30';
            document.querySelector('.overview-card .card-value').textContent = '¥0.00';
            document.querySelector('.breakdown-item .highlight').textContent = '¥0.00';
        }, 500);
    });
}

// ==================== 交易模态框 ====================
function showTradeModal(dramaName) {
    showNotification(`${dramaName} 交易功能开发中...`, 'info');
}

// ==================== 通知系统 ====================
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    notification.innerHTML = `
        <i class="fas ${icons[type]}"></i>
        <span>${message}</span>
    `;
    
    // 添加通知样式
    if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification {
                position: fixed;
                top: 100px;
                right: 2rem;
                padding: 1rem 1.5rem;
                background: var(--bg-card);
                border: 2px solid;
                border-radius: var(--radius-sm);
                color: var(--text-primary);
                display: flex;
                align-items: center;
                gap: 0.75rem;
                z-index: 10001;
                animation: slideInRight 0.3s ease, slideOutRight 0.3s ease 2.7s;
                box-shadow: var(--shadow-lg);
                min-width: 300px;
            }
            
            .notification-success { border-color: var(--success); }
            .notification-error { border-color: var(--error); }
            .notification-warning { border-color: var(--warning); }
            .notification-info { border-color: var(--color-primary); }
            
            .notification i {
                font-size: 1.2rem;
            }
            
            .notification-success i { color: var(--success); }
            .notification-error i { color: var(--error); }
            .notification-warning i { color: var(--warning); }
            .notification-info i { color: var(--color-primary); }
            
            @keyframes slideInRight {
                from {
                    opacity: 0;
                    transform: translateX(100%);
                }
                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }
            
            @keyframes slideOutRight {
                from {
                    opacity: 1;
                    transform: translateX(0);
                }
                to {
                    opacity: 0;
                    transform: translateX(100%);
                }
            }
            
            @keyframes spin {
                from {
                    transform: rotate(0deg);
                }
                to {
                    transform: rotate(360deg);
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    setTimeout(() => notification.remove(), 3000);
}

// ==================== 页面加载时的数据动画 ====================
window.addEventListener('load', () => {
    // 数字滚动动画
    animateNumbers();
});

function animateNumbers() {
    const numbers = document.querySelectorAll('.total-value, .card-value');
    numbers.forEach(num => {
        const text = num.textContent;
        const value = parseFloat(text.replace(/[^0-9.]/g, ''));
        
        if (!isNaN(value)) {
            let current = 0;
            const increment = value / 50;
            const timer = setInterval(() => {
                current += increment;
                if (current >= value) {
                    current = value;
                    clearInterval(timer);
                }
                
                if (text.includes('¥')) {
                    num.textContent = '¥' + current.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                } else if (text.includes('%')) {
                    num.textContent = current.toFixed(1) + '%';
                } else {
                    num.textContent = Math.floor(current);
                }
            }, 20);
        }
    });
}