// ==================== 智能合约交互模块 ====================

// 合约地址配置（部署后需要更新）
const CONTRACT_ADDRESSES = {
    // Polygon Mumbai 测试网
    80001: {
        SUKToken: '0x0000000000000000000000000000000000000000', // 待部署
        DramaFactory: '0x0000000000000000000000000000000000000000', // 待部署
    },
    // Polygon 主网
    137: {
        SUKToken: '0x0000000000000000000000000000000000000000', // 待部署
        DramaFactory: '0x0000000000000000000000000000000000000000', // 待部署
    }
};

// 合约ABI（简化版，实际使用需要完整ABI）
const SUK_TOKEN_ABI = [
    // 基础ERC20函数
    "function name() view returns (string)",
    "function symbol() view returns (string)",
    "function decimals() view returns (uint8)",
    "function totalSupply() view returns (uint256)",
    "function balanceOf(address) view returns (uint256)",
    "function transfer(address to, uint256 amount) returns (bool)",
    "function approve(address spender, uint256 amount) returns (bool)",
    "function allowance(address owner, address spender) view returns (uint256)",
    
    // 质押功能
    "function stake(uint256 amount)",
    "function unstake(uint256 amount)",
    "function claimReward()",
    "function calculateReward(address user) view returns (uint256)",
    "function getTotalRewards(address user) view returns (uint256)",
    "function getVotingPower(address user) view returns (uint256)",
    "function stakes(address) view returns (uint256 amount, uint256 startTime, uint256 lastClaimTime, uint256 rewards)",
    
    // 事件
    "event Staked(address indexed user, uint256 amount)",
    "event Unstaked(address indexed user, uint256 amount)",
    "event RewardClaimed(address indexed user, uint256 reward)"
];

const DRAMA_TOKEN_ABI = [
    // 基础ERC20函数
    "function name() view returns (string)",
    "function symbol() view returns (string)",
    "function decimals() view returns (uint8)",
    "function totalSupply() view returns (uint256)",
    "function balanceOf(address) view returns (uint256)",
    "function transfer(address to, uint256 amount) returns (bool)",
    
    // 短剧信息
    "function getDramaInfo() view returns (string title, string description, string category, uint256 totalEpisodes, uint256 releaseDate, address creator)",
    "function getRevenueStats() view returns (uint256 totalRevenue, uint256 distributedRevenue, uint256 platformFees, uint256 lastDistributionTime, uint256 distributionCount, uint256 revenuePerToken)",
    
    // 收益功能
    "function calculatePendingRevenue(address user) view returns (uint256)",
    "function claimRevenue()",
    "function getUserRevenueInfo(address user) view returns (uint256 totalClaimed, uint256 pendingRevenue, uint256 totalRevenue, uint256 claimCount)",
    
    // 事件
    "event RevenueDistributed(uint256 amount, uint256 timestamp)",
    "event RevenueClaimed(address indexed user, uint256 amount)"
];

// ==================== 合约实例管理 ====================

class ContractManager {
    constructor() {
        this.provider = null;
        this.signer = null;
        this.sukToken = null;
        this.dramaTokens = new Map();
    }
    
    /**
     * 初始化Provider和Signer
     */
    async initialize() {
        if (!window.ethereum) {
            throw new Error('Please install MetaMask');
        }
        
        // 创建Provider
        this.provider = new ethers.providers.Web3Provider(window.ethereum);
        
        // 获取Signer
        this.signer = this.provider.getSigner();
        
        // 获取网络
        const network = await this.provider.getNetwork();
        const chainId = network.chainId;
        
        // 初始化SUK代币合约
        const sukAddress = CONTRACT_ADDRESSES[chainId]?.SUKToken;
        if (sukAddress && sukAddress !== '0x0000000000000000000000000000000000000000') {
            this.sukToken = new ethers.Contract(sukAddress, SUK_TOKEN_ABI, this.signer);
        }
        
        return { chainId, provider: this.provider, signer: this.signer };
    }
    
    /**
     * 获取短剧代币合约实例
     */
    getDramaToken(address) {
        if (!this.dramaTokens.has(address)) {
            const contract = new ethers.Contract(address, DRAMA_TOKEN_ABI, this.signer);
            this.dramaTokens.set(address, contract);
        }
        return this.dramaTokens.get(address);
    }
}

// 全局合约管理器实例
const contractManager = new ContractManager();

// ==================== SUK代币操作 ====================

/**
 * 获取SUK代币余额
 */
async function getSUKBalance(address) {
    try {
        if (!contractManager.sukToken) {
            await contractManager.initialize();
        }
        
        const balance = await contractManager.sukToken.balanceOf(address);
        return ethers.utils.formatEther(balance);
    } catch (error) {
        console.error('获取SUK余额失败:', error);
        throw error;
    }
}

/**
 * 质押SUK代币
 */
async function stakeSUK(amount) {
    try {
        if (!contractManager.sukToken) {
            await contractManager.initialize();
        }
        
        const amountWei = ethers.utils.parseEther(amount.toString());
        const tx = await contractManager.sukToken.stake(amountWei);
        
        showNotification('交易已提交，等待确认...', 'info');
        
        const receipt = await tx.wait();
        showNotification('质押成功！', 'success');
        
        return receipt;
    } catch (error) {
        console.error('质押失败:', error);
        showNotification('质押失败: ' + error.message, 'error');
        throw error;
    }
}

/**
 * 解除质押
 */
async function unstakeSUK(amount) {
    try {
        if (!contractManager.sukToken) {
            await contractManager.initialize();
        }
        
        const amountWei = ethers.utils.parseEther(amount.toString());
        const tx = await contractManager.sukToken.unstake(amountWei);
        
        showNotification('交易已提交，等待确认...', 'info');
        
        const receipt = await tx.wait();
        showNotification('解除质押成功！', 'success');
        
        return receipt;
    } catch (error) {
        console.error('解除质押失败:', error);
        showNotification('解除质押失败: ' + error.message, 'error');
        throw error;
    }
}

/**
 * 领取质押奖励
 */
async function claimSUKReward() {
    try {
        if (!contractManager.sukToken) {
            await contractManager.initialize();
        }
        
        const tx = await contractManager.sukToken.claimReward();
        
        showNotification('交易已提交，等待确认...', 'info');
        
        const receipt = await tx.wait();
        showNotification('奖励领取成功！', 'success');
        
        return receipt;
    } catch (error) {
        console.error('领取奖励失败:', error);
        showNotification('领取奖励失败: ' + error.message, 'error');
        throw error;
    }
}

/**
 * 获取质押信息
 */
async function getStakeInfo(address) {
    try {
        if (!contractManager.sukToken) {
            await contractManager.initialize();
        }
        
        const stakeInfo = await contractManager.sukToken.stakes(address);
        const pendingReward = await contractManager.sukToken.calculateReward(address);
        
        return {
            amount: ethers.utils.formatEther(stakeInfo.amount),
            startTime: stakeInfo.startTime.toNumber(),
            rewards: ethers.utils.formatEther(stakeInfo.rewards),
            pendingReward: ethers.utils.formatEther(pendingReward)
        };
    } catch (error) {
        console.error('获取质押信息失败:', error);
        throw error;
    }
}

// ==================== 短剧代币操作 ====================

/**
 * 获取短剧代币余额
 */
async function getDramaTokenBalance(tokenAddress, userAddress) {
    try {
        const dramaToken = contractManager.getDramaToken(tokenAddress);
        const balance = await dramaToken.balanceOf(userAddress);
        return ethers.utils.formatEther(balance);
    } catch (error) {
        console.error('获取短剧代币余额失败:', error);
        throw error;
    }
}

/**
 * 获取短剧信息
 */
async function getDramaInfo(tokenAddress) {
    try {
        const dramaToken = contractManager.getDramaToken(tokenAddress);
        const info = await dramaToken.getDramaInfo();
        
        return {
            title: info.title,
            description: info.description,
            category: info.category,
            totalEpisodes: info.totalEpisodes.toNumber(),
            releaseDate: new Date(info.releaseDate.toNumber() * 1000),
            creator: info.creator
        };
    } catch (error) {
        console.error('获取短剧信息失败:', error);
        throw error;
    }
}

/**
 * 获取收益统计
 */
async function getRevenueStats(tokenAddress) {
    try {
        const dramaToken = contractManager.getDramaToken(tokenAddress);
        const stats = await dramaToken.getRevenueStats();
        
        return {
            totalRevenue: ethers.utils.formatEther(stats.totalRevenue),
            distributedRevenue: ethers.utils.formatEther(stats.distributedRevenue),
            platformFees: ethers.utils.formatEther(stats.platformFees),
            lastDistributionTime: new Date(stats.lastDistributionTime.toNumber() * 1000),
            distributionCount: stats.distributionCount.toNumber(),
            revenuePerToken: ethers.utils.formatEther(stats.revenuePerToken)
        };
    } catch (error) {
        console.error('获取收益统计失败:', error);
        throw error;
    }
}

/**
 * 获取用户收益信息
 */
async function getUserRevenueInfo(tokenAddress, userAddress) {
    try {
        const dramaToken = contractManager.getDramaToken(tokenAddress);
        const info = await dramaToken.getUserRevenueInfo(userAddress);
        
        return {
            totalClaimed: ethers.utils.formatEther(info.totalClaimed),
            pendingRevenue: ethers.utils.formatEther(info.pendingRevenue),
            totalRevenue: ethers.utils.formatEther(info.totalRevenue),
            claimCount: info.claimCount.toNumber()
        };
    } catch (error) {
        console.error('获取用户收益信息失败:', error);
        throw error;
    }
}

/**
 * 领取短剧收益
 */
async function claimDramaRevenue(tokenAddress) {
    try {
        const dramaToken = contractManager.getDramaToken(tokenAddress);
        const tx = await dramaToken.claimRevenue();
        
        showNotification('交易已提交，等待确认...', 'info');
        
        const receipt = await tx.wait();
        showNotification('收益领取成功！', 'success');
        
        return receipt;
    } catch (error) {
        console.error('领取收益失败:', error);
        showNotification('领取收益失败: ' + error.message, 'error');
        throw error;
    }
}

/**
 * 购买短剧代币（模拟）
 */
async function buyDramaToken(tokenAddress, amount, pricePerToken) {
    try {
        // 实际实现需要通过DEX或专门的购买合约
        // 这里仅作为示例
        showNotification('购买功能开发中...', 'info');
        
        // 模拟交易
        const totalPrice = amount * pricePerToken;
        console.log(`购买 ${amount} 代币，总价: ${totalPrice} ETH`);
        
        // 实际实现示例：
        // const tx = await exchangeContract.buy(tokenAddress, amount, {
        //     value: ethers.utils.parseEther(totalPrice.toString())
        // });
        // return await tx.wait();
    } catch (error) {
        console.error('购买失败:', error);
        showNotification('购买失败: ' + error.message, 'error');
        throw error;
    }
}

// ==================== 工具函数 ====================

/**
 * 格式化地址
 */
function formatAddress(address) {
    if (!address) return '';
    return address.substring(0, 6) + '...' + address.substring(38);
}

/**
 * 格式化金额
 */
function formatAmount(amount, decimals = 4) {
    const num = parseFloat(amount);
    return num.toFixed(decimals);
}

/**
 * 监听合约事件
 */
function listenToContractEvents(contract, eventName, callback) {
    contract.on(eventName, (...args) => {
        callback(...args);
    });
}

/**
 * 获取交易状态
 */
async function getTransactionStatus(txHash) {
    try {
        const provider = contractManager.provider;
        const receipt = await provider.getTransactionReceipt(txHash);
        
        if (!receipt) {
            return { status: 'pending', message: '交易待确认' };
        }
        
        if (receipt.status === 1) {
            return { status: 'success', message: '交易成功', receipt };
        } else {
            return { status: 'failed', message: '交易失败', receipt };
        }
    } catch (error) {
        console.error('获取交易状态失败:', error);
        return { status: 'error', message: error.message };
    }
}

// ==================== 导出给全局使用 ====================

window.ContractInteract = {
    // 初始化
    initialize: () => contractManager.initialize(),
    
    // SUK代币操作
    getSUKBalance,
    stakeSUK,
    unstakeSUK,
    claimSUKReward,
    getStakeInfo,
    
    // 短剧代币操作
    getDramaTokenBalance,
    getDramaInfo,
    getRevenueStats,
    getUserRevenueInfo,
    claimDramaRevenue,
    buyDramaToken,
    
    // 工具函数
    formatAddress,
    formatAmount,
    getTransactionStatus,
    listenToContractEvents
};

// ==================== 初始化 ====================

document.addEventListener('DOMContentLoaded', async function() {
    // 监听钱包连接事件
    window.addEventListener('walletConnected', async (event) => {
        try {
            await contractManager.initialize();
            console.log('合约管理器初始化成功');
            
            // 触发合约就绪事件
            window.dispatchEvent(new Event('contractsReady'));
        } catch (error) {
            console.error('初始化合约管理器失败:', error);
        }
    });
});