/**
 * SUK 智能合约配置文件
 * 用于前端与区块链智能合约的交互
 * 
 * 使用说明：
 * 1. 部署智能合约后，更新对应网络的合约地址
 * 2. 在 HTML 中引入此文件：<script src="js/contract-config.js"></script>
 * 3. 在其他 JS 文件中使用：const config = ContractConfig.getConfig('goerli');
 */

const ContractConfig = {
    // ===========================
    // 网络配置
    // ===========================
    networks: {
        // Ethereum 主网
        mainnet: {
            chainId: '0x1', // 1
            chainName: 'Ethereum Mainnet',
            nativeCurrency: {
                name: 'Ether',
                symbol: 'ETH',
                decimals: 18
            },
            rpcUrls: ['https://mainnet.infura.io/v3/YOUR_INFURA_KEY'],
            blockExplorerUrls: ['https://etherscan.io'],
            contracts: {
                SUKToken: '0x0000000000000000000000000000000000000000', // 待部署后更新
                SUKAirdrop: '0x0000000000000000000000000000000000000000', // 待部署后更新 (V1)
                SUKAirdropV2: '0x0000000000000000000000000000000000000000' // 待部署后更新 (V2)
            }
        },
        
        // Goerli 测试网（推荐用于测试）
        goerli: {
            chainId: '0x5', // 5
            chainName: 'Goerli Testnet',
            nativeCurrency: {
                name: 'Goerli Ether',
                symbol: 'ETH',
                decimals: 18
            },
            rpcUrls: ['https://goerli.infura.io/v3/YOUR_INFURA_KEY'],
            blockExplorerUrls: ['https://goerli.etherscan.io'],
            contracts: {
                SUKToken: '0x0000000000000000000000000000000000000000', // 待部署后更新
                SUKAirdrop: '0x0000000000000000000000000000000000000000', // 待部署后更新 (V1)
                SUKAirdropV2: '0x0000000000000000000000000000000000000000' // 待部署后更新 (V2)
            }
        },
        
        // Sepolia 测试网
        sepolia: {
            chainId: '0xaa36a7', // 11155111
            chainName: 'Sepolia Testnet',
            nativeCurrency: {
                name: 'Sepolia Ether',
                symbol: 'ETH',
                decimals: 18
            },
            rpcUrls: ['https://sepolia.infura.io/v3/YOUR_INFURA_KEY'],
            blockExplorerUrls: ['https://sepolia.etherscan.io'],
            contracts: {
                SUKToken: '0x0000000000000000000000000000000000000000', // 待部署后更新
                SUKAirdrop: '0x0000000000000000000000000000000000000000', // 待部署后更新 (V1)
                SUKAirdropV2: '0x0000000000000000000000000000000000000000' // 待部署后更新 (V2)
            }
        },
        
        // Polygon 主网
        polygon: {
            chainId: '0x89', // 137
            chainName: 'Polygon Mainnet',
            nativeCurrency: {
                name: 'MATIC',
                symbol: 'MATIC',
                decimals: 18
            },
            rpcUrls: ['https://polygon-rpc.com'],
            blockExplorerUrls: ['https://polygonscan.com'],
            contracts: {
                SUKToken: '0x0000000000000000000000000000000000000000', // 待部署后更新
                SUKAirdrop: '0x0000000000000000000000000000000000000000', // 待部署后更新 (V1)
                SUKAirdropV2: '0x0000000000000000000000000000000000000000' // 待部署后更新 (V2)
            }
        },
        
        // BSC 主网
        bsc: {
            chainId: '0x38', // 56
            chainName: 'BNB Smart Chain',
            nativeCurrency: {
                name: 'BNB',
                symbol: 'BNB',
                decimals: 18
            },
            rpcUrls: ['https://bsc-dataseed1.binance.org'],
            blockExplorerUrls: ['https://bscscan.com'],
            contracts: {
                SUKToken: '0x0000000000000000000000000000000000000000', // 待部署后更新
                SUKAirdrop: '0x0000000000000000000000000000000000000000', // 待部署后更新 (V1)
                SUKAirdropV2: '0x0000000000000000000000000000000000000000' // 待部署后更新 (V2)
            }
        }
    },
    
    // ===========================
    // 默认网络设置
    // ===========================
    defaultNetwork: 'goerli', // 默认使用 Goerli 测试网
    
    // ===========================
    // SUK Token ABI
    // ===========================
    SUKTokenABI: [
        // ERC20 标准接口
        "function name() view returns (string)",
        "function symbol() view returns (string)",
        "function decimals() view returns (uint8)",
        "function totalSupply() view returns (uint256)",
        "function balanceOf(address account) view returns (uint256)",
        "function transfer(address to, uint256 amount) returns (bool)",
        "function allowance(address owner, address spender) view returns (uint256)",
        "function approve(address spender, uint256 amount) returns (bool)",
        "function transferFrom(address from, address to, uint256 amount) returns (bool)",
        
        // SUKToken 特殊接口
        "function TOTAL_SUPPLY() view returns (uint256)",
        "function AIRDROP_ALLOCATION() view returns (uint256)",
        "function ECOSYSTEM_ALLOCATION() view returns (uint256)",
        "function blacklist(address account) view returns (bool)",
        "function addToBlacklist(address account)",
        "function removeFromBlacklist(address account)",
        "function pause()",
        "function unpause()",
        "function paused() view returns (bool)",
        
        // 事件
        "event Transfer(address indexed from, address indexed to, uint256 value)",
        "event Approval(address indexed owner, address indexed spender, uint256 value)",
        "event Paused(address account)",
        "event Unpaused(address account)",
        "event BlacklistAdded(address indexed account)",
        "event BlacklistRemoved(address indexed account)"
    ],
    
    // ===========================
    // SUK Airdrop ABI (V1)
    // ===========================
    SUKAirdropABI: [
        // 查询接口
        "function sukToken() view returns (address)",
        "function whitelistStartTime() view returns (uint256)",
        "function publicStartTime() view returns (uint256)",
        "function endTime() view returns (uint256)",
        "function whitelistAmount() view returns (uint256)",
        "function publicAmount() view returns (uint256)",
        "function totalClaimed() view returns (uint256)",
        "function hasClaimed(address account) view returns (bool)",
        "function isWhitelisted(address account) view returns (bool)",
        "function whitelist(address account) view returns (bool)",
        
        // 用户操作接口
        "function claim() returns (bool)",
        "function getClaimableAmount() view returns (uint256)",
        "function canClaim() view returns (bool)",
        "function getTimeUntilStart() view returns (uint256)",
        "function getTimeUntilEnd() view returns (uint256)",
        
        // 管理员接口
        "function addToWhitelist(address[] calldata accounts)",
        "function removeFromWhitelist(address[] calldata accounts)",
        "function pause()",
        "function unpause()",
        "function paused() view returns (bool)",
        "function withdrawRemaining()",
        
        // 统计接口
        "function getAirdropStats() view returns (uint256 totalClaimed, uint256 remainingAmount, uint256 claimedCount)",
        
        // 事件
        "event Claimed(address indexed account, uint256 amount, bool isWhitelisted)",
        "event WhitelistAdded(address[] accounts)",
        "event WhitelistRemoved(address[] accounts)",
        "event AirdropEnded(uint256 remainingAmount)",
        "event Paused(address account)",
        "event Unpaused(address account)"
    ],
    
    // ===========================
    // SUK Airdrop V2 ABI (邀请码系统)
    // ===========================
    SUKAirdropV2ABI: [
        // 基本信息查询
        "function sukToken() view returns (address)",
        "function startTime() view returns (uint256)",
        "function endTime() view returns (uint256)",
        "function TOTAL_AIRDROP_AMOUNT() view returns (uint256)",
        "function WHITELIST_AMOUNT() view returns (uint256)",
        "function REFERRAL_AMOUNT() view returns (uint256)",
        "function INVITE_CODE_VALIDITY() view returns (uint256)",
        "function totalClaimed() view returns (uint256)",
        "function totalWhitelistActivated() view returns (uint256)",
        "function totalReferralRegistered() view returns (uint256)",
        
        // 邀请码管理（仅管理员）
        "function generateInviteCode(string memory code) returns (bytes32)",
        "function batchGenerateInviteCodes(string[] memory codes)",
        "function isInviteCodeValid(string memory code) view returns (bool exists, bool isUsed, bool isExpired, bool isValid, uint256 expiresAt)",
        "function getInviteCodeInfo(string memory code) view returns (bool exists, address creator, uint256 createdAt, uint256 expiresAt, bool isUsed, address usedBy, uint256 usedAt)",
        
        // 用户操作
        "function activateInviteCode(string memory code)",
        "function registerReferral(address referrer, uint256 investAmount)",
        "function claim()",
        
        // 用户状态查询
        "function getClaimInfo(address user) view returns (bool claimed, uint256 amount, uint256 timestamp, bool isWhitelist)",
        "function isWhitelisted(address user) view returns (bool)",
        "function getReferralInfo(address user) view returns (bool isReferred, address referrer, uint256 investAmount, uint256 timestamp)",
        
        // 统计查询
        "function getStats() view returns (uint256 _totalClaimed, uint256 _totalWhitelistActivated, uint256 _totalReferralRegistered, uint256 _remainingAmount)",
        
        // 管理功能
        "function pause()",
        "function unpause()",
        "function paused() view returns (bool)",
        "function withdrawRemaining()",
        
        // 事件
        "event InviteCodeGenerated(bytes32 indexed codeHash, address indexed creator, uint256 expiresAt)",
        "event InviteCodeActivated(bytes32 indexed codeHash, address indexed user, uint256 timestamp)",
        "event ReferralRegistered(address indexed user, address indexed referrer, uint256 investAmount, uint256 timestamp)",
        "event Claimed(address indexed user, uint256 amount, bool isWhitelist, uint256 timestamp)",
        "event Paused(address account)",
        "event Unpaused(address account)"
    ],
    
    // ===========================
    // 辅助方法
    // ===========================
    
    /**
     * 获取指定网络的配置
     * @param {string} network - 网络名称（mainnet, goerli, sepolia, polygon, bsc）
     * @returns {object} 网络配置对象
     */
    getConfig(network) {
        network = network || this.defaultNetwork;
        const config = this.networks[network];
        if (!config) {
            throw new Error(`未找到网络配置: ${network}`);
        }
        return config;
    },
    
    /**
     * 获取当前默认网络的配置
     * @returns {object} 网络配置对象
     */
    getCurrentConfig() {
        return this.getConfig(this.defaultNetwork);
    },
    
    /**
     * 设置默认网络
     * @param {string} network - 网络名称
     */
    setDefaultNetwork(network) {
        if (!this.networks[network]) {
            throw new Error(`未找到网络配置: ${network}`);
        }
        this.defaultNetwork = network;
        console.log(`✅ 默认网络已切换至: ${network}`);
    },
    
    /**
     * 更新合约地址
     * @param {string} network - 网络名称
     * @param {string} contractName - 合约名称（SUKToken 或 SUKAirdrop）
     * @param {string} address - 合约地址
     */
    updateContractAddress(network, contractName, address) {
        if (!this.networks[network]) {
            throw new Error(`未找到网络配置: ${network}`);
        }
        if (!this.networks[network].contracts[contractName]) {
            throw new Error(`未找到合约配置: ${contractName}`);
        }
        this.networks[network].contracts[contractName] = address;
        console.log(`✅ ${network} 上的 ${contractName} 地址已更新为: ${address}`);
    },
    
    /**
     * 批量更新合约地址
     * @param {string} network - 网络名称
     * @param {object} addresses - 合约地址对象 { SUKToken: '0x...', SUKAirdrop: '0x...' }
     */
    updateAllAddresses(network, addresses) {
        if (!this.networks[network]) {
            throw new Error(`未找到网络配置: ${network}`);
        }
        Object.keys(addresses).forEach(contractName => {
            this.updateContractAddress(network, contractName, addresses[contractName]);
        });
        console.log(`✅ ${network} 上的所有合约地址已更新`);
    },
    
    /**
     * 验证合约地址是否已配置
     * @param {string} network - 网络名称
     * @returns {boolean} 是否已配置
     */
    isConfigured(network) {
        network = network || this.defaultNetwork;
        const config = this.getConfig(network);
        const tokenAddress = config.contracts.SUKToken;
        const airdropAddress = config.contracts.SUKAirdrop;
        return tokenAddress !== '0x0000000000000000000000000000000000000000' && 
               airdropAddress !== '0x0000000000000000000000000000000000000000';
    },
    
    /**
     * 获取区块浏览器上的合约链接
     * @param {string} network - 网络名称
     * @param {string} contractName - 合约名称
     * @returns {string} 区块浏览器链接
     */
    getExplorerLink(network, contractName) {
        const config = this.getConfig(network);
        const address = config.contracts[contractName];
        return `${config.blockExplorerUrls[0]}/address/${address}`;
    },
    
    /**
     * 格式化 SUK 金额（从 Wei 转换）
     * @param {string|number} amount - Wei 金额
     * @returns {string} 格式化后的 SUK 金额
     */
    formatSUK(amount) {
        if (!amount) return '0';
        // SUK 使用 18 位小数
        const formatted = (Number(amount) / 1e18).toFixed(2);
        return formatted.replace(/\.?0+$/, ''); // 移除尾部的 0
    },
    
    /**
     * 解析 SUK 金额（转换为 Wei）
     * @param {string|number} amount - SUK 金额
     * @returns {string} Wei 金额
     */
    parseSUK(amount) {
        if (!amount) return '0';
        return (Number(amount) * 1e18).toString();
    }
};

// 导出配置对象（用于 Node.js 环境）
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ContractConfig;
}

console.log('✅ SUK 智能合约配置已加载');
console.log(`📍 当前默认网络: ${ContractConfig.defaultNetwork}`);
