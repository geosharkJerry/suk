// ========================================
// SUK Protocol - 用户认证系统
// ⚠️ 注意：这是前端模拟认证，仅用于演示
// 真实环境需要后端服务器进行安全认证
// ========================================

// 认证管理器
const AuthManager = {
    // 当前登录用户
    currentUser: null,

    // 初始化
    init() {
        this.loadCurrentUser();
        this.setupFormHandlers();
    },

    // 加载当前用户（从 LocalStorage）
    loadCurrentUser() {
        const userJson = localStorage.getItem('suk_current_user');
        if (userJson) {
            try {
                this.currentUser = JSON.parse(userJson);
                console.log('✅ 用户已登录:', this.currentUser.username);
            } catch (e) {
                console.error('❌ 加载用户信息失败:', e);
                localStorage.removeItem('suk_current_user');
            }
        }
    },

    // 设置表单处理器
    setupFormHandlers() {
        // 登录表单
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleLogin();
            });
        }

        // 注册表单
        const registerForm = document.getElementById('register-form');
        if (registerForm) {
            registerForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleRegister();
            });
        }
    },

    // 处理登录
    async handleLogin() {
        const email = document.getElementById('login-email').value.trim();
        const password = document.getElementById('login-password').value;
        const rememberMe = document.getElementById('remember-me').checked;

        // 验证输入
        if (!email || !password) {
            this.showError('请填写完整的登录信息');
            return;
        }

        // 显示加载状态
        const submitBtn = document.querySelector('#login-form .btn-primary');
        const originalText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 登录中...';

        // 模拟网络延迟
        await this.delay(1000);

        try {
            // 从 LocalStorage 获取用户数据库
            const users = this.getAllUsers();
            
            // 查找用户（通过邮箱或用户名）
            const user = users.find(u => 
                u.email.toLowerCase() === email.toLowerCase() || 
                u.username.toLowerCase() === email.toLowerCase()
            );

            if (!user) {
                throw new Error('用户不存在');
            }

            // 验证密码（⚠️ 实际应用中需要使用加密哈希）
            if (user.password !== password) {
                throw new Error('密码错误');
            }

            // 登录成功
            this.currentUser = {
                id: user.id,
                username: user.username,
                email: user.email,
                walletAddress: user.walletAddress,
                createdAt: user.createdAt,
                loginAt: Date.now()
            };

            // 保存到 LocalStorage
            localStorage.setItem('suk_current_user', JSON.stringify(this.currentUser));
            
            if (rememberMe) {
                localStorage.setItem('suk_remember_me', 'true');
            }

            this.showSuccess('登录成功！正在跳转...');
            
            // 记录登录日志
            this.logActivity('login', '用户登录');

            // 延迟跳转
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 1500);

        } catch (error) {
            this.showError(error.message);
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        }
    },

    // 处理注册
    async handleRegister() {
        const username = document.getElementById('register-username').value.trim();
        const email = document.getElementById('register-email').value.trim();
        const password = document.getElementById('register-password').value;
        const confirmPassword = document.getElementById('register-confirm-password').value;
        const agreeTerms = document.getElementById('agree-terms').checked;

        // 验证输入
        if (!username || !email || !password || !confirmPassword) {
            this.showError('请填写完整的注册信息');
            return;
        }

        if (!agreeTerms) {
            this.showError('请同意服务条款和隐私政策');
            return;
        }

        // 验证用户名
        if (username.length < 3) {
            this.showError('用户名至少3个字符');
            return;
        }

        if (!/^[a-zA-Z0-9_]+$/.test(username)) {
            this.showError('用户名只能包含字母、数字和下划线');
            return;
        }

        // 验证邮箱
        if (!this.isValidEmail(email)) {
            this.showError('请输入有效的邮箱地址');
            return;
        }

        // 验证密码
        if (password.length < 8) {
            this.showError('密码至少8个字符');
            return;
        }

        if (!/(?=.*[a-zA-Z])(?=.*[0-9])/.test(password)) {
            this.showError('密码必须包含字母和数字');
            return;
        }

        if (password !== confirmPassword) {
            this.showError('两次输入的密码不一致');
            return;
        }

        // 显示加载状态
        const submitBtn = document.querySelector('#register-form .btn-primary');
        const originalText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 注册中...';

        // 模拟网络延迟
        await this.delay(1500);

        try {
            // 检查用户是否已存在
            const users = this.getAllUsers();
            
            const existingUser = users.find(u => 
                u.email.toLowerCase() === email.toLowerCase() || 
                u.username.toLowerCase() === username.toLowerCase()
            );

            if (existingUser) {
                if (existingUser.email.toLowerCase() === email.toLowerCase()) {
                    throw new Error('该邮箱已被注册');
                } else {
                    throw new Error('该用户名已被使用');
                }
            }

            // 创建新用户
            const newUser = {
                id: this.generateUserId(),
                username: username,
                email: email,
                password: password, // ⚠️ 实际应用中需要加密存储
                walletAddress: null,
                createdAt: Date.now(),
                profile: {
                    avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(username)}&background=FFD700&color=000`,
                    bio: '',
                    verified: false
                }
            };

            // 保存到 LocalStorage
            users.push(newUser);
            localStorage.setItem('suk_users', JSON.stringify(users));

            this.showSuccess('注册成功！正在跳转到登录...');

            // 延迟切换到登录
            setTimeout(() => {
                switchTab('login');
                document.getElementById('login-email').value = email;
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }, 1500);

        } catch (error) {
            this.showError(error.message);
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        }
    },

    // 使用 MetaMask 登录
    async loginWithMetaMask() {
        try {
            if (typeof window.ethereum === 'undefined') {
                throw new Error('请先安装 MetaMask 钱包');
            }

            // 连接钱包
            const accounts = await window.ethereum.request({
                method: 'eth_requestAccounts'
            });

            const walletAddress = accounts[0];
            
            // 查找或创建用户
            const users = this.getAllUsers();
            let user = users.find(u => u.walletAddress?.toLowerCase() === walletAddress.toLowerCase());

            if (!user) {
                // 创建新用户
                user = {
                    id: this.generateUserId(),
                    username: `User_${walletAddress.slice(2, 8)}`,
                    email: `${walletAddress.slice(2, 10)}@wallet.suk`,
                    password: null,
                    walletAddress: walletAddress,
                    createdAt: Date.now(),
                    profile: {
                        avatar: `https://ui-avatars.com/api/?name=${walletAddress.slice(0, 6)}&background=8B5CF6&color=fff`,
                        bio: '通过钱包登录',
                        verified: true
                    }
                };

                users.push(user);
                localStorage.setItem('suk_users', JSON.stringify(users));
            }

            // 登录
            this.currentUser = {
                id: user.id,
                username: user.username,
                email: user.email,
                walletAddress: user.walletAddress,
                createdAt: user.createdAt,
                loginAt: Date.now()
            };

            localStorage.setItem('suk_current_user', JSON.stringify(this.currentUser));
            
            this.showSuccess('钱包登录成功！正在跳转...');
            this.logActivity('wallet_login', 'MetaMask 钱包登录');

            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 1500);

        } catch (error) {
            this.showError(error.message || '钱包连接失败');
        }
    },

    // 使用 MetaMask 注册
    async registerWithMetaMask() {
        await this.loginWithMetaMask(); // 同样的流程
    },

    // 登出
    logout() {
        this.logActivity('logout', '用户登出');
        this.currentUser = null;
        localStorage.removeItem('suk_current_user');
        localStorage.removeItem('suk_remember_me');
        window.location.href = 'auth.html';
    },

    // 获取所有用户
    getAllUsers() {
        const usersJson = localStorage.getItem('suk_users');
        if (!usersJson) {
            return [];
        }
        try {
            return JSON.parse(usersJson);
        } catch (e) {
            console.error('❌ 解析用户数据失败:', e);
            return [];
        }
    },

    // 生成用户 ID
    generateUserId() {
        return 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    },

    // 验证邮箱格式
    isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    },

    // 记录活动日志
    logActivity(action, description) {
        const activities = JSON.parse(localStorage.getItem('suk_activities') || '[]');
        activities.unshift({
            id: Date.now(),
            userId: this.currentUser?.id,
            action: action,
            description: description,
            timestamp: Date.now()
        });
        
        // 只保留最近100条
        if (activities.length > 100) {
            activities.length = 100;
        }
        
        localStorage.setItem('suk_activities', JSON.stringify(activities));
    },

    // 显示错误消息
    showError(message) {
        const errorDiv = document.getElementById('error-message');
        const errorText = document.getElementById('error-text');
        const successDiv = document.getElementById('success-message');
        
        if (errorDiv && errorText) {
            successDiv.classList.remove('show');
            errorText.textContent = message;
            errorDiv.classList.add('show');
            
            setTimeout(() => {
                errorDiv.classList.remove('show');
            }, 5000);
        }
    },

    // 显示成功消息
    showSuccess(message) {
        const successDiv = document.getElementById('success-message');
        const successText = document.getElementById('success-text');
        const errorDiv = document.getElementById('error-message');
        
        if (successDiv && successText) {
            errorDiv.classList.remove('show');
            successText.textContent = message;
            successDiv.classList.add('show');
            
            setTimeout(() => {
                successDiv.classList.remove('show');
            }, 5000);
        }
    },

    // 延迟函数
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    },

    // 检查用户是否已登录
    isLoggedIn() {
        return this.currentUser !== null;
    },

    // 获取当前用户
    getCurrentUser() {
        return this.currentUser;
    },

    // 要求登录（重定向）
    requireLogin() {
        if (!this.isLoggedIn()) {
            window.location.href = 'auth.html';
            return false;
        }
        return true;
    }
};

// 切换标签
function switchTab(tab) {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const tabs = document.querySelectorAll('.tab-btn');

    tabs.forEach(t => t.classList.remove('active'));

    if (tab === 'login') {
        loginForm.classList.add('active');
        registerForm.classList.remove('active');
        tabs[0].classList.add('active');
    } else {
        registerForm.classList.add('active');
        loginForm.classList.remove('active');
        tabs[1].classList.add('active');
    }

    // 清除消息
    document.getElementById('error-message').classList.remove('show');
    document.getElementById('success-message').classList.remove('show');
}

// 切换密码可见性
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const button = input.nextElementSibling;
    const icon = button.querySelector('i');

    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// 检查密码强度
function checkPasswordStrength(password) {
    const bar = document.getElementById('password-strength-bar');
    
    if (!password) {
        bar.className = 'password-strength-bar';
        return;
    }

    let strength = 0;
    
    // 长度检查
    if (password.length >= 8) strength++;
    if (password.length >= 12) strength++;
    
    // 包含字母
    if (/[a-z]/.test(password)) strength++;
    if (/[A-Z]/.test(password)) strength++;
    
    // 包含数字
    if (/[0-9]/.test(password)) strength++;
    
    // 包含特殊字符
    if (/[^a-zA-Z0-9]/.test(password)) strength++;

    // 设置强度等级
    bar.className = 'password-strength-bar';
    if (strength <= 2) {
        bar.classList.add('weak');
    } else if (strength <= 4) {
        bar.classList.add('medium');
    } else {
        bar.classList.add('strong');
    }
}

// MetaMask 登录
async function loginWithMetaMask() {
    await AuthManager.loginWithMetaMask();
}

// MetaMask 注册
async function registerWithMetaMask() {
    await AuthManager.registerWithMetaMask();
}

// 页面加载时初始化
window.addEventListener('DOMContentLoaded', () => {
    AuthManager.init();
    
    // 如果已登录，重定向到仪表盘
    if (AuthManager.isLoggedIn()) {
        console.log('✅ 用户已登录，跳转到仪表盘');
        window.location.href = 'dashboard.html';
    }
});
