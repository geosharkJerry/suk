/**
 * X402 UI Components
 * X402协议的用户界面组件
 * 
 * @version 1.0.0
 * @author SUK Protocol
 */

class X402UI {
    constructor(container, options = {}) {
        this.container = typeof container === 'string' 
            ? document.querySelector(container) 
            : container;
        
        this.options = {
            showProgress: options.showProgress !== false,
            showCost: options.showCost !== false,
            showBalance: options.showBalance !== false,
            showEstimate: options.showEstimate !== false,
            theme: options.theme || 'dark',
            currency: options.currency || 'SUK',
            ...options
        };
        
        this.init();
    }
    
    /**
     * 初始化UI
     */
    init() {
        this.render();
        this.applyTheme();
    }
    
    /**
     * 渲染UI
     */
    render() {
        this.container.innerHTML = `
            <div class="x402-billing-widget ${this.options.theme}">
                <!-- 费用显示 -->
                <div class="x402-cost-display">
                    <div class="x402-cost-label">当前费用</div>
                    <div class="x402-cost-value" id="x402-current-cost">0.00 ${this.options.currency}</div>
                </div>
                
                <!-- 余额显示 -->
                <div class="x402-balance-display">
                    <div class="x402-balance-label">账户余额</div>
                    <div class="x402-balance-value" id="x402-balance">--</div>
                    <button class="x402-recharge-btn" id="x402-recharge-btn">充值</button>
                </div>
                
                <!-- 进度条 -->
                <div class="x402-progress-bar">
                    <div class="x402-progress-fill" id="x402-progress-fill" style="width: 0%"></div>
                    <div class="x402-progress-text" id="x402-progress-text">0%</div>
                </div>
                
                <!-- 详细信息 -->
                <div class="x402-details">
                    <div class="x402-detail-item">
                        <span class="label">观看时长:</span>
                        <span class="value" id="x402-duration">0:00</span>
                    </div>
                    <div class="x402-detail-item">
                        <span class="label">每分钟:</span>
                        <span class="value" id="x402-rate-per-minute">--</span>
                    </div>
                    <div class="x402-detail-item">
                        <span class="label">预计总计:</span>
                        <span class="value" id="x402-estimated-total">--</span>
                    </div>
                    <div class="x402-detail-item">
                        <span class="label">剩余费用:</span>
                        <span class="value" id="x402-remaining-cost">--</span>
                    </div>
                </div>
                
                <!-- 折扣信息 -->
                <div class="x402-discount-info" id="x402-discount-info" style="display: none;">
                    <span class="discount-icon">🎉</span>
                    <span class="discount-text"></span>
                </div>
            </div>
        `;
    }
    
    /**
     * 应用主题
     */
    applyTheme() {
        const style = document.createElement('style');
        style.textContent = `
            .x402-billing-widget {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                padding: 20px;
                border-radius: 12px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                max-width: 400px;
            }
            
            .x402-billing-widget.dark {
                background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                color: #ffffff;
            }
            
            .x402-billing-widget.light {
                background: linear-gradient(135deg, #ffffff 0%, #f5f5f5 100%);
                color: #333333;
            }
            
            /* 费用显示 */
            .x402-cost-display {
                text-align: center;
                margin-bottom: 20px;
            }
            
            .x402-cost-label {
                font-size: 14px;
                opacity: 0.7;
                margin-bottom: 8px;
            }
            
            .x402-cost-value {
                font-size: 32px;
                font-weight: bold;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
            }
            
            /* 余额显示 */
            .x402-balance-display {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 12px;
                background: rgba(255, 255, 255, 0.05);
                border-radius: 8px;
                margin-bottom: 16px;
            }
            
            .x402-balance-label {
                font-size: 14px;
                opacity: 0.7;
            }
            
            .x402-balance-value {
                font-size: 18px;
                font-weight: 600;
                color: #4ade80;
            }
            
            .x402-recharge-btn {
                padding: 6px 16px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border: none;
                border-radius: 6px;
                font-size: 14px;
                cursor: pointer;
                transition: transform 0.2s;
            }
            
            .x402-recharge-btn:hover {
                transform: scale(1.05);
            }
            
            /* 进度条 */
            .x402-progress-bar {
                position: relative;
                height: 8px;
                background: rgba(255, 255, 255, 0.1);
                border-radius: 4px;
                overflow: hidden;
                margin-bottom: 20px;
            }
            
            .x402-progress-fill {
                height: 100%;
                background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
                transition: width 0.3s ease;
            }
            
            .x402-progress-text {
                position: absolute;
                top: -20px;
                right: 0;
                font-size: 12px;
                opacity: 0.7;
            }
            
            /* 详细信息 */
            .x402-details {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 12px;
                margin-bottom: 16px;
            }
            
            .x402-detail-item {
                display: flex;
                flex-direction: column;
                padding: 8px;
                background: rgba(255, 255, 255, 0.05);
                border-radius: 6px;
            }
            
            .x402-detail-item .label {
                font-size: 12px;
                opacity: 0.6;
                margin-bottom: 4px;
            }
            
            .x402-detail-item .value {
                font-size: 16px;
                font-weight: 600;
            }
            
            /* 折扣信息 */
            .x402-discount-info {
                padding: 12px;
                background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%);
                border-radius: 8px;
                color: #000;
                font-size: 14px;
                display: flex;
                align-items: center;
                gap: 8px;
                animation: slideIn 0.3s ease;
            }
            
            @keyframes slideIn {
                from {
                    opacity: 0;
                    transform: translateY(-10px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            .discount-icon {
                font-size: 20px;
            }
            
            /* 余额警告 */
            .x402-balance-warning {
                background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
                color: white;
                padding: 12px;
                border-radius: 8px;
                margin-top: 12px;
                display: flex;
                align-items: center;
                gap: 8px;
                animation: pulse 2s infinite;
            }
            
            @keyframes pulse {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.8; }
            }
        `;
        
        document.head.appendChild(style);
    }
    
    /**
     * 更新费用显示
     */
    updateCost(cost) {
        const costElement = document.getElementById('x402-current-cost');
        if (costElement) {
            costElement.textContent = `${cost.toFixed(4)} ${this.options.currency}`;
        }
    }
    
    /**
     * 更新余额显示
     */
    updateBalance(balance) {
        const balanceElement = document.getElementById('x402-balance');
        if (balanceElement) {
            balanceElement.textContent = `${balance.toFixed(2)} ${this.options.currency}`;
            
            // 余额低时变红
            if (balance < 10) {
                balanceElement.style.color = '#ef4444';
            } else {
                balanceElement.style.color = '#4ade80';
            }
        }
    }
    
    /**
     * 更新进度
     */
    updateProgress(progress) {
        const progressPercent = Math.round(progress * 100);
        
        const fillElement = document.getElementById('x402-progress-fill');
        const textElement = document.getElementById('x402-progress-text');
        
        if (fillElement) {
            fillElement.style.width = `${progressPercent}%`;
        }
        
        if (textElement) {
            textElement.textContent = `${progressPercent}%`;
        }
    }
    
    /**
     * 更新观看时长
     */
    updateDuration(seconds) {
        const minutes = Math.floor(seconds / 60);
        const secs = seconds % 60;
        const formatted = `${minutes}:${secs.toString().padStart(2, '0')}`;
        
        const durationElement = document.getElementById('x402-duration');
        if (durationElement) {
            durationElement.textContent = formatted;
        }
    }
    
    /**
     * 更新每分钟费率
     */
    updateRatePerMinute(rate) {
        const rateElement = document.getElementById('x402-rate-per-minute');
        if (rateElement) {
            rateElement.textContent = `${rate.toFixed(4)} ${this.options.currency}/分钟`;
        }
    }
    
    /**
     * 更新预计总计
     */
    updateEstimatedTotal(total) {
        const totalElement = document.getElementById('x402-estimated-total');
        if (totalElement) {
            totalElement.textContent = `${total.toFixed(2)} ${this.options.currency}`;
        }
    }
    
    /**
     * 更新剩余费用
     */
    updateRemainingCost(remaining) {
        const remainingElement = document.getElementById('x402-remaining-cost');
        if (remainingElement) {
            remainingElement.textContent = `${remaining.toFixed(2)} ${this.options.currency}`;
        }
    }
    
    /**
     * 显示折扣信息
     */
    showDiscount(discountRate) {
        const discountInfo = document.getElementById('x402-discount-info');
        if (discountInfo) {
            const discountPercent = Math.round((1 - discountRate) * 100);
            discountInfo.querySelector('.discount-text').textContent = 
                `您已享受 ${discountPercent}% 累计观看折扣！`;
            discountInfo.style.display = 'flex';
        }
    }
    
    /**
     * 隐藏折扣信息
     */
    hideDiscount() {
        const discountInfo = document.getElementById('x402-discount-info');
        if (discountInfo) {
            discountInfo.style.display = 'none';
        }
    }
    
    /**
     * 显示余额警告
     */
    showBalanceWarning(message) {
        // 移除旧警告
        this.hideBalanceWarning();
        
        const warning = document.createElement('div');
        warning.className = 'x402-balance-warning';
        warning.id = 'x402-balance-warning';
        warning.innerHTML = `
            <span>⚠️</span>
            <span>${message}</span>
        `;
        
        this.container.querySelector('.x402-billing-widget').appendChild(warning);
    }
    
    /**
     * 隐藏余额警告
     */
    hideBalanceWarning() {
        const warning = document.getElementById('x402-balance-warning');
        if (warning) {
            warning.remove();
        }
    }
    
    /**
     * 完整更新所有数据
     */
    update(data) {
        if (data.totalCost !== undefined) {
            this.updateCost(data.totalCost);
        }
        
        if (data.balance !== undefined) {
            this.updateBalance(data.balance);
        }
        
        if (data.progress !== undefined) {
            this.updateProgress(data.progress);
        }
        
        if (data.currentTime !== undefined) {
            this.updateDuration(data.currentTime);
        }
        
        if (data.pricePerMinute !== undefined) {
            this.updateRatePerMinute(data.pricePerMinute);
        }
        
        if (data.estimatedTotal !== undefined) {
            this.updateEstimatedTotal(data.estimatedTotal);
        }
        
        if (data.remainingCost !== undefined) {
            this.updateRemainingCost(data.remainingCost);
        }
        
        if (data.discount !== undefined && data.discount < 1.0) {
            this.showDiscount(data.discount);
        } else {
            this.hideDiscount();
        }
    }
    
    /**
     * 绑定充值按钮
     */
    onRecharge(callback) {
        const rechargeBtn = document.getElementById('x402-recharge-btn');
        if (rechargeBtn) {
            rechargeBtn.addEventListener('click', callback);
        }
    }
}

// 导出
if (typeof module !== 'undefined' && module.exports) {
    module.exports = X402UI;
}
