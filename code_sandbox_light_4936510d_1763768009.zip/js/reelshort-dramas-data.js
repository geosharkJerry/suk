/**
 * SUK Protocol - ReelShort 风格剧集数据库
 * 包含多个类别的精品短剧
 * 代币计价: 1 SUK = $0.01 USD
 * 所有金额使用 SUK 代币计价
 */

const dramaCategories = {
    billionaire: "霸总豪门",
    revenge: "复仇逆袭",
    campus: "校园青春",
    timeTravelhistorical: "穿越古装",
    career: "职场精英",
    mafia: "黑帮危情",
    medical: "医者仁心",
    contract: "契约婚姻",
    fantasy: "奇幻玄幻",
    rebirth: "重生归来",
    hiddenIdentity: "隐藏身份",
    pregnancy: "意外怀孕",
    action: "动作保镖",
    royal: "王室贵族",
    entertainment: "娱乐圈"
};

const reelShortDramas = {
    // ========== 霸总豪门类 ==========
    "1": {
        id: 1,
        title: "闪婚霸总宠上天",
        englishTitle: "Flash Marriage CEO Spoils Me",
        category: "billionaire",
        categoryName: "霸总豪门",
        tags: ["霸总", "闪婚", "甜宠", "豪门"],
        rating: 9.4,
        hotLevel: "🔥🔥🔥",
        
        coverImage: "https://www.genspark.ai/api/files/s/7t75exG8?cache_control=3600",
        
        description: "一场意外的闪婚，让平凡女孩嫁给神秘霸总。本以为只是契约夫妻，却被宠上天。从职场菜鸟到霸总夫人，她的逆袭之路精彩纷呈。商战、爱情、家族恩怨交织，甜宠与虐心并存。",
        episodes: 100,
        duration: "每集3分钟",
        totalDuration: "5小时",
        releaseDate: "2024-08",
        status: "完结",
        updateFrequency: "已完结",
        
        director: "李晨曦",
        screenwriter: "王雪儿",
        cast: ["陈俊豪", "林心怡", "张国强"],
        production: "星辰影视",
        
        // SUK 代币经济数据
        tokenPrice: 150, // SUK
        tokenPriceUSD: 1.50, // USD
        priceChange24h: 8.5, // %
        initialPrice: 100, // SUK
        totalSupply: 15000000, // 1500万 SUK
        circulatingSupply: 12000000, // 1200万 SUK
        marketCap: 180000000, // 1.8亿 SUK
        tvl: 120000000, // 1.2亿 SUK ($1.2M USD)
        tvlUSD: 1200000,
        
        // 收益数据
        apy: 16.8,
        monthlyReturn: 1.4,
        totalRevenue: 18000000, // 1800万 SUK
        revenuePerToken: 1.5, // SUK
        distributedRevenue: 15000000, // 1500万 SUK
        
        // 播放数据
        views: 850000000, // 8.5亿
        likes: 68000000, // 6800万
        comments: 5200000, // 520万
        shares: 15000000, // 1500万
        favorites: 28000000, // 2800万
        completionRate: 92, // %
        
        // 收益来源
        revenueStreams: [
            { source: "平台分成", percentage: 48, amount: 8640000 },
            { source: "广告收入", percentage: 28, amount: 5040000 },
            { source: "付费观看", percentage: 16, amount: 2880000 },
            { source: "衍生授权", percentage: 8, amount: 1440000 }
        ],
        
        holders: [
            { rank: 1, address: "0xa1b2...c3d4", percentage: 15.2, amount: 1824000 },
            { rank: 2, address: "0xe5f6...g7h8", percentage: 10.8, amount: 1296000 },
            { rank: 3, address: "0xi9j0...k1l2", percentage: 8.5, amount: 1020000 },
            { rank: 4, address: "0xm3n4...o5p6", percentage: 6.2, amount: 744000 },
            { rank: 5, address: "0xq7r8...s9t0", percentage: 4.8, amount: 576000 }
        ]
    },
    
    "2": {
        id: 2,
        title: "隐形富豪",
        englishTitle: "Billionaire in Disguise",
        category: "hiddenIdentity",
        categoryName: "隐藏身份",
        tags: ["隐藏身份", "霸总", "误会", "逆袭"],
        rating: 9.1,
        hotLevel: "🔥🔥",
        
        coverImage: "https://www.genspark.ai/api/files/s/HG8b6nxo?cache_control=3600",
        
        description: "身家百亿的富豪为了寻找真爱，隐藏身份成为普通员工。在底层打拼中遇见真心，却被误会是穷小子。当身份揭露的那一刻，所有人都震惊了。",
        episodes: 80,
        duration: "每集3分钟",
        totalDuration: "4小时",
        releaseDate: "2024-09",
        status: "完结",
        
        director: "赵明轩",
        screenwriter: "李思远",
        cast: ["王浩然", "苏晴", "马天宇"],
        production: "梦想影业",
        
        tokenPrice: 128, // SUK
        tokenPriceUSD: 1.28,
        priceChange24h: 5.2,
        initialPrice: 95, // SUK
        totalSupply: 12000000,
        circulatingSupply: 9600000,
        marketCap: 122880000,
        tvl: 96000000, // 9600万 SUK
        tvlUSD: 960000,
        
        apy: 14.5,
        monthlyReturn: 1.21,
        totalRevenue: 14000000,
        revenuePerToken: 1.46,
        
        views: 620000000,
        likes: 52000000,
        comments: 3800000,
        shares: 11000000,
        favorites: 22000000,
        completionRate: 88,
        
        revenueStreams: [
            { source: "平台分成", percentage: 45, amount: 6300000 },
            { source: "广告收入", percentage: 30, amount: 4200000 },
            { source: "付费观看", percentage: 18, amount: 2520000 },
            { source: "衍生授权", percentage: 7, amount: 980000 }
        ]
    },
    
    // ========== 复仇逆袭类 ==========
    "3": {
        id: 3,
        title: "双面复仇记",
        englishTitle: "Double Life Revenge",
        category: "revenge",
        categoryName: "复仇逆袭",
        tags: ["复仇", "悬疑", "逆袭", "爽剧"],
        rating: 9.6,
        hotLevel: "🔥🔥🔥🔥",
        
        coverImage: "https://www.genspark.ai/api/files/s/UMAOUrYj?cache_control=3600",
        
        description: "前世被陷害家破人亡，重生归来她化身复仇女神。双重身份游走于黑白两道，步步为营揭开真相。每一步都精心设计，让仇人付出代价。烧脑剧情，爽感十足。",
        episodes: 90,
        duration: "每集4分钟",
        totalDuration: "6小时",
        releaseDate: "2024-10",
        status: "完结",
        
        director: "张艺谋",
        screenwriter: "陈思涵",
        cast: ["江晓月", "孙浩宇", "李慧敏"],
        production: "暗影传媒",
        
        tokenPrice: 165, // SUK
        tokenPriceUSD: 1.65,
        priceChange24h: 12.3,
        initialPrice: 110, // SUK
        totalSupply: 10000000,
        circulatingSupply: 8200000,
        marketCap: 135300000,
        tvl: 102000000, // 1.02亿 SUK
        tvlUSD: 1020000,
        
        apy: 19.2,
        monthlyReturn: 1.6,
        totalRevenue: 16500000,
        revenuePerToken: 2.01,
        
        views: 920000000,
        likes: 75000000,
        comments: 6500000,
        shares: 18000000,
        favorites: 32000000,
        completionRate: 94,
        
        revenueStreams: [
            { source: "平台分成", percentage: 42, amount: 6930000 },
            { source: "广告收入", percentage: 33, amount: 5445000 },
            { source: "付费观看", percentage: 20, amount: 3300000 },
            { source: "衍生授权", percentage: 5, amount: 825000 }
        ]
    },
    
    "4": {
        id: 4,
        title: "重生之巅峰女王",
        englishTitle: "Reborn to Revenge",
        category: "rebirth",
        categoryName: "重生归来",
        tags: ["重生", "复仇", "女强", "逆袭"],
        rating: 9.3,
        hotLevel: "🔥🔥🔥",
        
        coverImage: "https://www.genspark.ai/api/files/s/scw8cZcN?cache_control=3600",
        
        description: "前世惨死，重生归来的她誓要改写命运。利用前世记忆，她在商界叱咤风云，成为令人敬畏的女王。复仇的同时，也收获了真爱。",
        episodes: 85,
        duration: "每集3分钟",
        totalDuration: "4.25小时",
        releaseDate: "2024-09",
        status: "完结",
        
        director: "周雨晴",
        screenwriter: "王思雨",
        cast: ["赵丽颖", "张若昀", "刘诗诗"],
        production: "凤凰影视",
        
        tokenPrice: 142, // SUK
        tokenPriceUSD: 1.42,
        priceChange24h: 7.8,
        initialPrice: 100, // SUK
        totalSupply: 11000000,
        circulatingSupply: 8800000,
        marketCap: 125040000,
        tvl: 88000000,
        tvlUSD: 880000,
        
        apy: 17.5,
        monthlyReturn: 1.46,
        totalRevenue: 14200000,
        revenuePerToken: 1.61,
        
        views: 740000000,
        likes: 61000000,
        comments: 4900000,
        shares: 14000000,
        favorites: 26000000,
        completionRate: 91,
        
        revenueStreams: [
            { source: "平台分成", percentage: 44, amount: 6248000 },
            { source: "广告收入", percentage: 32, amount: 4544000 },
            { source: "付费观看", percentage: 17, amount: 2414000 },
            { source: "衍生授权", percentage: 7, amount: 994000 }
        ]
    },
    
    // ========== 校园青春类 ==========
    "5": {
        id: 5,
        title: "我的校园小甜心",
        englishTitle: "My Campus Sweetheart",
        category: "campus",
        categoryName: "校园青春",
        tags: ["校园", "青春", "初恋", "治愈"],
        rating: 9.0,
        hotLevel: "🔥🔥",
        
        coverImage: "https://www.genspark.ai/api/files/s/TkBN7TKz?cache_control=3600",
        
        description: "高中时期的暗恋，大学时代的重逢。从青涩到成熟，从暗恋到表白，记录最美好的青春时光。樱花树下的约定，图书馆的邂逅，每一幕都是心动瞬间。",
        episodes: 60,
        duration: "每集2.5分钟",
        totalDuration: "2.5小时",
        releaseDate: "2024-10",
        status: "连载中",
        
        director: "林心如",
        screenwriter: "张思怡",
        cast: ["刘昊然", "欧阳娜娜", "易烊千玺"],
        production: "青春映画",
        
        tokenPrice: 98, // SUK
        tokenPriceUSD: 0.98,
        priceChange24h: 4.5,
        initialPrice: 75, // SUK
        totalSupply: 8000000,
        circulatingSupply: 6400000,
        marketCap: 62720000,
        tvl: 52000000,
        tvlUSD: 520000,
        
        apy: 13.8,
        monthlyReturn: 1.15,
        totalRevenue: 9800000,
        revenuePerToken: 1.53,
        
        views: 480000000,
        likes: 42000000,
        comments: 3200000,
        shares: 9000000,
        favorites: 18000000,
        completionRate: 87,
        
        revenueStreams: [
            { source: "平台分成", percentage: 50, amount: 4900000 },
            { source: "广告收入", percentage: 26, amount: 2548000 },
            { source: "付费观看", percentage: 15, amount: 1470000 },
            { source: "衍生授权", percentage: 9, amount: 882000 }
        ]
    },
    
    // ========== 穿越古装类 ==========
    "6": {
        id: 6,
        title: "穿越之古代皇后",
        englishTitle: "Back to Ancient Dynasty",
        category: "timeTravel",
        categoryName: "穿越古装",
        tags: ["穿越", "古装", "宫廷", "甜宠"],
        rating: 9.2,
        hotLevel: "🔥🔥🔥",
        
        coverImage: "https://www.genspark.ai/api/files/s/3pkpydSQ?cache_control=3600",
        
        description: "现代白领意外穿越到古代，凭借现代知识在宫廷中如鱼得水。从一个无名宫女到母仪天下的皇后，她用智慧和勇气改写历史。与皇上的爱情故事感人至深。",
        episodes: 100,
        duration: "每集3分钟",
        totalDuration: "5小时",
        releaseDate: "2024-08",
        status: "完结",
        
        director: "郑晓龙",
        screenwriter: "流潋紫",
        cast: ["杨幂", "霍建华", "刘恺威"],
        production: "盛世华章",
        
        tokenPrice: 135, // SUK
        tokenPriceUSD: 1.35,
        priceChange24h: 6.8,
        initialPrice: 100, // SUK
        totalSupply: 13000000,
        circulatingSupply: 10400000,
        marketCap: 140400000,
        tvl: 98000000,
        tvlUSD: 980000,
        
        apy: 15.6,
        monthlyReturn: 1.3,
        totalRevenue: 15000000,
        revenuePerToken: 1.44,
        
        views: 780000000,
        likes: 64000000,
        comments: 5000000,
        shares: 16000000,
        favorites: 29000000,
        completionRate: 90,
        
        revenueStreams: [
            { source: "平台分成", percentage: 46, amount: 6900000 },
            { source: "广告收入", percentage: 29, amount: 4350000 },
            { source: "付费观看", percentage: 18, amount: 2700000 },
            { source: "衍生授权", percentage: 7, amount: 1050000 }
        ]
    },
    
    // ========== 职场精英类 ==========
    "7": {
        id: 7,
        title: "新星律政佳人",
        englishTitle: "Rising Star Attorney",
        category: "career",
        categoryName: "职场精英",
        tags: ["职场", "律政", "女强", "励志"],
        rating: 9.1,
        hotLevel: "🔥🔥",
        
        coverImage: "https://www.genspark.ai/api/files/s/FPx0bcdv?cache_control=3600",
        
        description: "从菜鸟律师到金牌大律师，她用实力证明女性在职场的无限可能。每一个案件都是挑战，每一次辩护都是精彩交锋。职场与爱情的双丰收。",
        episodes: 75,
        duration: "每集4分钟",
        totalDuration: "5小时",
        releaseDate: "2024-09",
        status: "完结",
        
        director: "吴秀波",
        screenwriter: "李丽华",
        cast: ["刘涛", "靳东", "袁泉"],
        production: "正道影业",
        
        tokenPrice: 118, // SUK
        tokenPriceUSD: 1.18,
        priceChange24h: 5.5,
        initialPrice: 90, // SUK
        totalSupply: 9000000,
        circulatingSupply: 7200000,
        marketCap: 84960000,
        tvl: 68000000,
        tvlUSD: 680000,
        
        apy: 14.2,
        monthlyReturn: 1.18,
        totalRevenue: 11800000,
        revenuePerToken: 1.64,
        
        views: 550000000,
        likes: 48000000,
        comments: 3600000,
        shares: 10000000,
        favorites: 20000000,
        completionRate: 86,
        
        revenueStreams: [
            { source: "平台分成", percentage: 47, amount: 5546000 },
            { source: "广告收入", percentage: 28, amount: 3304000 },
            { source: "付费观看", percentage: 17, amount: 2006000 },
            { source: "衍生授权", percentage: 8, amount: 944000 }
        ]
    },
    
    // ========== 黑帮危情类 ==========
    "8": {
        id: 8,
        title: "黑帮老大的禁忌之恋",
        englishTitle: "Dangerous Love with Mafia Boss",
        category: "mafia",
        categoryName: "黑帮危情",
        tags: ["黑帮", "危险", "禁忌", "激情"],
        rating: 9.4,
        hotLevel: "🔥🔥🔥",
        
        coverImage: "https://www.genspark.ai/api/files/s/xeeYFmHp?cache_control=3600",
        
        description: "她是清纯女孩，他是黑帮老大。命运让他们相遇，危险与激情并存。在黑白两道的夹缝中，这段禁忌之恋能否开花结果？每一刻都惊心动魄。",
        episodes: 80,
        duration: "每集3.5分钟",
        totalDuration: "4.67小时",
        releaseDate: "2024-10",
        status: "完结",
        
        director: "陈凯歌",
        screenwriter: "宁浩",
        cast: ["彭于晏", "倪妮", "张震"],
        production: "黑金影业",
        
        tokenPrice: 155, // SUK
        tokenPriceUSD: 1.55,
        priceChange24h: 9.2,
        initialPrice: 105, // SUK
        totalSupply: 11000000,
        circulatingSupply: 8800000,
        marketCap: 136400000,
        tvl: 92000000,
        tvlUSD: 920000,
        
        apy: 18.3,
        monthlyReturn: 1.53,
        totalRevenue: 15500000,
        revenuePerToken: 1.76,
        
        views: 680000000,
        likes: 58000000,
        comments: 4700000,
        shares: 13000000,
        favorites: 25000000,
        completionRate: 89,
        
        revenueStreams: [
            { source: "平台分成", percentage: 43, amount: 6665000 },
            { source: "广告收入", percentage: 31, amount: 4805000 },
            { source: "付费观看", percentage: 19, amount: 2945000 },
            { source: "衍生授权", percentage: 7, amount: 1085000 }
        ]
    },
    
    // ========== 医者仁心类 ==========
    "9": {
        id: 9,
        title: "医生的秘密恋情",
        englishTitle: "Doctor's Secret Love",
        category: "medical",
        categoryName: "医者仁心",
        tags: ["医生", "医疗", "暖男", "治愈"],
        rating: 8.9,
        hotLevel: "🔥",
        
        coverImage: "https://www.genspark.ai/api/files/s/nEOIrAy2?cache_control=3600",
        
        description: "年轻天才医生在救死扶伤中遇见真爱。手术室的紧张，病房里的温暖，医患之间的信任。医者仁心与浪漫爱情的完美结合，展现医护人员的职业精神。",
        episodes: 70,
        duration: "每集3分钟",
        totalDuration: "3.5小时",
        releaseDate: "2024-09",
        status: "完结",
        
        director: "张黎",
        screenwriter: "刘和平",
        cast: ["罗晋", "白百何", "张嘉译"],
        production: "仁心影视",
        
        tokenPrice: 105, // SUK
        tokenPriceUSD: 1.05,
        priceChange24h: 3.8,
        initialPrice: 80, // SUK
        totalSupply: 8000000,
        circulatingSupply: 6400000,
        marketCap: 67200000,
        tvl: 58000000,
        tvlUSD: 580000,
        
        apy: 13.2,
        monthlyReturn: 1.1,
        totalRevenue: 10500000,
        revenuePerToken: 1.64,
        
        views: 420000000,
        likes: 38000000,
        comments: 2900000,
        shares: 8000000,
        favorites: 16000000,
        completionRate: 85,
        
        revenueStreams: [
            { source: "平台分成", percentage: 48, amount: 5040000 },
            { source: "广告收入", percentage: 27, amount: 2835000 },
            { source: "付费观看", percentage: 16, amount: 1680000 },
            { source: "衍生授权", percentage: 9, amount: 945000 }
        ]
    },
    
    // ========== 契约婚姻类 ==========
    "10": {
        id: 10,
        title: "99天契约妻子",
        englishTitle: "99 Days Contract Wife",
        category: "contract",
        categoryName: "契约婚姻",
        tags: ["契约", "婚姻", "假戏真做", "甜宠"],
        rating: 9.3,
        hotLevel: "🔥🔥🔥",
        
        coverImage: "https://www.genspark.ai/api/files/s/TsAZIy2J?cache_control=3600",
        
        description: "为了各自的目的，他们签下99天的契约婚姻。本是逢场作戏，却在朝夕相处中假戏真做。从陌生到熟悉，从演戏到真心，99天后他们的选择是？",
        episodes: 99,
        duration: "每集2分钟",
        totalDuration: "3.3小时",
        releaseDate: "2024-10",
        status: "连载中",
        
        director: "徐峥",
        screenwriter: "束焕",
        cast: ["邓超", "孙俪", "郭京飞"],
        production: "真爱影业",
        
        tokenPrice: 132, // SUK
        tokenPriceUSD: 1.32,
        priceChange24h: 6.5,
        initialPrice: 95, // SUK
        totalSupply: 12000000,
        circulatingSupply: 9600000,
        marketCap: 126720000,
        tvl: 85000000,
        tvlUSD: 850000,
        
        apy: 16.2,
        monthlyReturn: 1.35,
        totalRevenue: 13200000,
        revenuePerToken: 1.38,
        
        views: 720000000,
        likes: 59000000,
        comments: 4500000,
        shares: 15000000,
        favorites: 27000000,
        completionRate: 93,
        
        revenueStreams: [
            { source: "平台分成", percentage: 45, amount: 5940000 },
            { source: "广告收入", percentage: 30, amount: 3960000 },
            { source: "付费观看", percentage: 18, amount: 2376000 },
            { source: "衍生授权", percentage: 7, amount: 924000 }
        ]
    },
    
    // ========== 奇幻玄幻类 ==========
    "11": {
        id: 11,
        title: "狼人Alpha的命定伴侣",
        englishTitle: "My Werewolf Alpha Mate",
        category: "fantasy",
        categoryName: "奇幻玄幻",
        tags: ["狼人", "玄幻", "命运", "超自然"],
        rating: 9.0,
        hotLevel: "🔥🔥",
        
        coverImage: "https://www.genspark.ai/api/files/s/gvN6abxC?cache_control=3600",
        
        description: "普通女孩意外发现自己是狼人Alpha的命定伴侣。在超自然世界与人类世界之间，她开启了奇幻冒险。狼族传说，命运羁绊，跨越种族的爱恋感天动地。",
        episodes: 80,
        duration: "每集3分钟",
        totalDuration: "4小时",
        releaseDate: "2024-09",
        status: "完结",
        
        director: "乌尔善",
        screenwriter: "江南",
        cast: ["李易峰", "杨幂", "陈伟霆"],
        production: "幻想影视",
        
        tokenPrice: 122, // SUK
        tokenPriceUSD: 1.22,
        priceChange24h: 5.8,
        initialPrice: 90, // SUK
        totalSupply: 10000000,
        circulatingSupply: 8000000,
        marketCap: 97600000,
        tvl: 72000000,
        tvlUSD: 720000,
        
        apy: 14.8,
        monthlyReturn: 1.23,
        totalRevenue: 12200000,
        revenuePerToken: 1.53,
        
        views: 560000000,
        likes: 47000000,
        comments: 3700000,
        shares: 11000000,
        favorites: 21000000,
        completionRate: 87,
        
        revenueStreams: [
            { source: "平台分成", percentage: 44, amount: 5368000 },
            { source: "广告收入", percentage: 30, amount: 3660000 },
            { source: "付费观看", percentage: 18, amount: 2196000 },
            { source: "衍生授权", percentage: 8, amount: 976000 }
        ]
    },
    
    // ========== 意外怀孕类 ==========
    "12": {
        id: 12,
        title: "意外三胞胎",
        englishTitle: "Surprised by Triplets",
        category: "pregnancy",
        categoryName: "意外怀孕",
        tags: ["怀孕", "三胞胎", "温馨", "家庭"],
        rating: 8.8,
        hotLevel: "🔥",
        
        coverImage: "https://www.genspark.ai/api/files/s/ZSOrCZHG?cache_control=3600",
        
        description: "一夜意外后怀上三胞胎，她决定独自抚养孩子。五年后孩子们的父亲出现，展开了一场温馨又爆笑的追妻之旅。从陌生到相爱，组建温馨家庭。",
        episodes: 65,
        duration: "每集2.5分钟",
        totalDuration: "2.7小时",
        releaseDate: "2024-10",
        status: "连载中",
        
        director: "高群书",
        screenwriter: "赵冬苓",
        cast: ["赵薇", "黄晓明", "陈坤"],
        production: "温馨影视",
        
        tokenPrice: 95, // SUK
        tokenPriceUSD: 0.95,
        priceChange24h: 3.2,
        initialPrice: 70, // SUK
        totalSupply: 7000000,
        circulatingSupply: 5600000,
        marketCap: 53200000,
        tvl: 48000000,
        tvlUSD: 480000,
        
        apy: 12.5,
        monthlyReturn: 1.04,
        totalRevenue: 9500000,
        revenuePerToken: 1.70,
        
        views: 380000000,
        likes: 34000000,
        comments: 2600000,
        shares: 7000000,
        favorites: 15000000,
        completionRate: 84,
        
        revenueStreams: [
            { source: "平台分成", percentage: 49, amount: 4655000 },
            { source: "广告收入", percentage: 26, amount: 2470000 },
            { source: "付费观看", percentage: 16, amount: 1520000 },
            { source: "衍生授权", percentage: 9, amount: 855000 }
        ]
    },
    
    // ========== 动作保镖类 ==========
    "13": {
        id: 13,
        title: "保镖的禁忌恋情",
        englishTitle: "Bodyguard's Forbidden Love",
        category: "action",
        categoryName: "动作保镖",
        tags: ["保镖", "动作", "禁忌", "保护"],
        rating: 9.2,
        hotLevel: "🔥🔥",
        
        coverImage: "https://www.genspark.ai/api/files/s/hLRZ0J9K?cache_control=3600",
        
        description: "精英保镖被派保护千金小姐，却在朝夕相处中陷入情网。职责与爱情的冲突，危险与浪漫的交织。当危机来临，他用生命守护她，证明爱情的力量。",
        episodes: 70,
        duration: "每集3.5分钟",
        totalDuration: "4.1小时",
        releaseDate: "2024-09",
        status: "完结",
        
        director: "林超贤",
        screenwriter: "陈木胜",
        cast: ["吴京", "章子怡", "甄子丹"],
        production: "铁血影业",
        
        tokenPrice: 138, // SUK
        tokenPriceUSD: 1.38,
        priceChange24h: 7.2,
        initialPrice: 100, // SUK
        totalSupply: 9000000,
        circulatingSupply: 7200000,
        marketCap: 99360000,
        tvl: 75000000,
        tvlUSD: 750000,
        
        apy: 15.8,
        monthlyReturn: 1.32,
        totalRevenue: 13800000,
        revenuePerToken: 1.92,
        
        views: 630000000,
        likes: 54000000,
        comments: 4200000,
        shares: 12000000,
        favorites: 23000000,
        completionRate: 88,
        
        revenueStreams: [
            { source: "平台分成", percentage: 46, amount: 6348000 },
            { source: "广告收入", percentage: 29, amount: 4002000 },
            { source: "付费观看", percentage: 17, amount: 2346000 },
            { source: "衍生授权", percentage: 8, amount: 1104000 }
        ]
    },
    
    // ========== 王室贵族类 ==========
    "14": {
        id: 14,
        title: "王子的灰姑娘",
        englishTitle: "The Prince's Cinderella",
        category: "royal",
        categoryName: "王室贵族",
        tags: ["王室", "王子", "灰姑娘", "童话"],
        rating: 8.9,
        hotLevel: "🔥",
        
        coverImage: "https://www.genspark.ai/api/files/s/7sb6011a?cache_control=3600",
        
        description: "现实版灰姑娘故事，平凡女孩意外邂逅隐藏身份的王子。从误会到相识，从普通到童话，她如何征服王室？浪漫唯美的爱情童话在现代上演。",
        episodes: 75,
        duration: "每集3分钟",
        totalDuration: "3.75小时",
        releaseDate: "2024-10",
        status: "完结",
        
        director: "李安",
        screenwriter: "简奥斯汀",
        cast: ["胡歌", "林依晨", "霍建华"],
        production: "皇家影视",
        
        tokenPrice: 112, // SUK
        tokenPriceUSD: 1.12,
        priceChange24h: 4.5,
        initialPrice: 85, // SUK
        totalSupply: 8500000,
        circulatingSupply: 6800000,
        marketCap: 76160000,
        tvl: 62000000,
        tvlUSD: 620000,
        
        apy: 13.5,
        monthlyReturn: 1.13,
        totalRevenue: 11200000,
        revenuePerToken: 1.65,
        
        views: 490000000,
        likes: 41000000,
        comments: 3300000,
        shares: 9500000,
        favorites: 19000000,
        completionRate: 86,
        
        revenueStreams: [
            { source: "平台分成", percentage: 47, amount: 5264000 },
            { source: "广告收入", percentage: 28, amount: 3136000 },
            { source: "付费观看", percentage: 17, amount: 1904000 },
            { source: "衍生授权", percentage: 8, amount: 896000 }
        ]
    },
    
    // ========== 娱乐圈类 ==========
    "15": {
        id: 15,
        title: "巨星的隐婚妻子",
        englishTitle: "Superstar's Secret Wife",
        category: "entertainment",
        categoryName: "娱乐圈",
        tags: ["明星", "娱乐圈", "隐婚", "甜宠"],
        rating: 9.1,
        hotLevel: "🔥🔥",
        
        coverImage: "https://www.genspark.ai/api/files/s/89Iidgcr?cache_control=3600",
        
        description: "顶级巨星的秘密妻子身份曝光，娱乐圈震动。从默默无闻到站在聚光灯下，她如何应对流言蜚语？真爱能否战胜名利场的考验？",
        episodes: 85,
        duration: "每集3分钟",
        totalDuration: "4.25小时",
        releaseDate: "2024-09",
        status: "完结",
        
        director: "冯小刚",
        screenwriter: "刘震云",
        cast: ["黄晓明", "Angelababy", "陈赫"],
        production: "星光影业",
        
        tokenPrice: 128, // SUK
        tokenPriceUSD: 1.28,
        priceChange24h: 6.2,
        initialPrice: 95, // SUK
        totalSupply: 10000000,
        circulatingSupply: 8000000,
        marketCap: 102400000,
        tvl: 78000000,
        tvlUSD: 780000,
        
        apy: 15.2,
        monthlyReturn: 1.27,
        totalRevenue: 12800000,
        revenuePerToken: 1.60,
        
        views: 670000000,
        likes: 56000000,
        comments: 4400000,
        shares: 14000000,
        favorites: 26000000,
        completionRate: 89,
        
        revenueStreams: [
            { source: "平台分成", percentage: 45, amount: 5760000 },
            { source: "广告收入", percentage: 30, amount: 3840000 },
            { source: "付费观看", percentage: 18, amount: 2304000 },
            { source: "衍生授权", percentage: 7, amount: 896000 }
        ]
    }
};

// 辅助函数
function getDramaById(id) {
    return reelShortDramas[id] || null;
}

function getDramasByCategory(category) {
    return Object.values(reelShortDramas).filter(drama => drama.category === category);
}

function getAllDramas() {
    return Object.values(reelShortDramas);
}

function getTopDramas(limit = 5) {
    return getAllDramas()
        .sort((a, b) => b.rating - a.rating)
        .slice(0, limit);
}

function getHotDramas(limit = 5) {
    return getAllDramas()
        .sort((a, b) => b.views - a.views)
        .slice(0, limit);
}

function getTotalTVL() {
    return getAllDramas().reduce((sum, drama) => sum + drama.tvl, 0);
}

function getAverageAPY() {
    const dramas = getAllDramas();
    const totalAPY = dramas.reduce((sum, drama) => sum + drama.apy, 0);
    return (totalAPY / dramas.length).toFixed(1);
}

function getTotalViews() {
    return getAllDramas().reduce((sum, drama) => sum + drama.views, 0);
}

function formatSUK(amount) {
    if (amount >= 100000000) {
        return `${(amount / 100000000).toFixed(1)}亿`;
    } else if (amount >= 10000) {
        return `${(amount / 10000).toFixed(0)}万`;
    }
    return amount.toLocaleString();
}

function formatViews(views) {
    if (views >= 100000000) {
        return `${(views / 100000000).toFixed(1)}亿`;
    } else if (views >= 10000) {
        return `${(views / 10000).toFixed(0)}万`;
    }
    return views.toLocaleString();
}

// 导出
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        dramaCategories,
        reelShortDramas,
        getDramaById,
        getDramasByCategory,
        getAllDramas,
        getTopDramas,
        getHotDramas,
        getTotalTVL,
        getAverageAPY,
        getTotalViews,
        formatSUK,
        formatViews
    };
}
