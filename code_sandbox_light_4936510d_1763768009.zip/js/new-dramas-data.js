/**
 * SUK Protocol - 新增剧集数据
 * 2025-11-16 新增19部热门短剧
 * 代币计价: 1 SUK = $0.01 USD
 */

const newDramasData = {
    // 剧集20: 这个太子有点狂
    "20": {
        id: 20,
        title: "这个太子有点狂",
        englishTitle: "The Wild Crown Prince",
        genre: "古装喜剧",
        tags: ["古装", "喜剧", "穿越", "轻松"],
        rating: 9.1,
        
        videoUrl: "https://example.com/videos/wild-prince.mp4",
        coverImage: "https://example.com/covers/wild-prince.jpg",
        
        description: "现代灵魂穿越成为古代太子，凭借现代思维玩转朝堂，用幽默化解危机，用智慧改变王朝命运。一个不按常理出牌的太子，带你领略不一样的古代宫廷生活。",
        episodes: 70,
        duration: "每集5分钟",
        releaseDate: "2024-11",
        status: "热播中",
        
        director: "刘天华",
        screenwriter: "陈若愚",
        cast: ["赵逸凡", "李梦瑶", "王浩天"],
        production: "天下影视",
        
        tokenPrice: 110,
        tokenPriceUSD: 1.10,
        initialPrice: 90,
        totalSupply: 9000000,
        circulatingSupply: 6500000,
        tvl: 71500000,
        tvlUSD: 715000,
        
        apy: 16.5,
        monthlyReturn: 1.38,
        totalRevenue: 10800000,
        revenuePerToken: 1.66,
        
        views: 520000000,
        likes: 42000000,
        comments: 3200000,
        shares: 11000000,
        
        revenueStreams: [
            { source: "平台分成", percentage: 43, amount: 4644000 },
            { source: "广告收入", percentage: 32, amount: 3456000 },
            { source: "付费观看", percentage: 16, amount: 1728000 },
            { source: "衍生授权", percentage: 9, amount: 972000 }
        ],
        
        holders: [
            { rank: 1, address: "0x1a2b...3c4d", percentage: 11.5, amount: 747500 },
            { rank: 2, address: "0x5e6f...7g8h", percentage: 9.2, amount: 598000 },
            { rank: 3, address: "0x9i0j...1k2l", percentage: 7.1, amount: 461500 }
        ],
        
        earningsHistory: [
            { date: "2024-11", amount: 360000, perToken: 0.036, status: "pending" },
            { date: "2024-10", amount: 395000, perToken: 0.0395, status: "claimed" }
        ],
        
        priceHistory: [
            { date: "2024-10-20", price: 90 },
            { date: "2024-10-27", price: 95 },
            { date: "2024-11-03", price: 100 },
            { date: "2024-11-10", price: 105 },
            { date: "2024-11-15", price: 110 }
        ]
    },

    // 剧集21: 慕少娇妻的秘密
    "21": {
        id: 21,
        title: "慕少娇妻的秘密",
        englishTitle: "The Secret of Young Master Mu's Wife",
        genre: "豪门虐恋",
        tags: ["豪门", "虐恋", "甜宠", "逆袭"],
        rating: 9.3,
        
        videoUrl: "https://example.com/videos/mu-wife-secret.mp4",
        coverImage: "https://example.com/covers/mu-wife-secret.jpg",
        
        description: "隐藏身份嫁入豪门的女主，在重重考验中逐渐展露真实实力。与冷酷慕少从误会到相爱的虐心甜蜜之旅，揭开层层谜团，上演豪门爱恨情仇。",
        episodes: 85,
        duration: "每集5分钟",
        releaseDate: "2024-10",
        status: "完结",
        
        director: "周雨晴",
        screenwriter: "林诗雅",
        cast: ["慕辰宇", "苏晓晴", "江浩然"],
        production: "星耀传媒",
        
        tokenPrice: 132,
        tokenPriceUSD: 1.32,
        initialPrice: 105,
        totalSupply: 10500000,
        circulatingSupply: 7850000,
        tvl: 103620000,
        tvlUSD: 1036200,
        
        apy: 17.2,
        monthlyReturn: 1.43,
        totalRevenue: 13800000,
        revenuePerToken: 1.76,
        
        views: 650000000,
        likes: 52000000,
        comments: 4100000,
        shares: 14500000,
        
        revenueStreams: [
            { source: "平台分成", percentage: 46, amount: 6348000 },
            { source: "广告收入", percentage: 29, amount: 4002000 },
            { source: "付费观看", percentage: 17, amount: 2346000 },
            { source: "衍生授权", percentage: 8, amount: 1104000 }
        ]
    },

    // 剧集22: 千禧商王
    "22": {
        id: 22,
        title: "千禧商王",
        englishTitle: "Millennium Business King",
        genre: "都市商战",
        tags: ["商战", "创业", "逆袭", "励志"],
        rating: 9.4,
        
        videoUrl: "https://example.com/videos/business-king.mp4",
        coverImage: "https://example.com/covers/business-king.jpg",
        
        description: "从底层打工仔到商业帝国之主，见证一代商业天才的崛起之路。精彩商战对决，智慧与胆识并存，展现新时代商业精英的传奇故事。",
        episodes: 90,
        duration: "每集6分钟",
        releaseDate: "2024-09",
        status: "完结",
        
        director: "张建国",
        screenwriter: "李商业",
        cast: ["沈傲天", "叶紫萱", "钱多多"],
        production: "商道影业",
        
        tokenPrice: 145,
        tokenPriceUSD: 1.45,
        initialPrice: 115,
        totalSupply: 11500000,
        circulatingSupply: 8900000,
        tvl: 129050000,
        tvlUSD: 1290500,
        
        apy: 18.9,
        monthlyReturn: 1.58,
        totalRevenue: 16500000,
        revenuePerToken: 1.85,
        
        views: 780000000,
        likes: 61000000,
        comments: 5200000,
        shares: 17800000
    },

    // 剧集23: 穿越后得到了泼天富贵
    "23": {
        id: 23,
        title: "穿越后得到了泼天富贵",
        englishTitle: "Transmigrated Into Unimaginable Wealth",
        genre: "古装穿越",
        tags: ["穿越", "古装", "搞笑", "爽文"],
        rating: 9.0,
        
        videoUrl: "https://example.com/videos/wealth-transmigration.mp4",
        coverImage: "https://example.com/covers/wealth-transmigration.jpg",
        
        description: "现代人穿越古代，意外继承富可敌国的家业。用现代思维玩转古代商业，开启躺赢人生。轻松搞笑，爽感十足的穿越爽剧。",
        episodes: 75,
        duration: "每集5分钟",
        releaseDate: "2024-11",
        status: "热播中",
        
        director: "王富贵",
        screenwriter: "钱多多",
        cast: ["李逍遥", "赵灵儿", "林月如"],
        production: "富贵影视",
        
        tokenPrice: 118,
        tokenPriceUSD: 1.18,
        initialPrice: 95,
        totalSupply: 9500000,
        circulatingSupply: 7100000,
        tvl: 83780000,
        tvlUSD: 837800,
        
        apy: 16.8,
        monthlyReturn: 1.40,
        totalRevenue: 12200000,
        revenuePerToken: 1.71,
        
        views: 590000000,
        likes: 48000000,
        comments: 3500000,
        shares: 13200000
    },

    // 剧集24: 女总裁的绝世保镖
    "24": {
        id: 24,
        title: "女总裁的绝世保镖",
        englishTitle: "The Peerless Bodyguard of Female CEO",
        genre: "都市爽文",
        tags: ["都市", "保镖", "甜宠", "打脸"],
        rating: 9.2,
        
        videoUrl: "https://example.com/videos/ceo-bodyguard.mp4",
        coverImage: "https://example.com/covers/ceo-bodyguard.jpg",
        
        description: "身怀绝技的神秘保镖，守护冰山女总裁的安全。在危机四伏的商业世界中，用实力打脸小人，用真心融化冰山。动作与爱情完美结合。",
        episodes: 80,
        duration: "每集5分钟",
        releaseDate: "2024-10",
        status: "完结",
        
        director: "陈大威",
        screenwriter: "林保镖",
        cast: ["秦天", "冷艳冰", "张小人"],
        production: "威龙影视",
        
        tokenPrice: 128,
        tokenPriceUSD: 1.28,
        initialPrice: 100,
        totalSupply: 10000000,
        circulatingSupply: 7600000,
        tvl: 97280000,
        tvlUSD: 972800,
        
        apy: 17.5,
        monthlyReturn: 1.46,
        totalRevenue: 13500000,
        revenuePerToken: 1.78,
        
        views: 620000000,
        likes: 50000000,
        comments: 3800000,
        shares: 13800000
    },

    // 剧集25: 双世渔歌
    "25": {
        id: 25,
        title: "双世渔歌",
        englishTitle: "Fisher's Song of Two Worlds",
        genre: "古装奇幻",
        tags: ["古装", "奇幻", "浪漫", "双世"],
        rating: 9.1,
        
        videoUrl: "https://example.com/videos/fisher-song.mp4",
        coverImage: "https://example.com/covers/fisher-song.jpg",
        
        description: "穿梭于两个世界的渔家女子，在现代与古代之间寻找真爱与归宿。唯美的画面，动人的爱情，编织出一曲浪漫的双世之歌。",
        episodes: 65,
        duration: "每集6分钟",
        releaseDate: "2024-10",
        status: "完结",
        
        director: "海文",
        screenwriter: "浪涛",
        cast: ["渔小渔", "陆天明", "水灵儿"],
        production: "海天影视",
        
        tokenPrice: 105,
        tokenPriceUSD: 1.05,
        initialPrice: 85,
        totalSupply: 8500000,
        circulatingSupply: 6400000,
        tvl: 67200000,
        tvlUSD: 672000,
        
        apy: 15.8,
        monthlyReturn: 1.32,
        totalRevenue: 10200000,
        revenuePerToken: 1.59,
        
        views: 480000000,
        likes: 39000000,
        comments: 2900000,
        shares: 10500000
    },

    // 剧集26: 天降咒术师
    "26": {
        id: 26,
        title: "天降咒术师",
        englishTitle: "The Descended Spell Master",
        genre: "玄幻修仙",
        tags: ["玄幻", "修仙", "热血", "逆袭"],
        rating: 9.3,
        
        videoUrl: "https://example.com/videos/spell-master.mp4",
        coverImage: "https://example.com/covers/spell-master.jpg",
        
        description: "天降异象，咒术师觉醒。从废柴到巅峰，用咒术改写命运。热血修仙，惊心动魄的战斗，展现咒术的神秘力量。",
        episodes: 88,
        duration: "每集5分钟",
        releaseDate: "2024-09",
        status: "完结",
        
        director: "玄天子",
        screenwriter: "咒法师",
        cast: ["叶咒", "灵月", "魔尊"],
        production: "玄幻世界",
        
        tokenPrice: 136,
        tokenPriceUSD: 1.36,
        initialPrice: 110,
        totalSupply: 11000000,
        circulatingSupply: 8200000,
        tvl: 111520000,
        tvlUSD: 1115200,
        
        apy: 18.2,
        monthlyReturn: 1.52,
        totalRevenue: 15000000,
        revenuePerToken: 1.83,
        
        views: 720000000,
        likes: 58000000,
        comments: 4800000,
        shares: 16500000
    },

    // 剧集27: 圣王神婿
    "27": {
        id: 27,
        title: "圣王神婿",
        englishTitle: "The Divine Son-in-Law",
        genre: "都市逆袭",
        tags: ["都市", "逆袭", "装逼打脸", "爽文"],
        rating: 9.0,
        
        videoUrl: "https://example.com/videos/divine-son-in-law.mp4",
        coverImage: "https://example.com/covers/divine-son-in-law.jpg",
        
        description: "隐藏身份的圣王下凡，成为小家族的上门女婿。面对嘲讽和欺凌，逐步展露真实实力，打脸所有看不起他的人。",
        episodes: 92,
        duration: "每集5分钟",
        releaseDate: "2024-10",
        status: "完结",
        
        director: "圣天",
        screenwriter: "王者归来",
        cast: ["叶圣", "林若雪", "张狂"],
        production: "圣王影业",
        
        tokenPrice: 124,
        tokenPriceUSD: 1.24,
        initialPrice: 98,
        totalSupply: 9800000,
        circulatingSupply: 7350000,
        tvl: 91140000,
        tvlUSD: 911400,
        
        apy: 17.0,
        monthlyReturn: 1.42,
        totalRevenue: 12800000,
        revenuePerToken: 1.74,
        
        views: 610000000,
        likes: 49500000,
        comments: 3700000,
        shares: 13500000
    },

    // 剧集28: 大师兄为何不娶我
    "28": {
        id: 28,
        title: "大师兄为何不娶我",
        englishTitle: "Why Won't Senior Brother Marry Me",
        genre: "古装爱情",
        tags: ["古装", "爱情", "师徒", "纯爱"],
        rating: 9.2,
        
        videoUrl: "https://example.com/videos/senior-brother.mp4",
        coverImage: "https://example.com/covers/senior-brother.jpg",
        
        description: "痴情师妹追爱高冷大师兄，从懵懂到坚定的爱情之旅。清新脱俗的师门恋情，纯真动人的爱情故事，治愈系古装甜宠剧。",
        episodes: 70,
        duration: "每集5分钟",
        releaseDate: "2024-11",
        status: "热播中",
        
        director: "云梦",
        screenwriter: "仙侠笔",
        cast: ["慕容云", "苏小小", "玄青"],
        production: "仙侠影视",
        
        tokenPrice: 112,
        tokenPriceUSD: 1.12,
        initialPrice: 90,
        totalSupply: 9000000,
        circulatingSupply: 6750000,
        tvl: 75600000,
        tvlUSD: 756000,
        
        apy: 16.3,
        monthlyReturn: 1.36,
        totalRevenue: 11000000,
        revenuePerToken: 1.63,
        
        views: 550000000,
        likes: 44000000,
        comments: 3300000,
        shares: 12000000
    },

    // 剧集29: 特工凤凰
    "29": {
        id: 29,
        title: "特工凤凰",
        englishTitle: "Agent Phoenix",
        genre: "谍战悬疑",
        tags: ["谍战", "悬疑", "动作", "烧脑"],
        rating: 9.4,
        
        videoUrl: "https://example.com/videos/agent-phoenix.mp4",
        coverImage: "https://example.com/covers/agent-phoenix.jpg",
        
        description: "顶级女特工代号凤凰，潜伏敌营执行绝密任务。智斗敌人，层层揭秘，惊心动魄的谍战故事，每一步都是生死博弈。",
        episodes: 85,
        duration: "每集6分钟",
        releaseDate: "2024-09",
        status: "完结",
        
        director: "战鹰",
        screenwriter: "谍影",
        cast: ["凤凰", "暗影", "冷锋"],
        production: "战狼影视",
        
        tokenPrice: 142,
        tokenPriceUSD: 1.42,
        initialPrice: 115,
        totalSupply: 11500000,
        circulatingSupply: 8600000,
        tvl: 122120000,
        tvlUSD: 1221200,
        
        apy: 18.6,
        monthlyReturn: 1.55,
        totalRevenue: 16200000,
        revenuePerToken: 1.88,
        
        views: 760000000,
        likes: 60000000,
        comments: 5000000,
        shares: 17200000
    },

    // 剧集30: 豪门千金的腹黑保镖
    "30": {
        id: 30,
        title: "豪门千金的腹黑保镖",
        englishTitle: "The Cunning Bodyguard of Wealthy Heiress",
        genre: "都市甜宠",
        tags: ["都市", "甜宠", "豪门", "保镖"],
        rating: 9.1,
        
        videoUrl: "https://example.com/videos/cunning-bodyguard.mp4",
        coverImage: "https://example.com/covers/cunning-bodyguard.jpg",
        
        description: "表面呆萌实则腹黑的保镖，守护任性千金小姐。一黑一白的反差萌，欢喜冤家的甜蜜互动，上演豪门爱情喜剧。",
        episodes: 78,
        duration: "每集5分钟",
        releaseDate: "2024-10",
        status: "完结",
        
        director: "欢喜",
        screenwriter: "甜蜜",
        cast: ["黑羽", "白雪", "灰狼"],
        production: "欢乐影视",
        
        tokenPrice: 120,
        tokenPriceUSD: 1.20,
        initialPrice: 95,
        totalSupply: 9500000,
        circulatingSupply: 7200000,
        tvl: 86400000,
        tvlUSD: 864000,
        
        apy: 16.9,
        monthlyReturn: 1.41,
        totalRevenue: 12400000,
        revenuePerToken: 1.72,
        
        views: 580000000,
        likes: 47000000,
        comments: 3500000,
        shares: 12800000
    },

    // 剧集31: 许你倾世温柔
    "31": {
        id: 31,
        title: "许你倾世温柔",
        englishTitle: "Promise You Tender Love",
        genre: "现代浪漫",
        tags: ["浪漫", "治愈", "纯爱", "温馨"],
        rating: 9.3,
        
        videoUrl: "https://example.com/videos/tender-love.mp4",
        coverImage: "https://example.com/covers/tender-love.jpg",
        
        description: "温柔医生与坚强女孩的治愈系爱情故事。用温柔化解创伤,用爱意填满空白。最纯粹的爱情，最温暖的陪伴。",
        episodes: 72,
        duration: "每集5分钟",
        releaseDate: "2024-11",
        status: "热播中",
        
        director: "温暖",
        screenwriter: "柔情",
        cast: ["许温柔", "林倾城", "陈治愈"],
        production: "温情影视",
        
        tokenPrice: 115,
        tokenPriceUSD: 1.15,
        initialPrice: 92,
        totalSupply: 9200000,
        circulatingSupply: 6900000,
        tvl: 79350000,
        tvlUSD: 793500,
        
        apy: 16.5,
        monthlyReturn: 1.38,
        totalRevenue: 11500000,
        revenuePerToken: 1.67,
        
        views: 560000000,
        likes: 45500000,
        comments: 3400000,
        shares: 12300000
    },

    // 剧集32: 丑妻的逆袭
    "32": {
        id: 32,
        title: "丑妻的逆袭",
        englishTitle: "The Ugly Wife's Comeback",
        genre: "都市励志",
        tags: ["励志", "逆袭", "变美", "复仇"],
        rating: 9.0,
        
        videoUrl: "https://example.com/videos/ugly-wife-comeback.mp4",
        coverImage: "https://example.com/covers/ugly-wife-comeback.jpg",
        
        description: "被嫌弃的丑妻华丽蜕变，从自卑到自信的完美逆袭。打脸渣男，惊艳所有人，证明真正的美丽来自内心的强大。",
        episodes: 82,
        duration: "每集5分钟",
        releaseDate: "2024-10",
        status: "完结",
        
        director: "华丽",
        screenwriter: "逆袭",
        cast: ["丑小丫", "渣男", "真爱"],
        production: "蜕变影视",
        
        tokenPrice: 108,
        tokenPriceUSD: 1.08,
        initialPrice: 88,
        totalSupply: 8800000,
        circulatingSupply: 6650000,
        tvl: 71820000,
        tvlUSD: 718200,
        
        apy: 15.9,
        monthlyReturn: 1.33,
        totalRevenue: 10600000,
        revenuePerToken: 1.59,
        
        views: 530000000,
        likes: 43000000,
        comments: 3200000,
        shares: 11500000
    },

    // 剧集33: 傅少的私宠罪妻
    "33": {
        id: 33,
        title: "傅少的私宠罪妻",
        englishTitle: "Young Master Fu's Guilty Wife",
        genre: "豪门虐恋",
        tags: ["豪门", "虐恋", "追妻", "甜虐"],
        rating: 9.2,
        
        videoUrl: "https://example.com/videos/fu-guilty-wife.mp4",
        coverImage: "https://example.com/covers/fu-guilty-wife.jpg",
        
        description: "误会让她成为罪妻，真相让他悔不当初。豪门傅少的追妻火葬场，虐心到甜蜜的情感逆转，见证爱情的救赎之路。",
        episodes: 86,
        duration: "每集5分钟",
        releaseDate: "2024-09",
        status: "完结",
        
        director: "虐心",
        screenwriter: "甜蜜",
        cast: ["傅寒夜", "苏清", "白月光"],
        production: "虐恋影视",
        
        tokenPrice: 130,
        tokenPriceUSD: 1.30,
        initialPrice: 105,
        totalSupply: 10500000,
        circulatingSupply: 7900000,
        tvl: 102700000,
        tvlUSD: 1027000,
        
        apy: 17.4,
        monthlyReturn: 1.45,
        totalRevenue: 14200000,
        revenuePerToken: 1.80,
        
        views: 640000000,
        likes: 51500000,
        comments: 4000000,
        shares: 14000000
    },

    // 剧集34: 回到古代送外卖
    "34": {
        id: 34,
        title: "回到古代送外卖",
        englishTitle: "Delivering Food in Ancient Times",
        genre: "古装喜剧",
        tags: ["古装", "喜剧", "穿越", "美食"],
        rating: 8.9,
        
        videoUrl: "https://example.com/videos/ancient-delivery.mp4",
        coverImage: "https://example.com/covers/ancient-delivery.jpg",
        
        description: "现代外卖小哥穿越古代，用外卖改变历史。搞笑的穿越经历，美食的奇妙碰撞，开启古代外卖第一人的传奇故事。",
        episodes: 68,
        duration: "每集5分钟",
        releaseDate: "2024-11",
        status: "热播中",
        
        director: "搞笑王",
        screenwriter: "美食家",
        cast: ["送外卖", "古代人", "皇帝"],
        production: "搞笑影视",
        
        tokenPrice: 102,
        tokenPriceUSD: 1.02,
        initialPrice: 82,
        totalSupply: 8200000,
        circulatingSupply: 6200000,
        tvl: 63240000,
        tvlUSD: 632400,
        
        apy: 15.5,
        monthlyReturn: 1.29,
        totalRevenue: 9800000,
        revenuePerToken: 1.58,
        
        views: 470000000,
        likes: 38000000,
        comments: 2800000,
        shares: 10200000
    },

    // 剧集35: 契妻的诱惑
    "35": {
        id: 35,
        title: "契妻的诱惑",
        englishTitle: "The Contract Wife's Temptation",
        genre: "都市言情",
        tags: ["言情", "契约", "假戏真做", "甜宠"],
        rating: 9.1,
        
        videoUrl: "https://example.com/videos/contract-wife.mp4",
        coverImage: "https://example.com/covers/contract-wife.jpg",
        
        description: "契约婚姻假戏真做，冷酷总裁逐渐沦陷。从利益关系到真心相爱，见证假结婚到真感情的甜蜜转变。",
        episodes: 76,
        duration: "每集5分钟",
        releaseDate: "2024-10",
        status: "完结",
        
        director: "契约",
        screenwriter: "真爱",
        cast: ["冷峻", "甜心", "闺蜜"],
        production: "言情影视",
        
        tokenPrice: 122,
        tokenPriceUSD: 1.22,
        initialPrice: 98,
        totalSupply: 9800000,
        circulatingSupply: 7400000,
        tvl: 90280000,
        tvlUSD: 902800,
        
        apy: 17.1,
        monthlyReturn: 1.43,
        totalRevenue: 12600000,
        revenuePerToken: 1.70,
        
        views: 600000000,
        likes: 48500000,
        comments: 3600000,
        shares: 13200000
    },

    // 剧集36: 狂飙神王
    "36": {
        id: 36,
        title: "狂飙神王",
        englishTitle: "Raging God King",
        genre: "玄幻热血",
        tags: ["玄幻", "热血", "战斗", "称王"],
        rating: 9.3,
        
        videoUrl: "https://example.com/videos/raging-god-king.mp4",
        coverImage: "https://example.com/covers/raging-god-king.jpg",
        
        description: "热血少年从废柴到神王的逆袭之路。狂飙突进，一路称王，震撼的战斗场面，燃爆的修炼历程，见证神王的诞生。",
        episodes: 95,
        duration: "每集5分钟",
        releaseDate: "2024-09",
        status: "完结",
        
        director: "热血",
        screenwriter: "称王",
        cast: ["狂少年", "神女", "魔尊"],
        production: "热血影视",
        
        tokenPrice: 138,
        tokenPriceUSD: 1.38,
        initialPrice: 112,
        totalSupply: 11200000,
        circulatingSupply: 8400000,
        tvl: 115920000,
        tvlUSD: 1159200,
        
        apy: 18.3,
        monthlyReturn: 1.53,
        totalRevenue: 15600000,
        revenuePerToken: 1.86,
        
        views: 740000000,
        likes: 59000000,
        comments: 4900000,
        shares: 16800000
    },

    // 剧集37: 赤焰神童
    "37": {
        id: 37,
        title: "赤焰神童",
        englishTitle: "The Crimson Flame Prodigy",
        genre: "玄幻修仙",
        tags: ["玄幻", "修仙", "天才", "热血"],
        rating: 9.2,
        
        videoUrl: "https://example.com/videos/crimson-flame.mp4",
        coverImage: "https://example.com/covers/crimson-flame.jpg",
        
        description: "天赋异禀的赤焰神童，掌控烈火之力纵横修仙界。从稚嫩到成熟，从弱小到强大，展现天才的成长传奇。",
        episodes: 84,
        duration: "每集5分钟",
        releaseDate: "2024-10",
        status: "完结",
        
        director: "烈焰",
        screenwriter: "神童",
        cast: ["赤焰", "冰灵", "雷霆"],
        production: "修仙世界",
        
        tokenPrice: 126,
        tokenPriceUSD: 1.26,
        initialPrice: 102,
        totalSupply: 10200000,
        circulatingSupply: 7650000,
        tvl: 96390000,
        tvlUSD: 963900,
        
        apy: 17.3,
        monthlyReturn: 1.44,
        totalRevenue: 13200000,
        revenuePerToken: 1.73,
        
        views: 630000000,
        likes: 51000000,
        comments: 3900000,
        shares: 13800000
    },

    // 剧集38: 我的合约恋人
    "38": {
        id: 38,
        title: "我的合约恋人",
        englishTitle: "My Contract Lover",
        genre: "都市言情",
        tags: ["言情", "合约", "甜宠", "职场"],
        rating: 9.0,
        
        videoUrl: "https://example.com/videos/contract-lover.mp4",
        coverImage: "https://example.com/covers/contract-lover.jpg",
        
        description: "职场精英的合约恋爱游戏，假装情侣逐渐动真情。从演戏到真爱，从理智到沦陷，展现都市男女的情感纠葛。",
        episodes: 74,
        duration: "每集5分钟",
        releaseDate: "2024-11",
        status: "热播中",
        
        director: "职场",
        screenwriter: "恋爱",
        cast: ["职场女", "精英男", "情敌"],
        production: "都市影视",
        
        tokenPrice: 114,
        tokenPriceUSD: 1.14,
        initialPrice: 91,
        totalSupply: 9100000,
        circulatingSupply: 6850000,
        tvl: 78090000,
        tvlUSD: 780900,
        
        apy: 16.4,
        monthlyReturn: 1.37,
        totalRevenue: 11200000,
        revenuePerToken: 1.64,
        
        views: 540000000,
        likes: 44500000,
        comments: 3300000,
        shares: 11800000
    }
};

// 导出数据
if (typeof module !== 'undefined' && module.exports) {
    module.exports = newDramasData;
}
