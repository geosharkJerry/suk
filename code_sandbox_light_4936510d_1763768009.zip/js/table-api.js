// ========================================
// SUK Protocol - Table API 管理器
// 使用项目提供的 RESTful Table API
// ========================================

const TableAPI = {
    currentTable: 'dramas',
    currentPage: 1,
    pageLimit: 10,
    totalRecords: 0,
    currentData: [],
    editingId: null,

    // 表格配置
    tables: {
        dramas: {
            name: '短剧数据',
            fields: [
                { name: 'id', label: 'ID', type: 'text', readonly: true },
                { name: 'title', label: '剧名', type: 'text', required: true },
                { name: 'description', label: '简介', type: 'textarea', required: true },
                { name: 'category', label: '分类', type: 'text', required: true },
                { name: 'episodes', label: '集数', type: 'number', required: true },
                { name: 'price', label: '代币价格', type: 'number', required: true },
                { name: 'apy', label: 'APY (%)', type: 'number', required: true },
                { name: 'tvl', label: 'TVL (¥)', type: 'number', required: true },
                { name: 'views', label: '播放量', type: 'number' },
                { name: 'status', label: '状态', type: 'select', options: ['active', 'pending', 'archived'] }
            ]
        },
        investments: {
            name: '投资记录',
            fields: [
                { name: 'id', label: 'ID', type: 'text', readonly: true },
                { name: 'userId', label: '用户ID', type: 'text', required: true },
                { name: 'dramaId', label: '短剧ID', type: 'text', required: true },
                { name: 'amount', label: '投资金额', type: 'number', required: true },
                { name: 'tokens', label: '代币数量', type: 'number', required: true },
                { name: 'price', label: '购买价格', type: 'number', required: true },
                { name: 'timestamp', label: '时间戳', type: 'datetime', readonly: true }
            ]
        },
        revenues: {
            name: '收益记录',
            fields: [
                { name: 'id', label: 'ID', type: 'text', readonly: true },
                { name: 'dramaId', label: '短剧ID', type: 'text', required: true },
                { name: 'source', label: '收益来源', type: 'select', options: ['platform', 'advertising', 'licensing', 'overseas'], required: true },
                { name: 'amount', label: '金额', type: 'number', required: true },
                { name: 'date', label: '日期', type: 'date', required: true },
                { name: 'distributed', label: '已分配', type: 'checkbox' }
            ]
        },
        users: {
            name: '用户数据',
            fields: [
                { name: 'id', label: 'ID', type: 'text', readonly: true },
                { name: 'username', label: '用户名', type: 'text', required: true },
                { name: 'email', label: '邮箱', type: 'email', required: true },
                { name: 'walletAddress', label: '钱包地址', type: 'text' },
                { name: 'totalInvested', label: '总投资额', type: 'number' },
                { name: 'totalEarnings', label: '总收益', type: 'number' },
                { name: 'verified', label: '已认证', type: 'checkbox' }
            ]
        }
    },

    // 初始化
    init() {
        this.loadTable(this.currentTable);
        
        // 检查用户登录
        if (!AuthManager.isLoggedIn()) {
            showNotification('请先登录', 'warning');
            setTimeout(() => {
                window.location.href = 'auth.html';
            }, 2000);
        }
    },

    // 加载表格数据
    async loadTable(tableName) {
        this.currentTable = tableName;
        this.currentPage = 1;
        await this.fetchData();
    },

    // 获取数据
    async fetchData() {
        try {
            const searchQuery = document.getElementById('search-input')?.value || '';
            
            const params = new URLSearchParams({
                page: this.currentPage,
                limit: this.pageLimit,
                search: searchQuery
            });

            // ⚠️ 注意：这是模拟 API 调用
            // 实际环境中应使用：const response = await fetch(`tables/${this.currentTable}?${params}`);
            
            const mockData = this.getMockData(this.currentTable, this.currentPage, this.pageLimit, searchQuery);
            
            this.currentData = mockData.data;
            this.totalRecords = mockData.total;
            
            this.renderTable();
            this.updatePagination();
            
        } catch (error) {
            console.error('❌ 加载数据失败:', error);
            showNotification('加载数据失败', 'error');
        }
    },

    // 获取模拟数据
    getMockData(tableName, page, limit, search) {
        // 从 LocalStorage 获取或生成模拟数据
        const storageKey = `suk_table_${tableName}`;
        let allData = JSON.parse(localStorage.getItem(storageKey) || '[]');
        
        // 如果没有数据，生成一些
        if (allData.length === 0) {
            allData = this.generateMockData(tableName);
            localStorage.setItem(storageKey, JSON.stringify(allData));
        }

        // 搜索过滤
        let filteredData = allData;
        if (search) {
            filteredData = allData.filter(item => {
                return Object.values(item).some(val => 
                    String(val).toLowerCase().includes(search.toLowerCase())
                );
            });
        }

        // 分页
        const startIndex = (page - 1) * limit;
        const endIndex = startIndex + limit;
        const paginatedData = filteredData.slice(startIndex, endIndex);

        return {
            data: paginatedData,
            total: filteredData.length,
            page: page,
            limit: limit
        };
    },

    // 生成模拟数据
    generateMockData(tableName) {
        const data = [];
        const count = 15;

        switch (tableName) {
            case 'dramas':
                const categories = ['都市爱情', '穿越时空', '悬疑推理', '古装宫廷', '科幻未来'];
                for (let i = 1; i <= count; i++) {
                    data.push({
                        id: `drama_${Date.now()}_${i}`,
                        title: `热门短剧 ${i}`,
                        description: `这是一部精彩的短剧作品，讲述了...`,
                        category: categories[Math.floor(Math.random() * categories.length)],
                        episodes: Math.floor(Math.random() * 100) + 20,
                        price: (Math.random() * 20 + 5).toFixed(2),
                        apy: (Math.random() * 15 + 5).toFixed(1),
                        tvl: Math.floor(Math.random() * 10000000) + 1000000,
                        views: Math.floor(Math.random() * 100000000) + 10000000,
                        status: 'active',
                        created_at: Date.now() - (Math.random() * 90 * 24 * 60 * 60 * 1000)
                    });
                }
                break;

            case 'investments':
                for (let i = 1; i <= count; i++) {
                    data.push({
                        id: `inv_${Date.now()}_${i}`,
                        userId: `user_${Math.floor(Math.random() * 100)}`,
                        dramaId: `drama_${Math.floor(Math.random() * 10) + 1}`,
                        amount: (Math.random() * 50000 + 1000).toFixed(2),
                        tokens: Math.floor(Math.random() * 5000) + 100,
                        price: (Math.random() * 20 + 5).toFixed(2),
                        timestamp: Date.now() - (Math.random() * 30 * 24 * 60 * 60 * 1000)
                    });
                }
                break;

            case 'revenues':
                const sources = ['platform', 'advertising', 'licensing', 'overseas'];
                for (let i = 1; i <= count; i++) {
                    data.push({
                        id: `rev_${Date.now()}_${i}`,
                        dramaId: `drama_${Math.floor(Math.random() * 10) + 1}`,
                        source: sources[Math.floor(Math.random() * sources.length)],
                        amount: (Math.random() * 500000 + 50000).toFixed(2),
                        date: new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                        distributed: Math.random() > 0.5
                    });
                }
                break;

            case 'users':
                for (let i = 1; i <= count; i++) {
                    data.push({
                        id: `user_${Date.now()}_${i}`,
                        username: `user${i}`,
                        email: `user${i}@example.com`,
                        walletAddress: `0x${Math.random().toString(16).substr(2, 40)}`,
                        totalInvested: (Math.random() * 100000 + 10000).toFixed(2),
                        totalEarnings: (Math.random() * 20000 + 1000).toFixed(2),
                        verified: Math.random() > 0.3
                    });
                }
                break;
        }

        return data;
    },

    // 渲染表格
    renderTable() {
        const config = this.tables[this.currentTable];
        const thead = document.getElementById('table-head');
        const tbody = document.getElementById('table-body');

        // 渲染表头
        let headerHTML = '<tr>';
        config.fields.slice(0, 6).forEach(field => {
            headerHTML += `<th>${field.label}</th>`;
        });
        headerHTML += '<th>操作</th></tr>';
        thead.innerHTML = headerHTML;

        // 渲染数据
        if (this.currentData.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="${config.fields.length + 1}" style="text-align: center; padding: 60px;">
                        <div class="empty-state">
                            <i class="fas fa-inbox"></i>
                            <h3>暂无数据</h3>
                            <p>点击"添加数据"创建新记录</p>
                        </div>
                    </td>
                </tr>
            `;
            return;
        }

        let bodyHTML = '';
        this.currentData.forEach(row => {
            bodyHTML += '<tr>';
            config.fields.slice(0, 6).forEach(field => {
                let value = row[field.name];
                
                // 格式化显示
                if (field.type === 'datetime' || field.name === 'timestamp') {
                    value = new Date(value).toLocaleString('zh-CN');
                } else if (field.type === 'checkbox') {
                    value = value ? '<i class="fas fa-check" style="color: #4CAF50;"></i>' : '<i class="fas fa-times" style="color: #F44336;"></i>';
                } else if (field.name === 'walletAddress') {
                    value = value ? `${value.slice(0, 6)}...${value.slice(-4)}` : '-';
                } else if (typeof value === 'number' && value > 1000) {
                    value = value.toLocaleString('zh-CN');
                }
                
                bodyHTML += `<td>${value || '-'}</td>`;
            });
            
            bodyHTML += `
                <td>
                    <div class="action-buttons">
                        <button class="btn-icon btn-edit" onclick="TableAPI.editRecord('${row.id}')" title="编辑">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn-icon btn-delete" onclick="TableAPI.deleteRecord('${row.id}')" title="删除">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            `;
            bodyHTML += '</tr>';
        });
        tbody.innerHTML = bodyHTML;
    },

    // 更新分页
    updatePagination() {
        const totalPages = Math.ceil(this.totalRecords / this.pageLimit);
        document.getElementById('page-info').textContent = `第 ${this.currentPage} 页 / 共 ${totalPages} 页 (共 ${this.totalRecords} 条记录)`;
        
        document.getElementById('prev-btn').disabled = this.currentPage === 1;
        document.getElementById('next-btn').disabled = this.currentPage >= totalPages;
    },

    // 添加记录
    async addRecord(data) {
        try {
            // ⚠️ 实际环境中使用 API
            // const response = await fetch(`tables/${this.currentTable}`, {
            //     method: 'POST',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify(data)
            // });

            // 模拟添加
            const storageKey = `suk_table_${this.currentTable}`;
            const allData = JSON.parse(localStorage.getItem(storageKey) || '[]');
            
            const newRecord = {
                id: `${this.currentTable}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                ...data,
                created_at: Date.now(),
                updated_at: Date.now()
            };
            
            allData.unshift(newRecord);
            localStorage.setItem(storageKey, JSON.stringify(allData));
            
            await this.fetchData();
            showNotification('添加成功！', 'success');
            
        } catch (error) {
            console.error('❌ 添加失败:', error);
            showNotification('添加失败', 'error');
        }
    },

    // 更新记录
    async updateRecord(id, data) {
        try {
            // ⚠️ 实际环境中使用 API
            // const response = await fetch(`tables/${this.currentTable}/${id}`, {
            //     method: 'PUT',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify(data)
            // });

            // 模拟更新
            const storageKey = `suk_table_${this.currentTable}`;
            const allData = JSON.parse(localStorage.getItem(storageKey) || '[]');
            
            const index = allData.findIndex(r => r.id === id);
            if (index !== -1) {
                allData[index] = {
                    ...allData[index],
                    ...data,
                    updated_at: Date.now()
                };
                localStorage.setItem(storageKey, JSON.stringify(allData));
            }
            
            await this.fetchData();
            showNotification('更新成功！', 'success');
            
        } catch (error) {
            console.error('❌ 更新失败:', error);
            showNotification('更新失败', 'error');
        }
    },

    // 删除记录
    async deleteRecord(id) {
        if (!confirm('确定要删除这条记录吗？')) {
            return;
        }

        try {
            // ⚠️ 实际环境中使用 API
            // await fetch(`tables/${this.currentTable}/${id}`, { method: 'DELETE' });

            // 模拟删除
            const storageKey = `suk_table_${this.currentTable}`;
            const allData = JSON.parse(localStorage.getItem(storageKey) || '[]');
            
            const filteredData = allData.filter(r => r.id !== id);
            localStorage.setItem(storageKey, JSON.stringify(filteredData));
            
            await this.fetchData();
            showNotification('删除成功！', 'success');
            
        } catch (error) {
            console.error('❌ 删除失败:', error);
            showNotification('删除失败', 'error');
        }
    },

    // 编辑记录
    editRecord(id) {
        const record = this.currentData.find(r => r.id === id);
        if (!record) return;

        this.editingId = id;
        openEditModal(record);
    }
};

// 切换表格
function switchTable(tableName) {
    document.querySelectorAll('.table-tab').forEach(tab => tab.classList.remove('active'));
    event.target.closest('.table-tab').classList.add('active');
    
    TableAPI.loadTable(tableName);
}

// 搜索处理
let searchTimeout;
function handleSearch() {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
        TableAPI.currentPage = 1;
        TableAPI.fetchData();
    }, 500);
}

// 分页
function previousPage() {
    if (TableAPI.currentPage > 1) {
        TableAPI.currentPage--;
        TableAPI.fetchData();
    }
}

function nextPage() {
    const totalPages = Math.ceil(TableAPI.totalRecords / TableAPI.pageLimit);
    if (TableAPI.currentPage < totalPages) {
        TableAPI.currentPage++;
        TableAPI.fetchData();
    }
}

// 打开添加模态框
function openAddModal() {
    TableAPI.editingId = null;
    openEditModal();
}

// 打开编辑模态框
function openEditModal(data = {}) {
    const modal = document.getElementById('edit-modal');
    const title = document.getElementById('modal-title');
    const formFields = document.getElementById('form-fields');
    
    title.textContent = TableAPI.editingId ? '编辑数据' : '添加数据';
    
    const config = TableAPI.tables[TableAPI.currentTable];
    let fieldsHTML = '';
    
    config.fields.forEach(field => {
        if (field.readonly && !TableAPI.editingId) return;
        
        const value = data[field.name] || '';
        const required = field.required ? 'required' : '';
        const disabled = field.readonly ? 'disabled' : '';
        
        fieldsHTML += `<div class="form-group">`;
        fieldsHTML += `<label for="field-${field.name}">${field.label} ${field.required ? '*' : ''}</label>`;
        
        if (field.type === 'textarea') {
            fieldsHTML += `<textarea id="field-${field.name}" class="form-control" ${required} ${disabled}>${value}</textarea>`;
        } else if (field.type === 'select') {
            fieldsHTML += `<select id="field-${field.name}" class="form-control" ${required} ${disabled}>`;
            field.options.forEach(opt => {
                const selected = value === opt ? 'selected' : '';
                fieldsHTML += `<option value="${opt}" ${selected}>${opt}</option>`;
            });
            fieldsHTML += `</select>`;
        } else if (field.type === 'checkbox') {
            const checked = value ? 'checked' : '';
            fieldsHTML += `<input type="checkbox" id="field-${field.name}" ${checked} ${disabled}>`;
        } else {
            fieldsHTML += `<input type="${field.type}" id="field-${field.name}" class="form-control" value="${value}" ${required} ${disabled}>`;
        }
        
        fieldsHTML += `</div>`;
    });
    
    formFields.innerHTML = fieldsHTML;
    modal.classList.add('show');
}

// 关闭模态框
function closeModal() {
    document.getElementById('edit-modal').classList.remove('show');
}

// 表单提交
document.getElementById('edit-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const config = TableAPI.tables[TableAPI.currentTable];
    const formData = {};
    
    config.fields.forEach(field => {
        if (field.readonly && !TableAPI.editingId) return;
        
        const element = document.getElementById(`field-${field.name}`);
        if (!element) return;
        
        if (field.type === 'checkbox') {
            formData[field.name] = element.checked;
        } else if (field.type === 'number') {
            formData[field.name] = parseFloat(element.value) || 0;
        } else {
            formData[field.name] = element.value;
        }
    });
    
    if (TableAPI.editingId) {
        await TableAPI.updateRecord(TableAPI.editingId, formData);
    } else {
        await TableAPI.addRecord(formData);
    }
    
    closeModal();
});

// 页面加载时初始化
window.addEventListener('DOMContentLoaded', () => {
    TableAPI.init();
});
