// SUK Protocol - 多语言国际化系统 (i18n)
// International Language System with Auto Translation

class I18nSystem {
    constructor() {
        this.currentLang = this.getStoredLanguage() || this.detectBrowserLanguage();
        this.translations = window.translations || {};
        this.supportedLanguages = [
            { code: 'zh', name: '中文', flag: '🇨🇳' },
            { code: 'en', name: 'English', flag: '🇺🇸' },
            { code: 'es', name: 'Español', flag: '🇪🇸' },
            { code: 'th', name: 'ไทย', flag: '🇹🇭' },
            { code: 'vi', name: 'Tiếng Việt', flag: '🇻🇳' },
            { code: 'ja', name: '日本語', flag: '🇯🇵' }
        ];
        
        this.init();
    }
    
    // 初始化系统
    init() {
        this.createLanguageSwitcher();
        this.translatePage();
        this.setupEventListeners();
    }
    
    // 检测浏览器语言
    detectBrowserLanguage() {
        const browserLang = navigator.language || navigator.userLanguage;
        const langCode = browserLang.split('-')[0].toLowerCase();
        
        // 检查是否支持该语言
        const supported = this.supportedLanguages.find(lang => lang.code === langCode);
        return supported ? langCode : 'zh'; // 默认中文
    }
    
    // 获取存储的语言
    getStoredLanguage() {
        return localStorage.getItem('sukProtocolLang');
    }
    
    // 保存语言选择
    saveLanguage(langCode) {
        localStorage.setItem('sukProtocolLang', langCode);
    }
    
    // 创建语言切换器UI
    createLanguageSwitcher() {
        // 查找导航栏
        const navContent = document.querySelector('.nav-content');
        if (!navContent) return;
        
        // 创建语言切换器容器
        const langSwitcher = document.createElement('div');
        langSwitcher.className = 'language-switcher';
        langSwitcher.innerHTML = `
            <button class="lang-btn" id="langBtn">
                <span class="lang-flag">${this.getCurrentLanguageFlag()}</span>
                <span class="lang-code">${this.currentLang.toUpperCase()}</span>
                <i class="fas fa-chevron-down"></i>
            </button>
            <div class="lang-dropdown" id="langDropdown">
                ${this.supportedLanguages.map(lang => `
                    <div class="lang-option" data-lang="${lang.code}">
                        <span class="lang-flag">${lang.flag}</span>
                        <span class="lang-name">${lang.name}</span>
                        ${lang.code === this.currentLang ? '<i class="fas fa-check"></i>' : ''}
                    </div>
                `).join('')}
            </div>
        `;
        
        // 插入到导航菜单之前
        const navMenu = navContent.querySelector('.nav-menu');
        if (navMenu) {
            navContent.insertBefore(langSwitcher, navMenu);
        }
        
        // 添加样式
        this.addStyles();
    }
    
    // 获取当前语言的旗帜emoji
    getCurrentLanguageFlag() {
        const lang = this.supportedLanguages.find(l => l.code === this.currentLang);
        return lang ? lang.flag : '🌐';
    }
    
    // 设置事件监听
    setupEventListeners() {
        const langBtn = document.getElementById('langBtn');
        const langDropdown = document.getElementById('langDropdown');
        
        if (langBtn && langDropdown) {
            // 切换下拉菜单
            langBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                langDropdown.classList.toggle('active');
            });
            
            // 选择语言
            const langOptions = langDropdown.querySelectorAll('.lang-option');
            langOptions.forEach(option => {
                option.addEventListener('click', (e) => {
                    const selectedLang = option.getAttribute('data-lang');
                    this.changeLanguage(selectedLang);
                    langDropdown.classList.remove('active');
                });
            });
            
            // 点击外部关闭下拉菜单
            document.addEventListener('click', () => {
                langDropdown.classList.remove('active');
            });
        }
    }
    
    // 切换语言
    changeLanguage(langCode) {
        if (langCode === this.currentLang) return;
        
        this.currentLang = langCode;
        this.saveLanguage(langCode);
        
        // 更新按钮显示
        const langBtn = document.getElementById('langBtn');
        if (langBtn) {
            langBtn.querySelector('.lang-flag').textContent = this.getCurrentLanguageFlag();
            langBtn.querySelector('.lang-code').textContent = langCode.toUpperCase();
        }
        
        // 更新选中状态
        document.querySelectorAll('.lang-option').forEach(option => {
            const checkIcon = option.querySelector('.fa-check');
            if (option.getAttribute('data-lang') === langCode) {
                if (!checkIcon) {
                    option.innerHTML += '<i class="fas fa-check"></i>';
                }
            } else {
                if (checkIcon) {
                    checkIcon.remove();
                }
            }
        });
        
        // 翻译页面
        this.translatePage();
        
        // 更新HTML lang属性
        document.documentElement.lang = this.getLangTag(langCode);
    }
    
    // 获取语言标签
    getLangTag(langCode) {
        const tags = {
            zh: 'zh-CN',
            en: 'en-US',
            es: 'es-ES',
            th: 'th-TH',
            vi: 'vi-VN',
            ja: 'ja-JP'
        };
        return tags[langCode] || 'zh-CN';
    }
    
    // 翻译页面内容
    translatePage() {
        const trans = this.translations[this.currentLang];
        if (!trans) return;
        
        // 翻译所有带有 data-i18n 属性的元素
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            const translation = this.getNestedTranslation(trans, key);
            
            if (translation) {
                // 判断是否为输入框的placeholder
                if (element.hasAttribute('placeholder')) {
                    element.setAttribute('placeholder', translation);
                } else {
                    element.textContent = translation;
                }
            }
        });
        
        // 翻译所有带有 data-i18n-html 属性的元素（支持HTML内容）
        document.querySelectorAll('[data-i18n-html]').forEach(element => {
            const key = element.getAttribute('data-i18n-html');
            const translation = this.getNestedTranslation(trans, key);
            
            if (translation) {
                element.innerHTML = translation;
            }
        });
    }
    
    // 获取嵌套翻译
    getNestedTranslation(obj, path) {
        return path.split('.').reduce((prev, curr) => {
            return prev ? prev[curr] : null;
        }, obj);
    }
    
    // 添加样式
    addStyles() {
        if (document.getElementById('i18n-styles')) return;
        
        const style = document.createElement('style');
        style.id = 'i18n-styles';
        style.textContent = `
            .language-switcher {
                position: relative;
                margin-right: 20px;
                z-index: 1000;
            }
            
            .lang-btn {
                display: flex;
                align-items: center;
                gap: 8px;
                padding: 8px 16px;
                background: rgba(255, 255, 255, 0.1);
                border: 1px solid rgba(255, 255, 255, 0.2);
                border-radius: 8px;
                color: white;
                cursor: pointer;
                font-size: 14px;
                font-weight: 500;
                transition: all 0.3s ease;
            }
            
            .lang-btn:hover {
                background: rgba(255, 255, 255, 0.15);
                border-color: rgba(255, 255, 255, 0.3);
                transform: translateY(-1px);
            }
            
            .lang-flag {
                font-size: 18px;
                line-height: 1;
            }
            
            .lang-code {
                font-weight: 600;
                letter-spacing: 0.5px;
            }
            
            .lang-btn .fa-chevron-down {
                font-size: 10px;
                transition: transform 0.3s ease;
            }
            
            .lang-dropdown.active + .lang-btn .fa-chevron-down {
                transform: rotate(180deg);
            }
            
            .lang-dropdown {
                position: absolute;
                top: calc(100% + 10px);
                right: 0;
                min-width: 200px;
                background: white;
                border-radius: 12px;
                box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
                opacity: 0;
                visibility: hidden;
                transform: translateY(-10px);
                transition: all 0.3s ease;
                overflow: hidden;
            }
            
            .lang-dropdown.active {
                opacity: 1;
                visibility: visible;
                transform: translateY(0);
            }
            
            .lang-option {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 12px 16px;
                cursor: pointer;
                transition: all 0.2s ease;
                color: #333;
                position: relative;
            }
            
            .lang-option:hover {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
            }
            
            .lang-option .lang-name {
                flex: 1;
                font-weight: 500;
            }
            
            .lang-option .fa-check {
                color: #667eea;
                font-size: 14px;
            }
            
            .lang-option:hover .fa-check {
                color: white;
            }
            
            /* 移动端适配 */
            @media (max-width: 768px) {
                .language-switcher {
                    margin-right: 10px;
                }
                
                .lang-btn {
                    padding: 6px 12px;
                    font-size: 12px;
                }
                
                .lang-flag {
                    font-size: 16px;
                }
                
                .lang-dropdown {
                    min-width: 180px;
                }
            }
        `;
        
        document.head.appendChild(style);
    }
    
    // 获取当前语言
    getCurrentLanguage() {
        return this.currentLang;
    }
    
    // 获取翻译文本（编程式访问）
    t(key) {
        const trans = this.translations[this.currentLang];
        return this.getNestedTranslation(trans, key) || key;
    }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    window.i18n = new I18nSystem();
});

// 导出供外部使用
if (typeof module !== 'undefined' && module.exports) {
    module.exports = I18nSystem;
}
