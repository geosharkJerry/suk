// ========================================
// SUK Protocol - Firebase Authentication
// 集成 Firebase Auth + Web3 钱包混合认证
// ========================================

const FirebaseAuthManager = {
    auth: null,
    currentUser: null,
    unsubscribeAuth: null,

    // 初始化
    async init() {
        this.auth = FirebaseConfig.getAuth();
        
        if (!this.auth) {
            console.warn('⚠️ Firebase Auth 未初始化');
            return false;
        }

        // 监听认证状态变化
        this.unsubscribeAuth = this.auth.onAuthStateChanged((user) => {
            this.handleAuthStateChanged(user);
        });

        console.log('✅ Firebase Auth 管理器初始化成功');
        return true;
    },

    // 处理认证状态变化
    async handleAuthStateChanged(firebaseUser) {
        if (firebaseUser) {
            // 用户已登录
            console.log('✅ Firebase 用户已登录:', firebaseUser.uid);
            
            // 获取用户详细信息
            const userDoc = await this.getUserProfile(firebaseUser.uid);
            
            this.currentUser = {
                uid: firebaseUser.uid,
                email: firebaseUser.email,
                emailVerified: firebaseUser.emailVerified,
                displayName: firebaseUser.displayName || userDoc?.username,
                photoURL: firebaseUser.photoURL || userDoc?.avatar,
                phoneNumber: firebaseUser.phoneNumber,
                walletAddress: userDoc?.walletAddress,
                createdAt: firebaseUser.metadata.creationTime,
                lastLoginAt: firebaseUser.metadata.lastSignInTime,
                ...userDoc
            };

            // 触发全局事件
            window.dispatchEvent(new CustomEvent('firebase-auth-login', {
                detail: { user: this.currentUser }
            }));

            // 更新 UI
            this.updateUserUI();

        } else {
            // 用户已登出
            console.log('ℹ️ 用户已登出');
            this.currentUser = null;

            // 触发全局事件
            window.dispatchEvent(new CustomEvent('firebase-auth-logout'));

            // 更新 UI
            this.updateUserUI();
        }
    },

    // ========================================
    // 邮箱密码认证
    // ========================================

    // 邮箱注册
    async registerWithEmail(email, password, username) {
        try {
            // 创建用户
            const userCredential = await this.auth.createUserWithEmailAndPassword(email, password);
            const user = userCredential.user;

            console.log('✅ 用户注册成功:', user.uid);

            // 更新显示名称
            await user.updateProfile({
                displayName: username
            });

            // 发送邮箱验证
            await user.sendEmailVerification();
            console.log('📧 验证邮件已发送');

            // 创建用户档案
            await this.createUserProfile({
                uid: user.uid,
                email: email,
                username: username,
                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                emailVerified: false
            });

            showNotification('注册成功！请查收验证邮件', 'success');
            
            return {
                success: true,
                user: user
            };

        } catch (error) {
            console.error('❌ 注册失败:', error);
            
            let errorMessage = '注册失败';
            switch (error.code) {
                case 'auth/email-already-in-use':
                    errorMessage = '该邮箱已被注册';
                    break;
                case 'auth/invalid-email':
                    errorMessage = '邮箱格式不正确';
                    break;
                case 'auth/weak-password':
                    errorMessage = '密码强度太弱（至少6位）';
                    break;
                default:
                    errorMessage = error.message;
            }
            
            showNotification(errorMessage, 'error');
            throw error;
        }
    },

    // 邮箱登录
    async loginWithEmail(email, password) {
        try {
            const userCredential = await this.auth.signInWithEmailAndPassword(email, password);
            const user = userCredential.user;

            console.log('✅ 登录成功:', user.uid);

            // 记录登录日志
            await this.logActivity(user.uid, 'login', 'email');

            showNotification('登录成功！', 'success');

            return {
                success: true,
                user: user
            };

        } catch (error) {
            console.error('❌ 登录失败:', error);
            
            let errorMessage = '登录失败';
            switch (error.code) {
                case 'auth/user-not-found':
                    errorMessage = '用户不存在';
                    break;
                case 'auth/wrong-password':
                    errorMessage = '密码错误';
                    break;
                case 'auth/invalid-email':
                    errorMessage = '邮箱格式不正确';
                    break;
                case 'auth/user-disabled':
                    errorMessage = '账户已被禁用';
                    break;
                default:
                    errorMessage = error.message;
            }
            
            showNotification(errorMessage, 'error');
            throw error;
        }
    },

    // ========================================
    // Web3 钱包认证
    // ========================================

    // 使用钱包登录/注册
    async loginWithWallet(walletAddress) {
        try {
            // 1. 生成随机消息
            const message = this.generateWalletMessage(walletAddress);
            
            // 2. 请求用户签名
            const signature = await this.requestWalletSignature(message);
            
            // 3. 调用 Cloud Function 验证签名并获取自定义 Token
            const functions = FirebaseConfig.getFunctions();
            const verifyWallet = functions.httpsCallable('verifyWalletAndCreateToken');
            
            showNotification('正在验证钱包签名...', 'info', 0);
            
            const result = await verifyWallet({
                walletAddress: walletAddress,
                signature: signature,
                message: message
            });

            const customToken = result.data.customToken;

            // 4. 使用自定义 Token 登录
            const userCredential = await this.auth.signInWithCustomToken(customToken);
            const user = userCredential.user;

            console.log('✅ 钱包登录成功:', user.uid);

            // 5. 更新用户档案（添加钱包地址）
            await this.updateUserProfile(user.uid, {
                walletAddress: walletAddress,
                lastLoginAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            // 6. 记录登录日志
            await this.logActivity(user.uid, 'login', 'wallet');

            showNotification('钱包登录成功！', 'success');

            return {
                success: true,
                user: user
            };

        } catch (error) {
            console.error('❌ 钱包登录失败:', error);
            showNotification(error.message || '钱包登录失败', 'error');
            throw error;
        }
    },

    // 生成钱包签名消息
    generateWalletMessage(walletAddress) {
        const timestamp = Date.now();
        const nonce = Math.random().toString(36).substring(7);
        
        return `SUK Protocol 登录验证

钱包地址: ${walletAddress}
时间戳: ${timestamp}
随机数: ${nonce}

请签名以验证您的身份。
此操作不会产生任何费用。`;
    },

    // 请求钱包签名
    async requestWalletSignature(message) {
        if (!window.ethereum) {
            throw new Error('未检测到 MetaMask 钱包');
        }

        try {
            const accounts = await window.ethereum.request({
                method: 'eth_requestAccounts'
            });

            const account = accounts[0];

            // 请求签名
            const signature = await window.ethereum.request({
                method: 'personal_sign',
                params: [message, account]
            });

            return signature;

        } catch (error) {
            if (error.code === 4001) {
                throw new Error('用户拒绝签名');
            }
            throw error;
        }
    },

    // ========================================
    // 密码重置
    // ========================================

    // 发送密码重置邮件
    async sendPasswordResetEmail(email) {
        try {
            await this.auth.sendPasswordResetEmail(email);
            
            console.log('✅ 密码重置邮件已发送');
            showNotification('密码重置邮件已发送，请查收', 'success');
            
            return { success: true };

        } catch (error) {
            console.error('❌ 发送重置邮件失败:', error);
            
            let errorMessage = '发送失败';
            if (error.code === 'auth/user-not-found') {
                errorMessage = '用户不存在';
            } else if (error.code === 'auth/invalid-email') {
                errorMessage = '邮箱格式不正确';
            }
            
            showNotification(errorMessage, 'error');
            throw error;
        }
    },

    // 更新密码
    async updatePassword(newPassword) {
        try {
            const user = this.auth.currentUser;
            if (!user) {
                throw new Error('用户未登录');
            }

            await user.updatePassword(newPassword);
            
            console.log('✅ 密码更新成功');
            showNotification('密码已更新', 'success');
            
            return { success: true };

        } catch (error) {
            console.error('❌ 更新密码失败:', error);
            
            if (error.code === 'auth/requires-recent-login') {
                showNotification('请重新登录后再修改密码', 'warning');
            } else {
                showNotification('密码更新失败', 'error');
            }
            
            throw error;
        }
    },

    // ========================================
    // 用户档案管理
    // ========================================

    // 创建用户档案
    async createUserProfile(profileData) {
        try {
            const db = FirebaseConfig.getDb();
            await db.collection('users').doc(profileData.uid).set({
                ...profileData,
                role: 'user',
                verified: false,
                totalInvested: 0,
                totalEarnings: 0,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            console.log('✅ 用户档案创建成功');

        } catch (error) {
            console.error('❌ 创建用户档案失败:', error);
            throw error;
        }
    },

    // 获取用户档案
    async getUserProfile(uid) {
        try {
            const db = FirebaseConfig.getDb();
            const doc = await db.collection('users').doc(uid).get();
            
            if (doc.exists) {
                return doc.data();
            } else {
                return null;
            }

        } catch (error) {
            console.error('❌ 获取用户档案失败:', error);
            return null;
        }
    },

    // 更新用户档案
    async updateUserProfile(uid, updates) {
        try {
            const db = FirebaseConfig.getDb();
            await db.collection('users').doc(uid).update({
                ...updates,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            console.log('✅ 用户档案更新成功');

        } catch (error) {
            console.error('❌ 更新用户档案失败:', error);
            throw error;
        }
    },

    // ========================================
    // 登出
    // ========================================

    async logout() {
        try {
            // 记录登出日志
            if (this.currentUser) {
                await this.logActivity(this.currentUser.uid, 'logout', 'manual');
            }

            await this.auth.signOut();
            
            console.log('✅ 用户已登出');
            showNotification('已退出登录', 'info');

            // 清除本地数据（可选）
            // localStorage.clear();

            return { success: true };

        } catch (error) {
            console.error('❌ 登出失败:', error);
            showNotification('登出失败', 'error');
            throw error;
        }
    },

    // ========================================
    // 活动日志
    // ========================================

    async logActivity(uid, action, method) {
        try {
            const db = FirebaseConfig.getDb();
            await db.collection('activities').add({
                uid: uid,
                action: action,
                method: method,
                timestamp: firebase.firestore.FieldValue.serverTimestamp(),
                userAgent: navigator.userAgent,
                ip: null  // 由 Cloud Function 填充
            });

        } catch (error) {
            console.error('⚠️ 记录活动日志失败:', error);
        }
    },

    // ========================================
    // UI 更新
    // ========================================

    updateUserUI() {
        // 更新导航栏
        const walletBtn = document.getElementById('wallet-btn-nav');
        const userMenuBtn = document.getElementById('user-menu-btn');

        if (this.currentUser) {
            // 已登录
            if (walletBtn) {
                walletBtn.innerHTML = `
                    <i class="fas fa-user-circle"></i>
                    <span>${this.currentUser.displayName || this.currentUser.email}</span>
                `;
            }
            
            if (userMenuBtn) {
                userMenuBtn.style.display = 'block';
            }

        } else {
            // 未登录
            if (walletBtn) {
                walletBtn.innerHTML = `
                    <i class="fas fa-wallet"></i>
                    <span>连接钱包</span>
                `;
            }
            
            if (userMenuBtn) {
                userMenuBtn.style.display = 'none';
            }
        }
    },

    // ========================================
    // 工具方法
    // ========================================

    // 检查是否已登录
    isLoggedIn() {
        return !!this.currentUser;
    },

    // 获取当前用户
    getCurrentUser() {
        return this.currentUser;
    },

    // 要求登录（重定向）
    requireLogin() {
        if (!this.isLoggedIn()) {
            showNotification('请先登录', 'warning');
            setTimeout(() => {
                window.location.href = 'auth.html';
            }, 1500);
            return false;
        }
        return true;
    }
};

// 页面加载时初始化
window.addEventListener('DOMContentLoaded', async () => {
    await FirebaseAuthManager.init();
});

// 导出到全局
window.FirebaseAuthManager = FirebaseAuthManager;

console.log('🔐 Firebase Auth 模块已加载');
