/**
 * SUK Web3 合约交互工具类
 * 封装与 SUKToken 和 SUKAirdrop 合约的所有交互逻辑
 * 
 * 依赖：
 * - ethers.js v5.7.2
 * - contract-config.js
 * 
 * 使用示例：
 * const web3Contract = new SUKWeb3Contract('goerli');
 * await web3Contract.connectWallet();
 * const balance = await web3Contract.getSUKBalance();
 */

class SUKWeb3Contract {
    constructor(network = 'goerli') {
        this.network = network;
        this.config = ContractConfig.getConfig(network);
        this.provider = null;
        this.signer = null;
        this.userAddress = null;
        this.sukTokenContract = null;
        this.sukAirdropContract = null;
    }
    
    // ===========================
    // 钱包连接相关
    // ===========================
    
    /**
     * 检查 MetaMask 是否已安装
     * @returns {boolean}
     */
    isMetaMaskInstalled() {
        return typeof window.ethereum !== 'undefined';
    }
    
    /**
     * 连接 MetaMask 钱包
     * @returns {Promise<string>} 用户地址
     */
    async connectWallet() {
        if (!this.isMetaMaskInstalled()) {
            throw new Error('请先安装 MetaMask 钱包插件');
        }
        
        try {
            // 请求账户访问权限
            const accounts = await window.ethereum.request({
                method: 'eth_requestAccounts'
            });
            
            this.userAddress = accounts[0];
            
            // 初始化 Provider 和 Signer
            this.provider = new ethers.providers.Web3Provider(window.ethereum);
            this.signer = this.provider.getSigner();
            
            // 检查并切换网络
            await this.switchNetwork();
            
            // 初始化合约实例
            this.initContracts();
            
            console.log('✅ 钱包已连接:', this.userAddress);
            return this.userAddress;
            
        } catch (error) {
            console.error('❌ 钱包连接失败:', error);
            throw error;
        }
    }
    
    /**
     * 切换到指定网络
     * @returns {Promise<void>}
     */
    async switchNetwork() {
        try {
            await window.ethereum.request({
                method: 'wallet_switchEthereumChain',
                params: [{ chainId: this.config.chainId }]
            });
            console.log('✅ 已切换到网络:', this.config.chainName);
        } catch (error) {
            // 如果网络不存在，尝试添加
            if (error.code === 4902) {
                await this.addNetwork();
            } else {
                throw error;
            }
        }
    }
    
    /**
     * 添加网络到 MetaMask
     * @returns {Promise<void>}
     */
    async addNetwork() {
        try {
            await window.ethereum.request({
                method: 'wallet_addEthereumChain',
                params: [{
                    chainId: this.config.chainId,
                    chainName: this.config.chainName,
                    nativeCurrency: this.config.nativeCurrency,
                    rpcUrls: this.config.rpcUrls,
                    blockExplorerUrls: this.config.blockExplorerUrls
                }]
            });
            console.log('✅ 网络已添加:', this.config.chainName);
        } catch (error) {
            console.error('❌ 添加网络失败:', error);
            throw error;
        }
    }
    
    /**
     * 初始化合约实例
     */
    initContracts() {
        // SUKToken 合约
        this.sukTokenContract = new ethers.Contract(
            this.config.contracts.SUKToken,
            ContractConfig.SUKTokenABI,
            this.signer
        );
        
        // SUKAirdrop 合约
        this.sukAirdropContract = new ethers.Contract(
            this.config.contracts.SUKAirdrop,
            ContractConfig.SUKAirdropABI,
            this.signer
        );
        
        console.log('✅ 合约实例已初始化');
    }
    
    /**
     * 断开钱包连接
     */
    disconnect() {
        this.provider = null;
        this.signer = null;
        this.userAddress = null;
        this.sukTokenContract = null;
        this.sukAirdropContract = null;
        console.log('✅ 钱包已断开');
    }
    
    // ===========================
    // SUKToken 合约交互
    // ===========================
    
    /**
     * 获取 SUK 余额
     * @param {string} address - 钱包地址（默认为当前用户）
     * @returns {Promise<string>} 格式化后的余额
     */
    async getSUKBalance(address = null) {
        address = address || this.userAddress;
        const balance = await this.sukTokenContract.balanceOf(address);
        return ContractConfig.formatSUK(balance.toString());
    }
    
    /**
     * 获取代币基本信息
     * @returns {Promise<object>}
     */
    async getTokenInfo() {
        const [name, symbol, decimals, totalSupply] = await Promise.all([
            this.sukTokenContract.name(),
            this.sukTokenContract.symbol(),
            this.sukTokenContract.decimals(),
            this.sukTokenContract.totalSupply()
        ]);
        
        return {
            name,
            symbol,
            decimals,
            totalSupply: ContractConfig.formatSUK(totalSupply.toString())
        };
    }
    
    /**
     * 转账 SUK 代币
     * @param {string} to - 接收地址
     * @param {string} amount - 转账金额（SUK）
     * @returns {Promise<object>} 交易收据
     */
    async transferSUK(to, amount) {
        const amountWei = ContractConfig.parseSUK(amount);
        const tx = await this.sukTokenContract.transfer(to, amountWei);
        console.log('📤 交易已发送:', tx.hash);
        
        const receipt = await tx.wait();
        console.log('✅ 交易已确认:', receipt.transactionHash);
        return receipt;
    }
    
    /**
     * 授权 SUK 代币
     * @param {string} spender - 授权地址
     * @param {string} amount - 授权金额（SUK）
     * @returns {Promise<object>} 交易收据
     */
    async approveSUK(spender, amount) {
        const amountWei = ContractConfig.parseSUK(amount);
        const tx = await this.sukTokenContract.approve(spender, amountWei);
        console.log('📤 授权交易已发送:', tx.hash);
        
        const receipt = await tx.wait();
        console.log('✅ 授权已确认:', receipt.transactionHash);
        return receipt;
    }
    
    /**
     * 检查授权额度
     * @param {string} owner - 所有者地址
     * @param {string} spender - 授权地址
     * @returns {Promise<string>} 格式化后的授权额度
     */
    async getAllowance(owner, spender) {
        const allowance = await this.sukTokenContract.allowance(owner, spender);
        return ContractConfig.formatSUK(allowance.toString());
    }
    
    // ===========================
    // SUKAirdrop 合约交互
    // ===========================
    
    /**
     * 检查是否可以领取空投
     * @returns {Promise<boolean>}
     */
    async canClaimAirdrop() {
        return await this.sukAirdropContract.canClaim();
    }
    
    /**
     * 检查是否在白名单中
     * @param {string} address - 钱包地址（默认为当前用户）
     * @returns {Promise<boolean>}
     */
    async isWhitelisted(address = null) {
        address = address || this.userAddress;
        return await this.sukAirdropContract.isWhitelisted(address);
    }
    
    /**
     * 检查是否已领取
     * @param {string} address - 钱包地址（默认为当前用户）
     * @returns {Promise<boolean>}
     */
    async hasClaimedAirdrop(address = null) {
        address = address || this.userAddress;
        return await this.sukAirdropContract.hasClaimed(address);
    }
    
    /**
     * 获取可领取金额
     * @returns {Promise<string>} 格式化后的金额
     */
    async getClaimableAmount() {
        const amount = await this.sukAirdropContract.getClaimableAmount();
        return ContractConfig.formatSUK(amount.toString());
    }
    
    /**
     * 领取空投
     * @returns {Promise<object>} 交易收据
     */
    async claimAirdrop() {
        try {
            const tx = await this.sukAirdropContract.claim();
            console.log('📤 领取交易已发送:', tx.hash);
            
            const receipt = await tx.wait();
            console.log('✅ 空投领取成功:', receipt.transactionHash);
            
            // 解析事件获取领取金额
            const claimEvent = receipt.events.find(e => e.event === 'Claimed');
            if (claimEvent) {
                const amount = ContractConfig.formatSUK(claimEvent.args.amount.toString());
                const isWhitelisted = claimEvent.args.isWhitelisted;
                console.log(`🎉 成功领取 ${amount} SUK (白名单用户: ${isWhitelisted})`);
            }
            
            return receipt;
        } catch (error) {
            console.error('❌ 领取空投失败:', error);
            throw error;
        }
    }
    
    /**
     * 获取空投统计信息
     * @returns {Promise<object>}
     */
    async getAirdropStats() {
        const [
            whitelistAmount,
            publicAmount,
            totalClaimed,
            whitelistStartTime,
            publicStartTime,
            endTime
        ] = await Promise.all([
            this.sukAirdropContract.whitelistAmount(),
            this.sukAirdropContract.publicAmount(),
            this.sukAirdropContract.totalClaimed(),
            this.sukAirdropContract.whitelistStartTime(),
            this.sukAirdropContract.publicStartTime(),
            this.sukAirdropContract.endTime()
        ]);
        
        return {
            whitelistAmount: ContractConfig.formatSUK(whitelistAmount.toString()),
            publicAmount: ContractConfig.formatSUK(publicAmount.toString()),
            totalClaimed: ContractConfig.formatSUK(totalClaimed.toString()),
            whitelistStartTime: whitelistStartTime.toNumber(),
            publicStartTime: publicStartTime.toNumber(),
            endTime: endTime.toNumber()
        };
    }
    
    /**
     * 获取距离空投开始的时间
     * @returns {Promise<number>} 秒数
     */
    async getTimeUntilStart() {
        const time = await this.sukAirdropContract.getTimeUntilStart();
        return time.toNumber();
    }
    
    /**
     * 获取距离空投结束的时间
     * @returns {Promise<number>} 秒数
     */
    async getTimeUntilEnd() {
        const time = await this.sukAirdropContract.getTimeUntilEnd();
        return time.toNumber();
    }
    
    // ===========================
    // X402 协议相关（时间计费）
    // ===========================
    
    /**
     * 为观看短剧支付 SUK
     * @param {string} dramaId - 短剧 ID
     * @param {number} watchTime - 观看时间（秒）
     * @param {string} recipient - 收款地址（平台或版权方）
     * @returns {Promise<object>} 交易收据
     */
    async payForWatching(dramaId, watchTime, recipient) {
        // X402 协议：按时间计费
        // 假设 1 秒 = 0.01 SUK（可根据实际情况调整）
        const ratePerSecond = 0.01;
        const amount = (watchTime * ratePerSecond).toFixed(2);
        
        console.log(`⏱️ X402 计费: 观看 ${watchTime} 秒, 需支付 ${amount} SUK`);
        
        return await this.transferSUK(recipient, amount);
    }
    
    // ===========================
    // 辅助方法
    // ===========================
    
    /**
     * 监听钱包账户变化
     * @param {Function} callback - 回调函数
     */
    onAccountsChanged(callback) {
        if (!this.isMetaMaskInstalled()) return;
        
        window.ethereum.on('accountsChanged', async (accounts) => {
            if (accounts.length === 0) {
                console.log('❌ 钱包已断开');
                this.disconnect();
            } else {
                this.userAddress = accounts[0];
                console.log('🔄 账户已切换:', this.userAddress);
            }
            callback(accounts);
        });
    }
    
    /**
     * 监听网络变化
     * @param {Function} callback - 回调函数
     */
    onChainChanged(callback) {
        if (!this.isMetaMaskInstalled()) return;
        
        window.ethereum.on('chainChanged', (chainId) => {
            console.log('🔄 网络已切换:', chainId);
            // 页面需要重新加载以使用新网络
            window.location.reload();
            callback(chainId);
        });
    }
    
    /**
     * 格式化地址（显示前6位和后4位）
     * @param {string} address - 地址
     * @returns {string}
     */
    formatAddress(address) {
        if (!address) return '';
        return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
    }
    
    /**
     * 获取交易链接
     * @param {string} txHash - 交易哈希
     * @returns {string}
     */
    getTxLink(txHash) {
        return `${this.config.blockExplorerUrls[0]}/tx/${txHash}`;
    }
}

// 导出类（用于 Node.js 环境）
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SUKWeb3Contract;
}

console.log('✅ SUK Web3 合约交互工具已加载');
