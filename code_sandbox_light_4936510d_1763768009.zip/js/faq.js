// ==================== FAQ页面交互逻辑 ====================

document.addEventListener('DOMContentLoaded', function() {
    
    // ==================== FAQ折叠/展开 ====================
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        question.addEventListener('click', function() {
            // 关闭其他已展开的项目（可选）
            // faqItems.forEach(otherItem => {
            //     if (otherItem !== item && otherItem.classList.contains('active')) {
            //         otherItem.classList.remove('active');
            //     }
            // });
            
            // 切换当前项目
            item.classList.toggle('active');
        });
    });
    
    // ==================== 分类过滤 ====================
    const categoryTabs = document.querySelectorAll('.category-tab');
    const faqSections = document.querySelectorAll('.faq-section');
    
    categoryTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const category = this.dataset.category;
            
            // 更新活动标签
            categoryTabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            // 过滤FAQ部分
            filterByCategory(category);
        });
    });
    
    function filterByCategory(category) {
        faqSections.forEach(section => {
            if (category === 'all') {
                section.classList.remove('hidden');
            } else {
                if (section.dataset.category === category) {
                    section.classList.remove('hidden');
                } else {
                    section.classList.add('hidden');
                }
            }
        });
        
        // 重置搜索
        const searchInput = document.getElementById('faqSearch');
        if (searchInput) {
            searchInput.value = '';
        }
        
        checkNoResults();
    }
    
    // ==================== 搜索功能 ====================
    const searchInput = document.getElementById('faqSearch');
    
    if (searchInput) {
        let searchTimeout;
        
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            
            searchTimeout = setTimeout(() => {
                const searchTerm = this.value.toLowerCase().trim();
                performSearch(searchTerm);
            }, 300); // 防抖300ms
        });
    }
    
    function performSearch(searchTerm) {
        if (searchTerm === '') {
            // 清空搜索，显示所有内容
            faqItems.forEach(item => item.classList.remove('hidden'));
            faqSections.forEach(section => section.classList.remove('hidden'));
            checkNoResults();
            return;
        }
        
        let hasResults = false;
        
        faqSections.forEach(section => {
            let sectionHasMatch = false;
            const items = section.querySelectorAll('.faq-item');
            
            items.forEach(item => {
                const question = item.querySelector('.faq-question span').textContent.toLowerCase();
                const answer = item.querySelector('.faq-answer').textContent.toLowerCase();
                
                if (question.includes(searchTerm) || answer.includes(searchTerm)) {
                    item.classList.remove('hidden');
                    sectionHasMatch = true;
                    hasResults = true;
                } else {
                    item.classList.add('hidden');
                }
            });
            
            // 如果该部分有匹配项，显示该部分
            if (sectionHasMatch) {
                section.classList.remove('hidden');
            } else {
                section.classList.add('hidden');
            }
        });
        
        checkNoResults();
    }
    
    function checkNoResults() {
        const visibleItems = document.querySelectorAll('.faq-item:not(.hidden)');
        let noResults = document.querySelector('.no-results');
        
        if (visibleItems.length === 0) {
            if (!noResults) {
                noResults = document.createElement('div');
                noResults.className = 'no-results show';
                noResults.innerHTML = `
                    <i class="fas fa-search"></i>
                    <h3>未找到相关问题</h3>
                    <p>尝试使用其他关键词搜索，或浏览分类查找</p>
                `;
                document.querySelector('.faq-content .container').appendChild(noResults);
            } else {
                noResults.classList.add('show');
            }
        } else {
            if (noResults) {
                noResults.classList.remove('show');
            }
        }
    }
    
    // ==================== 支持按钮点击 ====================
    const supportButtons = document.querySelectorAll('.btn-support');
    
    supportButtons.forEach(button => {
        button.addEventListener('click', function() {
            const icon = this.querySelector('i');
            
            if (icon.classList.contains('fa-discord')) {
                showNotification('Discord社区即将开放，敬请期待！', 'info');
            } else if (icon.classList.contains('fa-telegram')) {
                showNotification('Telegram群组即将开放，敬请期待！', 'info');
            } else if (icon.classList.contains('fa-envelope')) {
                showNotification('请发送邮件至：support@sukprotocol.io', 'info');
            }
        });
    });
    
    // ==================== URL锚点跳转到对应FAQ ====================
    if (window.location.hash) {
        const hash = window.location.hash.substring(1);
        const targetItem = document.getElementById(hash);
        
        if (targetItem && targetItem.classList.contains('faq-item')) {
            // 延迟执行以确保页面完全加载
            setTimeout(() => {
                targetItem.classList.add('active');
                targetItem.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 500);
        }
    }
    
    // ==================== 键盘快捷键 ====================
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + K 聚焦搜索框
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            searchInput.focus();
        }
        
        // ESC 清空搜索
        if (e.key === 'Escape' && searchInput === document.activeElement) {
            searchInput.value = '';
            searchInput.blur();
            performSearch('');
        }
    });
    
    // ==================== 平滑滚动优化 ====================
    const categoryNav = document.querySelector('.faq-categories');
    let lastScroll = 0;
    
    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;
        
        // 向下滚动时缩小分类导航
        if (currentScroll > lastScroll && currentScroll > 100) {
            categoryNav.style.transform = 'translateY(-10px)';
            categoryNav.style.opacity = '0.95';
        } else {
            categoryNav.style.transform = 'translateY(0)';
            categoryNav.style.opacity = '1';
        }
        
        lastScroll = currentScroll;
    });
    
});

// ==================== 通知系统 ====================
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    notification.innerHTML = `
        <i class="fas ${icons[type]}"></i>
        <span>${message}</span>
    `;
    
    // 添加通知样式
    if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification {
                position: fixed;
                top: 100px;
                right: 2rem;
                padding: 1rem 1.5rem;
                background: var(--bg-card);
                border: 2px solid;
                border-radius: var(--radius-sm);
                color: var(--text-primary);
                display: flex;
                align-items: center;
                gap: 0.75rem;
                z-index: 10001;
                animation: slideInRight 0.3s ease, slideOutRight 0.3s ease 2.7s;
                box-shadow: var(--shadow-lg);
                min-width: 300px;
            }
            
            .notification-success { border-color: var(--success); }
            .notification-error { border-color: var(--error); }
            .notification-warning { border-color: var(--warning); }
            .notification-info { border-color: var(--color-primary); }
            
            .notification i {
                font-size: 1.2rem;
            }
            
            .notification-success i { color: var(--success); }
            .notification-error i { color: var(--error); }
            .notification-warning i { color: var(--warning); }
            .notification-info i { color: var(--color-primary); }
            
            @keyframes slideInRight {
                from {
                    opacity: 0;
                    transform: translateX(100%);
                }
                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }
            
            @keyframes slideOutRight {
                from {
                    opacity: 1;
                    transform: translateX(0);
                }
                to {
                    opacity: 0;
                    transform: translateX(100%);
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    setTimeout(() => notification.remove(), 3000);
}

// ==================== 添加搜索提示 ====================
const searchTips = [
    '试试搜索"投资"、"收益"、"安全"等关键词',
    '按 Ctrl+K 快速聚焦搜索框',
    '按 ESC 清空搜索内容',
    '点击分类标签快速筛选问题'
];

function showSearchTip() {
    const searchInput = document.getElementById('faqSearch');
    if (searchInput && !searchInput.value) {
        const randomTip = searchTips[Math.floor(Math.random() * searchTips.length)];
        searchInput.placeholder = randomTip;
    }
}

// 每5秒更换一次搜索提示
setInterval(showSearchTip, 5000);

// ==================== 统计功能（可选） ====================
function trackFAQInteraction(action, category, question) {
    // 这里可以集成Google Analytics或其他分析工具
    console.log('FAQ Interaction:', { action, category, question });
    
    // 示例：Google Analytics 4
    // gtag('event', 'faq_interaction', {
    //     action: action,
    //     category: category,
    //     question: question
    // });
}

// 跟踪FAQ展开事件
document.addEventListener('DOMContentLoaded', function() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        question.addEventListener('click', function() {
            if (!item.classList.contains('active')) {
                const questionText = this.querySelector('span').textContent;
                const category = item.closest('.faq-section').dataset.category;
                trackFAQInteraction('expand', category, questionText);
            }
        });
    });
});