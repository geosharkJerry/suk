// ========================================
// SUK Protocol - 浏览器通知系统
// 支持页面内通知和浏览器原生通知
// ========================================

const NotificationManager = {
    notifications: [],
    permission: 'default',
    container: null,

    // 初始化
    init() {
        this.createContainer();
        this.checkPermission();
        this.loadNotifications();
    },

    // 创建通知容器
    createContainer() {
        if (document.getElementById('notification-container')) return;

        const container = document.createElement('div');
        container.id = 'notification-container';
        container.style.cssText = `
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 10000;
            display: flex;
            flex-direction: column;
            gap: 10px;
            max-width: 400px;
            pointer-events: none;
        `;
        
        document.body.appendChild(container);
        this.container = container;
    },

    // 检查浏览器通知权限
    async checkPermission() {
        if (!('Notification' in window)) {
            console.warn('⚠️ 浏览器不支持通知');
            return;
        }

        this.permission = Notification.permission;

        if (this.permission === 'default') {
            // 可以在用户操作时请求权限
            console.log('💡 可以请求通知权限');
        }
    },

    // 请求通知权限
    async requestPermission() {
        if (!('Notification' in window)) {
            showNotification('您的浏览器不支持通知', 'error');
            return false;
        }

        try {
            const permission = await Notification.requestPermission();
            this.permission = permission;
            
            if (permission === 'granted') {
                showNotification('通知权限已授予', 'success');
                return true;
            } else {
                showNotification('通知权限被拒绝', 'warning');
                return false;
            }
        } catch (error) {
            console.error('❌ 请求权限失败:', error);
            return false;
        }
    },

    // 显示页面内通知
    showToast(message, type = 'info', duration = 3000) {
        const toast = document.createElement('div');
        toast.className = 'toast-notification';
        
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };

        const colors = {
            success: '#4CAF50',
            error: '#F44336',
            warning: '#FFC107',
            info: '#2196F3'
        };

        toast.style.cssText = `
            background: rgba(26, 26, 46, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid ${colors[type]}40;
            border-left: 4px solid ${colors[type]};
            border-radius: 10px;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
            animation: slideIn 0.3s ease;
            pointer-events: auto;
            cursor: pointer;
            transition: all 0.3s ease;
            min-width: 300px;
        `;

        toast.innerHTML = `
            <i class="fas ${icons[type]}" style="color: ${colors[type]}; font-size: 1.2rem;"></i>
            <span style="color: #fff; flex: 1;">${message}</span>
            <i class="fas fa-times" style="color: #888; font-size: 0.9rem;"></i>
        `;

        // 添加样式
        if (!document.getElementById('toast-styles')) {
            const style = document.createElement('style');
            style.id = 'toast-styles';
            style.textContent = `
                @keyframes slideIn {
                    from {
                        transform: translateX(400px);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
                
                @keyframes slideOut {
                    from {
                        transform: translateX(0);
                        opacity: 1;
                    }
                    to {
                        transform: translateX(400px);
                        opacity: 0;
                    }
                }

                .toast-notification:hover {
                    transform: translateX(-5px);
                    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.4);
                }
            `;
            document.head.appendChild(style);
        }

        // 点击关闭
        toast.addEventListener('click', () => {
            this.removeToast(toast);
        });

        // 添加到容器
        this.container.appendChild(toast);

        // 自动关闭
        if (duration > 0) {
            setTimeout(() => {
                this.removeToast(toast);
            }, duration);
        }

        return toast;
    },

    // 移除通知
    removeToast(toast) {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    },

    // 显示浏览器原生通知
    showNativeNotification(title, options = {}) {
        if (!('Notification' in window)) {
            console.warn('⚠️ 浏览器不支持通知');
            return;
        }

        if (this.permission !== 'granted') {
            console.log('💡 需要通知权限');
            return;
        }

        const notification = new Notification(title, {
            icon: 'https://via.placeholder.com/128/FFD700/000000?text=SUK',
            badge: 'https://via.placeholder.com/96/8B5CF6/FFFFFF?text=S',
            body: options.body || '',
            tag: options.tag || 'suk-notification',
            requireInteraction: options.requireInteraction || false,
            ...options
        });

        notification.onclick = () => {
            window.focus();
            notification.close();
            if (options.onClick) {
                options.onClick();
            }
        };

        return notification;
    },

    // 保存通知到 LocalStorage
    saveNotification(notification) {
        this.notifications.unshift(notification);
        
        // 只保留最近50条
        if (this.notifications.length > 50) {
            this.notifications.length = 50;
        }
        
        localStorage.setItem('suk_notifications', JSON.stringify(this.notifications));
    },

    // 加载通知
    loadNotifications() {
        const notificationsJson = localStorage.getItem('suk_notifications');
        if (notificationsJson) {
            try {
                this.notifications = JSON.parse(notificationsJson);
            } catch (e) {
                console.error('❌ 加载通知失败:', e);
                this.notifications = [];
            }
        }
    },

    // 获取未读通知数量
    getUnreadCount() {
        return this.notifications.filter(n => !n.read).length;
    },

    // 标记为已读
    markAsRead(id) {
        const notification = this.notifications.find(n => n.id === id);
        if (notification) {
            notification.read = true;
            localStorage.setItem('suk_notifications', JSON.stringify(this.notifications));
        }
    },

    // 标记全部已读
    markAllAsRead() {
        this.notifications.forEach(n => n.read = true);
        localStorage.setItem('suk_notifications', JSON.stringify(this.notifications));
    },

    // 清空通知
    clearAll() {
        this.notifications = [];
        localStorage.removeItem('suk_notifications');
    },

    // 添加通知（用于模拟）
    addNotification(title, message, type = 'info') {
        const notification = {
            id: Date.now(),
            title: title,
            message: message,
            type: type,
            timestamp: Date.now(),
            read: false
        };

        this.saveNotification(notification);
        
        // 同时显示页面内通知
        this.showToast(message, type);
        
        // 如果有权限，显示浏览器通知
        if (this.permission === 'granted') {
            this.showNativeNotification(title, {
                body: message
            });
        }
    }
};

// 全局通知函数（简化调用）
function showNotification(message, type = 'info', duration = 3000) {
    return NotificationManager.showToast(message, type, duration);
}

// 请求通知权限（供按钮调用）
async function requestNotificationPermission() {
    return await NotificationManager.requestPermission();
}

// 页面加载时初始化
window.addEventListener('DOMContentLoaded', () => {
    NotificationManager.init();
});

// 导出供其他模块使用
window.NotificationManager = NotificationManager;
window.showNotification = showNotification;
