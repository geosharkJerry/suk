// ==================== 导航栏交互 ====================
document.addEventListener('DOMContentLoaded', function() {
    const navbar = document.querySelector('.navbar');
    const menuToggle = document.getElementById('menuToggle');
    const navMenu = document.getElementById('navMenu');
    
    // 滚动效果
    let lastScroll = 0;
    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;
        
        if (currentScroll > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
        
        lastScroll = currentScroll;
    });
    
    // 移动端菜单切换
    menuToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');
        const icon = menuToggle.querySelector('i');
        icon.classList.toggle('fa-bars');
        icon.classList.toggle('fa-times');
    });
    
    // 点击菜单项关闭菜单
    const navLinks = navMenu.querySelectorAll('a');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
            const icon = menuToggle.querySelector('i');
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
        });
    });
});

// ==================== 平滑滚动 ====================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
            const offsetTop = targetElement.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
});

// ==================== 滚动动画观察器 ====================
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// 观察所有需要动画的元素
document.addEventListener('DOMContentLoaded', () => {
    const animatedElements = document.querySelectorAll(
        '.step-card, .drama-card, .visual-card, .earn-item, .foundation-card'
    );
    
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});

// ==================== 数字计数动画 ====================
function animateCounter(element, target, duration = 2000) {
    const start = 0;
    const increment = target / (duration / 16);
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            current = target;
            clearInterval(timer);
        }
        
        // 格式化数字
        let displayValue;
        if (element.textContent.includes('万')) {
            displayValue = `¥${Math.floor(current)}万`;
        } else if (element.textContent.includes('%')) {
            displayValue = `${current.toFixed(1)}%`;
        } else if (element.textContent.includes('+')) {
            displayValue = `${Math.floor(current)}+`;
        } else {
            displayValue = Math.floor(current).toString();
        }
        
        element.textContent = displayValue;
    }, 16);
}

// 当元素进入视图时触发计数动画
const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting && !entry.target.classList.contains('counted')) {
            entry.target.classList.add('counted');
            const text = entry.target.textContent;
            
            // 提取数字
            let targetValue;
            if (text.includes('¥') && text.includes('万')) {
                targetValue = parseInt(text.match(/\d+/)[0]);
            } else if (text.includes('%')) {
                // 处理百分比范围，如 "6-12%"
                const matches = text.match(/\d+/g);
                if (matches && matches.length > 1) {
                    targetValue = parseFloat(matches[1]);
                } else {
                    targetValue = parseFloat(text.match(/[\d.]+/)[0]);
                }
            } else if (text.includes('+')) {
                targetValue = parseInt(text.match(/\d+/)[0]);
            } else {
                targetValue = parseInt(text.match(/\d+/)?.[0] || 0);
            }
            
            if (targetValue) {
                animateCounter(entry.target, targetValue);
            }
        }
    });
}, { threshold: 0.5 });

// 观察所有统计数字
document.addEventListener('DOMContentLoaded', () => {
    const statValues = document.querySelectorAll('.stat-value, .portfolio-value');
    statValues.forEach(el => counterObserver.observe(el));
});

// ==================== 按钮交互效果 ====================
document.addEventListener('DOMContentLoaded', () => {
    const buttons = document.querySelectorAll('button, .btn-view');
    
    buttons.forEach(button => {
        // 点击波纹效果
        button.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.style.position = 'absolute';
            ripple.style.borderRadius = '50%';
            ripple.style.background = 'rgba(255, 255, 255, 0.5)';
            ripple.style.transform = 'scale(0)';
            ripple.style.animation = 'ripple-animation 0.6s ease-out';
            ripple.style.pointerEvents = 'none';
            
            this.style.position = 'relative';
            this.style.overflow = 'hidden';
            this.appendChild(ripple);
            
            setTimeout(() => ripple.remove(), 600);
        });
    });
});

// 添加波纹动画样式
const style = document.createElement('style');
style.textContent = `
    @keyframes ripple-animation {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// ==================== 卡片悬停视差效果 ====================
document.addEventListener('DOMContentLoaded', () => {
    const cards = document.querySelectorAll('.drama-card, .step-card, .foundation-card');
    
    cards.forEach(card => {
        card.addEventListener('mousemove', function(e) {
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = (y - centerY) / 20;
            const rotateY = (centerX - x) / 20;
            
            this.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-10px)`;
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = '';
        });
    });
});

// ==================== 滚动进度指示器 ====================
function createScrollProgress() {
    const progressBar = document.createElement('div');
    progressBar.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        height: 3px;
        background: linear-gradient(135deg, #FFD700 0%, #FFA500 25%, #FF6B9D 50%, #C471ED 75%, #8B5CF6 100%);
        z-index: 9999;
        transition: width 0.1s ease;
        width: 0;
    `;
    document.body.appendChild(progressBar);
    
    window.addEventListener('scroll', () => {
        const windowHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrolled = (window.pageYOffset / windowHeight) * 100;
        progressBar.style.width = scrolled + '%';
    });
}

createScrollProgress();

// ==================== 懒加载优化 ====================
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                if (img.dataset.src) {
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                }
                observer.unobserve(img);
            }
        });
    });
    
    document.addEventListener('DOMContentLoaded', () => {
        const lazyImages = document.querySelectorAll('img[data-src]');
        lazyImages.forEach(img => imageObserver.observe(img));
    });
}

// ==================== 按钮点击事件处理 ====================
document.addEventListener('DOMContentLoaded', () => {
    // 启动应用按钮
    const launchButtons = document.querySelectorAll('.btn-primary, .btn-gradient');
    launchButtons.forEach(button => {
        if (button.textContent.includes('启动应用') || button.textContent.includes('探索作品集')) {
            button.addEventListener('click', () => {
                alert('SUK Protocol 应用即将上线，敬请期待！');
            });
        }
    });
    
    // 了解更多按钮
    const learnMoreButtons = document.querySelectorAll('.btn-outline');
    learnMoreButtons.forEach(button => {
        if (button.textContent.includes('了解更多')) {
            button.addEventListener('click', () => {
                document.querySelector('#about').scrollIntoView({ behavior: 'smooth', block: 'start' });
            });
        }
    });
    
    // 投资按钮
    const investButtons = document.querySelectorAll('.btn-invest');
    investButtons.forEach(button => {
        button.addEventListener('click', function() {
            const dramaTitle = this.closest('.drama-card').querySelector('h3').textContent;
            alert(`感谢您对《${dramaTitle}》的关注！\n\n投资功能即将开放，请持续关注SUK Protocol。`);
        });
    });
    
    // 查看详情按钮
    const viewButtons = document.querySelectorAll('.btn-view');
    viewButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.stopPropagation();
            const dramaTitle = this.closest('.drama-card').querySelector('h3').textContent;
            alert(`《${dramaTitle}》详情页面开发中...\n\n您将能够查看：\n- 完整剧集信息\n- 版权收益数据\n- 投资历史记录\n- 社区讨论`);
        });
    });
    
    // 加入社区按钮
    const communityButtons = document.querySelectorAll('.btn-outline-light');
    communityButtons.forEach(button => {
        if (button.textContent.includes('加入社区')) {
            button.addEventListener('click', () => {
                alert('SUK Protocol 社区即将开放！\n\n加入我们的社区，您可以：\n✨ 参与治理投票\n✨ 获取独家资讯\n✨ 与创作者互动\n✨ 分享投资心得');
            });
        }
    });
});

// ==================== 动态背景效果 ====================
function createParticles() {
    const hero = document.querySelector('.hero');
    const particleCount = 30;
    
    for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.style.cssText = `
            position: absolute;
            width: ${Math.random() * 4 + 2}px;
            height: ${Math.random() * 4 + 2}px;
            background: rgba(139, 92, 246, ${Math.random() * 0.5 + 0.2});
            border-radius: 50%;
            left: ${Math.random() * 100}%;
            top: ${Math.random() * 100}%;
            animation: float-particle ${Math.random() * 10 + 10}s ease-in-out infinite;
            animation-delay: ${Math.random() * 5}s;
        `;
        hero.appendChild(particle);
    }
}

// 添加粒子动画样式
const particleStyle = document.createElement('style');
particleStyle.textContent = `
    @keyframes float-particle {
        0%, 100% {
            transform: translate(0, 0);
            opacity: 0;
        }
        10% {
            opacity: 1;
        }
        90% {
            opacity: 1;
        }
        50% {
            transform: translate(${Math.random() * 200 - 100}px, ${Math.random() * 200 - 100}px);
        }
    }
`;
document.head.appendChild(particleStyle);

document.addEventListener('DOMContentLoaded', createParticles);

// ==================== 性能优化：防抖函数 ====================
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// 优化窗口调整大小事件
window.addEventListener('resize', debounce(() => {
    // 重新计算布局或其他需要响应窗口大小变化的操作
    console.log('Window resized');
}, 250));

// ==================== 主题切换功能（预留） ====================
function initThemeToggle() {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    // 目前使用深色主题，可以在此添加主题切换逻辑
}

document.addEventListener('DOMContentLoaded', initThemeToggle);

// ==================== Console 彩蛋 ====================
console.log(
    '%c🎬 SUK Protocol',
    'color: #8B5CF6; font-size: 24px; font-weight: bold; text-shadow: 2px 2px 4px rgba(139, 92, 246, 0.5);'
);
console.log(
    '%c欢迎来到竖屏短剧版权RWA平台！',
    'color: #FF6B9D; font-size: 16px; font-weight: bold;'
);
console.log(
    '%c正在寻找开发者？访问我们的 GitHub 了解更多信息。',
    'color: #FFA500; font-size: 14px;'
);

// ==================== 性能监控 ====================
if ('performance' in window) {
    window.addEventListener('load', () => {
        setTimeout(() => {
            const perfData = window.performance.timing;
            const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
            console.log(`%c⚡ 页面加载时间: ${pageLoadTime}ms`, 'color: #10b981; font-weight: bold;');
        }, 0);
    });
}