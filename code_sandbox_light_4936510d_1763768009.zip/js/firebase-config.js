// ========================================
// SUK Protocol - Firebase 配置
// ⚠️ 这个文件需要在 Firebase Console 创建项目后填写真实配置
// ========================================

// Firebase 配置对象
// 🔧 请在 Firebase Console 获取您的配置信息
// https://console.firebase.google.com/ → 项目设置 → 常规 → 您的应用
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",                    // 替换为您的 API Key
    authDomain: "YOUR_PROJECT.firebaseapp.com", // 替换为您的 Auth Domain
    projectId: "YOUR_PROJECT_ID",               // 替换为您的 Project ID
    storageBucket: "YOUR_PROJECT.appspot.com",  // 替换为您的 Storage Bucket
    messagingSenderId: "YOUR_SENDER_ID",        // 替换为您的 Messaging Sender ID
    appId: "YOUR_APP_ID",                       // 替换为您的 App ID
    measurementId: "YOUR_MEASUREMENT_ID"        // 可选：Google Analytics Measurement ID
};

// Firebase 服务配置
const firebaseServiceConfig = {
    // Firestore 配置
    firestore: {
        enablePersistence: true,  // 启用离线持久化
        cacheSizeBytes: 40000000  // 缓存大小 40MB
    },
    
    // Functions 配置
    functions: {
        region: 'asia-east1',     // Cloud Functions 区域（推荐香港）
        emulator: {
            host: 'localhost',
            port: 5001
        }
    },
    
    // Storage 配置
    storage: {
        maxUploadSize: 10 * 1024 * 1024  // 最大上传 10MB
    },
    
    // FCM 配置
    messaging: {
        vapidKey: 'YOUR_VAPID_KEY'  // Web Push 证书密钥
    }
};

// 环境配置
const envConfig = {
    isDevelopment: window.location.hostname === 'localhost',
    isProduction: window.location.hostname.includes('sukprotocol'),
    
    // API 端点
    apiEndpoint: window.location.hostname === 'localhost' 
        ? 'http://localhost:5001/YOUR_PROJECT_ID/asia-east1'
        : 'https://asia-east1-YOUR_PROJECT_ID.cloudfunctions.net',
    
    // 合约地址（根据网络切换）
    contracts: {
        // Polygon Mumbai Testnet
        80001: {
            sukToken: '0x...',              // SUK 代币合约地址
            dramaFactory: '0x...',          // 版权代币工厂合约
            staking: '0x...',               // 质押合约
            marketplace: '0x...'            // 市场合约
        },
        // Polygon Mainnet
        137: {
            sukToken: '0x...',
            dramaFactory: '0x...',
            staking: '0x...',
            marketplace: '0x...'
        }
    },
    
    // RPC 节点
    rpcUrls: {
        80001: 'https://rpc-mumbai.maticvigil.com',
        137: 'https://polygon-rpc.com'
    }
};

// Firebase 实例缓存
let firebaseApp = null;
let firebaseAuth = null;
let firebaseDb = null;
let firebaseStorage = null;
let firebaseFunctions = null;
let firebaseMessaging = null;

// 初始化 Firebase
function initializeFirebase() {
    if (firebaseApp) {
        console.log('✅ Firebase 已初始化');
        return firebaseApp;
    }

    try {
        // 检查配置是否已填写
        if (firebaseConfig.apiKey === 'YOUR_API_KEY') {
            console.warn('⚠️ Firebase 配置未填写，请在 firebase-config.js 中配置');
            console.warn('📖 参考 FIREBASE_SETUP_GUIDE.md 获取配置步骤');
            return null;
        }

        // 检查 Firebase SDK 是否已加载
        if (typeof firebase === 'undefined') {
            console.error('❌ Firebase SDK 未加载，请在 HTML 中引入 Firebase CDN');
            console.error('💡 添加以下代码到 <head> 标签：');
            console.error(`
                <script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js"></script>
                <script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-auth-compat.js"></script>
                <script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore-compat.js"></script>
                <script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-storage-compat.js"></script>
                <script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-functions-compat.js"></script>
                <script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-messaging-compat.js"></script>
            `);
            return null;
        }

        // 初始化 Firebase App
        firebaseApp = firebase.initializeApp(firebaseConfig);
        console.log('✅ Firebase App 初始化成功');

        // 初始化各个服务
        firebaseAuth = firebase.auth();
        firebaseDb = firebase.firestore();
        firebaseStorage = firebase.storage();
        firebaseFunctions = firebase.functions();
        
        // 配置 Functions 区域
        if (firebaseServiceConfig.functions.region) {
            firebaseFunctions = firebase.app().functions(firebaseServiceConfig.functions.region);
        }

        // 配置 Firestore
        if (firebaseServiceConfig.firestore.enablePersistence) {
            firebaseDb.enablePersistence({
                synchronizeTabs: true
            }).catch((err) => {
                console.warn('⚠️ Firestore 持久化启用失败:', err.code);
            });
        }

        // 初始化 FCM（仅在生产环境且支持的浏览器）
        if ('Notification' in window && 'serviceWorker' in navigator) {
            try {
                firebaseMessaging = firebase.messaging();
                console.log('✅ Firebase Cloud Messaging 初始化成功');
            } catch (err) {
                console.warn('⚠️ FCM 初始化失败:', err.message);
            }
        }

        console.log('🎉 Firebase 所有服务初始化成功！');
        console.log('- Authentication:', !!firebaseAuth);
        console.log('- Firestore:', !!firebaseDb);
        console.log('- Storage:', !!firebaseStorage);
        console.log('- Functions:', !!firebaseFunctions);
        console.log('- Messaging:', !!firebaseMessaging);

        return firebaseApp;

    } catch (error) {
        console.error('❌ Firebase 初始化失败:', error);
        console.error('💡 请检查 firebase-config.js 中的配置是否正确');
        return null;
    }
}

// 获取 Firebase 服务实例
function getFirebaseAuth() {
    if (!firebaseAuth) {
        initializeFirebase();
    }
    return firebaseAuth;
}

function getFirebaseDb() {
    if (!firebaseDb) {
        initializeFirebase();
    }
    return firebaseDb;
}

function getFirebaseStorage() {
    if (!firebaseStorage) {
        initializeFirebase();
    }
    return firebaseStorage;
}

function getFirebaseFunctions() {
    if (!firebaseFunctions) {
        initializeFirebase();
    }
    return firebaseFunctions;
}

function getFirebaseMessaging() {
    if (!firebaseMessaging) {
        initializeFirebase();
    }
    return firebaseMessaging;
}

// 检查 Firebase 是否已配置
function isFirebaseConfigured() {
    return firebaseConfig.apiKey !== 'YOUR_API_KEY';
}

// 使用模拟器（开发环境）
function useFirebaseEmulators() {
    if (!envConfig.isDevelopment) {
        console.warn('⚠️ 模拟器仅在开发环境使用');
        return;
    }

    try {
        const auth = getFirebaseAuth();
        const db = getFirebaseDb();
        const functions = getFirebaseFunctions();
        const storage = getFirebaseStorage();

        // 连接到 Auth 模拟器
        auth.useEmulator('http://localhost:9099');
        console.log('✅ 连接到 Auth 模拟器: http://localhost:9099');

        // 连接到 Firestore 模拟器
        db.useEmulator('localhost', 8080);
        console.log('✅ 连接到 Firestore 模拟器: http://localhost:8080');

        // 连接到 Functions 模拟器
        functions.useEmulator('localhost', 5001);
        console.log('✅ 连接到 Functions 模拟器: http://localhost:5001');

        // 连接到 Storage 模拟器
        storage.useEmulator('localhost', 9199);
        console.log('✅ 连接到 Storage 模拟器: http://localhost:9199');

        console.log('🎯 所有 Firebase 模拟器已连接');
        console.log('💡 运行 "firebase emulators:start" 启动模拟器');

    } catch (error) {
        console.error('❌ 连接模拟器失败:', error);
    }
}

// 导出配置和方法
window.FirebaseConfig = {
    config: firebaseConfig,
    serviceConfig: firebaseServiceConfig,
    envConfig: envConfig,
    
    // 初始化方法
    initialize: initializeFirebase,
    useEmulators: useFirebaseEmulators,
    
    // 服务获取方法
    getAuth: getFirebaseAuth,
    getDb: getFirebaseDb,
    getStorage: getFirebaseStorage,
    getFunctions: getFirebaseFunctions,
    getMessaging: getFirebaseMessaging,
    
    // 工具方法
    isConfigured: isFirebaseConfigured,
    isDevelopment: envConfig.isDevelopment,
    isProduction: envConfig.isProduction
};

// 自动初始化（页面加载时）
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        initializeFirebase();
    });
} else {
    initializeFirebase();
}

console.log('📦 Firebase 配置模块已加载');
console.log('💡 使用 FirebaseConfig.initialize() 手动初始化');
console.log('💡 使用 FirebaseConfig.getAuth() 获取认证实例');
