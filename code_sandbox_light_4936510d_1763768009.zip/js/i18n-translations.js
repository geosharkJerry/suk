// SUK Protocol - 多语言翻译系统
// Supported Languages: 中文(zh), English(en), Español(es), ไทย(th), Tiếng Việt(vi), 日本語(ja)

const translations = {
    // 中文 (Chinese - Simplified)
    zh: {
        // 导航栏
        nav: {
            about: "关于",
            howItWorks: "工作原理",
            portfolio: "作品集",
            dashboard: "仪表盘",
            faq: "FAQ",
            whitepaper: "白皮书",
            login: "登录/注册"
        },
        
        // Hero Section
        hero: {
            badge: "🎬 全球Web3.0链剧资产平台",
            title1: "拥有",
            titleHighlight: "经典内容",
            title2: "共享创作收益",
            subtitle1: "通过SUK Protocol，将竖屏短剧版权转化为链上资产（RWA）",
            subtitle2: "让创作者和投资者都能从优质内容中获得收益",
            stat1Value: "29.8亿 SUK",
            stat1Label: "总锁仓价值 ($29.8M)",
            stat2Value: "38+",
            stat2Label: "精品短剧版权",
            stat3Value: "15-19%",
            stat3Label: "预期年化收益",
            btnExplore: "探索作品集",
            btnLearnMore: "了解更多"
        },
        
        // 首个作品集
        firstPortfolio: {
            tag: "SUK首个短剧RWA作品集",
            value1: "2850万 SUK",
            desc1: "通过合作伙伴筹集",
            value2: "128",
            desc2: "优质短剧部分版权",
            value3: "6-12%",
            desc3: "预期年化收益率"
        },
        
        // 关于SUK
        about: {
            title: "什么是SUK？",
            subtitle: "竖屏短剧版权的未来",
            text1: "SUK Protocol由SUK基金会管理运营。我们与SUK Protocol Labs等开发者共同努力，将优质竖屏短剧版权转化为链上资产，让所有人都能参与投资并从中获益。",
            text2: "随着短视频和竖屏内容的爆发式增长，短剧已成为最具潜力的文化娱乐形式之一。SUK Protocol通过区块链技术，让创作者能够更好地保护和变现版权，让投资者能够分享优质内容带来的收益。",
            card1Title: "版权保护",
            card1Desc: "区块链确保版权归属清晰可追溯",
            card2Title: "收益共享",
            card2Desc: "创作者与投资者共同分享版权收益",
            card3Title: "价值增长",
            card3Desc: "优质内容的长期价值不断提升"
        },
        
        // 工作原理
        howItWorks: {
            title: "SUK如何运作",
            step1Title: "发现",
            step1Desc: "浏览我们精心筛选的优质竖屏短剧版权资产，包括热门剧集、新锐作品和经典IP",
            step2Title: "投资",
            step2Desc: "参与版权池或购买RWA代币，获得您喜爱的短剧作品的部分版权收益权",
            step3Title: "收益",
            step3Desc: "通过多种方式获得收益：版权分红、质押奖励、交易收益等，分享短剧成功带来的回报",
            step4Title: "授权",
            step4Desc: "持有版权代币的用户可以参与内容授权决策，甚至获得二次创作和衍生开发的权利"
        },
        
        // 作品集
        portfolio: {
            title: "热门短剧RWA",
            subtitle: "投资优质短剧版权，获得持续收益",
            badgeHot: "🔥🔥🔥 热门",
            badgeHighScore: "🔥🔥🔥🔥 高分",
            badgePopular: "🔥🔥🔥 热播",
            btnViewDetails: "查看详情",
            btnInvest: "立即投资",
            labelTokenPrice: "代币价格",
            labelAPY: "年化收益",
            labelTVL: "总锁仓"
        },
        
        // 收益说明
        earn: {
            title: "从优质短剧中获得版权收益",
            subtitle: "持有短剧RWA代币，您将获得多重收益来源",
            item1Title: "版权分红",
            item1Desc: "从短剧播放、授权、衍生品等收入中获得分红",
            item2Title: "质押奖励",
            item2Desc: "质押代币获得额外奖励，参与平台治理",
            item3Title: "交易收益",
            item3Desc: "在二级市场交易版权代币，享受价值增长",
            item4Title: "社区权益",
            item4Desc: "参与内容决策，获得独家内容和活动权益"
        },
        
        // 基金会
        foundation: {
            title: "为SUK而建",
            name: "SUK基金会",
            desc: "SUK基金会是SUK Protocol的管理机构，致力于推动竖屏短剧版权的数字化和资产化进程，保护创作者权益，促进产业健康发展。"
        },
        
        // 通用
        common: {
            episodes: "集",
            rating: "评分",
            views: "播放",
            suk: "SUK"
        }
    },
    
    // English
    en: {
        nav: {
            about: "About",
            howItWorks: "How It Works",
            portfolio: "Portfolio",
            dashboard: "Dashboard",
            faq: "FAQ",
            whitepaper: "Whitepaper",
            login: "Login/Sign Up"
        },
        
        hero: {
            badge: "🎬 Innovative Vertical Drama IP Platform",
            title1: "Own",
            titleHighlight: "Premium Content",
            title2: "Share Creative Revenue",
            subtitle1: "Through SUK Protocol, transform vertical drama copyrights into on-chain assets (RWA)",
            subtitle2: "Enabling creators and investors to profit from quality content together",
            stat1Value: "2.98B SUK",
            stat1Label: "Total Value Locked ($29.8M)",
            stat2Value: "38+",
            stat2Label: "Premium Drama IPs",
            stat3Value: "15-19%",
            stat3Label: "Expected Annual Yield",
            btnExplore: "Explore Portfolio",
            btnLearnMore: "Learn More"
        },
        
        firstPortfolio: {
            tag: "SUK's First Drama RWA Portfolio",
            value1: "28.5M SUK",
            desc1: "Raised Through Partners",
            value2: "128",
            desc2: "Quality Drama Partial Rights",
            value3: "6-12%",
            desc3: "Expected Annual Return"
        },
        
        about: {
            title: "What is SUK?",
            subtitle: "The Future of Vertical Drama Copyright",
            text1: "SUK Protocol is managed by the SUK Foundation. We work with developers like SUK Protocol Labs to transform quality vertical drama copyrights into on-chain assets, allowing everyone to invest and benefit.",
            text2: "With the explosive growth of short videos and vertical content, short dramas have become one of the most promising forms of cultural entertainment. SUK Protocol uses blockchain technology to help creators better protect and monetize copyrights, allowing investors to share in the revenue from quality content.",
            card1Title: "Copyright Protection",
            card1Desc: "Blockchain ensures clear and traceable copyright ownership",
            card2Title: "Revenue Sharing",
            card2Desc: "Creators and investors jointly share copyright revenue",
            card3Title: "Value Growth",
            card3Desc: "Long-term value of quality content continues to grow"
        },
        
        howItWorks: {
            title: "How SUK Works",
            step1Title: "Discover",
            step1Desc: "Browse our carefully selected quality vertical drama copyright assets, including popular series, emerging works, and classic IPs",
            step2Title: "Invest",
            step2Desc: "Participate in copyright pools or purchase RWA tokens to gain partial copyright revenue rights from your favorite drama works",
            step3Title: "Earn",
            step3Desc: "Earn through multiple channels: copyright dividends, staking rewards, trading profits, etc., sharing in the success of dramas",
            step4Title: "License",
            step4Desc: "Token holders can participate in content licensing decisions and even obtain rights for derivative creation and development"
        },
        
        portfolio: {
            title: "Popular Drama RWAs",
            subtitle: "Invest in quality drama copyrights for continuous returns",
            badgeHot: "🔥🔥🔥 Hot",
            badgeHighScore: "🔥🔥🔥🔥 Top Rated",
            badgePopular: "🔥🔥🔥 Trending",
            btnViewDetails: "View Details",
            btnInvest: "Invest Now",
            labelTokenPrice: "Token Price",
            labelAPY: "Annual Yield",
            labelTVL: "Total Locked"
        },
        
        earn: {
            title: "Earn Copyright Revenue from Quality Dramas",
            subtitle: "Holding drama RWA tokens provides multiple revenue streams",
            item1Title: "Copyright Dividends",
            item1Desc: "Earn dividends from drama plays, licensing, merchandise, and more",
            item2Title: "Staking Rewards",
            item2Desc: "Stake tokens for additional rewards and participate in platform governance",
            item3Title: "Trading Profits",
            item3Desc: "Trade copyright tokens in secondary markets, enjoying value appreciation",
            item4Title: "Community Benefits",
            item4Desc: "Participate in content decisions, access exclusive content and event perks"
        },
        
        foundation: {
            title: "Built for SUK",
            name: "SUK Foundation",
            desc: "The SUK Foundation is the governing body of SUK Protocol, dedicated to advancing the digitization and assetization of vertical drama copyrights, protecting creator rights, and promoting healthy industry development."
        },
        
        common: {
            episodes: "Episodes",
            rating: "Rating",
            views: "Views",
            suk: "SUK"
        }
    },
    
    // Español (Spanish)
    es: {
        nav: {
            about: "Acerca de",
            howItWorks: "Cómo Funciona",
            portfolio: "Portafolio",
            dashboard: "Panel",
            faq: "Preguntas",
            whitepaper: "Libro Blanco",
            login: "Iniciar Sesión"
        },
        
        hero: {
            badge: "🎬 Plataforma Innovadora de IP de Drama Vertical",
            title1: "Poseer",
            titleHighlight: "Contenido Premium",
            title2: "Compartir Ingresos Creativos",
            subtitle1: "A través de SUK Protocol, transformamos los derechos de autor de dramas verticales en activos en cadena (RWA)",
            subtitle2: "Permitiendo que creadores e inversores se beneficien juntos del contenido de calidad",
            stat1Value: "1.23B SUK",
            stat1Label: "Valor Total Bloqueado ($12.3M)",
            stat2Value: "38+",
            stat2Label: "IPs de Drama Premium",
            stat3Value: "15-19%",
            stat3Label: "Rendimiento Anual Esperado",
            btnExplore: "Explorar Portafolio",
            btnLearnMore: "Saber Más"
        },
        
        firstPortfolio: {
            tag: "Primer Portafolio RWA de Drama de SUK",
            value1: "28.5M SUK",
            desc1: "Recaudado a Través de Socios",
            value2: "128",
            desc2: "Derechos Parciales de Drama de Calidad",
            value3: "6-12%",
            desc3: "Retorno Anual Esperado"
        },
        
        about: {
            title: "¿Qué es SUK?",
            subtitle: "El Futuro de los Derechos de Autor de Drama Vertical",
            text1: "SUK Protocol es administrado por la Fundación SUK. Trabajamos con desarrolladores como SUK Protocol Labs para transformar los derechos de autor de dramas verticales de calidad en activos en cadena, permitiendo que todos inviertan y se beneficien.",
            text2: "Con el crecimiento explosivo de videos cortos y contenido vertical, los dramas cortos se han convertido en una de las formas más prometedoras de entretenimiento cultural. SUK Protocol utiliza tecnología blockchain para ayudar a los creadores a proteger y monetizar mejor los derechos de autor, permitiendo a los inversores compartir los ingresos del contenido de calidad.",
            card1Title: "Protección de Derechos",
            card1Desc: "Blockchain garantiza propiedad clara y rastreable",
            card2Title: "Compartir Ingresos",
            card2Desc: "Creadores e inversores comparten ingresos de derechos de autor",
            card3Title: "Crecimiento de Valor",
            card3Desc: "El valor a largo plazo del contenido de calidad continúa creciendo"
        },
        
        howItWorks: {
            title: "Cómo Funciona SUK",
            step1Title: "Descubrir",
            step1Desc: "Explora nuestros activos de derechos de autor de dramas verticales cuidadosamente seleccionados, incluyendo series populares, obras emergentes e IPs clásicos",
            step2Title: "Invertir",
            step2Desc: "Participa en pools de derechos de autor o compra tokens RWA para obtener derechos de ingresos parciales de tus obras de drama favoritas",
            step3Title: "Ganar",
            step3Desc: "Gana a través de múltiples canales: dividendos de derechos de autor, recompensas de staking, ganancias comerciales, etc.",
            step4Title: "Licenciar",
            step4Desc: "Los titulares de tokens pueden participar en decisiones de licencias de contenido e incluso obtener derechos para creación y desarrollo derivados"
        },
        
        portfolio: {
            title: "RWAs de Drama Populares",
            subtitle: "Invierte en derechos de autor de dramas de calidad para retornos continuos",
            badgeHot: "🔥🔥🔥 Popular",
            badgeHighScore: "🔥🔥🔥🔥 Mejor Calificado",
            badgePopular: "🔥🔥🔥 Tendencia",
            btnViewDetails: "Ver Detalles",
            btnInvest: "Invertir Ahora",
            labelTokenPrice: "Precio del Token",
            labelAPY: "Rendimiento Anual",
            labelTVL: "Total Bloqueado"
        },
        
        earn: {
            title: "Gana Ingresos de Derechos de Dramas de Calidad",
            subtitle: "Los tokens RWA de drama proporcionan múltiples fuentes de ingresos",
            item1Title: "Dividendos de Derechos",
            item1Desc: "Gana dividendos de reproducciones, licencias, mercancía y más",
            item2Title: "Recompensas de Staking",
            item2Desc: "Apuesta tokens para recompensas adicionales y participa en la gobernanza",
            item3Title: "Ganancias Comerciales",
            item3Desc: "Comercia tokens de derechos en mercados secundarios, disfrutando de apreciación",
            item4Title: "Beneficios Comunitarios",
            item4Desc: "Participa en decisiones de contenido, accede a contenido exclusivo y beneficios"
        },
        
        foundation: {
            title: "Construido para SUK",
            name: "Fundación SUK",
            desc: "La Fundación SUK es el órgano de gobierno de SUK Protocol, dedicado a avanzar en la digitalización y actificación de los derechos de autor de dramas verticales, protegiendo los derechos de los creadores y promoviendo el desarrollo saludable de la industria."
        },
        
        common: {
            episodes: "Episodios",
            rating: "Calificación",
            views: "Vistas",
            suk: "SUK"
        }
    },
    
    // ไทย (Thai)
    th: {
        nav: {
            about: "เกี่ยวกับ",
            howItWorks: "วิธีการทำงาน",
            portfolio: "ผลงาน",
            dashboard: "แดชบอร์ด",
            faq: "คำถามที่พบบ่อย",
            whitepaper: "เอกสารไวท์เปเปอร์",
            login: "เข้าสู่ระบบ/ลงทะเบียน"
        },
        
        hero: {
            badge: "🎬 แพลตฟอร์มลิขสิทธิ์ละครแนวตั้งนวัตกรรม",
            title1: "เป็นเจ้าของ",
            titleHighlight: "เนื้อหาพรีเมียม",
            title2: "แบ่งปันรายได้สร้างสรรค์",
            subtitle1: "ผ่าน SUK Protocol เปลี่ยนลิขสิทธิ์ละครแนวตั้งเป็นสินทรัพย์บนเชน (RWA)",
            subtitle2: "ทำให้ผู้สร้างสรรค์และนักลงทุนได้รับผลกำไรจากเนื้อหาคุณภาพร่วมกัน",
            stat1Value: "1.23B SUK",
            stat1Label: "มูลค่ารวมที่ล็อค ($12.3M)",
            stat2Value: "38+",
            stat2Label: "ลิขสิทธิ์ละครพรีเมียม",
            stat3Value: "15-19%",
            stat3Label: "ผลตอบแทนต่อปีที่คาดหวัง",
            btnExplore: "สำรวจผลงาน",
            btnLearnMore: "เรียนรู้เพิ่มเติม"
        },
        
        firstPortfolio: {
            tag: "พอร์ตการลงทุน RWA ละครแรกของ SUK",
            value1: "28.5M SUK",
            desc1: "ระดมทุนผ่านพาร์ทเนอร์",
            value2: "128",
            desc2: "ลิขสิทธิ์บางส่วนของละครคุณภาพ",
            value3: "6-12%",
            desc3: "ผลตอบแทนต่อปีที่คาดหวัง"
        },
        
        about: {
            title: "SUK คืออะไร?",
            subtitle: "อนาคตของลิขสิทธิ์ละครแนวตั้ง",
            text1: "SUK Protocol จัดการโดยมูลนิธิ SUK เราทำงานร่วมกับนักพัฒนาเช่น SUK Protocol Labs เพื่อเปลี่ยนลิขสิทธิ์ละครแนวตั้งคุณภาพเป็นสินทรัพย์บนเชน ทำให้ทุกคนสามารถลงทุนและได้รับผลประโยชน์",
            text2: "ด้วยการเติบโตอย่างรวดเร็วของวิดีโอสั้นและเนื้อหาแนวตั้ง ละครสั้นกลายเป็นรูปแบบความบันเทิงทางวัฒนธรรมที่มีแนวโน้มมากที่สุดรูปแบบหนึ่ง SUK Protocol ใช้เทคโนโลยีบล็อกเชนเพื่อช่วยผู้สร้างสรรค์ปกป้องและสร้างรายได้จากลิขสิทธิ์ได้ดีขึ้น ทำให้นักลงทุนสามารถแบ่งปันรายได้จากเนื้อหาคุณภาพ",
            card1Title: "การปกป้องลิขสิทธิ์",
            card1Desc: "บล็อกเชนรับประกันความเป็นเจ้าของที่ชัดเจนและตรวจสอบได้",
            card2Title: "แบ่งปันรายได้",
            card2Desc: "ผู้สร้างสรรค์และนักลงทุนแบ่งปันรายได้จากลิขสิทธิ์ร่วมกัน",
            card3Title: "การเติบโตของมูลค่า",
            card3Desc: "มูลค่าระยะยาวของเนื้อหาคุณภาพเติบโตอย่างต่อเนื่อง"
        },
        
        howItWorks: {
            title: "SUK ทำงานอย่างไร",
            step1Title: "ค้นพบ",
            step1Desc: "เรียกดูสินทรัพย์ลิขสิทธิ์ละครแนวตั้งคุณภาพที่คัดสรรมาอย่างพิถีพิถัน รวมถึงซีรีส์ยอดนิยม ผลงานใหม่ และ IP คลาสสิก",
            step2Title: "ลงทุน",
            step2Desc: "เข้าร่วมพูลลิขสิทธิ์หรือซื้อโทเค็น RWA เพื่อรับสิทธิ์รายได้บางส่วนจากผลงานละครที่คุณชื่นชอบ",
            step3Title: "รับรายได้",
            step3Desc: "รับรายได้ผ่านช่องทางหลากหลาย: เงินปันผลจากลิขสิทธิ์ รางวัลจากการ staking กำไรจากการเทรด ฯลฯ",
            step4Title: "ให้สิทธิ์",
            step4Desc: "ผู้ถือโทเค็นสามารถมีส่วนร่วมในการตัดสินใจให้สิทธิ์เนื้อหาและแม้แต่ได้รับสิทธิ์ในการสร้างสรรค์และพัฒนาผลงานอนุพันธ์"
        },
        
        portfolio: {
            title: "RWA ละครยอดนิยม",
            subtitle: "ลงทุนในลิขสิทธิ์ละครคุณภาพเพื่อผลตอบแทนที่ต่อเนื่อง",
            badgeHot: "🔥🔥🔥 ฮอต",
            badgeHighScore: "🔥🔥🔥🔥 คะแนนสูงสุด",
            badgePopular: "🔥🔥🔥 กำลังมาแรง",
            btnViewDetails: "ดูรายละเอียด",
            btnInvest: "ลงทุนตอนนี้",
            labelTokenPrice: "ราคาโทเค็น",
            labelAPY: "ผลตอบแทนต่อปี",
            labelTVL: "ยอดรวมที่ล็อค"
        },
        
        earn: {
            title: "รับรายได้จากลิขสิทธิ์ละครคุณภาพ",
            subtitle: "การถือโทเค็น RWA ละครให้แหล่งรายได้หลากหลาย",
            item1Title: "เงินปันผลจากลิขสิทธิ์",
            item1Desc: "รับเงินปันผลจากการเล่น การให้สิทธิ์ สินค้า และอื่นๆ",
            item2Title: "รางวัลจากการ Staking",
            item2Desc: "Stake โทเค็นเพื่อรับรางวัลเพิ่มเติมและมีส่วนร่วมในการกำกับดูแลแพลตฟอร์ม",
            item3Title: "กำไรจากการเทรด",
            item3Desc: "เทรดโทเค็นลิขสิทธิ์ในตลาดรอง เพลิดเพลินกับการเพิ่มมูลค่า",
            item4Title: "สิทธิประโยชน์ชุมชน",
            item4Desc: "มีส่วนร่วมในการตัดสินใจเนื้อหา เข้าถึงเนื้อหาพิเศษและสิทธิประโยชน์กิจกรรม"
        },
        
        foundation: {
            title: "สร้างเพื่อ SUK",
            name: "มูลนิธิ SUK",
            desc: "มูลนิธิ SUK เป็นองค์กรกำกับดูแลของ SUK Protocol มุ่งมั่นที่จะส่งเสริมการแปลงเป็นดิจิทัลและสินทรัพย์ของลิขสิทธิ์ละครแนวตั้ง ปกป้องสิทธิ์ของผู้สร้างสรรค์ และส่งเสริมการพัฒนาอุตสาหกรรมที่ดีต่อสุขภาพ"
        },
        
        common: {
            episodes: "ตอน",
            rating: "คะแนน",
            views: "ครั้งดู",
            suk: "SUK"
        }
    },
    
    // Tiếng Việt (Vietnamese)
    vi: {
        nav: {
            about: "Giới Thiệu",
            howItWorks: "Cách Hoạt Động",
            portfolio: "Danh Mục",
            dashboard: "Bảng Điều Khiển",
            faq: "Câu Hỏi",
            whitepaper: "Sách Trắng",
            login: "Đăng Nhập/Đăng Ký"
        },
        
        hero: {
            badge: "🎬 Nền Tảng Bản Quyền Phim Dọc Sáng Tạo",
            title1: "Sở Hữu",
            titleHighlight: "Nội Dung Cao Cấp",
            title2: "Chia Sẻ Doanh Thu Sáng Tạo",
            subtitle1: "Thông qua SUK Protocol, chuyển đổi bản quyền phim dọc thành tài sản trên chuỗi (RWA)",
            subtitle2: "Cho phép người sáng tạo và nhà đầu tư cùng có lợi từ nội dung chất lượng",
            stat1Value: "1.23B SUK",
            stat1Label: "Tổng Giá Trị Khóa ($12.3M)",
            stat2Value: "38+",
            stat2Label: "Bản Quyền Phim Cao Cấp",
            stat3Value: "15-19%",
            stat3Label: "Lợi Nhuận Hàng Năm Dự Kiến",
            btnExplore: "Khám Phá Danh Mục",
            btnLearnMore: "Tìm Hiểu Thêm"
        },
        
        firstPortfolio: {
            tag: "Danh Mục RWA Phim Đầu Tiên Của SUK",
            value1: "28.5M SUK",
            desc1: "Huy Động Qua Đối Tác",
            value2: "128",
            desc2: "Quyền Một Phần Phim Chất Lượng",
            value3: "6-12%",
            desc3: "Lợi Nhuận Hàng Năm Dự Kiến"
        },
        
        about: {
            title: "SUK Là Gì?",
            subtitle: "Tương Lai Của Bản Quyền Phim Dọc",
            text1: "SUK Protocol được quản lý bởi Quỹ SUK. Chúng tôi làm việc với các nhà phát triển như SUK Protocol Labs để chuyển đổi bản quyền phim dọc chất lượng thành tài sản trên chuỗi, cho phép mọi người đầu tư và hưởng lợi.",
            text2: "Với sự tăng trưởng bùng nổ của video ngắn và nội dung dọc, phim ngắn đã trở thành một trong những hình thức giải trí văn hóa hứa hẹn nhất. SUK Protocol sử dụng công nghệ blockchain để giúp người sáng tạo bảo vệ và kiếm tiền từ bản quyền tốt hơn, cho phép nhà đầu tư chia sẻ doanh thu từ nội dung chất lượng.",
            card1Title: "Bảo Vệ Bản Quyền",
            card1Desc: "Blockchain đảm bảo quyền sở hữu rõ ràng và có thể truy vết",
            card2Title: "Chia Sẻ Doanh Thu",
            card2Desc: "Người sáng tạo và nhà đầu tư cùng chia sẻ doanh thu bản quyền",
            card3Title: "Tăng Trưởng Giá Trị",
            card3Desc: "Giá trị dài hạn của nội dung chất lượng tiếp tục tăng"
        },
        
        howItWorks: {
            title: "SUK Hoạt Động Như Thế Nào",
            step1Title: "Khám Phá",
            step1Desc: "Duyệt các tài sản bản quyền phim dọc chất lượng được chọn lọc cẩn thận của chúng tôi, bao gồm phim truyền hình nổi tiếng, tác phẩm mới nổi và IP cổ điển",
            step2Title: "Đầu Tư",
            step2Desc: "Tham gia các nhóm bản quyền hoặc mua token RWA để có được quyền doanh thu bản quyền một phần từ các tác phẩm phim yêu thích của bạn",
            step3Title: "Kiếm Tiền",
            step3Desc: "Kiếm tiền thông qua nhiều kênh: cổ tức bản quyền, phần thưởng staking, lợi nhuận giao dịch, v.v.",
            step4Title: "Cấp Phép",
            step4Desc: "Người nắm giữ token có thể tham gia vào các quyết định cấp phép nội dung và thậm chí có được quyền cho sáng tạo và phát triển phái sinh"
        },
        
        portfolio: {
            title: "RWA Phim Phổ Biến",
            subtitle: "Đầu tư vào bản quyền phim chất lượng để có lợi nhuận liên tục",
            badgeHot: "🔥🔥🔥 Nóng",
            badgeHighScore: "🔥🔥🔥🔥 Đánh Giá Cao",
            badgePopular: "🔥🔥🔥 Xu Hướng",
            btnViewDetails: "Xem Chi Tiết",
            btnInvest: "Đầu Tư Ngay",
            labelTokenPrice: "Giá Token",
            labelAPY: "Lợi Nhuận Hàng Năm",
            labelTVL: "Tổng Khóa"
        },
        
        earn: {
            title: "Kiếm Doanh Thu Bản Quyền Từ Phim Chất Lượng",
            subtitle: "Nắm giữ token RWA phim cung cấp nhiều nguồn doanh thu",
            item1Title: "Cổ Tức Bản Quyền",
            item1Desc: "Kiếm cổ tức từ lượt phát, cấp phép, hàng hóa và nhiều hơn nữa",
            item2Title: "Phần Thưởng Staking",
            item2Desc: "Stake token để nhận phần thưởng bổ sung và tham gia quản trị nền tảng",
            item3Title: "Lợi Nhuận Giao Dịch",
            item3Desc: "Giao dịch token bản quyền trên thị trường thứ cấp, tận hưởng sự tăng giá",
            item4Title: "Quyền Lợi Cộng Đồng",
            item4Desc: "Tham gia vào quyết định nội dung, truy cập nội dung độc quyền và quyền lợi sự kiện"
        },
        
        foundation: {
            title: "Xây Dựng Cho SUK",
            name: "Quỹ SUK",
            desc: "Quỹ SUK là cơ quan quản lý của SUK Protocol, cam kết thúc đẩy việc số hóa và tài sản hóa bản quyền phim dọc, bảo vệ quyền của người sáng tạo và thúc đẩy sự phát triển lành mạnh của ngành."
        },
        
        common: {
            episodes: "Tập",
            rating: "Đánh Giá",
            views: "Lượt Xem",
            suk: "SUK"
        }
    },
    
    // 日本語 (Japanese)
    ja: {
        nav: {
            about: "について",
            howItWorks: "仕組み",
            portfolio: "ポートフォリオ",
            dashboard: "ダッシュボード",
            faq: "よくある質問",
            whitepaper: "ホワイトペーパー",
            login: "ログイン/登録"
        },
        
        hero: {
            badge: "🎬 革新的な縦型ドラマ著作権プラットフォーム",
            title1: "所有する",
            titleHighlight: "プレミアムコンテンツ",
            title2: "創作収益を共有",
            subtitle1: "SUK Protocolを通じて、縦型ドラマの著作権をオンチェーンアセット（RWA）に変換",
            subtitle2: "クリエイターと投資家が共に高品質コンテンツから利益を得ることを可能に",
            stat1Value: "12.3億 SUK",
            stat1Label: "総ロック価値 ($12.3M)",
            stat2Value: "38+",
            stat2Label: "プレミアムドラマIP",
            stat3Value: "15-19%",
            stat3Label: "予想年間利回り",
            btnExplore: "ポートフォリオを探索",
            btnLearnMore: "詳細を見る"
        },
        
        firstPortfolio: {
            tag: "SUKの最初のドラマRWAポートフォリオ",
            value1: "2850万 SUK",
            desc1: "パートナーを通じて調達",
            value2: "128",
            desc2: "高品質ドラマの部分的権利",
            value3: "6-12%",
            desc3: "予想年間収益"
        },
        
        about: {
            title: "SUKとは？",
            subtitle: "縦型ドラマ著作権の未来",
            text1: "SUK ProtocolはSUK財団によって管理されています。私たちはSUK Protocol Labsなどの開発者と協力して、高品質な縦型ドラマの著作権をオンチェーンアセットに変換し、誰もが投資して利益を得られるようにしています。",
            text2: "短編動画と縦型コンテンツの爆発的な成長により、短編ドラマは最も有望な文化エンターテイメント形式の1つになりました。SUK Protocolはブロックチェーン技術を使用して、クリエイターが著作権をより良く保護し収益化できるようにし、投資家が高品質コンテンツからの収益を共有できるようにします。",
            card1Title: "著作権保護",
            card1Desc: "ブロックチェーンが明確で追跡可能な著作権所有権を保証",
            card2Title: "収益共有",
            card2Desc: "クリエイターと投資家が著作権収益を共同で共有",
            card3Title: "価値成長",
            card3Desc: "高品質コンテンツの長期的価値は成長し続けます"
        },
        
        howItWorks: {
            title: "SUKの仕組み",
            step1Title: "発見",
            step1Desc: "人気シリーズ、新興作品、クラシックIPを含む、厳選された高品質な縦型ドラマの著作権資産を閲覧",
            step2Title: "投資",
            step2Desc: "著作権プールに参加するか、RWAトークンを購入して、お気に入りのドラマ作品から部分的な著作権収益権を取得",
            step3Title: "収益",
            step3Desc: "複数のチャネルを通じて収益を得る：著作権配当、ステーキング報酬、取引利益など",
            step4Title: "ライセンス",
            step4Desc: "トークン保有者はコンテンツライセンス決定に参加でき、派生的な創作と開発の権利を得ることもできます"
        },
        
        portfolio: {
            title: "人気ドラマRWA",
            subtitle: "高品質なドラマ著作権に投資して継続的な収益を",
            badgeHot: "🔥🔥🔥 人気",
            badgeHighScore: "🔥🔥🔥🔥 高評価",
            badgePopular: "🔥🔥🔥 トレンド",
            btnViewDetails: "詳細を見る",
            btnInvest: "今すぐ投資",
            labelTokenPrice: "トークン価格",
            labelAPY: "年間利回り",
            labelTVL: "総ロック"
        },
        
        earn: {
            title: "高品質ドラマから著作権収益を獲得",
            subtitle: "ドラマRWAトークンの保有は複数の収益源を提供",
            item1Title: "著作権配当",
            item1Desc: "再生、ライセンス、商品などから配当を獲得",
            item2Title: "ステーキング報酬",
            item2Desc: "トークンをステークして追加報酬を獲得し、プラットフォームガバナンスに参加",
            item3Title: "取引利益",
            item3Desc: "セカンダリーマーケットで著作権トークンを取引し、価値の上昇を享受",
            item4Title: "コミュニティ特典",
            item4Desc: "コンテンツ決定に参加し、限定コンテンツとイベント特典にアクセス"
        },
        
        foundation: {
            title: "SUKのために構築",
            name: "SUK財団",
            desc: "SUK財団はSUK Protocolの統治機関であり、縦型ドラマの著作権のデジタル化と資産化を推進し、クリエイターの権利を保護し、業界の健全な発展を促進することに専念しています。"
        },
        
        common: {
            episodes: "話",
            rating: "評価",
            views: "視聴回数",
            suk: "SUK"
        }
    }
};

// 导出翻译对象
if (typeof module !== 'undefined' && module.exports) {
    module.exports = translations;
}
