/**
 * SUK奖励服务
 * 
 * 功能:
 * 1. 观看奖励计算和发放
 * 2. 邀请奖励计算和发放
 * 3. 奖励统计和查询
 */

const { WatchReward, InviteReward, InviteRelation, UserRewardStats } = require('../models/Reward');
const { Drama } = require('../models/Drama');
const { Order } = require('../models/Order');
const crypto = require('crypto');

class RewardService {
    /**
     * 记录观看奖励
     * @param {Object} data - 观看数据
     * @returns {Object} 奖励记录
     */
    async recordWatchReward(data) {
        const {
            userId,
            walletAddress,
            dramaId,
            episodeId,
            watchDuration,
            totalDuration
        } = data;

        // 1. 获取剧集价格
        const drama = await Drama.findById(dramaId);
        if (!drama) {
            throw new Error('短剧不存在');
        }

        const episode = drama.episodes.find(ep => ep.episodeId === episodeId);
        if (!episode) {
            throw new Error('剧集不存在');
        }

        // 2. 计算观看百分比
        const watchPercent = (watchDuration / totalDuration) * 100;

        // 3. 计算奖励金额
        // 奖励 = (观看时长 / 总时长) * 剧集价格 * 1%
        const watchRatio = watchDuration / totalDuration;
        const dramaPrice = episode.price || drama.price || 0;
        const rewardRate = 0.01; // 1%
        const rewardAmount = watchRatio * dramaPrice * rewardRate;

        // 4. 防作弊检查
        const validationScore = await this.calculateValidationScore({
            userId,
            watchDuration,
            totalDuration,
            watchPercent
        });

        // 5. 创建奖励记录
        const reward = new WatchReward({
            userId,
            walletAddress,
            dramaId,
            episodeId,
            watchDuration,
            totalDuration,
            watchPercent,
            dramaPrice,
            rewardRate,
            rewardAmount,
            isValid: validationScore >= 50,
            validationScore,
            status: validationScore >= 50 ? 'pending' : 'rejected'
        });

        await reward.save();

        // 6. 更新用户统计
        await this.updateUserRewardStats(userId);

        return reward;
    }

    /**
     * 记录邀请奖励
     * @param {Object} data - 邀请数据
     * @returns {Object} 奖励记录
     */
    async recordInviteReward(data) {
        const {
            inviterId,
            inviterWallet,
            inviteeId,
            inviteeWallet,
            orderId
        } = data;

        // 1. 检查邀请关系是否存在
        const relation = await InviteRelation.findOne({ 
            inviterId, 
            inviteeId 
        });

        if (!relation) {
            throw new Error('邀请关系不存在');
        }

        // 2. 检查订单
        const order = await Order.findById(orderId);
        if (!order) {
            throw new Error('订单不存在');
        }

        // 防止重复奖励
        const existingReward = await InviteReward.findOne({ orderId });
        if (existingReward) {
            throw new Error('该订单已发放邀请奖励');
        }

        // 3. 计算奖励金额
        // 奖励 = 购买金额 * 7%
        const purchaseAmount = order.amount;
        const rewardRate = 0.07; // 7%
        const rewardAmount = purchaseAmount * rewardRate;

        // 4. 创建奖励记录
        const reward = new InviteReward({
            inviterId,
            inviterWallet,
            inviteeId,
            inviteeWallet,
            orderId,
            dramaId: order.dramaId,
            purchaseAmount,
            rewardRate,
            rewardAmount,
            status: 'pending'
        });

        await reward.save();

        // 5. 更新邀请关系统计
        await InviteRelation.findOneAndUpdate(
            { inviterId, inviteeId },
            {
                $inc: {
                    totalPurchaseAmount: purchaseAmount,
                    totalRewardAmount: rewardAmount,
                    purchaseCount: 1
                },
                $set: {
                    status: 'purchased',
                    firstPurchaseAt: relation.firstPurchaseAt || new Date()
                }
            }
        );

        // 6. 更新用户统计
        await this.updateUserRewardStats(inviterId);

        return reward;
    }

    /**
     * 创建邀请关系
     * @param {Object} data - 邀请数据
     * @returns {Object} 邀请关系
     */
    async createInviteRelation(data) {
        const {
            inviterId,
            inviterWallet,
            inviteeId,
            inviteCode,
            inviteSource = 'link'
        } = data;

        // 检查是否已被邀请
        const existing = await InviteRelation.findOne({ inviteeId });
        if (existing) {
            return existing; // 已经有邀请关系，返回现有关系
        }

        // 创建邀请关系
        const relation = new InviteRelation({
            inviterId,
            inviterWallet,
            inviteeId,
            inviteCode,
            inviteSource,
            status: 'registered',
            registeredAt: new Date()
        });

        await relation.save();

        // 更新邀请人统计
        await this.updateUserRewardStats(inviterId);

        return relation;
    }

    /**
     * 生成邀请码
     * @param {String} userId - 用户ID
     * @returns {String} 邀请码
     */
    generateInviteCode(userId) {
        // 生成8位邀请码: SUK + 5位随机字符
        const randomPart = crypto.randomBytes(3).toString('hex').toUpperCase().slice(0, 5);
        return `SUK${randomPart}`;
    }

    /**
     * 获取用户邀请码
     * @param {String} userId - 用户ID
     * @returns {String} 邀请码
     */
    async getUserInviteCode(userId) {
        // 查找是否有现有的邀请关系（作为邀请人）
        const relation = await InviteRelation.findOne({ inviterId: userId });
        
        if (relation) {
            return relation.inviteCode;
        }

        // 如果没有，生成新的邀请码
        return this.generateInviteCode(userId);
    }

    /**
     * 验证邀请码
     * @param {String} inviteCode - 邀请码
     * @returns {Object} 邀请人信息
     */
    async validateInviteCode(inviteCode) {
        const relation = await InviteRelation.findOne({ inviteCode });
        
        if (!relation) {
            return null;
        }

        return {
            inviterId: relation.inviterId,
            inviterWallet: relation.inviterWallet
        };
    }

    /**
     * 绑定钱包（更新邀请关系）
     * @param {String} userId - 用户ID
     * @param {String} walletAddress - 钱包地址
     */
    async bindWallet(userId, walletAddress) {
        // 更新作为被邀请人的关系
        await InviteRelation.findOneAndUpdate(
            { inviteeId: userId },
            {
                $set: {
                    inviteeWallet: walletAddress,
                    boundAt: new Date(),
                    status: 'bound'
                }
            }
        );

        // 更新作为邀请人的关系
        await InviteRelation.updateMany(
            { inviterId: userId },
            {
                $set: {
                    inviterWallet: walletAddress
                }
            }
        );

        // 更新奖励记录
        await WatchReward.updateMany(
            { userId, walletAddress: null },
            { $set: { walletAddress } }
        );

        await InviteReward.updateMany(
            { inviterId: userId, inviterWallet: null },
            { $set: { inviterWallet: walletAddress } }
        );
    }

    /**
     * 计算验证得分（防作弊）
     * @param {Object} data - 验证数据
     * @returns {Number} 得分 (0-100)
     */
    async calculateValidationScore(data) {
        const { userId, watchDuration, totalDuration, watchPercent } = data;
        let score = 100;

        // 1. 检查观看时长是否合理
        if (watchDuration > totalDuration) {
            score -= 50; // 观看时长超过总时长，严重可疑
        }

        // 2. 检查观看百分比
        if (watchPercent < 5) {
            score -= 20; // 观看太少
        }

        // 3. 检查是否频繁刷奖励（同一用户1分钟内多次记录）
        const recentCount = await WatchReward.countDocuments({
            userId,
            createdAt: { $gte: new Date(Date.now() - 60000) }
        });

        if (recentCount > 5) {
            score -= 30; // 频繁刷奖励
        }

        // 4. 检查是否有过多的待发放奖励
        const pendingCount = await WatchReward.countDocuments({
            userId,
            status: 'pending'
        });

        if (pendingCount > 100) {
            score -= 20; // 大量待发放奖励，可能是作弊
        }

        return Math.max(0, score);
    }

    /**
     * 更新用户奖励统计
     * @param {String} userId - 用户ID
     */
    async updateUserRewardStats(userId) {
        // 1. 计算观看奖励统计
        const watchStats = await WatchReward.aggregate([
            { $match: { userId } },
            {
                $group: {
                    _id: '$status',
                    total: { $sum: '$rewardAmount' },
                    count: { $sum: 1 }
                }
            }
        ]);

        const watchRewards = {
            total: 0,
            pending: 0,
            paid: 0,
            count: 0
        };

        watchStats.forEach(stat => {
            if (stat._id === 'pending' || stat._id === 'approved') {
                watchRewards.pending += stat.total;
            } else if (stat._id === 'paid') {
                watchRewards.paid += stat.total;
            }
            watchRewards.total += stat.total;
            watchRewards.count += stat.count;
        });

        // 2. 计算邀请奖励统计
        const inviteStats = await InviteReward.aggregate([
            { $match: { inviterId: userId } },
            {
                $group: {
                    _id: '$status',
                    total: { $sum: '$rewardAmount' },
                    count: { $sum: 1 }
                }
            }
        ]);

        const inviteRewards = {
            total: 0,
            pending: 0,
            paid: 0,
            count: 0
        };

        inviteStats.forEach(stat => {
            if (stat._id === 'pending' || stat._id === 'approved') {
                inviteRewards.pending += stat.total;
            } else if (stat._id === 'paid') {
                inviteRewards.paid += stat.total;
            }
            inviteRewards.total += stat.total;
            inviteRewards.count += stat.count;
        });

        // 3. 计算邀请统计
        const relations = await InviteRelation.aggregate([
            { $match: { inviterId: userId } },
            {
                $group: {
                    _id: null,
                    total: { $sum: 1 },
                    bound: {
                        $sum: {
                            $cond: [
                                { $in: ['$status', ['bound', 'purchased']] },
                                1,
                                0
                            ]
                        }
                    },
                    purchased: {
                        $sum: {
                            $cond: [{ $eq: ['$status', 'purchased'] }, 1, 0]
                        }
                    }
                }
            }
        ]);

        const inviteStatsData = relations[0] || { total: 0, bound: 0, purchased: 0 };
        const conversionRate = inviteStatsData.total > 0
            ? (inviteStatsData.purchased / inviteStatsData.total) * 100
            : 0;

        // 4. 更新或创建统计记录
        const stats = await UserRewardStats.findOneAndUpdate(
            { userId },
            {
                $set: {
                    watchRewards,
                    inviteRewards,
                    inviteStats: {
                        totalInvites: inviteStatsData.total,
                        boundInvites: inviteStatsData.bound,
                        purchasedInvites: inviteStatsData.purchased,
                        conversionRate: Math.round(conversionRate * 100) / 100
                    },
                    totalEarned: watchRewards.total + inviteRewards.total,
                    totalPending: watchRewards.pending + inviteRewards.pending,
                    totalPaid: watchRewards.paid + inviteRewards.paid,
                    lastUpdated: new Date()
                }
            },
            { upsert: true, new: true }
        );

        return stats;
    }

    /**
     * 获取用户奖励统计
     * @param {String} userId - 用户ID
     * @returns {Object} 统计数据
     */
    async getUserRewardStats(userId) {
        let stats = await UserRewardStats.findOne({ userId });
        
        if (!stats) {
            // 如果没有统计数据，创建一个
            stats = await this.updateUserRewardStats(userId);
        }

        return stats;
    }

    /**
     * 获取用户邀请列表
     * @param {String} userId - 用户ID
     * @param {Object} options - 查询选项
     * @returns {Array} 邀请列表
     */
    async getUserInvites(userId, options = {}) {
        const {
            page = 1,
            limit = 20,
            status
        } = options;

        const query = { inviterId: userId };
        if (status) {
            query.status = status;
        }

        const invites = await InviteRelation.find(query)
            .sort({ createdAt: -1 })
            .skip((page - 1) * limit)
            .limit(limit)
            .lean();

        const total = await InviteRelation.countDocuments(query);

        return {
            data: invites,
            pagination: {
                page,
                limit,
                total,
                pages: Math.ceil(total / limit)
            }
        };
    }

    /**
     * 获取用户奖励记录
     * @param {String} userId - 用户ID
     * @param {Object} options - 查询选项
     * @returns {Object} 奖励记录
     */
    async getUserRewards(userId, options = {}) {
        const {
            page = 1,
            limit = 20,
            type = 'all', // all, watch, invite
            status
        } = options;

        const results = {
            watch: { data: [], total: 0 },
            invite: { data: [], total: 0 }
        };

        // 查询观看奖励
        if (type === 'all' || type === 'watch') {
            const watchQuery = { userId };
            if (status) watchQuery.status = status;

            results.watch.data = await WatchReward.find(watchQuery)
                .populate('dramaId', 'title coverUrl')
                .sort({ createdAt: -1 })
                .skip((page - 1) * limit)
                .limit(limit)
                .lean();

            results.watch.total = await WatchReward.countDocuments(watchQuery);
        }

        // 查询邀请奖励
        if (type === 'all' || type === 'invite') {
            const inviteQuery = { inviterId: userId };
            if (status) inviteQuery.status = status;

            results.invite.data = await InviteReward.find(inviteQuery)
                .populate('dramaId', 'title coverUrl')
                .sort({ createdAt: -1 })
                .skip((page - 1) * limit)
                .limit(limit)
                .lean();

            results.invite.total = await InviteReward.countDocuments(inviteQuery);
        }

        return {
            watch: results.watch,
            invite: results.invite,
            pagination: {
                page,
                limit
            }
        };
    }

    /**
     * 批准奖励（管理员操作）
     * @param {String} rewardId - 奖励ID
     * @param {String} type - 奖励类型 (watch, invite)
     */
    async approveReward(rewardId, type = 'watch') {
        const Model = type === 'watch' ? WatchReward : InviteReward;
        
        const reward = await Model.findByIdAndUpdate(
            rewardId,
            { $set: { status: 'approved' } },
            { new: true }
        );

        return reward;
    }

    /**
     * 发放奖励（管理员操作）
     * @param {String} rewardId - 奖励ID
     * @param {String} type - 奖励类型
     * @param {String} txHash - 交易哈希
     */
    async payReward(rewardId, type = 'watch', txHash) {
        const Model = type === 'watch' ? WatchReward : InviteReward;
        
        const reward = await Model.findByIdAndUpdate(
            rewardId,
            {
                $set: {
                    status: 'paid',
                    paidAt: new Date(),
                    txHash
                }
            },
            { new: true }
        );

        // 更新用户统计
        const userId = type === 'watch' ? reward.userId : reward.inviterId;
        await this.updateUserRewardStats(userId);

        return reward;
    }
}

module.exports = new RewardService();
