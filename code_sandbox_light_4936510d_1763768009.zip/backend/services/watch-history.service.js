/**
 * 观看历史服务
 * 负责记录和管理用户的观看历史、播放进度
 */

const WatchHistory = require('../models/WatchHistory');
const Drama = require('../models/Drama');

class WatchHistoryService {
    /**
     * 保存或更新观看进度
     * @param {object} data - 观看数据
     * @returns {Promise<object>} 保存结果
     */
    async saveWatchProgress(data) {
        try {
            const {
                userId,
                dramaId,
                episodeId,
                watchProgress,  // 当前观看进度（秒）
                totalDuration,  // 视频总时长（秒）
                videoId         // 阿里云视频ID
            } = data;
            
            // 计算观看百分比
            const progressPercent = totalDuration > 0 
                ? Math.round((watchProgress / totalDuration) * 100) 
                : 0;
            
            // 判断是否已观看完成（观看超过95%视为完成）
            const isCompleted = progressPercent >= 95;
            
            // 查找或创建观看记录
            let history = await WatchHistory.findOne({
                userId,
                dramaId,
                episodeId
            });
            
            if (history) {
                // 更新现有记录
                history.watchProgress = watchProgress;
                history.totalDuration = totalDuration;
                history.progressPercent = progressPercent;
                history.isCompleted = isCompleted;
                history.lastWatchedAt = new Date();
                history.watchCount += 1;
                
                await history.save();
                
                console.log(`✅ 更新观看进度: ${userId} - ${episodeId}, 进度: ${progressPercent}%`);
            } else {
                // 创建新记录
                history = new WatchHistory({
                    userId,
                    dramaId,
                    episodeId,
                    videoId,
                    watchProgress,
                    totalDuration,
                    progressPercent,
                    isCompleted,
                    firstWatchedAt: new Date(),
                    lastWatchedAt: new Date(),
                    watchCount: 1
                });
                
                await history.save();
                
                console.log(`✅ 创建观看记录: ${userId} - ${episodeId}`);
            }
            
            return {
                success: true,
                historyId: history._id,
                progressPercent,
                isCompleted
            };
            
        } catch (error) {
            console.error('❌ 保存观看进度失败:', error);
            throw new Error(`保存观看进度失败: ${error.message}`);
        }
    }
    
    /**
     * 获取用户的观看历史列表
     * @param {string} userId - 用户ID
     * @param {object} options - 查询选项
     * @returns {Promise<Array>} 观看历史列表
     */
    async getUserWatchHistory(userId, options = {}) {
        try {
            const {
                page = 1,
                limit = 20,
                sortBy = 'lastWatchedAt',
                order = 'desc'
            } = options;
            
            const skip = (page - 1) * limit;
            const sortOptions = { [sortBy]: order === 'desc' ? -1 : 1 };
            
            // 查询观看历史
            const histories = await WatchHistory.find({ userId })
                .populate({
                    path: 'dramaId',
                    select: 'title coverImage category rating totalEpisodes'
                })
                .sort(sortOptions)
                .skip(skip)
                .limit(limit)
                .lean();
            
            // 获取总数
            const total = await WatchHistory.countDocuments({ userId });
            
            // 为每个历史记录添加剧集信息
            const enrichedHistories = await Promise.all(
                histories.map(async (history) => {
                    if (history.dramaId) {
                        const drama = await Drama.findById(history.dramaId._id);
                        const episode = drama?.episodes.find(
                            ep => ep.episodeId === history.episodeId
                        );
                        
                        return {
                            ...history,
                            episodeInfo: episode ? {
                                episodeId: episode.episodeId,
                                title: episode.title,
                                number: episode.number,
                                duration: episode.duration
                            } : null
                        };
                    }
                    return history;
                })
            );
            
            console.log(`✅ 获取观看历史成功: ${userId}, 共${total}条`);
            
            return {
                success: true,
                data: enrichedHistories,
                pagination: {
                    page,
                    limit,
                    total,
                    pages: Math.ceil(total / limit)
                }
            };
            
        } catch (error) {
            console.error('❌ 获取观看历史失败:', error);
            throw new Error(`获取观看历史失败: ${error.message}`);
        }
    }
    
    /**
     * 获取特定剧集的观看进度
     * @param {string} userId - 用户ID
     * @param {string} dramaId - 短剧ID
     * @param {string} episodeId - 剧集ID
     * @returns {Promise<object>} 观看进度信息
     */
    async getEpisodeProgress(userId, dramaId, episodeId) {
        try {
            const history = await WatchHistory.findOne({
                userId,
                dramaId,
                episodeId
            }).lean();
            
            if (!history) {
                return {
                    success: true,
                    hasHistory: false,
                    watchProgress: 0,
                    progressPercent: 0
                };
            }
            
            console.log(`✅ 获取剧集进度: ${episodeId}, 进度: ${history.progressPercent}%`);
            
            return {
                success: true,
                hasHistory: true,
                watchProgress: history.watchProgress,
                totalDuration: history.totalDuration,
                progressPercent: history.progressPercent,
                isCompleted: history.isCompleted,
                lastWatchedAt: history.lastWatchedAt
            };
            
        } catch (error) {
            console.error('❌ 获取剧集进度失败:', error);
            throw new Error(`获取剧集进度失败: ${error.message}`);
        }
    }
    
    /**
     * 获取短剧的整体观看进度
     * @param {string} userId - 用户ID
     * @param {string} dramaId - 短剧ID
     * @returns {Promise<object>} 短剧观看进度
     */
    async getDramaProgress(userId, dramaId) {
        try {
            // 获取该短剧的所有观看记录
            const histories = await WatchHistory.find({
                userId,
                dramaId
            }).lean();
            
            if (histories.length === 0) {
                return {
                    success: true,
                    hasHistory: false,
                    watchedEpisodes: 0,
                    lastWatchedEpisode: null
                };
            }
            
            // 找出最后观看的剧集
            const lastWatched = histories.reduce((prev, current) => {
                return new Date(current.lastWatchedAt) > new Date(prev.lastWatchedAt) 
                    ? current 
                    : prev;
            });
            
            // 统计已完成的剧集数
            const completedCount = histories.filter(h => h.isCompleted).length;
            
            console.log(`✅ 获取短剧进度: ${dramaId}, 已观看${histories.length}集`);
            
            return {
                success: true,
                hasHistory: true,
                watchedEpisodes: histories.length,
                completedEpisodes: completedCount,
                lastWatchedEpisode: {
                    episodeId: lastWatched.episodeId,
                    watchProgress: lastWatched.watchProgress,
                    progressPercent: lastWatched.progressPercent,
                    lastWatchedAt: lastWatched.lastWatchedAt
                }
            };
            
        } catch (error) {
            console.error('❌ 获取短剧进度失败:', error);
            throw new Error(`获取短剧进度失败: ${error.message}`);
        }
    }
    
    /**
     * 删除观看历史
     * @param {string} userId - 用户ID
     * @param {string} historyId - 历史记录ID
     * @returns {Promise<boolean>} 是否成功
     */
    async deleteWatchHistory(userId, historyId) {
        try {
            const result = await WatchHistory.deleteOne({
                _id: historyId,
                userId
            });
            
            if (result.deletedCount === 0) {
                throw new Error('观看历史不存在');
            }
            
            console.log(`✅ 删除观看历史成功: ${historyId}`);
            
            return true;
            
        } catch (error) {
            console.error('❌ 删除观看历史失败:', error);
            throw new Error(`删除观看历史失败: ${error.message}`);
        }
    }
    
    /**
     * 清空用户的所有观看历史
     * @param {string} userId - 用户ID
     * @returns {Promise<number>} 删除的记录数
     */
    async clearUserHistory(userId) {
        try {
            const result = await WatchHistory.deleteMany({ userId });
            
            console.log(`✅ 清空观看历史成功: ${userId}, 删除${result.deletedCount}条`);
            
            return result.deletedCount;
            
        } catch (error) {
            console.error('❌ 清空观看历史失败:', error);
            throw new Error(`清空观看历史失败: ${error.message}`);
        }
    }
    
    /**
     * 获取用户观看统计
     * @param {string} userId - 用户ID
     * @returns {Promise<object>} 统计数据
     */
    async getUserWatchStatistics(userId) {
        try {
            const histories = await WatchHistory.find({ userId }).lean();
            
            if (histories.length === 0) {
                return {
                    totalWatched: 0,
                    totalCompleted: 0,
                    totalWatchTime: 0,
                    uniqueDramas: 0
                };
            }
            
            // 计算总观看时长（分钟）
            const totalWatchTime = Math.round(
                histories.reduce((sum, h) => sum + h.watchProgress, 0) / 60
            );
            
            // 统计已完成的剧集数
            const totalCompleted = histories.filter(h => h.isCompleted).length;
            
            // 统计观看过的不同短剧数
            const uniqueDramas = new Set(histories.map(h => h.dramaId.toString())).size;
            
            console.log(`✅ 获取观看统计成功: ${userId}`);
            
            return {
                totalWatched: histories.length,
                totalCompleted,
                totalWatchTime, // 分钟
                uniqueDramas,
                averageProgress: Math.round(
                    histories.reduce((sum, h) => sum + h.progressPercent, 0) / histories.length
                )
            };
            
        } catch (error) {
            console.error('❌ 获取观看统计失败:', error);
            throw new Error(`获取观看统计失败: ${error.message}`);
        }
    }
    
    /**
     * 继续观看推荐（获取未完成的剧集）
     * @param {string} userId - 用户ID
     * @param {number} limit - 返回数量
     * @returns {Promise<Array>} 推荐列表
     */
    async getContinueWatchingList(userId, limit = 10) {
        try {
            const histories = await WatchHistory.find({
                userId,
                isCompleted: false,
                progressPercent: { $gt: 5 } // 至少观看了5%
            })
                .populate({
                    path: 'dramaId',
                    select: 'title coverImage category rating'
                })
                .sort({ lastWatchedAt: -1 })
                .limit(limit)
                .lean();
            
            // 添加剧集信息
            const enrichedList = await Promise.all(
                histories.map(async (history) => {
                    if (history.dramaId) {
                        const drama = await Drama.findById(history.dramaId._id);
                        const episode = drama?.episodes.find(
                            ep => ep.episodeId === history.episodeId
                        );
                        
                        return {
                            historyId: history._id,
                            drama: history.dramaId,
                            episode: episode ? {
                                episodeId: episode.episodeId,
                                title: episode.title,
                                number: episode.number
                            } : null,
                            watchProgress: history.watchProgress,
                            progressPercent: history.progressPercent,
                            lastWatchedAt: history.lastWatchedAt
                        };
                    }
                    return null;
                })
            );
            
            console.log(`✅ 获取继续观看列表成功: ${userId}, 共${enrichedList.length}项`);
            
            return enrichedList.filter(item => item !== null);
            
        } catch (error) {
            console.error('❌ 获取继续观看列表失败:', error);
            throw new Error(`获取继续观看列表失败: ${error.message}`);
        }
    }
}

// 导出单例
module.exports = new WatchHistoryService();
