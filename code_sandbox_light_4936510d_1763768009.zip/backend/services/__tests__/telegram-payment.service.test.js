/**
 * Telegram 支付服务单元测试
 * Telegram Payment Service Unit Tests
 */

const TelegramPaymentService = require('../telegram-payment.service');

describe('Telegram Payment Service', () => {
    
    describe('generateOrderId', () => {
        test('应该生成唯一的订单ID', () => {
            const orderId1 = TelegramPaymentService.generateOrderId();
            const orderId2 = TelegramPaymentService.generateOrderId();
            
            expect(orderId1).toBeDefined();
            expect(orderId2).toBeDefined();
            expect(orderId1).not.toBe(orderId2);
            expect(orderId1).toMatch(/^ORDER_[A-Z0-9_]+$/);
        });
        
        test('订单ID应该包含时间戳和随机数', () => {
            const orderId = TelegramPaymentService.generateOrderId();
            expect(orderId).toContain('ORDER_');
            expect(orderId.split('_').length).toBeGreaterThanOrEqual(3);
        });
    });
    
    describe('Service Methods', () => {
        test('应该有 createStarsInvoice 方法', () => {
            expect(TelegramPaymentService.createStarsInvoice).toBeDefined();
            expect(typeof TelegramPaymentService.createStarsInvoice).toBe('function');
        });
        
        test('应该有 createTonInvoice 方法', () => {
            expect(TelegramPaymentService.createTonInvoice).toBeDefined();
            expect(typeof TelegramPaymentService.createTonInvoice).toBe('function');
        });
        
        test('应该有 createSukOrder 方法', () => {
            expect(TelegramPaymentService.createSukOrder).toBeDefined();
            expect(typeof TelegramPaymentService.createSukOrder).toBe('function');
        });
        
        test('应该有 verifyPayment 方法', () => {
            expect(TelegramPaymentService.verifyPayment).toBeDefined();
            expect(typeof TelegramPaymentService.verifyPayment).toBe('function');
        });
        
        test('应该有 verifyTonPayment 方法', () => {
            expect(TelegramPaymentService.verifyTonPayment).toBeDefined();
            expect(typeof TelegramPaymentService.verifyTonPayment).toBe('function');
        });
        
        test('应该有 verifySukPayment 方法', () => {
            expect(TelegramPaymentService.verifySukPayment).toBeDefined();
            expect(typeof TelegramPaymentService.verifySukPayment).toBe('function');
        });
        
        test('应该有 checkPurchaseStatus 方法', () => {
            expect(TelegramPaymentService.checkPurchaseStatus).toBeDefined();
            expect(typeof TelegramPaymentService.checkPurchaseStatus).toBe('function');
        });
        
        test('应该有 processRefund 方法', () => {
            expect(TelegramPaymentService.processRefund).toBeDefined();
            expect(typeof TelegramPaymentService.processRefund).toBe('function');
        });
    });
    
    describe('Order Management', () => {
        test('应该有 saveOrder 方法', () => {
            expect(TelegramPaymentService.saveOrder).toBeDefined();
        });
        
        test('应该有 getOrder 方法', () => {
            expect(TelegramPaymentService.getOrder).toBeDefined();
        });
        
        test('应该有 updateOrderStatus 方法', () => {
            expect(TelegramPaymentService.updateOrderStatus).toBeDefined();
        });
    });
    
    describe('Purchase Management', () => {
        test('应该有 createPurchaseRecord 方法', () => {
            expect(TelegramPaymentService.createPurchaseRecord).toBeDefined();
        });
        
        test('应该有 getUserPurchases 方法', () => {
            expect(TelegramPaymentService.getUserPurchases).toBeDefined();
        });
    });
});
