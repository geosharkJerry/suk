/**
 * TON 区块链交易验证服务
 * TON Blockchain Transaction Verification Service
 * 
 * 使用 tonweb 库验证 TON 区块链交易
 */

const TonWeb = require('tonweb');

class TonBlockchainService {
    constructor() {
        // TON HTTP API 端点
        // Mainnet: https://toncenter.com/api/v2/jsonRPC
        // Testnet: https://testnet.toncenter.com/api/v2/jsonRPC
        const apiKey = process.env.TON_API_KEY || '';
        const network = process.env.TON_NETWORK || 'mainnet'; // 'mainnet' or 'testnet'
        
        const endpoint = network === 'testnet' 
            ? 'https://testnet.toncenter.com/api/v2/jsonRPC'
            : 'https://toncenter.com/api/v2/jsonRPC';
        
        this.tonweb = new TonWeb(new TonWeb.HttpProvider(endpoint, { apiKey }));
        this.receiverAddress = process.env.TON_WALLET_ADDRESS;
        
        // 验证配置
        if (!this.receiverAddress) {
            console.warn('⚠️  TON_WALLET_ADDRESS 未配置，TON 支付验证将无法使用');
        }
        
        console.log(`✅ TON 区块链服务已初始化 (${network})`);
    }

    /**
     * 验证 TON 交易
     * Verify TON transaction
     * 
     * @param {Object} params - 验证参数
     * @param {string} params.orderId - 订单ID
     * @param {number} params.expectedAmount - 期望金额（TON）
     * @param {string} params.senderAddress - 发送者地址
     * @param {string} params.transactionHash - 交易哈希（可选）
     * @param {number} params.timeout - 超时时间（毫秒，默认5分钟）
     * @returns {Promise<Object>} 验证结果
     */
    async verifyTransaction(params) {
        const {
            orderId,
            expectedAmount,
            senderAddress,
            transactionHash = null,
            timeout = 5 * 60 * 1000 // 5分钟
        } = params;

        try {
            console.log('🔍 开始验证 TON 交易:', {
                orderId,
                expectedAmount,
                senderAddress,
                transactionHash
            });

            // 验证接收地址
            if (!this.receiverAddress) {
                throw new Error('接收钱包地址未配置');
            }

            // 方法1: 如果提供了交易哈希，直接验证该交易
            if (transactionHash) {
                const result = await this.verifyTransactionByHash(
                    transactionHash,
                    expectedAmount,
                    orderId
                );
                return result;
            }

            // 方法2: 监听接收地址的新交易（轮询）
            const result = await this.waitForTransaction(
                orderId,
                expectedAmount,
                senderAddress,
                timeout
            );
            
            return result;

        } catch (error) {
            console.error('❌ TON 交易验证失败:', error.message);
            throw error;
        }
    }

    /**
     * 通过交易哈希验证交易
     * Verify transaction by hash
     */
    async verifyTransactionByHash(txHash, expectedAmount, orderId) {
        try {
            console.log('🔍 通过交易哈希验证:', txHash);

            // 获取交易详情
            const transactions = await this.tonweb.getTransactions(
                this.receiverAddress,
                1 // 最近1笔交易
            );

            if (!transactions || transactions.length === 0) {
                throw new Error('未找到交易记录');
            }

            // 查找匹配的交易
            const tx = transactions.find(t => {
                const hash = this.getTransactionHash(t);
                return hash === txHash;
            });

            if (!tx) {
                throw new Error('未找到匹配的交易');
            }

            // 验证交易
            return await this.validateTransaction(tx, expectedAmount, orderId);

        } catch (error) {
            console.error('通过哈希验证交易失败:', error);
            throw error;
        }
    }

    /**
     * 等待交易到达（轮询模式）
     * Wait for transaction (polling mode)
     */
    async waitForTransaction(orderId, expectedAmount, senderAddress, timeout) {
        const startTime = Date.now();
        const pollInterval = 3000; // 每3秒轮询一次
        const expectedAmountNano = Math.floor(expectedAmount * 1e9); // 转换为 nanotons

        console.log('⏳ 开始等待交易...', {
            orderId,
            expectedAmount: `${expectedAmount} TON`,
            expectedAmountNano: `${expectedAmountNano} nanotons`,
            senderAddress,
            timeout: `${timeout / 1000}秒`
        });

        while (Date.now() - startTime < timeout) {
            try {
                // 获取接收地址的最近交易
                const transactions = await this.tonweb.getTransactions(
                    this.receiverAddress,
                    10 // 最近10笔交易
                );

                console.log(`📡 轮询交易 (已等待 ${Math.floor((Date.now() - startTime) / 1000)}秒)...`);

                if (transactions && transactions.length > 0) {
                    // 查找匹配的交易
                    for (const tx of transactions) {
                        try {
                            // 检查交易时间（只检查最近的交易）
                            const txTime = tx.utime * 1000;
                            if (txTime < startTime - 60000) { // 忽略1分钟前的交易
                                continue;
                            }

                            // 验证交易
                            const result = await this.validateTransaction(
                                tx,
                                expectedAmount,
                                orderId,
                                senderAddress
                            );

                            if (result.success) {
                                console.log('✅ 找到匹配的交易！');
                                return result;
                            }
                        } catch (err) {
                            // 继续检查下一笔交易
                            continue;
                        }
                    }
                }

                // 等待下一次轮询
                await this.sleep(pollInterval);

            } catch (error) {
                console.error('轮询交易出错:', error.message);
                await this.sleep(pollInterval);
            }
        }

        throw new Error('交易等待超时，请检查交易是否已发送');
    }

    /**
     * 验证交易详情
     * Validate transaction details
     */
    async validateTransaction(tx, expectedAmount, orderId, senderAddress = null) {
        try {
            // 1. 检查交易类型（必须是incoming）
            if (!tx.in_msg || !tx.in_msg.source) {
                throw new Error('不是incoming交易');
            }

            // 2. 检查发送者地址（如果提供）
            if (senderAddress) {
                const txSender = tx.in_msg.source;
                if (txSender !== senderAddress) {
                    throw new Error(`发送者地址不匹配: expected ${senderAddress}, got ${txSender}`);
                }
            }

            // 3. 检查接收者地址
            const txReceiver = tx.in_msg.destination;
            if (txReceiver !== this.receiverAddress) {
                throw new Error('接收者地址不匹配');
            }

            // 4. 检查交易金额
            const txAmount = parseInt(tx.in_msg.value); // nanotons
            const expectedAmountNano = Math.floor(expectedAmount * 1e9);
            
            // 允许 ±0.01 TON 的误差（考虑手续费）
            const tolerance = 0.01 * 1e9;
            if (Math.abs(txAmount - expectedAmountNano) > tolerance) {
                throw new Error(
                    `金额不匹配: expected ${expectedAmountNano} nanotons, got ${txAmount} nanotons`
                );
            }

            // 5. 检查交易消息（comment）
            let txComment = '';
            try {
                if (tx.in_msg.message) {
                    const msgCell = TonWeb.boc.Cell.oneFromBoc(
                        TonWeb.utils.base64ToBytes(tx.in_msg.message)
                    );
                    const slice = msgCell.beginParse();
                    const op = slice.loadUint(32);
                    
                    // 文本消息的 op code 是 0
                    if (op === 0) {
                        const bytes = slice.loadBits(slice.remainingBits);
                        txComment = new TextDecoder().decode(bytes);
                    }
                }
            } catch (err) {
                console.log('解析交易消息失败:', err.message);
            }

            // 验证订单ID是否在comment中
            if (txComment && !txComment.includes(orderId)) {
                console.warn('⚠️  交易comment中未找到订单ID:', txComment);
                // 不抛出错误，因为用户可能没有填写comment
            }

            // 6. 检查交易确认状态
            // TON 交易一旦出现在区块中就是确认的
            if (!tx.transaction_id || !tx.transaction_id.hash) {
                throw new Error('交易未确认');
            }

            // 获取交易哈希
            const txHash = this.getTransactionHash(tx);

            console.log('✅ 交易验证通过:', {
                hash: txHash,
                from: tx.in_msg.source,
                to: txReceiver,
                amount: `${txAmount / 1e9} TON`,
                comment: txComment,
                time: new Date(tx.utime * 1000).toISOString()
            });

            return {
                success: true,
                verified: true,
                transactionHash: txHash,
                amount: txAmount / 1e9, // TON
                sender: tx.in_msg.source,
                receiver: txReceiver,
                comment: txComment,
                timestamp: tx.utime * 1000,
                blockNumber: tx.transaction_id.lt
            };

        } catch (error) {
            console.error('验证交易详情失败:', error.message);
            throw error;
        }
    }

    /**
     * 获取交易哈希
     * Get transaction hash
     */
    getTransactionHash(tx) {
        if (tx.transaction_id && tx.transaction_id.hash) {
            return TonWeb.utils.bytesToBase64(
                TonWeb.utils.hexToBytes(tx.transaction_id.hash)
            );
        }
        return null;
    }

    /**
     * 获取钱包余额
     * Get wallet balance
     */
    async getBalance(address = null) {
        try {
            const addr = address || this.receiverAddress;
            if (!addr) {
                throw new Error('钱包地址未提供');
            }

            const balance = await this.tonweb.getBalance(addr);
            const balanceTON = parseFloat(TonWeb.utils.fromNano(balance));
            
            console.log(`💰 钱包余额: ${balanceTON} TON`);
            
            return {
                address: addr,
                balance: balanceTON,
                balanceNano: balance.toString()
            };

        } catch (error) {
            console.error('获取余额失败:', error);
            throw error;
        }
    }

    /**
     * 获取最近的交易记录
     * Get recent transactions
     */
    async getRecentTransactions(address = null, limit = 10) {
        try {
            const addr = address || this.receiverAddress;
            if (!addr) {
                throw new Error('钱包地址未提供');
            }

            const transactions = await this.tonweb.getTransactions(addr, limit);
            
            const formatted = transactions.map(tx => ({
                hash: this.getTransactionHash(tx),
                from: tx.in_msg ? tx.in_msg.source : null,
                to: tx.in_msg ? tx.in_msg.destination : null,
                amount: tx.in_msg ? parseFloat(tx.in_msg.value) / 1e9 : 0,
                time: new Date(tx.utime * 1000).toISOString(),
                type: tx.in_msg ? 'incoming' : 'outgoing'
            }));

            console.log(`📜 获取到 ${formatted.length} 条交易记录`);
            
            return formatted;

        } catch (error) {
            console.error('获取交易记录失败:', error);
            throw error;
        }
    }

    /**
     * 验证钱包地址格式
     * Validate wallet address format
     */
    isValidAddress(address) {
        try {
            // TON 地址可以是以下格式之一:
            // 1. Raw address (workchain:hash)
            // 2. User-friendly address (EQ... or UQ...)
            
            if (!address || typeof address !== 'string') {
                return false;
            }

            // 简单验证：检查是否以 EQ 或 UQ 开头（user-friendly）
            // 或者包含冒号（raw format）
            if (address.startsWith('EQ') || address.startsWith('UQ') || address.includes(':')) {
                return true;
            }

            return false;

        } catch (error) {
            return false;
        }
    }

    /**
     * 辅助方法：延迟
     */
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    /**
     * 健康检查
     * Health check
     */
    async healthCheck() {
        try {
            // 测试 API 连接
            const balance = await this.tonweb.getBalance(this.receiverAddress);
            
            return {
                status: 'healthy',
                network: process.env.TON_NETWORK || 'mainnet',
                receiverAddress: this.receiverAddress,
                connected: true,
                balance: parseFloat(TonWeb.utils.fromNano(balance))
            };

        } catch (error) {
            return {
                status: 'unhealthy',
                network: process.env.TON_NETWORK || 'mainnet',
                receiverAddress: this.receiverAddress,
                connected: false,
                error: error.message
            };
        }
    }
}

module.exports = new TonBlockchainService();
