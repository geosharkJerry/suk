/**
 * SUK Token 区块链验证服务
 * SUK Token Blockchain Verification Service
 * 
 * 使用 ethers.js 验证 ERC-20 SUK Token 转账
 */

const { ethers } = require('ethers');

class SukBlockchainService {
    constructor() {
        // RPC 端点配置
        const rpcUrl = process.env.ETHEREUM_RPC_URL || 'https://eth-mainnet.g.alchemy.com/v2/your-api-key';
        const network = process.env.ETHEREUM_NETWORK || 'mainnet'; // 'mainnet', 'goerli', 'sepolia'
        
        // SUK Token 合约地址
        this.contractAddress = process.env.SUK_TOKEN_CONTRACT;
        this.receiverAddress = process.env.PLATFORM_WALLET_ADDRESS;
        
        // 连接到以太坊节点
        this.provider = new ethers.providers.JsonRpcProvider(rpcUrl);
        
        // ERC-20 标准 ABI（只需要 Transfer 事件和基本方法）
        this.erc20Abi = [
            // Transfer 事件
            'event Transfer(address indexed from, address indexed to, uint256 value)',
            // 查询方法
            'function balanceOf(address owner) view returns (uint256)',
            'function decimals() view returns (uint8)',
            'function symbol() view returns (string)',
            'function name() view returns (string)',
            'function totalSupply() view returns (uint256)'
        ];
        
        // 验证配置
        if (!this.contractAddress) {
            console.warn('⚠️  SUK_TOKEN_CONTRACT 未配置，SUK 支付验证将无法使用');
        }
        
        if (!this.receiverAddress) {
            console.warn('⚠️  PLATFORM_WALLET_ADDRESS 未配置，SUK 支付验证将无法使用');
        }
        
        // 创建合约实例
        if (this.contractAddress) {
            this.contract = new ethers.Contract(
                this.contractAddress,
                this.erc20Abi,
                this.provider
            );
        }
        
        console.log(`✅ SUK Token 区块链服务已初始化 (${network})`);
    }

    /**
     * 验证 SUK Token 转账
     * Verify SUK Token transfer
     * 
     * @param {Object} params - 验证参数
     * @param {string} params.orderId - 订单ID
     * @param {number} params.expectedAmount - 期望金额（SUK，最小单位）
     * @param {string} params.senderAddress - 发送者地址
     * @param {string} params.transactionHash - 交易哈希
     * @returns {Promise<Object>} 验证结果
     */
    async verifyTransaction(params) {
        const {
            orderId,
            expectedAmount,
            senderAddress,
            transactionHash
        } = params;

        try {
            console.log('🔍 开始验证 SUK Token 交易:', {
                orderId,
                expectedAmount,
                senderAddress,
                transactionHash
            });

            // 验证配置
            if (!this.contractAddress || !this.receiverAddress) {
                throw new Error('合约地址或接收地址未配置');
            }

            // 验证交易哈希格式
            if (!transactionHash || !ethers.utils.isHexString(transactionHash, 32)) {
                throw new Error('无效的交易哈希格式');
            }

            // 获取交易收据
            const receipt = await this.provider.getTransactionReceipt(transactionHash);
            
            if (!receipt) {
                throw new Error('交易未找到或未确认');
            }

            // 检查交易状态
            if (receipt.status === 0) {
                throw new Error('交易执行失败');
            }

            // 验证交易已确认（至少1个确认）
            const currentBlock = await this.provider.getBlockNumber();
            const confirmations = currentBlock - receipt.blockNumber;
            
            if (confirmations < 1) {
                throw new Error('交易尚未确认');
            }

            console.log(`✅ 交易已确认 (${confirmations} 个区块确认)`);

            // 获取交易详情
            const transaction = await this.provider.getTransaction(transactionHash);
            
            if (!transaction) {
                throw new Error('无法获取交易详情');
            }

            // 验证交易是调用了 SUK Token 合约
            if (transaction.to.toLowerCase() !== this.contractAddress.toLowerCase()) {
                throw new Error('交易不是发送到 SUK Token 合约');
            }

            // 解析 Transfer 事件
            const transferEvent = this.parseTransferEvent(receipt);
            
            if (!transferEvent) {
                throw new Error('未找到 Transfer 事件');
            }

            // 验证发送者
            if (transferEvent.from.toLowerCase() !== senderAddress.toLowerCase()) {
                throw new Error(
                    `发送者地址不匹配: expected ${senderAddress}, got ${transferEvent.from}`
                );
            }

            // 验证接收者
            if (transferEvent.to.toLowerCase() !== this.receiverAddress.toLowerCase()) {
                throw new Error(
                    `接收者地址不匹配: expected ${this.receiverAddress}, got ${transferEvent.to}`
                );
            }

            // 获取 token decimals
            const decimals = await this.contract.decimals();
            
            // 转换金额（从 wei 单位）
            const actualAmount = ethers.utils.formatUnits(transferEvent.value, decimals);
            const expectedAmountFormatted = expectedAmount.toString();
            
            // 验证金额（允许 0.1% 的误差）
            const actualAmountBN = ethers.BigNumber.from(transferEvent.value);
            const expectedAmountBN = ethers.utils.parseUnits(expectedAmountFormatted, decimals);
            const tolerance = expectedAmountBN.div(1000); // 0.1%
            
            const diff = actualAmountBN.sub(expectedAmountBN).abs();
            
            if (diff.gt(tolerance)) {
                throw new Error(
                    `金额不匹配: expected ${expectedAmountFormatted} SUK, got ${actualAmount} SUK`
                );
            }

            // 获取区块时间戳
            const block = await this.provider.getBlock(receipt.blockNumber);

            console.log('✅ SUK Token 交易验证通过:', {
                hash: transactionHash,
                from: transferEvent.from,
                to: transferEvent.to,
                amount: `${actualAmount} SUK`,
                confirmations,
                blockNumber: receipt.blockNumber,
                time: new Date(block.timestamp * 1000).toISOString()
            });

            return {
                success: true,
                verified: true,
                transactionHash: transactionHash,
                amount: parseFloat(actualAmount),
                sender: transferEvent.from,
                receiver: transferEvent.to,
                blockNumber: receipt.blockNumber,
                confirmations: confirmations,
                timestamp: block.timestamp * 1000,
                gasUsed: receipt.gasUsed.toString()
            };

        } catch (error) {
            console.error('❌ SUK Token 交易验证失败:', error.message);
            throw error;
        }
    }

    /**
     * 解析 Transfer 事件
     * Parse Transfer event from transaction receipt
     */
    parseTransferEvent(receipt) {
        try {
            // 查找 Transfer 事件
            // Transfer 事件的签名: Transfer(address,address,uint256)
            const transferEventSignature = ethers.utils.id('Transfer(address,address,uint256)');
            
            for (const log of receipt.logs) {
                // 检查是否是 SUK Token 合约的事件
                if (log.address.toLowerCase() !== this.contractAddress.toLowerCase()) {
                    continue;
                }
                
                // 检查事件签名
                if (log.topics[0] === transferEventSignature) {
                    // 解析事件参数
                    // topics[0] = 事件签名
                    // topics[1] = from (indexed)
                    // topics[2] = to (indexed)
                    // data = value
                    
                    const from = ethers.utils.getAddress('0x' + log.topics[1].slice(26));
                    const to = ethers.utils.getAddress('0x' + log.topics[2].slice(26));
                    const value = ethers.BigNumber.from(log.data);
                    
                    return {
                        from,
                        to,
                        value
                    };
                }
            }
            
            return null;

        } catch (error) {
            console.error('解析 Transfer 事件失败:', error);
            return null;
        }
    }

    /**
     * 获取钱包 SUK Token 余额
     * Get wallet SUK Token balance
     */
    async getBalance(address = null) {
        try {
            const addr = address || this.receiverAddress;
            
            if (!addr) {
                throw new Error('钱包地址未提供');
            }

            if (!this.contract) {
                throw new Error('合约未初始化');
            }

            // 验证地址格式
            if (!ethers.utils.isAddress(addr)) {
                throw new Error('无效的钱包地址');
            }

            const balance = await this.contract.balanceOf(addr);
            const decimals = await this.contract.decimals();
            const balanceFormatted = ethers.utils.formatUnits(balance, decimals);
            
            console.log(`💰 SUK Token 余额: ${balanceFormatted} SUK`);
            
            return {
                address: addr,
                balance: parseFloat(balanceFormatted),
                balanceRaw: balance.toString(),
                decimals: decimals
            };

        } catch (error) {
            console.error('获取余额失败:', error);
            throw error;
        }
    }

    /**
     * 获取 Token 信息
     * Get token information
     */
    async getTokenInfo() {
        try {
            if (!this.contract) {
                throw new Error('合约未初始化');
            }

            const [name, symbol, decimals, totalSupply] = await Promise.all([
                this.contract.name(),
                this.contract.symbol(),
                this.contract.decimals(),
                this.contract.totalSupply()
            ]);

            const totalSupplyFormatted = ethers.utils.formatUnits(totalSupply, decimals);

            return {
                contractAddress: this.contractAddress,
                name,
                symbol,
                decimals,
                totalSupply: parseFloat(totalSupplyFormatted),
                totalSupplyRaw: totalSupply.toString()
            };

        } catch (error) {
            console.error('获取 Token 信息失败:', error);
            throw error;
        }
    }

    /**
     * 获取最近的 Transfer 事件
     * Get recent Transfer events
     */
    async getRecentTransfers(address = null, limit = 10) {
        try {
            if (!this.contract) {
                throw new Error('合约未初始化');
            }

            const addr = address || this.receiverAddress;
            
            if (!addr || !ethers.utils.isAddress(addr)) {
                throw new Error('无效的钱包地址');
            }

            // 获取最近的区块
            const currentBlock = await this.provider.getBlockNumber();
            const fromBlock = Math.max(0, currentBlock - 10000); // 最近 10000 个区块

            // 查询接收到的转账
            const filter = this.contract.filters.Transfer(null, addr);
            const events = await this.contract.queryFilter(filter, fromBlock, currentBlock);

            // 获取 decimals
            const decimals = await this.contract.decimals();

            // 格式化事件
            const transfers = await Promise.all(
                events.slice(-limit).map(async (event) => {
                    const amount = ethers.utils.formatUnits(event.args.value, decimals);
                    const block = await this.provider.getBlock(event.blockNumber);
                    
                    return {
                        transactionHash: event.transactionHash,
                        from: event.args.from,
                        to: event.args.to,
                        amount: parseFloat(amount),
                        blockNumber: event.blockNumber,
                        timestamp: block.timestamp * 1000,
                        time: new Date(block.timestamp * 1000).toISOString()
                    };
                })
            );

            console.log(`📜 获取到 ${transfers.length} 条转账记录`);
            
            return transfers.reverse(); // 最新的在前面

        } catch (error) {
            console.error('获取转账记录失败:', error);
            throw error;
        }
    }

    /**
     * 等待交易确认
     * Wait for transaction confirmation
     */
    async waitForConfirmation(transactionHash, confirmations = 1, timeout = 5 * 60 * 1000) {
        try {
            console.log(`⏳ 等待交易确认 (${confirmations} 个区块)...`);
            
            const receipt = await this.provider.waitForTransaction(
                transactionHash,
                confirmations,
                timeout
            );

            if (!receipt) {
                throw new Error('等待交易确认超时');
            }

            if (receipt.status === 0) {
                throw new Error('交易执行失败');
            }

            console.log(`✅ 交易已确认 (${confirmations} 个区块)`);
            
            return receipt;

        } catch (error) {
            console.error('等待交易确认失败:', error);
            throw error;
        }
    }

    /**
     * 验证钱包地址格式
     * Validate wallet address format
     */
    isValidAddress(address) {
        try {
            return ethers.utils.isAddress(address);
        } catch (error) {
            return false;
        }
    }

    /**
     * 健康检查
     * Health check
     */
    async healthCheck() {
        try {
            // 测试节点连接
            const blockNumber = await this.provider.getBlockNumber();
            const network = await this.provider.getNetwork();
            
            // 测试合约连接
            let tokenInfo = null;
            if (this.contract) {
                try {
                    tokenInfo = await this.getTokenInfo();
                } catch (err) {
                    console.error('获取 Token 信息失败:', err.message);
                }
            }

            return {
                status: 'healthy',
                network: network.name,
                chainId: network.chainId,
                blockNumber: blockNumber,
                contractAddress: this.contractAddress,
                receiverAddress: this.receiverAddress,
                connected: true,
                tokenInfo: tokenInfo
            };

        } catch (error) {
            return {
                status: 'unhealthy',
                network: process.env.ETHEREUM_NETWORK || 'mainnet',
                contractAddress: this.contractAddress,
                receiverAddress: this.receiverAddress,
                connected: false,
                error: error.message
            };
        }
    }
}

module.exports = new SukBlockchainService();
