/**
 * 阿里云视频点播 (VoD) 服务集成
 * 提供视频上传、播放凭证生成、视频管理等功能
 */

const RPCClient = require('@alicloud/pop-core').RPCClient;
const OSS = require('ali-oss');

class AliyunVoDService {
    constructor() {
        // 阿里云VoD客户端
        this.vodClient = new RPCClient({
            accessKeyId: process.env.ALIYUN_ACCESS_KEY_ID,
            accessKeySecret: process.env.ALIYUN_ACCESS_KEY_SECRET,
            endpoint: 'https://vod.cn-shanghai.aliyuncs.com',
            apiVersion: '2017-03-21'
        });
        
        // OSS客户端（用于上传）
        this.ossClient = null;
    }
    
    /**
     * 生成播放凭证（推荐方式）
     * @param {string} videoId - 阿里云视频ID
     * @param {number} timeout - 凭证有效期（秒），默认1800秒（30分钟）
     * @returns {Promise<string>} 播放凭证
     */
    async generatePlayAuth(videoId, timeout = 1800) {
        try {
            const params = {
                VideoId: videoId,
                AuthInfoTimeout: timeout
            };
            
            const result = await this.vodClient.request('GetVideoPlayAuth', params, {});
            
            console.log(`✅ 生成播放凭证成功: ${videoId}, 有效期: ${timeout}秒`);
            
            return result.PlayAuth;
            
        } catch (error) {
            console.error('❌ 生成播放凭证失败:', error);
            throw new Error(`生成播放凭证失败: ${error.message}`);
        }
    }
    
    /**
     * 获取播放地址（备用方式）
     * @param {string} videoId - 视频ID
     * @returns {Promise<object>} 播放地址信息
     */
    async getPlayUrl(videoId) {
        try {
            const params = {
                VideoId: videoId
            };
            
            const result = await this.vodClient.request('GetPlayInfo', params, {});
            
            return {
                playUrl: result.PlayInfoList?.PlayInfo[0]?.PlayURL,
                duration: result.VideoBase?.Duration,
                coverUrl: result.VideoBase?.CoverURL
            };
            
        } catch (error) {
            console.error('❌ 获取播放地址失败:', error);
            throw new Error(`获取播放地址失败: ${error.message}`);
        }
    }
    
    /**
     * 获取视频信息
     * @param {string} videoId - 视频ID
     * @returns {Promise<object>} 视频详细信息
     */
    async getVideoInfo(videoId) {
        try {
            const params = {
                VideoId: videoId
            };
            
            const result = await this.vodClient.request('GetVideoInfo', params, {});
            
            return {
                videoId: result.Video.VideoId,
                title: result.Video.Title,
                duration: result.Video.Duration,
                coverUrl: result.Video.CoverURL,
                status: result.Video.Status,
                createTime: result.Video.CreationTime,
                size: result.Video.Size
            };
            
        } catch (error) {
            console.error('❌ 获取视频信息失败:', error);
            throw new Error(`获取视频信息失败: ${error.message}`);
        }
    }
    
    /**
     * 获取上传凭证和地址
     * @param {string} title - 视频标题
     * @param {string} fileName - 文件名
     * @returns {Promise<object>} 上传凭证信息
     */
    async getUploadAuth(title, fileName) {
        try {
            const params = {
                Title: title,
                FileName: fileName,
                Description: `SUK Protocol - ${title}`,
                CoverURL: '', // 可选：封面图URL
                Tags: 'SUK,短剧,竖屏'
            };
            
            const result = await this.vodClient.request('CreateUploadVideo', params, {});
            
            console.log(`✅ 获取上传凭证成功: ${title}`);
            
            return {
                videoId: result.VideoId,
                uploadAddress: result.UploadAddress,
                uploadAuth: result.UploadAuth,
                requestId: result.RequestId
            };
            
        } catch (error) {
            console.error('❌ 获取上传凭证失败:', error);
            throw new Error(`获取上传凭证失败: ${error.message}`);
        }
    }
    
    /**
     * 刷新上传凭证
     * @param {string} videoId - 视频ID
     * @returns {Promise<object>} 新的上传凭证
     */
    async refreshUploadAuth(videoId) {
        try {
            const params = {
                VideoId: videoId
            };
            
            const result = await this.vodClient.request('RefreshUploadVideo', params, {});
            
            return {
                uploadAddress: result.UploadAddress,
                uploadAuth: result.UploadAuth
            };
            
        } catch (error) {
            console.error('❌ 刷新上传凭证失败:', error);
            throw new Error(`刷新上传凭证失败: ${error.message}`);
        }
    }
    
    /**
     * 初始化OSS上传客户端
     * @param {string} uploadAuth - 上传凭证
     * @param {string} uploadAddress - 上传地址
     */
    initOSSClient(uploadAuth, uploadAddress) {
        const authInfo = JSON.parse(Buffer.from(uploadAuth, 'base64').toString());
        const addressInfo = JSON.parse(Buffer.from(uploadAddress, 'base64').toString());
        
        this.ossClient = new OSS({
            region: addressInfo.Region,
            accessKeyId: authInfo.AccessKeyId,
            accessKeySecret: authInfo.AccessKeySecret,
            stsToken: authInfo.SecurityToken,
            bucket: addressInfo.Bucket
        });
        
        return {
            endpoint: addressInfo.Endpoint,
            bucket: addressInfo.Bucket,
            fileName: addressInfo.FileName
        };
    }
    
    /**
     * 上传视频文件到OSS
     * @param {Buffer} fileBuffer - 文件内容
     * @param {string} fileName - 文件名
     * @param {object} uploadInfo - 上传信息
     * @returns {Promise<string>} 视频ID
     */
    async uploadVideoFile(fileBuffer, fileName, uploadInfo) {
        try {
            const { uploadAuth, uploadAddress, videoId } = uploadInfo;
            
            // 初始化OSS客户端
            const { fileName: ossFileName } = this.initOSSClient(uploadAuth, uploadAddress);
            
            // 上传文件
            const result = await this.ossClient.put(ossFileName, fileBuffer);
            
            console.log(`✅ 视频上传成功: ${videoId}`);
            
            return videoId;
            
        } catch (error) {
            console.error('❌ 视频上传失败:', error);
            throw new Error(`视频上传失败: ${error.message}`);
        }
    }
    
    /**
     * 删除视频
     * @param {string} videoId - 视频ID
     * @returns {Promise<boolean>} 是否成功
     */
    async deleteVideo(videoId) {
        try {
            const params = {
                VideoIds: videoId
            };
            
            await this.vodClient.request('DeleteVideo', params, {});
            
            console.log(`✅ 删除视频成功: ${videoId}`);
            
            return true;
            
        } catch (error) {
            console.error('❌ 删除视频失败:', error);
            throw new Error(`删除视频失败: ${error.message}`);
        }
    }
    
    /**
     * 获取视频列表
     * @param {object} options - 查询选项
     * @returns {Promise<Array>} 视频列表
     */
    async getVideoList(options = {}) {
        try {
            const {
                status = 'Normal', // Normal, Checking, Blocked
                startTime,
                endTime,
                pageNo = 1,
                pageSize = 20
            } = options;
            
            const params = {
                Status: status,
                StartTime: startTime,
                EndTime: endTime,
                PageNo: pageNo,
                PageSize: pageSize
            };
            
            const result = await this.vodClient.request('GetVideoList', params, {});
            
            return {
                videos: result.VideoList?.Video || [],
                total: result.Total,
                pageNo: pageNo,
                pageSize: pageSize
            };
            
        } catch (error) {
            console.error('❌ 获取视频列表失败:', error);
            throw new Error(`获取视频列表失败: ${error.message}`);
        }
    }
    
    /**
     * 搜索视频
     * @param {string} keyword - 搜索关键词
     * @param {object} options - 搜索选项
     * @returns {Promise<Array>} 搜索结果
     */
    async searchVideo(keyword, options = {}) {
        try {
            const {
                pageNo = 1,
                pageSize = 20,
                sortBy = 'CreationTime:Desc'
            } = options;
            
            const params = {
                SearchType: 'video',
                Fields: 'Title,Tags,Description',
                Match: keyword,
                PageNo: pageNo,
                PageSize: pageSize,
                SortBy: sortBy
            };
            
            const result = await this.vodClient.request('SearchMedia', params, {});
            
            return {
                videos: result.MediaList || [],
                total: result.Total
            };
            
        } catch (error) {
            console.error('❌ 搜索视频失败:', error);
            throw new Error(`搜索视频失败: ${error.message}`);
        }
    }
    
    /**
     * 设置视频封面
     * @param {string} videoId - 视频ID
     * @param {string} coverUrl - 封面图URL
     * @returns {Promise<boolean>} 是否成功
     */
    async setVideoCover(videoId, coverUrl) {
        try {
            const params = {
                VideoId: videoId,
                CoverURL: coverUrl
            };
            
            await this.vodClient.request('UpdateVideoInfo', params, {});
            
            console.log(`✅ 设置视频封面成功: ${videoId}`);
            
            return true;
            
        } catch (error) {
            console.error('❌ 设置视频封面失败:', error);
            throw new Error(`设置视频封面失败: ${error.message}`);
        }
    }
    
    /**
     * 获取视频播放统计
     * @param {string} videoId - 视频ID
     * @param {string} startTime - 开始时间
     * @param {string} endTime - 结束时间
     * @returns {Promise<object>} 统计数据
     */
    async getVideoPlayStatistics(videoId, startTime, endTime) {
        try {
            const params = {
                VideoId: videoId,
                StartTime: startTime,
                EndTime: endTime
            };
            
            const result = await this.vodClient.request('DescribePlayVideoStatis', params, {});
            
            return {
                playCount: result.VideoPlayStatisDetails?.VideoPlayStatisDetail || [],
                total: result.Total
            };
            
        } catch (error) {
            console.error('❌ 获取播放统计失败:', error);
            throw new Error(`获取播放统计失败: ${error.message}`);
        }
    }
}

// 导出单例
module.exports = new AliyunVoDService();
