/**
 * Telegram 支付服务
 * Telegram Payment Service
 * 
 * 处理 Telegram Stars、TON 等支付方式
 */

const crypto = require('crypto');

class TelegramPaymentService {
    constructor() {
        this.botToken = process.env.TELEGRAM_BOT_TOKEN;
        this.botApiUrl = `https://api.telegram.org/bot${this.botToken}`;
    }

    /**
     * 创建 Telegram Stars 发票
     * Create Telegram Stars invoice
     * 
     * @param {Object} params - 发票参数
     * @param {string} params.userId - Telegram 用户 ID
     * @param {string} params.dramaId - 剧集 ID
     * @param {string} params.dramaTitle - 剧集标题
     * @param {number} params.priceStars - Stars 价格
     * @param {string} params.purchaseType - 购买类型 ('single' | 'full')
     * @param {string} params.episodeId - 剧集 ID（单集购买时）
     * @returns {Promise<Object>} 发票链接和信息
     */
    async createStarsInvoice(params) {
        const {
            userId,
            dramaId,
            dramaTitle,
            priceStars,
            purchaseType,
            episodeId
        } = params;

        try {
            // 生成唯一订单 ID
            const orderId = this.generateOrderId();

            // 构建发票标题和描述
            const title = purchaseType === 'single' 
                ? `${dramaTitle} - 单集购买`
                : `${dramaTitle} - 全集购买`;

            const description = purchaseType === 'single'
                ? `购买剧集 ${dramaTitle} 第${episodeId.split('_')[1]}集`
                : `购买剧集 ${dramaTitle} 全部集数`;

            // Stars 发票参数
            const invoiceParams = {
                chat_id: userId,
                title: title,
                description: description,
                payload: JSON.stringify({
                    orderId: orderId,
                    dramaId: dramaId,
                    purchaseType: purchaseType,
                    episodeId: episodeId || null,
                    timestamp: Date.now()
                }),
                provider_token: '', // Stars 支付不需要 provider_token
                currency: 'XTR', // Telegram Stars 货币代码
                prices: [
                    {
                        label: title,
                        amount: priceStars // Stars 数量
                    }
                ],
                // 可选参数
                max_tip_amount: 0,
                suggested_tip_amounts: [],
                start_parameter: `order_${orderId}`,
                photo_url: '', // 可以添加剧集封面
                photo_size: 0,
                photo_width: 0,
                photo_height: 0,
                need_name: false,
                need_phone_number: false,
                need_email: false,
                need_shipping_address: false,
                send_phone_number_to_provider: false,
                send_email_to_provider: false,
                is_flexible: false
            };

            // 调用 Telegram Bot API 创建发票
            const response = await this.sendInvoice(invoiceParams);

            if (!response.ok) {
                throw new Error(response.description || '创建发票失败');
            }

            // 保存订单到数据库（TODO: 实现数据库保存）
            await this.saveOrder({
                orderId: orderId,
                userId: userId,
                dramaId: dramaId,
                purchaseType: purchaseType,
                episodeId: episodeId,
                paymentMethod: 'stars',
                amount: priceStars,
                currency: 'XTR',
                status: 'pending',
                createdAt: new Date()
            });

            return {
                success: true,
                orderId: orderId,
                invoiceLink: null, // Stars 支付通过消息发送，不需要链接
                message: '发票已发送到您的 Telegram 聊天'
            };

        } catch (error) {
            console.error('创建 Stars 发票失败:', error);
            throw error;
        }
    }

    /**
     * 发送发票消息
     * Send invoice message
     */
    async sendInvoice(params) {
        try {
            const response = await fetch(`${this.botApiUrl}/sendInvoice`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(params)
            });

            return await response.json();

        } catch (error) {
            console.error('发送发票失败:', error);
            throw error;
        }
    }

    /**
     * 验证支付成功回调
     * Verify payment callback
     * 
     * @param {Object} update - Telegram 更新对象
     * @returns {Promise<Object>} 验证结果
     */
    async verifyPayment(update) {
        try {
            // 检查是否是支付成功消息
            if (!update.message || !update.message.successful_payment) {
                throw new Error('不是有效的支付成功消息');
            }

            const payment = update.message.successful_payment;
            const payload = JSON.parse(payment.invoice_payload);

            // 验证订单是否存在
            const order = await this.getOrder(payload.orderId);
            if (!order) {
                throw new Error('订单不存在');
            }

            // 验证订单状态
            if (order.status === 'completed') {
                return {
                    success: true,
                    alreadyProcessed: true,
                    message: '订单已处理'
                };
            }

            // 验证支付金额
            if (payment.total_amount !== order.amount) {
                throw new Error('支付金额不匹配');
            }

            // 更新订单状态
            await this.updateOrderStatus(payload.orderId, {
                status: 'completed',
                paymentId: payment.telegram_payment_charge_id,
                completedAt: new Date()
            });

            // 创建购买记录（TODO: 实现）
            await this.createPurchaseRecord({
                userId: order.userId,
                dramaId: order.dramaId,
                purchaseType: order.purchaseType,
                episodeId: order.episodeId,
                orderId: payload.orderId,
                paymentMethod: 'stars',
                amount: order.amount,
                currency: order.currency
            });

            return {
                success: true,
                orderId: payload.orderId,
                dramaId: payload.dramaId,
                purchaseType: payload.purchaseType,
                episodeId: payload.episodeId
            };

        } catch (error) {
            console.error('验证支付失败:', error);
            throw error;
        }
    }

    /**
     * 创建 TON 支付发票
     * Create TON payment invoice
     */
    async createTonInvoice(params) {
        const {
            userId,
            dramaId,
            dramaTitle,
            priceTON,
            purchaseType,
            episodeId
        } = params;

        try {
            // 生成唯一订单 ID
            const orderId = this.generateOrderId();

            // TON 钱包地址（从环境变量获取）
            const tonWallet = process.env.TON_WALLET_ADDRESS;

            if (!tonWallet) {
                throw new Error('TON 钱包地址未配置');
            }

            // 构建 TON 支付链接
            // 格式: ton://transfer/<destination>?amount=<nanotons>&text=<url-encoded-utf8-text>
            const amount = Math.floor(priceTON * 1e9); // 转换为 nanotons
            const comment = encodeURIComponent(`Order:${orderId}|Drama:${dramaId}`);
            
            const tonLink = `ton://transfer/${tonWallet}?amount=${amount}&text=${comment}`;

            // 保存订单
            await this.saveOrder({
                orderId: orderId,
                userId: userId,
                dramaId: dramaId,
                purchaseType: purchaseType,
                episodeId: episodeId,
                paymentMethod: 'ton',
                amount: priceTON,
                currency: 'TON',
                status: 'pending',
                paymentLink: tonLink,
                createdAt: new Date()
            });

            return {
                success: true,
                orderId: orderId,
                invoiceLink: tonLink,
                message: '请使用 TON 钱包完成支付'
            };

        } catch (error) {
            console.error('创建 TON 发票失败:', error);
            throw error;
        }
    }

    /**
     * 验证 TON 支付
     * Verify TON payment
     */
    async verifyTonPayment(orderId, transactionHash = null, senderAddress = null) {
        try {
            // 获取订单信息
            const order = await this.getOrder(orderId);
            if (!order) {
                throw new Error('订单不存在');
            }

            if (order.status === 'completed') {
                return {
                    success: true,
                    alreadyProcessed: true,
                    message: '订单已处理'
                };
            }

            // 使用 TON 区块链服务验证交易
            const tonService = require('./ton-blockchain.service');
            
            const verifyResult = await tonService.verifyTransaction({
                orderId: orderId,
                expectedAmount: order.amount,
                senderAddress: senderAddress,
                transactionHash: transactionHash,
                timeout: 5 * 60 * 1000 // 5分钟超时
            });

            if (!verifyResult.success) {
                throw new Error('交易验证失败');
            }

            // 更新订单状态
            await this.updateOrderStatus(orderId, {
                status: 'completed',
                txHash: verifyResult.transactionHash,
                verifiedAmount: verifyResult.amount,
                senderAddress: verifyResult.sender,
                completedAt: new Date()
            });

            // 创建购买记录
            await this.createPurchaseRecord({
                userId: order.userId,
                dramaId: order.dramaId,
                purchaseType: order.purchaseType,
                episodeId: order.episodeId,
                orderId: orderId,
                paymentMethod: 'ton',
                amount: order.amount,
                currency: order.currency,
                txHash: verifyResult.transactionHash
            });

            return {
                success: true,
                orderId: orderId,
                verified: true,
                transactionHash: verifyResult.transactionHash,
                amount: verifyResult.amount
            };

        } catch (error) {
            console.error('验证 TON 支付失败:', error);
            throw error;
        }
    }

    /**
     * 创建 SUK Token 支付订单
     * Create SUK Token payment order
     */
    async createSukOrder(params) {
        const {
            userId,
            dramaId,
            dramaTitle,
            priceSUK,
            purchaseType,
            episodeId,
            userWallet
        } = params;

        try {
            // 生成唯一订单 ID
            const orderId = this.generateOrderId();

            // SUK 合约地址（从环境变量获取）
            const sukContract = process.env.SUK_TOKEN_CONTRACT;

            if (!sukContract) {
                throw new Error('SUK Token 合约地址未配置');
            }

            // 保存订单
            await this.saveOrder({
                orderId: orderId,
                userId: userId,
                dramaId: dramaId,
                purchaseType: purchaseType,
                episodeId: episodeId,
                paymentMethod: 'suk',
                amount: priceSUK,
                currency: 'SUK',
                status: 'pending',
                userWallet: userWallet,
                createdAt: new Date()
            });

            return {
                success: true,
                orderId: orderId,
                contractAddress: sukContract,
                amount: priceSUK,
                message: '请使用钱包完成 SUK Token 支付'
            };

        } catch (error) {
            console.error('创建 SUK 订单失败:', error);
            throw error;
        }
    }

    /**
     * 验证 SUK Token 支付
     * Verify SUK Token payment
     */
    async verifySukPayment(orderId, txHash) {
        try {
            // 获取订单信息
            const order = await this.getOrder(orderId);
            if (!order) {
                throw new Error('订单不存在');
            }

            if (order.status === 'completed') {
                return {
                    success: true,
                    alreadyProcessed: true,
                    message: '订单已处理'
                };
            }

            // 使用 SUK 区块链服务验证交易
            const sukService = require('./suk-blockchain.service');
            
            const verifyResult = await sukService.verifyTransaction({
                orderId: orderId,
                expectedAmount: order.amount,
                senderAddress: order.userWallet,
                transactionHash: txHash
            });

            if (!verifyResult.success) {
                throw new Error('交易验证失败');
            }

            // 更新订单状态
            await this.updateOrderStatus(orderId, {
                status: 'completed',
                txHash: verifyResult.transactionHash,
                verifiedAmount: verifyResult.amount,
                senderAddress: verifyResult.sender,
                blockNumber: verifyResult.blockNumber,
                confirmations: verifyResult.confirmations,
                completedAt: new Date()
            });

            // 创建购买记录
            await this.createPurchaseRecord({
                userId: order.userId,
                dramaId: order.dramaId,
                purchaseType: order.purchaseType,
                episodeId: order.episodeId,
                orderId: orderId,
                paymentMethod: 'suk',
                amount: order.amount,
                currency: order.currency,
                txHash: verifyResult.transactionHash
            });

            return {
                success: true,
                orderId: orderId,
                verified: true,
                transactionHash: verifyResult.transactionHash,
                amount: verifyResult.amount,
                blockNumber: verifyResult.blockNumber,
                confirmations: verifyResult.confirmations
            };

        } catch (error) {
            console.error('验证 SUK 支付失败:', error);
            throw error;
        }
    }

    /**
     * 生成订单 ID
     * Generate order ID
     */
    generateOrderId() {
        const timestamp = Date.now().toString(36);
        const random = crypto.randomBytes(6).toString('hex');
        return `ORDER_${timestamp}_${random}`.toUpperCase();
    }

    /**
     * 保存订单到数据库
     * Save order to database
     */
    async saveOrder(orderData) {
        try {
            const Order = require('../models/Order');
            const order = new Order(orderData);
            await order.save();
            console.log('订单保存成功:', orderData.orderId);
            return order;
        } catch (error) {
            console.error('保存订单失败:', error);
            throw error;
        }
    }

    /**
     * 获取订单信息
     * Get order information
     */
    async getOrder(orderId) {
        try {
            const Order = require('../models/Order');
            const order = await Order.findOne({ orderId: orderId });
            if (!order) {
                console.log('订单不存在:', orderId);
            }
            return order;
        } catch (error) {
            console.error('获取订单失败:', error);
            throw error;
        }
    }

    /**
     * 更新订单状态
     * Update order status
     */
    async updateOrderStatus(orderId, updateData) {
        try {
            const Order = require('../models/Order');
            const order = await Order.findOneAndUpdate(
                { orderId: orderId },
                { $set: updateData },
                { new: true }
            );
            if (!order) {
                throw new Error('订单不存在');
            }
            console.log('订单状态更新成功:', orderId, updateData.status);
            return order;
        } catch (error) {
            console.error('更新订单状态失败:', error);
            throw error;
        }
    }

    /**
     * 创建购买记录
     * Create purchase record
     */
    async createPurchaseRecord(purchaseData) {
        try {
            const Purchase = require('../models/Purchase');
            
            // 检查是否已存在购买记录（防止重复创建）
            const existing = await Purchase.findOne({
                userId: purchaseData.userId,
                dramaId: purchaseData.dramaId,
                purchaseType: purchaseData.purchaseType,
                episodeId: purchaseData.episodeId,
                isValid: true
            });
            
            if (existing) {
                console.log('购买记录已存在，跳过创建:', purchaseData);
                return existing;
            }
            
            const purchase = new Purchase(purchaseData);
            await purchase.save();
            console.log('购买记录创建成功:', purchaseData.orderId);
            return purchase;
        } catch (error) {
            console.error('创建购买记录失败:', error);
            throw error;
        }
    }

    /**
     * 检查用户购买状态
     * Check user purchase status
     */
    async checkPurchaseStatus(userId, dramaId, episodeId = null) {
        try {
            const Purchase = require('../models/Purchase');
            
            // 使用 Purchase 模型的静态方法检查购买状态
            const result = await Purchase.checkPurchase(userId, dramaId, episodeId);
            return result;

        } catch (error) {
            console.error('检查购买状态失败:', error);
            throw error;
        }
    }

    /**
     * 获取用户所有购买记录
     * Get user all purchases
     */
    async getUserPurchases(userId) {
        try {
            const Purchase = require('../models/Purchase');
            const purchases = await Purchase.find({ 
                userId: userId,
                isValid: true 
            })
            .sort({ purchasedAt: -1 })
            .limit(100);
            
            return purchases;

        } catch (error) {
            console.error('获取购买记录失败:', error);
            throw error;
        }
    }

    /**
     * 退款处理
     * Process refund
     */
    async processRefund(orderId, reason) {
        try {
            const order = await this.getOrder(orderId);
            
            if (!order) {
                throw new Error('订单不存在');
            }

            if (order.status !== 'completed') {
                throw new Error('订单状态不允许退款');
            }

            // 根据支付方式处理退款
            switch (order.paymentMethod) {
                case 'stars':
                    // Telegram Stars 退款需要通过 Bot API
                    // TODO: 实现 Stars 退款
                    console.log('处理 Stars 退款:', orderId);
                    break;

                case 'ton':
                    // TON 退款需要发起链上交易
                    // TODO: 实现 TON 退款
                    console.log('处理 TON 退款:', orderId);
                    break;

                case 'suk':
                    // SUK Token 退款
                    // TODO: 实现 SUK 退款
                    console.log('处理 SUK 退款:', orderId);
                    break;

                default:
                    throw new Error('不支持的支付方式');
            }

            // 更新订单状态
            await this.updateOrderStatus(orderId, {
                status: 'refunded',
                refundReason: reason,
                refundedAt: new Date()
            });

            // 标记购买记录为无效（软删除）
            const Purchase = require('../models/Purchase');
            await Purchase.updateOne(
                { orderId: orderId },
                { $set: { isValid: false } }
            );
            console.log('购买记录已标记为无效:', orderId);

            return {
                success: true,
                orderId: orderId,
                message: '退款成功'
            };

        } catch (error) {
            console.error('退款失败:', error);
            throw error;
        }
    }
}

module.exports = new TelegramPaymentService();
