/**
 * 观看历史数据模型
 */

const mongoose = require('mongoose');

const watchHistorySchema = new mongoose.Schema({
    // 用户ID（钱包地址）
    userId: {
        type: String,
        required: true,
        index: true
    },
    
    // 短剧ID
    dramaId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Drama',
        required: true,
        index: true
    },
    
    // 剧集ID
    episodeId: {
        type: String,
        required: true,
        index: true
    },
    
    // 阿里云视频ID
    videoId: {
        type: String,
        required: true
    },
    
    // 观看进度（秒）
    watchProgress: {
        type: Number,
        required: true,
        default: 0,
        min: 0
    },
    
    // 视频总时长（秒）
    totalDuration: {
        type: Number,
        required: true,
        default: 0
    },
    
    // 观看进度百分比
    progressPercent: {
        type: Number,
        default: 0,
        min: 0,
        max: 100
    },
    
    // 是否已观看完成（超过95%视为完成）
    isCompleted: {
        type: Boolean,
        default: false,
        index: true
    },
    
    // 首次观看时间
    firstWatchedAt: {
        type: Date,
        default: Date.now
    },
    
    // 最后观看时间
    lastWatchedAt: {
        type: Date,
        default: Date.now,
        index: true
    },
    
    // 观看次数
    watchCount: {
        type: Number,
        default: 1,
        min: 1
    },
    
    // 观看设备信息（可选）
    deviceInfo: {
        userAgent: String,
        platform: String,
        browser: String
    }
}, {
    timestamps: true, // 自动添加createdAt和updatedAt
    collection: 'watch_histories'
});

// 复合索引：用户ID + 短剧ID + 剧集ID（唯一）
watchHistorySchema.index({ userId: 1, dramaId: 1, episodeId: 1 }, { unique: true });

// 索引：用户ID + 最后观看时间（用于排序）
watchHistorySchema.index({ userId: 1, lastWatchedAt: -1 });

// 索引：用户ID + 是否完成（用于筛选）
watchHistorySchema.index({ userId: 1, isCompleted: 1 });

// 虚拟字段：格式化的观看进度
watchHistorySchema.virtual('formattedProgress').get(function() {
    const minutes = Math.floor(this.watchProgress / 60);
    const seconds = Math.floor(this.watchProgress % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
});

// 虚拟字段：格式化的总时长
watchHistorySchema.virtual('formattedDuration').get(function() {
    const minutes = Math.floor(this.totalDuration / 60);
    const seconds = Math.floor(this.totalDuration % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
});

// 实例方法：更新观看进度
watchHistorySchema.methods.updateProgress = async function(newProgress, newDuration) {
    this.watchProgress = newProgress;
    this.totalDuration = newDuration;
    this.progressPercent = Math.round((newProgress / newDuration) * 100);
    this.isCompleted = this.progressPercent >= 95;
    this.lastWatchedAt = new Date();
    this.watchCount += 1;
    
    return await this.save();
};

// 静态方法：获取用户的继续观看列表
watchHistorySchema.statics.getContinueWatching = async function(userId, limit = 10) {
    return this.find({
        userId,
        isCompleted: false,
        progressPercent: { $gt: 5 }
    })
        .populate('dramaId', 'title coverImage')
        .sort({ lastWatchedAt: -1 })
        .limit(limit);
};

// 静态方法：获取用户观看统计
watchHistorySchema.statics.getUserStatistics = async function(userId) {
    const stats = await this.aggregate([
        { $match: { userId } },
        {
            $group: {
                _id: null,
                totalWatched: { $sum: 1 },
                totalCompleted: {
                    $sum: { $cond: ['$isCompleted', 1, 0] }
                },
                totalWatchTime: { $sum: '$watchProgress' },
                uniqueDramas: { $addToSet: '$dramaId' }
            }
        }
    ]);
    
    if (stats.length === 0) {
        return {
            totalWatched: 0,
            totalCompleted: 0,
            totalWatchTime: 0,
            uniqueDramas: 0
        };
    }
    
    return {
        ...stats[0],
        uniqueDramas: stats[0].uniqueDramas.length,
        totalWatchTime: Math.round(stats[0].totalWatchTime / 60) // 转换为分钟
    };
};

// 中间件：保存前更新进度百分比
watchHistorySchema.pre('save', function(next) {
    if (this.isModified('watchProgress') || this.isModified('totalDuration')) {
        if (this.totalDuration > 0) {
            this.progressPercent = Math.round((this.watchProgress / this.totalDuration) * 100);
            this.isCompleted = this.progressPercent >= 95;
        }
    }
    next();
});

// 导出模型
module.exports = mongoose.model('WatchHistory', watchHistorySchema);
