/**
 * 短剧数据模型
 * Drama Data Model
 */

const mongoose = require('mongoose');

const episodeSchema = new mongoose.Schema({
    episodeNumber: {
        type: Number,
        required: true
    },
    episodeId: {
        type: String,
        required: true,
        unique: true
    },
    title: {
        type: String,
        required: true
    },
    videoId: {
        type: String, // 阿里云VoD视频ID
        required: true
    },
    duration: {
        type: Number, // 时长（秒）
        default: 0
    },
    isFree: {
        type: Boolean,
        default: false
    },
    coverUrl: {
        type: String,
        default: ''
    }
});

const dramaSchema = new mongoose.Schema({
    dramaId: {
        type: String,
        required: true,
        unique: true
    },
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
        default: ''
    },
    coverUrl: {
        type: String,
        default: ''
    },
    category: {
        type: String,
        enum: ['romance', 'fantasy', 'drama', 'comedy', 'action', 'thriller', 'other'],
        default: 'other'
    },
    // 价格信息
    price: {
        type: Number, // SUK Token 价格
        required: true
    },
    priceUSD: {
        type: Number, // 美元价格（参考）
        default: 0
    },
    priceTON: {
        type: Number, // TON 价格
        default: 0
    },
    priceStars: {
        type: Number, // Telegram Stars 价格
        default: 0
    },
    // 单集价格
    singleEpisodePrice: {
        type: Number,
        default: 0
    },
    singleEpisodePriceTON: {
        type: Number,
        default: 0
    },
    singleEpisodePriceStars: {
        type: Number,
        default: 0
    },
    // 剧集信息
    episodes: [episodeSchema],
    totalEpisodes: {
        type: Number,
        default: 0
    },
    totalDuration: {
        type: Number, // 总时长（分钟）
        default: 0
    },
    // 统计信息
    rating: {
        type: Number,
        default: 0,
        min: 0,
        max: 5
    },
    views: {
        type: Number,
        default: 0
    },
    purchases: {
        type: Number,
        default: 0
    },
    // 状态
    status: {
        type: String,
        enum: ['draft', 'published', 'archived'],
        default: 'draft'
    },
    // 元数据
    tags: [String],
    cast: [String], // 演员
    director: String, // 导演
    releaseDate: Date,
    // 时间戳
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
});

// 更新 updatedAt 时间戳
dramaSchema.pre('save', function(next) {
    this.updatedAt = Date.now();
    next();
});

// 索引
dramaSchema.index({ dramaId: 1 });
dramaSchema.index({ status: 1, createdAt: -1 });
dramaSchema.index({ category: 1 });
dramaSchema.index({ 'episodes.episodeId': 1 });

// 静态方法：获取短剧详情（包含剧集列表）
dramaSchema.statics.getDramaWithEpisodes = async function(dramaId) {
    return await this.findOne({ dramaId: dramaId, status: 'published' });
};

// 静态方法：根据episodeId查找剧集
dramaSchema.statics.findEpisode = async function(episodeId) {
    const drama = await this.findOne(
        { 'episodes.episodeId': episodeId },
        { 'episodes.$': 1, dramaId: 1, title: 1 }
    );
    
    if (!drama || !drama.episodes || drama.episodes.length === 0) {
        return null;
    }
    
    return {
        drama: {
            dramaId: drama.dramaId,
            title: drama.title
        },
        episode: drama.episodes[0]
    };
};

// 实例方法：获取剧集的videoId
dramaSchema.methods.getEpisodeVideoId = function(episodeId) {
    const episode = this.episodes.find(ep => ep.episodeId === episodeId);
    return episode ? episode.videoId : null;
};

// 实例方法：检查剧集是否免费
dramaSchema.methods.isEpisodeFree = function(episodeId) {
    const episode = this.episodes.find(ep => ep.episodeId === episodeId);
    return episode ? episode.isFree : false;
};

// 实例方法：增加观看次数
dramaSchema.methods.incrementViews = async function() {
    this.views += 1;
    await this.save();
};

// 实例方法：增加购买次数
dramaSchema.methods.incrementPurchases = async function() {
    this.purchases += 1;
    await this.save();
};

const Drama = mongoose.model('Drama', dramaSchema);

module.exports = Drama;
