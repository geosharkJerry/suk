/**
 * 购买记录模型
 * Purchase Model
 * 
 * 存储用户购买的剧集信息
 */

const mongoose = require('mongoose');

const purchaseSchema = new mongoose.Schema({
    // 用户ID（Telegram ID）
    userId: {
        type: String,
        required: true,
        index: true
    },

    // 剧集ID
    dramaId: {
        type: String,
        required: true,
        index: true
    },

    // 购买类型
    purchaseType: {
        type: String,
        required: true,
        enum: ['single', 'full'] // single: 单集, full: 全集
    },

    // 剧集ID（单集购买时）
    episodeId: {
        type: String,
        default: null
    },

    // 关联订单ID
    orderId: {
        type: String,
        required: true,
        index: true
    },

    // 支付方式
    paymentMethod: {
        type: String,
        required: true,
        enum: ['stars', 'ton', 'suk']
    },

    // 支付金额
    amount: {
        type: Number,
        required: true
    },

    // 货币类型
    currency: {
        type: String,
        required: true,
        enum: ['XTR', 'TON', 'SUK']
    },

    // 交易哈希（区块链支付）
    txHash: {
        type: String,
        default: null
    },

    // 购买时间
    purchasedAt: {
        type: Date,
        default: Date.now,
        index: true
    },

    // 是否有效（退款后变为false）
    isValid: {
        type: Boolean,
        default: true,
        index: true
    },

    // 到期时间（如果有的话）
    expiresAt: {
        type: Date,
        default: null
    }
}, {
    timestamps: true
});

// 复合索引：用户+剧集
purchaseSchema.index({ userId: 1, dramaId: 1 });

// 复合索引：用户+剧集+剧集ID
purchaseSchema.index({ userId: 1, dramaId: 1, episodeId: 1 });

// 复合索引：用户+有效性
purchaseSchema.index({ userId: 1, isValid: 1 });

// 唯一索引：防止重复购买
purchaseSchema.index(
    { userId: 1, dramaId: 1, purchaseType: 1, episodeId: 1 },
    { 
        unique: true,
        partialFilterExpression: { isValid: true }
    }
);

// 虚拟字段：是否过期
purchaseSchema.virtual('isExpired').get(function() {
    if (!this.expiresAt) return false;
    return this.expiresAt < new Date();
});

// 虚拟字段：是否可用
purchaseSchema.virtual('isActive').get(function() {
    return this.isValid && !this.isExpired;
});

// 实例方法：标记为无效（退款）
purchaseSchema.methods.invalidate = function() {
    this.isValid = false;
    return this.save();
};

// 静态方法：创建购买记录
purchaseSchema.statics.createPurchase = async function(purchaseData) {
    // 检查是否已购买
    const existing = await this.findOne({
        userId: purchaseData.userId,
        dramaId: purchaseData.dramaId,
        purchaseType: purchaseData.purchaseType,
        episodeId: purchaseData.episodeId || null,
        isValid: true
    });

    if (existing) {
        return existing; // 已存在，返回现有记录
    }

    // 创建新记录
    const purchase = new this(purchaseData);
    await purchase.save();
    return purchase;
};

// 静态方法：检查用户是否购买了剧集
purchaseSchema.statics.checkPurchase = async function(userId, dramaId, episodeId = null) {
    // 先检查是否购买了全集
    const fullPurchase = await this.findOne({
        userId: userId,
        dramaId: dramaId,
        purchaseType: 'full',
        isValid: true
    });

    if (fullPurchase) {
        return { 
            purchased: true, 
            type: 'full',
            purchase: fullPurchase 
        };
    }

    // 如果指定了剧集ID，检查单集购买
    if (episodeId) {
        const episodePurchase = await this.findOne({
            userId: userId,
            dramaId: dramaId,
            episodeId: episodeId,
            purchaseType: 'single',
            isValid: true
        });

        if (episodePurchase) {
            return { 
                purchased: true, 
                type: 'single',
                purchase: episodePurchase 
            };
        }
    }

    return { 
        purchased: false, 
        type: null,
        purchase: null 
    };
};

// 静态方法：获取用户所有购买记录
purchaseSchema.statics.getUserPurchases = function(userId, options = {}) {
    const {
        isValid = true,
        limit = 100,
        skip = 0,
        sort = { purchasedAt: -1 }
    } = options;

    return this.find({ 
        userId: userId,
        isValid: isValid
    })
        .sort(sort)
        .limit(limit)
        .skip(skip);
};

// 静态方法：获取用户购买的剧集列表
purchaseSchema.statics.getUserDramas = async function(userId) {
    const purchases = await this.find({
        userId: userId,
        isValid: true
    }).distinct('dramaId');

    return purchases;
};

// 静态方法：获取剧集的购买统计
purchaseSchema.statics.getDramaStats = async function(dramaId) {
    const stats = await this.aggregate([
        {
            $match: {
                dramaId: dramaId,
                isValid: true
            }
        },
        {
            $group: {
                _id: '$purchaseType',
                count: { $sum: 1 },
                totalAmount: { $sum: '$amount' }
            }
        }
    ]);

    const result = {
        full: 0,
        single: 0,
        totalRevenue: 0
    };

    stats.forEach(stat => {
        result[stat._id] = stat.count;
        result.totalRevenue += stat.totalAmount;
    });

    return result;
};

// 前置钩子：保存前验证
purchaseSchema.pre('save', function(next) {
    // 验证单集购买必须有 episodeId
    if (this.purchaseType === 'single' && !this.episodeId) {
        next(new Error('单集购买必须指定 episodeId'));
    }
    
    next();
});

const Purchase = mongoose.model('Purchase', purchaseSchema);

module.exports = Purchase;
