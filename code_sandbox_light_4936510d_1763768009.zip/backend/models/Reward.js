/**
 * SUK奖励系统数据模型
 * 
 * 奖励类型:
 * 1. 观看奖励: 观看短剧时间获得SUK (观看时长 * 购买价格的1%)
 * 2. 邀请奖励: 邀请好友购买获得SUK (被邀请人购买金额的7%)
 */

const mongoose = require('mongoose');

// 观看奖励记录
const WatchRewardSchema = new mongoose.Schema({
    // 用户信息
    userId: {
        type: String,
        required: true,
        index: true,
        comment: 'Telegram用户ID'
    },
    walletAddress: {
        type: String,
        index: true,
        comment: '用户钱包地址（绑定后才有）'
    },
    
    // 短剧信息
    dramaId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Drama',
        required: true,
        index: true
    },
    episodeId: {
        type: String,
        required: true,
        comment: '剧集ID'
    },
    
    // 观看数据
    watchDuration: {
        type: Number,
        required: true,
        comment: '观看时长（秒）'
    },
    totalDuration: {
        type: Number,
        required: true,
        comment: '视频总时长（秒）'
    },
    watchPercent: {
        type: Number,
        required: true,
        comment: '观看百分比 (0-100)'
    },
    
    // 奖励计算
    dramaPrice: {
        type: Number,
        required: true,
        comment: '该剧集购买价格（SUK）'
    },
    rewardRate: {
        type: Number,
        default: 0.01,
        comment: '奖励比例（默认1%）'
    },
    rewardAmount: {
        type: Number,
        required: true,
        comment: '本次奖励金额（SUK）'
    },
    
    // 奖励状态
    status: {
        type: String,
        enum: ['pending', 'approved', 'paid', 'rejected'],
        default: 'pending',
        index: true,
        comment: '奖励状态: pending-待审核, approved-已批准, paid-已发放, rejected-已拒绝'
    },
    
    // 发放信息
    paidAt: {
        type: Date,
        comment: '奖励发放时间'
    },
    txHash: {
        type: String,
        comment: '区块链交易哈希'
    },
    
    // 防作弊
    isValid: {
        type: Boolean,
        default: true,
        comment: '是否有效（用于检测作弊）'
    },
    validationScore: {
        type: Number,
        default: 100,
        comment: '验证得分（0-100，低于50视为可疑）'
    },
    
    // 时间戳
    createdAt: {
        type: Date,
        default: Date.now,
        index: true
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// 邀请奖励记录
const InviteRewardSchema = new mongoose.Schema({
    // 邀请人信息
    inviterId: {
        type: String,
        required: true,
        index: true,
        comment: 'Telegram邀请人ID'
    },
    inviterWallet: {
        type: String,
        required: true,
        index: true,
        comment: '邀请人钱包地址'
    },
    
    // 被邀请人信息
    inviteeId: {
        type: String,
        required: true,
        index: true,
        comment: 'Telegram被邀请人ID'
    },
    inviteeWallet: {
        type: String,
        index: true,
        comment: '被邀请人钱包地址（绑定后才有）'
    },
    
    // 购买信息
    orderId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Order',
        required: true,
        index: true,
        comment: '被邀请人的购买订单ID'
    },
    dramaId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Drama',
        required: true
    },
    purchaseAmount: {
        type: Number,
        required: true,
        comment: '购买金额（SUK）'
    },
    
    // 奖励计算
    rewardRate: {
        type: Number,
        default: 0.07,
        comment: '邀请奖励比例（默认7%）'
    },
    rewardAmount: {
        type: Number,
        required: true,
        comment: '奖励金额（SUK）'
    },
    
    // 奖励状态
    status: {
        type: String,
        enum: ['pending', 'approved', 'paid', 'rejected'],
        default: 'pending',
        index: true
    },
    
    // 发放信息
    paidAt: {
        type: Date
    },
    txHash: {
        type: String
    },
    
    // 防作弊
    isValid: {
        type: Boolean,
        default: true
    },
    validationScore: {
        type: Number,
        default: 100
    },
    
    // 时间戳
    createdAt: {
        type: Date,
        default: Date.now,
        index: true
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// 用户邀请关系
const InviteRelationSchema = new mongoose.Schema({
    // 邀请人信息
    inviterId: {
        type: String,
        required: true,
        index: true,
        comment: 'Telegram邀请人ID'
    },
    inviterWallet: {
        type: String,
        comment: '邀请人钱包地址'
    },
    
    // 被邀请人信息
    inviteeId: {
        type: String,
        required: true,
        unique: true,
        index: true,
        comment: 'Telegram被邀请人ID（一个人只能被邀请一次）'
    },
    inviteeWallet: {
        type: String,
        comment: '被邀请人钱包地址'
    },
    
    // 邀请码
    inviteCode: {
        type: String,
        required: true,
        index: true,
        comment: '邀请码'
    },
    
    // 邀请来源
    inviteSource: {
        type: String,
        enum: ['link', 'code', 'qrcode'],
        default: 'link',
        comment: '邀请来源: link-链接, code-邀请码, qrcode-二维码'
    },
    
    // 状态
    status: {
        type: String,
        enum: ['registered', 'bound', 'purchased'],
        default: 'registered',
        index: true,
        comment: 'registered-已注册, bound-已绑定钱包, purchased-已购买'
    },
    
    // 统计
    totalPurchaseAmount: {
        type: Number,
        default: 0,
        comment: '被邀请人累计购买金额'
    },
    totalRewardAmount: {
        type: Number,
        default: 0,
        comment: '邀请人累计获得奖励'
    },
    purchaseCount: {
        type: Number,
        default: 0,
        comment: '购买次数'
    },
    
    // 时间记录
    registeredAt: {
        type: Date,
        default: Date.now,
        comment: '注册时间'
    },
    boundAt: {
        type: Date,
        comment: '绑定钱包时间'
    },
    firstPurchaseAt: {
        type: Date,
        comment: '首次购买时间'
    },
    
    createdAt: {
        type: Date,
        default: Date.now,
        index: true
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// 用户奖励统计
const UserRewardStatsSchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true,
        unique: true,
        index: true
    },
    walletAddress: {
        type: String,
        index: true
    },
    
    // 观看奖励统计
    watchRewards: {
        total: { type: Number, default: 0 },      // 总奖励
        pending: { type: Number, default: 0 },     // 待发放
        paid: { type: Number, default: 0 },        // 已发放
        count: { type: Number, default: 0 }        // 奖励次数
    },
    
    // 邀请奖励统计
    inviteRewards: {
        total: { type: Number, default: 0 },      // 总奖励
        pending: { type: Number, default: 0 },     // 待发放
        paid: { type: Number, default: 0 },        // 已发放
        count: { type: Number, default: 0 }        // 奖励次数
    },
    
    // 邀请统计
    inviteStats: {
        totalInvites: { type: Number, default: 0 },       // 总邀请人数
        boundInvites: { type: Number, default: 0 },       // 已绑定人数
        purchasedInvites: { type: Number, default: 0 },   // 已购买人数
        conversionRate: { type: Number, default: 0 }      // 转化率（%）
    },
    
    // 总计
    totalEarned: {
        type: Number,
        default: 0,
        comment: '累计赚取SUK'
    },
    totalPending: {
        type: Number,
        default: 0,
        comment: '待发放SUK'
    },
    totalPaid: {
        type: Number,
        default: 0,
        comment: '已发放SUK'
    },
    
    // 等级（未来扩展）
    rewardLevel: {
        type: Number,
        default: 1,
        comment: '奖励等级（影响奖励比例）'
    },
    
    lastUpdated: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// 索引
WatchRewardSchema.index({ userId: 1, createdAt: -1 });
WatchRewardSchema.index({ walletAddress: 1, status: 1 });
WatchRewardSchema.index({ dramaId: 1, episodeId: 1 });
WatchRewardSchema.index({ status: 1, createdAt: -1 });

InviteRewardSchema.index({ inviterId: 1, createdAt: -1 });
InviteRewardSchema.index({ inviterWallet: 1, status: 1 });
InviteRewardSchema.index({ inviteeId: 1 });
InviteRewardSchema.index({ orderId: 1 }, { unique: true });

InviteRelationSchema.index({ inviterId: 1, status: 1 });
InviteRelationSchema.index({ inviteCode: 1 });
InviteRelationSchema.index({ inviteeId: 1 }, { unique: true });

UserRewardStatsSchema.index({ walletAddress: 1 });

// 方法：计算观看奖励金额
WatchRewardSchema.methods.calculateReward = function() {
    // 奖励 = 观看时长 / 总时长 * 剧集价格 * 奖励比例
    const watchRatio = this.watchDuration / this.totalDuration;
    return watchRatio * this.dramaPrice * this.rewardRate;
};

// 方法：计算邀请奖励金额
InviteRewardSchema.methods.calculateReward = function() {
    // 奖励 = 购买金额 * 邀请奖励比例
    return this.purchaseAmount * this.rewardRate;
};

// 静态方法：获取用户总奖励
WatchRewardSchema.statics.getUserTotalRewards = async function(userId) {
    const result = await this.aggregate([
        { $match: { userId, status: 'paid' } },
        {
            $group: {
                _id: null,
                totalAmount: { $sum: '$rewardAmount' },
                count: { $sum: 1 }
            }
        }
    ]);
    
    return result[0] || { totalAmount: 0, count: 0 };
};

// 静态方法：获取用户邀请奖励
InviteRewardSchema.statics.getUserInviteRewards = async function(inviterId) {
    const result = await this.aggregate([
        { $match: { inviterId, status: 'paid' } },
        {
            $group: {
                _id: null,
                totalAmount: { $sum: '$rewardAmount' },
                count: { $sum: 1 }
            }
        }
    ]);
    
    return result[0] || { totalAmount: 0, count: 0 };
};

const WatchReward = mongoose.model('WatchReward', WatchRewardSchema);
const InviteReward = mongoose.model('InviteReward', InviteRewardSchema);
const InviteRelation = mongoose.model('InviteRelation', InviteRelationSchema);
const UserRewardStats = mongoose.model('UserRewardStats', UserRewardStatsSchema);

module.exports = {
    WatchReward,
    InviteReward,
    InviteRelation,
    UserRewardStats
};
