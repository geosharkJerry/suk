/**
 * 订单模型
 * Order Model
 * 
 * 存储支付订单信息
 */

const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    // 订单ID（唯一）
    orderId: {
        type: String,
        required: true,
        unique: true,
        index: true
    },

    // 用户ID（Telegram ID）
    userId: {
        type: String,
        required: true,
        index: true
    },

    // 剧集ID
    dramaId: {
        type: String,
        required: true,
        index: true
    },

    // 购买类型
    purchaseType: {
        type: String,
        required: true,
        enum: ['single', 'full'], // single: 单集, full: 全集
        index: true
    },

    // 剧集ID（单集购买时）
    episodeId: {
        type: String,
        default: null
    },

    // 支付方式
    paymentMethod: {
        type: String,
        required: true,
        enum: ['stars', 'ton', 'suk'],
        index: true
    },

    // 支付金额
    amount: {
        type: Number,
        required: true
    },

    // 货币类型
    currency: {
        type: String,
        required: true,
        enum: ['XTR', 'TON', 'SUK'] // XTR: Telegram Stars
    },

    // 订单状态
    status: {
        type: String,
        required: true,
        enum: ['pending', 'completed', 'failed', 'cancelled', 'refunded'],
        default: 'pending',
        index: true
    },

    // 支付链接（TON）
    paymentLink: {
        type: String,
        default: null
    },

    // 用户钱包地址（SUK Token）
    userWallet: {
        type: String,
        default: null
    },

    // 支付ID（Telegram Stars）
    paymentId: {
        type: String,
        default: null
    },

    // 交易哈希（TON/SUK）
    txHash: {
        type: String,
        default: null
    },

    // 退款原因
    refundReason: {
        type: String,
        default: null
    },

    // 创建时间
    createdAt: {
        type: Date,
        default: Date.now,
        index: true
    },

    // 完成时间
    completedAt: {
        type: Date,
        default: null
    },

    // 退款时间
    refundedAt: {
        type: Date,
        default: null
    },

    // 过期时间（30分钟）
    expiresAt: {
        type: Date,
        default: function() {
            return new Date(Date.now() + 30 * 60 * 1000);
        }
    }
}, {
    timestamps: true
});

// 复合索引
orderSchema.index({ userId: 1, dramaId: 1 });
orderSchema.index({ userId: 1, status: 1 });
orderSchema.index({ createdAt: 1, status: 1 });

// 自动清理过期的待支付订单（TTL索引）
orderSchema.index({ expiresAt: 1 }, { 
    expireAfterSeconds: 0,
    partialFilterExpression: { status: 'pending' }
});

// 虚拟字段：是否过期
orderSchema.virtual('isExpired').get(function() {
    return this.status === 'pending' && this.expiresAt < new Date();
});

// 实例方法：标记为完成
orderSchema.methods.markCompleted = function(paymentInfo) {
    this.status = 'completed';
    this.completedAt = new Date();
    
    if (paymentInfo.paymentId) {
        this.paymentId = paymentInfo.paymentId;
    }
    if (paymentInfo.txHash) {
        this.txHash = paymentInfo.txHash;
    }
    
    return this.save();
};

// 实例方法：标记为失败
orderSchema.methods.markFailed = function() {
    this.status = 'failed';
    return this.save();
};

// 实例方法：标记为取消
orderSchema.methods.markCancelled = function() {
    this.status = 'cancelled';
    return this.save();
};

// 实例方法：标记为退款
orderSchema.methods.markRefunded = function(reason) {
    this.status = 'refunded';
    this.refundReason = reason;
    this.refundedAt = new Date();
    return this.save();
};

// 静态方法：创建新订单
orderSchema.statics.createOrder = async function(orderData) {
    const order = new this(orderData);
    await order.save();
    return order;
};

// 静态方法：通过订单ID查找
orderSchema.statics.findByOrderId = function(orderId) {
    return this.findOne({ orderId: orderId });
};

// 静态方法：获取用户订单
orderSchema.statics.getUserOrders = function(userId, limit = 20) {
    return this.find({ userId: userId })
        .sort({ createdAt: -1 })
        .limit(limit);
};

// 静态方法：获取待支付订单
orderSchema.statics.getPendingOrders = function(userId) {
    return this.find({ 
        userId: userId, 
        status: 'pending',
        expiresAt: { $gt: new Date() }
    }).sort({ createdAt: -1 });
};

// 前置钩子：保存前验证
orderSchema.pre('save', function(next) {
    // 验证单集购买必须有 episodeId
    if (this.purchaseType === 'single' && !this.episodeId) {
        next(new Error('单集购买必须指定 episodeId'));
    }
    
    // 验证支付方式和货币匹配
    const currencyMap = {
        'stars': 'XTR',
        'ton': 'TON',
        'suk': 'SUK'
    };
    
    if (currencyMap[this.paymentMethod] !== this.currency) {
        next(new Error('支付方式和货币不匹配'));
    }
    
    next();
});

const Order = mongoose.model('Order', orderSchema);

module.exports = Order;
