/**
 * 评论数据模型
 * Comment Data Model
 */

const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema({
    // 评论ID
    commentId: {
        type: String,
        required: true,
        unique: true
    },
    
    // 关联的短剧或剧集
    dramaId: {
        type: String,
        required: true,
        index: true
    },
    
    episodeId: {
        type: String,
        default: null, // null 表示是短剧整体评论
        index: true
    },
    
    // 用户信息
    userId: {
        type: String,
        required: true,
        index: true
    },
    
    username: {
        type: String,
        required: true
    },
    
    userAvatar: {
        type: String,
        default: ''
    },
    
    // 评论内容
    content: {
        type: String,
        required: true,
        maxlength: 1000
    },
    
    // 评分（1-5星）
    rating: {
        type: Number,
        min: 1,
        max: 5,
        default: null
    },
    
    // 回复相关
    parentId: {
        type: String,
        default: null, // null 表示顶级评论
        index: true
    },
    
    replyToUserId: {
        type: String,
        default: null
    },
    
    replyToUsername: {
        type: String,
        default: ''
    },
    
    // 统计信息
    likes: {
        type: Number,
        default: 0
    },
    
    dislikes: {
        type: Number,
        default: 0
    },
    
    replyCount: {
        type: Number,
        default: 0
    },
    
    // 点赞/点踩用户列表（用于防止重复）
    likedBy: [{
        type: String
    }],
    
    dislikedBy: [{
        type: String
    }],
    
    // 状态
    status: {
        type: String,
        enum: ['active', 'deleted', 'hidden'],
        default: 'active'
    },
    
    // 审核状态
    moderationStatus: {
        type: String,
        enum: ['pending', 'approved', 'rejected'],
        default: 'approved' // 默认自动通过
    },
    
    moderationReason: {
        type: String,
        default: ''
    },
    
    // 是否置顶
    isPinned: {
        type: Boolean,
        default: false
    },
    
    // 时间戳
    createdAt: {
        type: Date,
        default: Date.now,
        index: true
    },
    
    updatedAt: {
        type: Date,
        default: Date.now
    }
});

// 更新 updatedAt 时间戳
commentSchema.pre('save', function(next) {
    this.updatedAt = Date.now();
    next();
});

// 索引
commentSchema.index({ dramaId: 1, episodeId: 1, createdAt: -1 });
commentSchema.index({ userId: 1, createdAt: -1 });
commentSchema.index({ parentId: 1, createdAt: 1 });
commentSchema.index({ status: 1, moderationStatus: 1 });

// 静态方法：获取短剧评论
commentSchema.statics.getDramaComments = async function(dramaId, options = {}) {
    const {
        page = 1,
        limit = 20,
        sortBy = 'createdAt',
        sortOrder = 'desc'
    } = options;

    const query = {
        dramaId: dramaId,
        episodeId: null,
        parentId: null,
        status: 'active',
        moderationStatus: 'approved'
    };

    const sort = {};
    sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

    const comments = await this.find(query)
        .sort(sort)
        .skip((page - 1) * limit)
        .limit(limit)
        .lean();

    const total = await this.countDocuments(query);

    return {
        comments,
        pagination: {
            page,
            limit,
            total,
            totalPages: Math.ceil(total / limit)
        }
    };
};

// 静态方法：获取评论的回复
commentSchema.statics.getCommentReplies = async function(commentId, options = {}) {
    const {
        page = 1,
        limit = 10
    } = options;

    const query = {
        parentId: commentId,
        status: 'active',
        moderationStatus: 'approved'
    };

    const replies = await this.find(query)
        .sort({ createdAt: 1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .lean();

    const total = await this.countDocuments(query);

    return {
        replies,
        pagination: {
            page,
            limit,
            total,
            totalPages: Math.ceil(total / limit)
        }
    };
};

// 实例方法：点赞
commentSchema.methods.like = async function(userId) {
    // 检查是否已点赞
    if (this.likedBy.includes(userId)) {
        // 取消点赞
        this.likedBy = this.likedBy.filter(id => id !== userId);
        this.likes = Math.max(0, this.likes - 1);
    } else {
        // 添加点赞
        this.likedBy.push(userId);
        this.likes += 1;
        
        // 如果之前点了踩，取消踩
        if (this.dislikedBy.includes(userId)) {
            this.dislikedBy = this.dislikedBy.filter(id => id !== userId);
            this.dislikes = Math.max(0, this.dislikes - 1);
        }
    }
    
    await this.save();
    return this;
};

// 实例方法：点踩
commentSchema.methods.dislike = async function(userId) {
    // 检查是否已点踩
    if (this.dislikedBy.includes(userId)) {
        // 取消点踩
        this.dislikedBy = this.dislikedBy.filter(id => id !== userId);
        this.dislikes = Math.max(0, this.dislikes - 1);
    } else {
        // 添加点踩
        this.dislikedBy.push(userId);
        this.dislikes += 1;
        
        // 如果之前点了赞，取消赞
        if (this.likedBy.includes(userId)) {
            this.likedBy = this.likedBy.filter(id => id !== userId);
            this.likes = Math.max(0, this.likes - 1);
        }
    }
    
    await this.save();
    return this;
};

// 实例方法：增加回复数
commentSchema.methods.incrementReplyCount = async function() {
    this.replyCount += 1;
    await this.save();
};

const Comment = mongoose.model('Comment', commentSchema);

module.exports = Comment;
