/**
 * Drama 模型单元测试
 * Drama Model Unit Tests
 */

const mongoose = require('mongoose');
const Drama = require('../Drama');

describe('Drama Model', () => {
    
    describe('Schema', () => {
        test('应该有必需的字段', () => {
            const drama = new Drama({});
            const error = drama.validateSync();
            
            expect(error.errors.dramaId).toBeDefined();
            expect(error.errors.title).toBeDefined();
            expect(error.errors.price).toBeDefined();
        });
        
        test('应该接受有效的数据', () => {
            const validDrama = new Drama({
                dramaId: 'drama_001',
                title: '测试短剧',
                price: 50,
                category: 'romance',
                status: 'published'
            });
            
            const error = validDrama.validateSync();
            expect(error).toBeUndefined();
        });
        
        test('应该验证 category 枚举值', () => {
            const drama = new Drama({
                dramaId: 'drama_001',
                title: '测试短剧',
                price: 50,
                category: 'invalid_category'
            });
            
            const error = drama.validateSync();
            expect(error.errors.category).toBeDefined();
        });
        
        test('应该验证 status 枚举值', () => {
            const drama = new Drama({
                dramaId: 'drama_001',
                title: '测试短剧',
                price: 50,
                status: 'invalid_status'
            });
            
            const error = drama.validateSync();
            expect(error.errors.status).toBeDefined();
        });
    });
    
    describe('Instance Methods', () => {
        let testDrama;
        
        beforeEach(() => {
            testDrama = new Drama({
                dramaId: 'drama_001',
                title: '测试短剧',
                price: 50,
                episodes: [
                    {
                        episodeNumber: 1,
                        episodeId: 'drama_001_ep_001',
                        title: '第1集',
                        videoId: 'video_001',
                        duration: 180,
                        isFree: true
                    },
                    {
                        episodeNumber: 2,
                        episodeId: 'drama_001_ep_002',
                        title: '第2集',
                        videoId: 'video_002',
                        duration: 180,
                        isFree: false
                    }
                ]
            });
        });
        
        test('getEpisodeVideoId 应该返回正确的 videoId', () => {
            const videoId = testDrama.getEpisodeVideoId('drama_001_ep_001');
            expect(videoId).toBe('video_001');
        });
        
        test('getEpisodeVideoId 应该处理不存在的剧集', () => {
            const videoId = testDrama.getEpisodeVideoId('non_existent');
            expect(videoId).toBeNull();
        });
        
        test('isEpisodeFree 应该正确判断免费剧集', () => {
            expect(testDrama.isEpisodeFree('drama_001_ep_001')).toBe(true);
            expect(testDrama.isEpisodeFree('drama_001_ep_002')).toBe(false);
        });
        
        test('isEpisodeFree 应该处理不存在的剧集', () => {
            const isFree = testDrama.isEpisodeFree('non_existent');
            expect(isFree).toBe(false);
        });
    });
    
    describe('Static Methods', () => {
        test('应该有 getDramaWithEpisodes 静态方法', () => {
            expect(Drama.getDramaWithEpisodes).toBeDefined();
            expect(typeof Drama.getDramaWithEpisodes).toBe('function');
        });
        
        test('应该有 findEpisode 静态方法', () => {
            expect(Drama.findEpisode).toBeDefined();
            expect(typeof Drama.findEpisode).toBe('function');
        });
    });
    
    describe('Indexes', () => {
        test('应该在 dramaId 上有索引', () => {
            const indexes = Drama.schema.indexes();
            const dramaIdIndex = indexes.find(idx => idx[0].dramaId);
            expect(dramaIdIndex).toBeDefined();
        });
        
        test('应该在 episodes.episodeId 上有索引', () => {
            const indexes = Drama.schema.indexes();
            const episodeIdIndex = indexes.find(idx => idx[0]['episodes.episodeId']);
            expect(episodeIdIndex).toBeDefined();
        });
    });
});
