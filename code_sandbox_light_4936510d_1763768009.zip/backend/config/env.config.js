/**
 * 环境配置加载模块
 * Environment Configuration Loader
 * 
 * 功能：
 * 1. 加载和验证环境变量
 * 2. 提供类型安全的配置访问
 * 3. 设置默认值
 * 4. 检查必需配置项
 */

require('dotenv').config();

/**
 * 验证必需的环境变量
 * @param {string[]} requiredVars - 必需的环境变量列表
 */
function validateRequiredEnvVars(requiredVars) {
    const missing = requiredVars.filter(varName => !process.env[varName]);
    
    if (missing.length > 0) {
        console.error('❌ 缺少必需的环境变量 (Missing required environment variables):');
        missing.forEach(varName => {
            console.error(`   - ${varName}`);
        });
        console.error('\n请检查 .env 文件配置。参考 .env.example 文件。');
        process.exit(1);
    }
}

/**
 * 获取布尔值环境变量
 * @param {string} key - 环境变量名
 * @param {boolean} defaultValue - 默认值
 * @returns {boolean}
 */
function getBooleanEnv(key, defaultValue = false) {
    const value = process.env[key];
    if (value === undefined) return defaultValue;
    return value === 'true' || value === '1' || value === 'yes';
}

/**
 * 获取数字环境变量
 * @param {string} key - 环境变量名
 * @param {number} defaultValue - 默认值
 * @returns {number}
 */
function getNumberEnv(key, defaultValue) {
    const value = process.env[key];
    if (value === undefined) return defaultValue;
    const parsed = parseInt(value, 10);
    return isNaN(parsed) ? defaultValue : parsed;
}

/**
 * 获取字符串环境变量
 * @param {string} key - 环境变量名
 * @param {string} defaultValue - 默认值
 * @returns {string}
 */
function getStringEnv(key, defaultValue = '') {
    return process.env[key] || defaultValue;
}

// 验证核心必需配置
const requiredEnvVars = [
    'MONGODB_URI',
    'ALIYUN_ACCESS_KEY_ID',
    'ALIYUN_ACCESS_KEY_SECRET',
    'JWT_SECRET',
    'SUK_TOKEN_CONTRACT'
];

// 仅在生产环境验证必需配置
if (process.env.NODE_ENV === 'production') {
    validateRequiredEnvVars(requiredEnvVars);
}

/**
 * 应用配置对象
 */
const config = {
    // 环境信息
    env: {
        nodeEnv: getStringEnv('NODE_ENV', 'development'),
        isDevelopment: getStringEnv('NODE_ENV', 'development') === 'development',
        isProduction: getStringEnv('NODE_ENV', 'development') === 'production',
        isTest: getStringEnv('NODE_ENV', 'development') === 'test'
    },

    // 服务器配置
    server: {
        port: getNumberEnv('PORT', 3000),
        apiBaseUrl: getStringEnv('API_BASE_URL', 'http://localhost:3000/api'),
        corsOrigin: getStringEnv('CORS_ORIGIN', 'http://localhost:3000').split(','),
        corsCredentials: getBooleanEnv('CORS_CREDENTIALS', true),
        forceHttps: getBooleanEnv('FORCE_HTTPS', false),
        maxRequestBodySize: getStringEnv('MAX_REQUEST_BODY_SIZE', '50mb')
    },

    // MongoDB配置
    mongodb: {
        uri: getStringEnv('MONGODB_URI', 'mongodb://localhost:27017/short_drama_platform'),
        user: getStringEnv('MONGODB_USER'),
        password: getStringEnv('MONGODB_PASSWORD'),
        poolSize: getNumberEnv('MONGODB_POOL_SIZE', 10),
        timeout: getNumberEnv('MONGODB_TIMEOUT', 5000),
        options: {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            serverSelectionTimeoutMS: getNumberEnv('MONGODB_TIMEOUT', 5000),
            maxPoolSize: getNumberEnv('MONGODB_POOL_SIZE', 10)
        }
    },

    // Redis配置
    redis: {
        host: getStringEnv('REDIS_HOST', 'localhost'),
        port: getNumberEnv('REDIS_PORT', 6379),
        password: getStringEnv('REDIS_PASSWORD'),
        db: getNumberEnv('REDIS_DB', 0),
        connectTimeout: getNumberEnv('REDIS_CONNECT_TIMEOUT', 10000),
        keyPrefix: getStringEnv('REDIS_KEY_PREFIX', 'drama_platform:'),
        options: {
            host: getStringEnv('REDIS_HOST', 'localhost'),
            port: getNumberEnv('REDIS_PORT', 6379),
            password: getStringEnv('REDIS_PASSWORD') || undefined,
            db: getNumberEnv('REDIS_DB', 0),
            connectTimeout: getNumberEnv('REDIS_CONNECT_TIMEOUT', 10000),
            keyPrefix: getStringEnv('REDIS_KEY_PREFIX', 'drama_platform:'),
            retryStrategy: (times) => {
                if (times > 3) {
                    console.error('Redis连接失败，停止重试');
                    return null;
                }
                return Math.min(times * 200, 2000);
            }
        }
    },

    // 阿里云VoD配置
    aliyun: {
        accessKeyId: getStringEnv('ALIYUN_ACCESS_KEY_ID'),
        accessKeySecret: getStringEnv('ALIYUN_ACCESS_KEY_SECRET'),
        vod: {
            region: getStringEnv('ALIYUN_VOD_REGION', 'cn-shanghai'),
            endpoint: getStringEnv('ALIYUN_VOD_ENDPOINT', 'https://vod.cn-shanghai.aliyuncs.com'),
            apiVersion: getStringEnv('ALIYUN_VOD_API_VERSION', '2017-03-21'),
            storageLocation: getStringEnv('ALIYUN_VOD_STORAGE_LOCATION'),
            templateGroupId: getStringEnv('ALIYUN_VOD_TEMPLATE_GROUP_ID')
        },
        playAuth: {
            timeout: getNumberEnv('PLAY_AUTH_TIMEOUT', 1800), // 30分钟
            cacheTtl: getNumberEnv('PLAY_AUTH_CACHE_TTL', 1500) // 25分钟
        }
    },

    // 视频配置
    video: {
        maxSizeMB: getNumberEnv('MAX_VIDEO_SIZE_MB', 2048),
        allowedFormats: getStringEnv('ALLOWED_VIDEO_FORMATS', 'mp4,mov,avi,mkv,flv').split(','),
        transcodePriority: getNumberEnv('VIDEO_TRANSCODE_PRIORITY', 6),
        encryptType: getNumberEnv('VIDEO_ENCRYPT_TYPE', 1),
        watermark: {
            enable: getBooleanEnv('VIDEO_WATERMARK_ENABLE', false),
            url: getStringEnv('VIDEO_WATERMARK_URL')
        }
    },

    // JWT配置
    jwt: {
        secret: getStringEnv('JWT_SECRET', 'change_this_secret_in_production'),
        expiresIn: getStringEnv('JWT_EXPIRES_IN', '7d'),
        refreshSecret: getStringEnv('JWT_REFRESH_SECRET', 'change_this_refresh_secret'),
        refreshExpiresIn: getStringEnv('JWT_REFRESH_EXPIRES_IN', '30d')
    },

    // 区块链配置
    blockchain: {
        rpcUrl: getStringEnv('ETH_RPC_URL', 'https://mainnet.infura.io/v3/YOUR_PROJECT_ID'),
        network: getStringEnv('ETH_NETWORK', 'mainnet'),
        sukTokenContract: getStringEnv('SUK_TOKEN_CONTRACT'),
        platformWallet: getStringEnv('PLATFORM_WALLET_ADDRESS'),
        blockConfirmations: getNumberEnv('BLOCK_CONFIRMATIONS', 12),
        transactionTimeout: getNumberEnv('TRANSACTION_TIMEOUT', 300000)
    },

    // 购买配置
    purchase: {
        defaultEpisodePrice: getNumberEnv('DEFAULT_EPISODE_PRICE', 10),
        defaultDramaPrice: getNumberEnv('DEFAULT_DRAMA_PRICE', 50),
        bulkDiscount: parseFloat(getStringEnv('BULK_PURCHASE_DISCOUNT', '0.8')),
        validityDays: getNumberEnv('PURCHASE_VALIDITY_DAYS', 365)
    },

    // 邮件配置
    email: {
        enable: getBooleanEnv('EMAIL_ENABLE', false),
        smtp: {
            host: getStringEnv('EMAIL_SMTP_HOST', 'smtp.gmail.com'),
            port: getNumberEnv('EMAIL_SMTP_PORT', 587),
            secure: getBooleanEnv('EMAIL_SMTP_SECURE', false),
            auth: {
                user: getStringEnv('EMAIL_SMTP_USER'),
                pass: getStringEnv('EMAIL_SMTP_PASSWORD')
            }
        },
        from: {
            name: getStringEnv('EMAIL_FROM_NAME', '短剧平台'),
            address: getStringEnv('EMAIL_FROM_ADDRESS', 'noreply@example.com')
        }
    },

    // 日志配置
    logging: {
        level: getStringEnv('LOG_LEVEL', 'info'),
        filePath: getStringEnv('LOG_FILE_PATH', './logs'),
        maxSize: getStringEnv('LOG_MAX_SIZE', '10m'),
        maxFiles: getNumberEnv('LOG_MAX_FILES', 7)
    },

    // 限流配置
    rateLimit: {
        windowMs: getNumberEnv('RATE_LIMIT_WINDOW_MS', 900000), // 15分钟
        maxRequests: getNumberEnv('RATE_LIMIT_MAX_REQUESTS', 100)
    },

    // 性能配置
    performance: {
        requestTimeout: getNumberEnv('REQUEST_TIMEOUT', 30000),
        maxConcurrentConnections: getNumberEnv('MAX_CONCURRENT_CONNECTIONS', 1000)
    },

    // CDN配置
    cdn: {
        enable: getBooleanEnv('CDN_ENABLE', false),
        domain: getStringEnv('CDN_DOMAIN'),
        authKey: getStringEnv('CDN_AUTH_KEY')
    },

    // 监控配置
    monitoring: {
        sentry: {
            dsn: getStringEnv('SENTRY_DSN'),
            environment: getStringEnv('SENTRY_ENVIRONMENT', 'production'),
            tracesSampleRate: parseFloat(getStringEnv('SENTRY_TRACES_SAMPLE_RATE', '0.1'))
        },
        ga: {
            trackingId: getStringEnv('GA_TRACKING_ID')
        }
    },

    // 安全配置
    security: {
        cookie: {
            secure: getBooleanEnv('COOKIE_SECURE', true),
            sameSite: getStringEnv('COOKIE_SAME_SITE', 'strict')
        }
    },

    // 开发配置
    development: {
        debug: getBooleanEnv('DEBUG', false),
        apiDocs: {
            enable: getBooleanEnv('API_DOCS_ENABLE', true),
            path: getStringEnv('API_DOCS_PATH', '/api/docs')
        },
        mockData: getBooleanEnv('MOCK_DATA_ENABLE', false)
    },

    // 备份配置
    backup: {
        enable: getBooleanEnv('BACKUP_ENABLE', true),
        cron: getStringEnv('BACKUP_CRON', '0 2 * * *'),
        storagePath: getStringEnv('BACKUP_STORAGE_PATH', '/var/backups/drama_platform'),
        retentionDays: getNumberEnv('BACKUP_RETENTION_DAYS', 30)
    },

    // 功能开关
    features: {
        recommendations: getBooleanEnv('FEATURE_RECOMMENDATIONS', true),
        comments: getBooleanEnv('FEATURE_COMMENTS', true),
        socialShare: getBooleanEnv('FEATURE_SOCIAL_SHARE', true),
        resumePlayback: getBooleanEnv('FEATURE_RESUME_PLAYBACK', true),
        download: getBooleanEnv('FEATURE_DOWNLOAD', false),
        danmaku: getBooleanEnv('FEATURE_DANMAKU', false)
    }
};

/**
 * 打印配置摘要（不包含敏感信息）
 */
function printConfigSummary() {
    console.log('\n🚀 应用配置摘要 (Application Configuration Summary)');
    console.log('================================================');
    console.log(`环境 (Environment):        ${config.env.nodeEnv}`);
    console.log(`端口 (Port):               ${config.server.port}`);
    console.log(`MongoDB:                   ${config.mongodb.uri.replace(/\/\/.*@/, '//***@')}`);
    console.log(`Redis:                     ${config.redis.host}:${config.redis.port}`);
    console.log(`阿里云VoD区域:              ${config.aliyun.vod.region}`);
    console.log(`JWT过期时间:                ${config.jwt.expiresIn}`);
    console.log(`播放授权超时:               ${config.aliyun.playAuth.timeout}秒`);
    console.log(`区块链网络:                 ${config.blockchain.network}`);
    console.log(`功能开关:`);
    console.log(`  - 续播功能:               ${config.features.resumePlayback ? '✅' : '❌'}`);
    console.log(`  - 推荐功能:               ${config.features.recommendations ? '✅' : '❌'}`);
    console.log(`  - 评论功能:               ${config.features.comments ? '✅' : '❌'}`);
    console.log(`  - 下载功能:               ${config.features.download ? '✅' : '❌'}`);
    console.log('================================================\n');
}

// 开发环境打印配置摘要
if (config.env.isDevelopment && config.development.debug) {
    printConfigSummary();
}

module.exports = config;
