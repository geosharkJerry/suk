/**
 * Redis 配置和连接
 * Redis Configuration and Connection
 */

const redis = require('redis');

class RedisConfig {
    constructor() {
        this.client = null;
        this.isConnected = false;
    }

    /**
     * 连接到 Redis
     * Connect to Redis
     */
    async connect() {
        if (this.isConnected && this.client) {
            return this.client;
        }

        try {
            // Redis 连接配置
            const config = {
                host: process.env.REDIS_HOST || 'localhost',
                port: parseInt(process.env.REDIS_PORT) || 6379,
                password: process.env.REDIS_PASSWORD || undefined,
                db: parseInt(process.env.REDIS_DB) || 0,
                retryStrategy: (times) => {
                    const delay = Math.min(times * 50, 2000);
                    return delay;
                }
            };

            // 创建 Redis 客户端
            this.client = redis.createClient(config);

            // 错误处理
            this.client.on('error', (err) => {
                console.error('❌ Redis 错误:', err);
                this.isConnected = false;
            });

            // 连接成功
            this.client.on('connect', () => {
                console.log('✅ Redis 已连接');
                this.isConnected = true;
            });

            // 断开连接
            this.client.on('end', () => {
                console.log('⚠️  Redis 连接已断开');
                this.isConnected = false;
            });

            // 重新连接
            this.client.on('reconnecting', () => {
                console.log('🔄 Redis 正在重新连接...');
            });

            // 等待连接建立
            await this.client.connect();

            console.log(`✅ Redis 连接成功: ${config.host}:${config.port}, DB: ${config.db}`);
            
            return this.client;

        } catch (error) {
            console.error('❌ Redis 连接失败:', error);
            this.isConnected = false;
            throw error;
        }
    }

    /**
     * 获取客户端
     * Get client
     */
    getClient() {
        if (!this.client || !this.isConnected) {
            throw new Error('Redis 未连接，请先调用 connect()');
        }
        return this.client;
    }

    /**
     * 设置键值（字符串）
     * Set key-value (string)
     */
    async set(key, value, ttl = null) {
        const client = this.getClient();
        if (ttl) {
            await client.setEx(key, ttl, value);
        } else {
            await client.set(key, value);
        }
    }

    /**
     * 设置键值（带过期时间）
     * Set key-value with expiration
     */
    async setex(key, ttl, value) {
        const client = this.getClient();
        await client.setEx(key, ttl, value);
    }

    /**
     * 获取值
     * Get value
     */
    async get(key) {
        const client = this.getClient();
        return await client.get(key);
    }

    /**
     * 删除键
     * Delete key
     */
    async del(key) {
        const client = this.getClient();
        return await client.del(key);
    }

    /**
     * 检查键是否存在
     * Check if key exists
     */
    async exists(key) {
        const client = this.getClient();
        return await client.exists(key);
    }

    /**
     * 设置过期时间
     * Set expiration time
     */
    async expire(key, ttl) {
        const client = this.getClient();
        return await client.expire(key, ttl);
    }

    /**
     * 获取剩余生存时间
     * Get remaining time to live
     */
    async ttl(key) {
        const client = this.getClient();
        return await client.ttl(key);
    }

    /**
     * 设置哈希字段
     * Set hash field
     */
    async hset(key, field, value) {
        const client = this.getClient();
        return await client.hSet(key, field, value);
    }

    /**
     * 获取哈希字段
     * Get hash field
     */
    async hget(key, field) {
        const client = this.getClient();
        return await client.hGet(key, field);
    }

    /**
     * 获取所有哈希字段
     * Get all hash fields
     */
    async hgetall(key) {
        const client = this.getClient();
        return await client.hGetAll(key);
    }

    /**
     * 删除哈希字段
     * Delete hash field
     */
    async hdel(key, field) {
        const client = this.getClient();
        return await client.hDel(key, field);
    }

    /**
     * 列表左侧推入
     * List push left
     */
    async lpush(key, ...values) {
        const client = this.getClient();
        return await client.lPush(key, values);
    }

    /**
     * 列表右侧推入
     * List push right
     */
    async rpush(key, ...values) {
        const client = this.getClient();
        return await client.rPush(key, values);
    }

    /**
     * 获取列表范围
     * Get list range
     */
    async lrange(key, start, stop) {
        const client = this.getClient();
        return await client.lRange(key, start, stop);
    }

    /**
     * 增加计数器
     * Increment counter
     */
    async incr(key) {
        const client = this.getClient();
        return await client.incr(key);
    }

    /**
     * 按指定值增加
     * Increment by value
     */
    async incrby(key, value) {
        const client = this.getClient();
        return await client.incrBy(key, value);
    }

    /**
     * 减少计数器
     * Decrement counter
     */
    async decr(key) {
        const client = this.getClient();
        return await client.decr(key);
    }

    /**
     * 按指定值减少
     * Decrement by value
     */
    async decrby(key, value) {
        const client = this.getClient();
        return await client.decrBy(key, value);
    }

    /**
     * 清空数据库
     * Flush database
     */
    async flushdb() {
        const client = this.getClient();
        return await client.flushDb();
    }

    /**
     * 断开连接
     * Disconnect
     */
    async disconnect() {
        if (this.client && this.isConnected) {
            await this.client.quit();
            this.isConnected = false;
            console.log('✅ Redis 连接已关闭');
        }
    }

    /**
     * 健康检查
     * Health check
     */
    async healthCheck() {
        try {
            if (!this.isConnected) {
                return {
                    status: 'unhealthy',
                    message: 'Redis 未连接'
                };
            }

            const client = this.getClient();
            const pong = await client.ping();
            
            if (pong === 'PONG') {
                return {
                    status: 'healthy',
                    message: 'Redis 连接正常',
                    host: process.env.REDIS_HOST || 'localhost',
                    port: process.env.REDIS_PORT || 6379
                };
            } else {
                return {
                    status: 'unhealthy',
                    message: 'Redis ping 失败'
                };
            }

        } catch (error) {
            return {
                status: 'unhealthy',
                message: error.message
            };
        }
    }
}

// 导出单例
const redisConfig = new RedisConfig();
module.exports = redisConfig;
