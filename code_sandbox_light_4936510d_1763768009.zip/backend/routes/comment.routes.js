/**
 * 评论路由
 * Comment Routes
 */

const express = require('express');
const router = express.Router();
const commentController = require('../controllers/comment.controller');

// 创建评论
router.post('/', commentController.createComment.bind(commentController));

// 获取短剧评论列表
router.get('/drama/:dramaId', commentController.getDramaComments.bind(commentController));

// 获取剧集评论列表
router.get('/episode/:dramaId/:episodeId', commentController.getEpisodeComments.bind(commentController));

// 获取评论的回复
router.get('/:commentId/replies', commentController.getCommentReplies.bind(commentController));

// 点赞评论
router.post('/:commentId/like', commentController.likeComment.bind(commentController));

// 点踩评论
router.post('/:commentId/dislike', commentController.dislikeComment.bind(commentController));

// 删除评论
router.delete('/:commentId', commentController.deleteComment.bind(commentController));

// 获取用户评论列表
router.get('/user/:userId', commentController.getUserComments.bind(commentController));

module.exports = router;
