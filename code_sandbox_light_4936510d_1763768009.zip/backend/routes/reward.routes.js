/**
 * SUK奖励系统路由
 */

const express = require('express');
const router = express.Router();
const rewardController = require('../controllers/reward.controller');
const telegramAuthMiddleware = require('../middleware/telegram-auth.middleware');

// 所有奖励路由都需要Telegram认证
router.use(telegramAuthMiddleware);

/**
 * 观看奖励相关
 */

// 记录观看奖励
router.post('/watch', rewardController.recordWatchReward);

/**
 * 奖励统计和记录
 */

// 获取用户奖励统计
router.get('/stats', rewardController.getRewardStats);

// 获取用户奖励记录
router.get('/records', rewardController.getRewardRecords);

/**
 * 邀请系统
 */

// 生成邀请码
router.post('/invite/code', rewardController.generateInviteCode);

// 使用邀请码
router.post('/invite/use', rewardController.useInviteCode);

// 获取邀请列表
router.get('/invite/list', rewardController.getInviteList);

/**
 * 钱包和提现
 */

// 绑定钱包地址
router.post('/bind-wallet', rewardController.bindWallet);

// 提现奖励
router.post('/withdraw', rewardController.withdrawRewards);

/**
 * 排行榜
 */

// 获取排行榜
router.get('/leaderboard', rewardController.getLeaderboard);

module.exports = router;
