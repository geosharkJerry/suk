/**
 * 健康检查路由
 * Health Check Routes
 */

const express = require('express');
const router = express.Router();
const healthController = require('../controllers/health.controller');

// 基础健康检查
router.get('/', healthController.basicHealth.bind(healthController));

// 详细健康检查
router.get('/detailed', healthController.detailedHealth.bind(healthController));

// 系统指标
router.get('/metrics', healthController.metrics.bind(healthController));

// Kubernetes 就绪探针
router.get('/ready', healthController.readinessCheck.bind(healthController));

// Kubernetes 存活探针
router.get('/live', healthController.livenessCheck.bind(healthController));

module.exports = router;
