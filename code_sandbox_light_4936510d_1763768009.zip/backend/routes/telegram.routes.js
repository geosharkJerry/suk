/**
 * Telegram Mini App 路由
 * Telegram Mini App Routes
 * 
 * 处理所有来自Telegram Mini App的API请求
 */

const express = require('express');
const router = express.Router();
const telegramController = require('../controllers/telegram.controller');
const telegramWebhookController = require('../controllers/telegram-webhook.controller');
const { 
    telegramAuthMiddleware, 
    optionalTelegramAuth 
} = require('../middleware/telegram-auth.middleware');

// ============================================
// 公开端点（无需认证）
// ============================================

// 健康检查
router.get('/health', (req, res) => {
    res.json({
        success: true,
        service: 'telegram-mini-app',
        status: 'running',
        timestamp: new Date().toISOString()
    });
});

// Telegram Webhook（接收 Bot 回调）
router.post('/webhook', telegramWebhookController.handleWebhook);

// ============================================
// 需要认证的端点
// ============================================

// 所有后续路由都需要Telegram认证
router.use(telegramAuthMiddleware);

// 短剧相关
router.get('/dramas', telegramController.getDramas);
router.get('/dramas/:dramaId', telegramController.getDramaDetail);

// 视频播放
router.get('/play-auth/:episodeId', telegramController.getPlayAuth);
router.post('/watch-progress', telegramController.saveWatchProgress);

// 观看历史
router.get('/watch-history', telegramController.getWatchHistory);
router.get('/continue-watching', telegramController.getContinueWatching);

// 支付相关
router.post('/invoice', telegramController.createInvoice);
router.post('/verify-payment', telegramController.verifyPayment);

// 用户相关
router.get('/profile', telegramController.getProfile);

module.exports = router;
