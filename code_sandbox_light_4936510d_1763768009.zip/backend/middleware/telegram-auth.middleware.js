/**
 * Telegram WebApp 认证中间件
 * Telegram WebApp Authentication Middleware
 * 
 * 验证来自Telegram Mini App的请求
 */

const crypto = require('crypto');

/**
 * 验证Telegram WebApp初始化数据
 * @param {string} initData - Telegram initData字符串
 * @param {string} botToken - Bot Token
 * @returns {boolean} 验证是否通过
 */
function verifyTelegramWebAppData(initData, botToken) {
    try {
        // URL解码
        const encoded = decodeURIComponent(initData);
        
        // 创建密钥
        const secret = crypto
            .createHmac('sha256', 'WebAppData')
            .update(botToken)
            .digest();

        // 分割参数
        const arr = encoded.split('&');
        const hashIndex = arr.findIndex(str => str.startsWith('hash='));
        
        if (hashIndex === -1) {
            return false;
        }

        const hash = arr.splice(hashIndex)[0].split('=')[1];
        
        // 按字母顺序排序
        arr.sort((a, b) => a.localeCompare(b));
        const dataCheckString = arr.join('\n');

        // 计算HMAC-SHA256
        const _hash = crypto
            .createHmac('sha256', secret)
            .update(dataCheckString)
            .digest('hex');

        return _hash === hash;

    } catch (error) {
        console.error('Telegram数据验证错误:', error);
        return false;
    }
}

/**
 * 解析Telegram用户数据
 * @param {string} initData - Telegram initData字符串
 * @returns {object|null} 用户数据对象
 */
function parseTelegramUser(initData) {
    try {
        const params = new URLSearchParams(initData);
        const userJson = params.get('user');
        
        if (userJson) {
            return JSON.parse(userJson);
        }
        
        return null;
    } catch (error) {
        console.error('解析Telegram用户数据失败:', error);
        return null;
    }
}

/**
 * 获取启动参数
 * @param {string} initData - Telegram initData字符串
 * @returns {string|null} 启动参数
 */
function getStartParam(initData) {
    try {
        const params = new URLSearchParams(initData);
        return params.get('start_param');
    } catch (error) {
        return null;
    }
}

/**
 * Telegram认证中间件
 * 验证所有来自Telegram Mini App的API请求
 */
function telegramAuthMiddleware(req, res, next) {
    const initData = req.headers['x-telegram-init-data'];
    
    if (!initData) {
        return res.status(401).json({
            success: false,
            message: '缺少Telegram认证数据',
            code: 'MISSING_INIT_DATA'
        });
    }

    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    
    if (!botToken) {
        console.error('错误: TELEGRAM_BOT_TOKEN未配置');
        return res.status(500).json({
            success: false,
            message: '服务器配置错误',
            code: 'MISSING_BOT_TOKEN'
        });
    }

    // 验证数据签名
    if (!verifyTelegramWebAppData(initData, botToken)) {
        return res.status(401).json({
            success: false,
            message: 'Telegram认证失败：签名验证不通过',
            code: 'INVALID_SIGNATURE'
        });
    }

    // 解析用户数据
    const user = parseTelegramUser(initData);
    
    if (!user) {
        return res.status(401).json({
            success: false,
            message: 'Telegram认证失败：无法解析用户数据',
            code: 'INVALID_USER_DATA'
        });
    }

    // 将用户数据附加到请求对象
    req.telegramUser = {
        id: user.id,
        firstName: user.first_name,
        lastName: user.last_name || '',
        username: user.username || '',
        languageCode: user.language_code || 'en',
        isPremium: user.is_premium || false,
        photoUrl: user.photo_url || null
    };

    // 获取启动参数（用于推荐链接等）
    req.startParam = getStartParam(initData);

    // 记录访问日志
    console.log('Telegram用户认证成功:', {
        userId: req.telegramUser.id,
        username: req.telegramUser.username,
        startParam: req.startParam
    });

    next();
}

/**
 * 可选的Telegram认证中间件
 * 如果有initData则验证，没有则跳过（用于公开端点）
 */
function optionalTelegramAuth(req, res, next) {
    const initData = req.headers['x-telegram-init-data'];
    
    if (!initData) {
        // 没有initData，设置为匿名用户
        req.telegramUser = null;
        return next();
    }

    // 有initData，进行验证
    telegramAuthMiddleware(req, res, next);
}

/**
 * 检查用户是否为Telegram Premium
 */
function requireTelegramPremium(req, res, next) {
    if (!req.telegramUser) {
        return res.status(401).json({
            success: false,
            message: '需要Telegram认证',
            code: 'AUTH_REQUIRED'
        });
    }

    if (!req.telegramUser.isPremium) {
        return res.status(403).json({
            success: false,
            message: '此功能仅限Telegram Premium用户',
            code: 'PREMIUM_REQUIRED'
        });
    }

    next();
}

/**
 * 验证推荐参数
 */
function validateReferralParam(startParam) {
    // 格式: agent_RyTf9gJ1ezo86nyAclUX
    const referralRegex = /^agent_[a-zA-Z0-9]{20,}$/;
    return referralRegex.test(startParam);
}

module.exports = {
    verifyTelegramWebAppData,
    parseTelegramUser,
    getStartParam,
    telegramAuthMiddleware,
    optionalTelegramAuth,
    requireTelegramPremium,
    validateReferralParam
};
