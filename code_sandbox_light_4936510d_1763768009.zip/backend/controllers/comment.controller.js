/**
 * 评论控制器
 * Comment Controller
 */

const Comment = require('../models/Comment');
const crypto = require('crypto');

class CommentController {
    /**
     * 生成评论ID
     */
    generateCommentId() {
        const timestamp = Date.now().toString(36);
        const random = crypto.randomBytes(4).toString('hex');
        return `COMMENT_${timestamp}_${random}`.toUpperCase();
    }

    /**
     * 创建评论
     * POST /api/comments
     */
    async createComment(req, res) {
        try {
            const {
                dramaId,
                episodeId = null,
                content,
                rating = null,
                parentId = null,
                replyToUserId = null,
                replyToUsername = ''
            } = req.body;

            // 验证必需字段
            if (!dramaId || !content) {
                return res.status(400).json({
                    success: false,
                    message: '缺少必需字段'
                });
            }

            // 获取用户信息（从认证中间件）
            const userId = req.user?.id || req.telegramUser?.id;
            const username = req.user?.username || req.telegramUser?.username || '匿名用户';
            const userAvatar = req.user?.avatar || req.telegramUser?.photo_url || '';

            if (!userId) {
                return res.status(401).json({
                    success: false,
                    message: '用户未认证'
                });
            }

            // 创建评论
            const comment = new Comment({
                commentId: this.generateCommentId(),
                dramaId,
                episodeId,
                userId: userId.toString(),
                username,
                userAvatar,
                content,
                rating,
                parentId,
                replyToUserId,
                replyToUsername
            });

            await comment.save();

            // 如果是回复，更新父评论的回复数
            if (parentId) {
                const parentComment = await Comment.findOne({ commentId: parentId });
                if (parentComment) {
                    await parentComment.incrementReplyCount();
                }
            }

            res.status(201).json({
                success: true,
                data: comment,
                message: '评论发表成功'
            });

        } catch (error) {
            console.error('创建评论失败:', error);
            res.status(500).json({
                success: false,
                message: '创建评论失败',
                error: error.message
            });
        }
    }

    /**
     * 获取短剧评论列表
     * GET /api/comments/drama/:dramaId
     */
    async getDramaComments(req, res) {
        try {
            const { dramaId } = req.params;
            const {
                page = 1,
                limit = 20,
                sortBy = 'createdAt',
                sortOrder = 'desc'
            } = req.query;

            const result = await Comment.getDramaComments(dramaId, {
                page: parseInt(page),
                limit: parseInt(limit),
                sortBy,
                sortOrder
            });

            res.json({
                success: true,
                ...result
            });

        } catch (error) {
            console.error('获取评论列表失败:', error);
            res.status(500).json({
                success: false,
                message: '获取评论列表失败',
                error: error.message
            });
        }
    }

    /**
     * 获取剧集评论列表
     * GET /api/comments/episode/:dramaId/:episodeId
     */
    async getEpisodeComments(req, res) {
        try {
            const { dramaId, episodeId } = req.params;
            const {
                page = 1,
                limit = 20,
                sortBy = 'createdAt',
                sortOrder = 'desc'
            } = req.query;

            const query = {
                dramaId,
                episodeId,
                parentId: null,
                status: 'active',
                moderationStatus: 'approved'
            };

            const sort = {};
            sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

            const comments = await Comment.find(query)
                .sort(sort)
                .skip((parseInt(page) - 1) * parseInt(limit))
                .limit(parseInt(limit))
                .lean();

            const total = await Comment.countDocuments(query);

            res.json({
                success: true,
                comments,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total,
                    totalPages: Math.ceil(total / parseInt(limit))
                }
            });

        } catch (error) {
            console.error('获取剧集评论失败:', error);
            res.status(500).json({
                success: false,
                message: '获取剧集评论失败',
                error: error.message
            });
        }
    }

    /**
     * 获取评论的回复
     * GET /api/comments/:commentId/replies
     */
    async getCommentReplies(req, res) {
        try {
            const { commentId } = req.params;
            const { page = 1, limit = 10 } = req.query;

            const result = await Comment.getCommentReplies(commentId, {
                page: parseInt(page),
                limit: parseInt(limit)
            });

            res.json({
                success: true,
                ...result
            });

        } catch (error) {
            console.error('获取评论回复失败:', error);
            res.status(500).json({
                success: false,
                message: '获取评论回复失败',
                error: error.message
            });
        }
    }

    /**
     * 点赞评论
     * POST /api/comments/:commentId/like
     */
    async likeComment(req, res) {
        try {
            const { commentId } = req.params;
            const userId = req.user?.id || req.telegramUser?.id;

            if (!userId) {
                return res.status(401).json({
                    success: false,
                    message: '用户未认证'
                });
            }

            const comment = await Comment.findOne({ commentId });
            
            if (!comment) {
                return res.status(404).json({
                    success: false,
                    message: '评论不存在'
                });
            }

            await comment.like(userId.toString());

            res.json({
                success: true,
                data: {
                    likes: comment.likes,
                    dislikes: comment.dislikes
                },
                message: '操作成功'
            });

        } catch (error) {
            console.error('点赞评论失败:', error);
            res.status(500).json({
                success: false,
                message: '点赞评论失败',
                error: error.message
            });
        }
    }

    /**
     * 点踩评论
     * POST /api/comments/:commentId/dislike
     */
    async dislikeComment(req, res) {
        try {
            const { commentId } = req.params;
            const userId = req.user?.id || req.telegramUser?.id;

            if (!userId) {
                return res.status(401).json({
                    success: false,
                    message: '用户未认证'
                });
            }

            const comment = await Comment.findOne({ commentId });
            
            if (!comment) {
                return res.status(404).json({
                    success: false,
                    message: '评论不存在'
                });
            }

            await comment.dislike(userId.toString());

            res.json({
                success: true,
                data: {
                    likes: comment.likes,
                    dislikes: comment.dislikes
                },
                message: '操作成功'
            });

        } catch (error) {
            console.error('点踩评论失败:', error);
            res.status(500).json({
                success: false,
                message: '点踩评论失败',
                error: error.message
            });
        }
    }

    /**
     * 删除评论
     * DELETE /api/comments/:commentId
     */
    async deleteComment(req, res) {
        try {
            const { commentId } = req.params;
            const userId = req.user?.id || req.telegramUser?.id;

            if (!userId) {
                return res.status(401).json({
                    success: false,
                    message: '用户未认证'
                });
            }

            const comment = await Comment.findOne({ commentId });
            
            if (!comment) {
                return res.status(404).json({
                    success: false,
                    message: '评论不存在'
                });
            }

            // 只能删除自己的评论
            if (comment.userId !== userId.toString()) {
                return res.status(403).json({
                    success: false,
                    message: '无权限删除此评论'
                });
            }

            // 软删除
            comment.status = 'deleted';
            await comment.save();

            res.json({
                success: true,
                message: '评论已删除'
            });

        } catch (error) {
            console.error('删除评论失败:', error);
            res.status(500).json({
                success: false,
                message: '删除评论失败',
                error: error.message
            });
        }
    }

    /**
     * 获取用户评论列表
     * GET /api/comments/user/:userId
     */
    async getUserComments(req, res) {
        try {
            const { userId } = req.params;
            const { page = 1, limit = 20 } = req.query;

            const query = {
                userId,
                status: 'active'
            };

            const comments = await Comment.find(query)
                .sort({ createdAt: -1 })
                .skip((parseInt(page) - 1) * parseInt(limit))
                .limit(parseInt(limit))
                .lean();

            const total = await Comment.countDocuments(query);

            res.json({
                success: true,
                comments,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total,
                    totalPages: Math.ceil(total / parseInt(limit))
                }
            });

        } catch (error) {
            console.error('获取用户评论失败:', error);
            res.status(500).json({
                success: false,
                message: '获取用户评论失败',
                error: error.message
            });
        }
    }
}

module.exports = new CommentController();
