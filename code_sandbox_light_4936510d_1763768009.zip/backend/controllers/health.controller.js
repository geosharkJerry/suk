/**
 * 健康检查控制器
 * Health Check Controller
 * 
 * 提供系统健康状态和监控数据
 */

const mongoose = require('mongoose');
const redis = require('../config/redis.config');
const AliyunVoDService = require('../services/aliyun-vod.service');
const tonService = require('../services/ton-blockchain.service');
const sukService = require('../services/suk-blockchain.service');

class HealthController {
    /**
     * 基础健康检查
     * GET /api/health
     */
    async basicHealth(req, res) {
        try {
            const health = {
                status: 'healthy',
                timestamp: new Date().toISOString(),
                uptime: process.uptime(),
                environment: process.env.NODE_ENV || 'development'
            };

            res.json(health);
        } catch (error) {
            res.status(503).json({
                status: 'unhealthy',
                timestamp: new Date().toISOString(),
                error: error.message
            });
        }
    }

    /**
     * 详细健康检查
     * GET /api/health/detailed
     */
    async detailedHealth(req, res) {
        try {
            const startTime = Date.now();

            // 并发检查所有服务
            const [
                mongoHealth,
                redisHealth,
                vodHealth,
                tonHealth,
                sukHealth
            ] = await Promise.allSettled([
                this.checkMongoDB(),
                this.checkRedis(),
                this.checkAliyunVoD(),
                this.checkTON(),
                this.checkSUK()
            ]);

            const services = {
                mongodb: this.formatHealthResult(mongoHealth),
                redis: this.formatHealthResult(redisHealth),
                aliyunVod: this.formatHealthResult(vodHealth),
                tonBlockchain: this.formatHealthResult(tonHealth),
                sukBlockchain: this.formatHealthResult(sukHealth)
            };

            // 判断整体状态
            const allHealthy = Object.values(services).every(
                service => service.status === 'healthy'
            );

            const responseTime = Date.now() - startTime;

            res.status(allHealthy ? 200 : 503).json({
                status: allHealthy ? 'healthy' : 'degraded',
                timestamp: new Date().toISOString(),
                responseTime: `${responseTime}ms`,
                uptime: process.uptime(),
                services: services
            });

        } catch (error) {
            console.error('详细健康检查失败:', error);
            res.status(503).json({
                status: 'unhealthy',
                timestamp: new Date().toISOString(),
                error: error.message
            });
        }
    }

    /**
     * 系统指标
     * GET /api/health/metrics
     */
    async metrics(req, res) {
        try {
            const metrics = {
                timestamp: new Date().toISOString(),
                process: {
                    uptime: process.uptime(),
                    pid: process.pid,
                    nodeVersion: process.version,
                    platform: process.platform,
                    arch: process.arch
                },
                memory: {
                    ...process.memoryUsage(),
                    heapUsedMB: (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2),
                    heapTotalMB: (process.memoryUsage().heapTotal / 1024 / 1024).toFixed(2),
                    rssMB: (process.memoryUsage().rss / 1024 / 1024).toFixed(2)
                },
                cpu: process.cpuUsage()
            };

            // MongoDB 统计
            if (mongoose.connection.readyState === 1) {
                try {
                    const dbStats = await mongoose.connection.db.stats();
                    metrics.mongodb = {
                        collections: dbStats.collections,
                        dataSize: `${(dbStats.dataSize / 1024 / 1024).toFixed(2)} MB`,
                        storageSize: `${(dbStats.storageSize / 1024 / 1024).toFixed(2)} MB`,
                        indexes: dbStats.indexes,
                        indexSize: `${(dbStats.indexSize / 1024 / 1024).toFixed(2)} MB`
                    };
                } catch (err) {
                    console.error('获取 MongoDB 统计失败:', err);
                }
            }

            // Redis 统计
            try {
                if (redis.isConnected) {
                    const client = redis.getClient();
                    const info = await client.info('memory');
                    const usedMemory = info.match(/used_memory_human:(.+)/);
                    if (usedMemory) {
                        metrics.redis = {
                            usedMemory: usedMemory[1].trim()
                        };
                    }
                }
            } catch (err) {
                console.error('获取 Redis 统计失败:', err);
            }

            res.json(metrics);

        } catch (error) {
            console.error('获取系统指标失败:', error);
            res.status(500).json({
                success: false,
                message: '获取系统指标失败',
                error: error.message
            });
        }
    }

    /**
     * 就绪检查（Readiness Probe）
     * GET /api/health/ready
     */
    async readinessCheck(req, res) {
        try {
            // 检查关键服务是否就绪
            const [mongoReady, redisReady] = await Promise.all([
                this.checkMongoDB(),
                this.checkRedis()
            ]);

            const ready = mongoReady.status === 'healthy' && 
                         redisReady.status === 'healthy';

            if (ready) {
                res.json({ status: 'ready' });
            } else {
                res.status(503).json({ status: 'not ready' });
            }

        } catch (error) {
            res.status(503).json({ 
                status: 'not ready',
                error: error.message 
            });
        }
    }

    /**
     * 存活检查（Liveness Probe）
     * GET /api/health/live
     */
    async livenessCheck(req, res) {
        // 简单的存活检查
        res.json({ status: 'alive' });
    }

    // ==========================================
    // 私有方法：检查各个服务
    // ==========================================

    async checkMongoDB() {
        const start = Date.now();
        try {
            if (mongoose.connection.readyState !== 1) {
                throw new Error('MongoDB 未连接');
            }

            // 执行简单的 ping 操作
            await mongoose.connection.db.admin().ping();

            return {
                status: 'healthy',
                responseTime: Date.now() - start,
                details: {
                    state: mongoose.connection.readyState,
                    host: mongoose.connection.host,
                    name: mongoose.connection.name
                }
            };

        } catch (error) {
            return {
                status: 'unhealthy',
                responseTime: Date.now() - start,
                error: error.message
            };
        }
    }

    async checkRedis() {
        const start = Date.now();
        try {
            const health = await redis.healthCheck();

            return {
                ...health,
                responseTime: Date.now() - start
            };

        } catch (error) {
            return {
                status: 'unhealthy',
                responseTime: Date.now() - start,
                error: error.message
            };
        }
    }

    async checkAliyunVoD() {
        const start = Date.now();
        try {
            // 简单检查配置是否存在
            const hasConfig = process.env.ALIYUN_ACCESS_KEY_ID && 
                            process.env.ALIYUN_ACCESS_KEY_SECRET;

            if (!hasConfig) {
                throw new Error('阿里云 VoD 配置缺失');
            }

            return {
                status: 'healthy',
                responseTime: Date.now() - start,
                details: {
                    configured: true
                }
            };

        } catch (error) {
            return {
                status: 'unhealthy',
                responseTime: Date.now() - start,
                error: error.message
            };
        }
    }

    async checkTON() {
        const start = Date.now();
        try {
            const health = await tonService.healthCheck();

            return {
                ...health,
                responseTime: Date.now() - start
            };

        } catch (error) {
            return {
                status: 'unhealthy',
                responseTime: Date.now() - start,
                error: error.message
            };
        }
    }

    async checkSUK() {
        const start = Date.now();
        try {
            const health = await sukService.healthCheck();

            return {
                ...health,
                responseTime: Date.now() - start
            };

        } catch (error) {
            return {
                status: 'unhealthy',
                responseTime: Date.now() - start,
                error: error.message
            };
        }
    }

    formatHealthResult(result) {
        if (result.status === 'fulfilled') {
            return result.value;
        } else {
            return {
                status: 'unhealthy',
                error: result.reason.message
            };
        }
    }
}

module.exports = new HealthController();
