/**
 * Telegram Webhook 控制器
 * Telegram Webhook Controller
 * 
 * 处理来自 Telegram 的 webhook 回调
 * 包括支付成功通知、命令消息等
 */

const TelegramPaymentService = require('../services/telegram-payment.service');

class TelegramWebhookController {
    /**
     * 处理 Telegram webhook
     * POST /api/telegram/webhook
     */
    async handleWebhook(req, res) {
        try {
            const update = req.body;

            console.log('收到 Telegram webhook:', JSON.stringify(update, null, 2));

            // 快速响应 Telegram 服务器
            res.status(200).send('OK');

            // 异步处理更新
            this.processUpdate(update).catch(error => {
                console.error('处理 webhook 失败:', error);
            });

        } catch (error) {
            console.error('Webhook 处理错误:', error);
            res.status(500).send('ERROR');
        }
    }

    /**
     * 处理更新内容
     * Process update
     */
    async processUpdate(update) {
        try {
            // 处理支付成功消息
            if (update.message && update.message.successful_payment) {
                await this.handleSuccessfulPayment(update);
                return;
            }

            // 处理预支付查询（pre-checkout query）
            if (update.pre_checkout_query) {
                await this.handlePreCheckoutQuery(update);
                return;
            }

            // 处理命令消息
            if (update.message && update.message.text) {
                const text = update.message.text;
                
                if (text.startsWith('/start')) {
                    await this.handleStartCommand(update);
                } else if (text.startsWith('/help')) {
                    await this.handleHelpCommand(update);
                } else if (text.startsWith('/wallet')) {
                    await this.handleWalletCommand(update);
                }
                return;
            }

            // 处理回调查询（inline button 点击）
            if (update.callback_query) {
                await this.handleCallbackQuery(update);
                return;
            }

        } catch (error) {
            console.error('处理更新失败:', error);
        }
    }

    /**
     * 处理支付成功
     * Handle successful payment
     */
    async handleSuccessfulPayment(update) {
        try {
            const payment = update.message.successful_payment;
            const chatId = update.message.chat.id;
            const userId = update.message.from.id;

            console.log('支付成功:', {
                userId: userId,
                amount: payment.total_amount,
                currency: payment.currency,
                payload: payment.invoice_payload
            });

            // 验证支付
            const result = await TelegramPaymentService.verifyPayment(update);

            if (result.success) {
                // 发送成功消息
                await this.sendMessage(chatId, {
                    text: `🎉 支付成功！\n\n您已成功购买剧集，现在可以观看了。\n\n订单号: ${result.orderId}`,
                    parse_mode: 'Markdown'
                });

                // 发送查看剧集按钮
                await this.sendMessage(chatId, {
                    text: '点击下方按钮查看剧集:',
                    reply_markup: {
                        inline_keyboard: [[
                            {
                                text: '📺 立即观看',
                                web_app: {
                                    url: `${process.env.WEB_APP_URL}/telegram-drama-detail.html?id=${result.dramaId}`
                                }
                            }
                        ]]
                    }
                });
            }

        } catch (error) {
            console.error('处理支付成功失败:', error);
            
            // 发送错误消息给用户
            const chatId = update.message.chat.id;
            await this.sendMessage(chatId, {
                text: '⚠️ 支付处理出现问题，请联系客服。'
            });
        }
    }

    /**
     * 处理预支付查询
     * Handle pre-checkout query
     */
    async handlePreCheckoutQuery(update) {
        try {
            const query = update.pre_checkout_query;
            const queryId = query.id;

            console.log('预支付查询:', {
                queryId: queryId,
                userId: query.from.id,
                currency: query.currency,
                total_amount: query.total_amount
            });

            // 验证订单（可以在这里做额外验证）
            const payload = JSON.parse(query.invoice_payload);
            
            // 答复预支付查询（必须在10秒内响应）
            await this.answerPreCheckoutQuery(queryId, {
                ok: true
            });

        } catch (error) {
            console.error('处理预支付查询失败:', error);
            
            // 拒绝支付
            const queryId = update.pre_checkout_query.id;
            await this.answerPreCheckoutQuery(queryId, {
                ok: false,
                error_message: '订单验证失败，请重试'
            });
        }
    }

    /**
     * 处理 /start 命令
     * Handle /start command
     */
    async handleStartCommand(update) {
        const chatId = update.message.chat.id;
        const userId = update.message.from.id;
        const firstName = update.message.from.first_name || '用户';

        await this.sendMessage(chatId, {
            text: `👋 你好，${firstName}！\n\n欢迎来到 SUK 短剧平台！\n\n📺 海量精彩短剧等你观看\n💎 多种支付方式可选\n⚡ 观看历史自动保存\n\n点击下方按钮开始浏览:`,
            reply_markup: {
                inline_keyboard: [[
                    {
                        text: '🎬 打开剧场',
                        web_app: {
                            url: `${process.env.WEB_APP_URL}/telegram-app.html`
                        }
                    }
                ]]
            }
        });
    }

    /**
     * 处理 /help 命令
     * Handle /help command
     */
    async handleHelpCommand(update) {
        const chatId = update.message.chat.id;

        const helpText = `
📖 *SUK 短剧平台使用帮助*

*基本功能:*
/start - 打开短剧平台
/help - 显示帮助信息
/wallet - 查看钱包余额

*如何观看:*
1️⃣ 点击菜单按钮或发送 /start
2️⃣ 浏览剧集列表
3️⃣ 选择感兴趣的剧集
4️⃣ 第1集免费观看
5️⃣ 购买后观看全集

*支付方式:*
⭐ Telegram Stars - 最便捷
💎 TON Coin - Telegram 原生加密货币
🪙 SUK Token - 平台代币，享受更多权益

*需要帮助?*
联系客服: @SUKSupport
        `;

        await this.sendMessage(chatId, {
            text: helpText.trim(),
            parse_mode: 'Markdown'
        });
    }

    /**
     * 处理 /wallet 命令
     * Handle /wallet command
     */
    async handleWalletCommand(update) {
        const chatId = update.message.chat.id;
        const userId = update.message.from.id;

        // TODO: 查询用户钱包余额和购买记录
        const walletInfo = `
💰 *我的钱包*

*余额:*
🪙 SUK Token: 0
⭐ Stars: 查看 Telegram 余额

*购买记录:*
📺 已购买剧集: 0 部
💰 总消费: 0 SUK

_点击下方按钮充值或查看详情_
        `;

        await this.sendMessage(chatId, {
            text: walletInfo.trim(),
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [[
                    {
                        text: '💰 充值',
                        web_app: {
                            url: `${process.env.WEB_APP_URL}/telegram-wallet.html`
                        }
                    },
                    {
                        text: '📜 购买记录',
                        callback_data: 'purchases'
                    }
                ]]
            }
        });
    }

    /**
     * 处理回调查询
     * Handle callback query
     */
    async handleCallbackQuery(update) {
        const query = update.callback_query;
        const chatId = query.message.chat.id;
        const data = query.data;

        // 答复回调查询
        await this.answerCallbackQuery(query.id, {
            text: '处理中...'
        });

        // 根据回调数据处理
        switch (data) {
            case 'purchases':
                // TODO: 显示购买记录
                await this.sendMessage(chatId, {
                    text: '📜 您的购买记录:\n\n暂无购买记录'
                });
                break;

            default:
                console.log('未知的回调数据:', data);
        }
    }

    /**
     * 发送消息
     * Send message
     */
    async sendMessage(chatId, options) {
        try {
            const botToken = process.env.TELEGRAM_BOT_TOKEN;
            const url = `https://api.telegram.org/bot${botToken}/sendMessage`;

            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    chat_id: chatId,
                    ...options
                })
            });

            return await response.json();

        } catch (error) {
            console.error('发送消息失败:', error);
            throw error;
        }
    }

    /**
     * 答复预支付查询
     * Answer pre-checkout query
     */
    async answerPreCheckoutQuery(queryId, options) {
        try {
            const botToken = process.env.TELEGRAM_BOT_TOKEN;
            const url = `https://api.telegram.org/bot${botToken}/answerPreCheckoutQuery`;

            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    pre_checkout_query_id: queryId,
                    ...options
                })
            });

            return await response.json();

        } catch (error) {
            console.error('答复预支付查询失败:', error);
            throw error;
        }
    }

    /**
     * 答复回调查询
     * Answer callback query
     */
    async answerCallbackQuery(queryId, options) {
        try {
            const botToken = process.env.TELEGRAM_BOT_TOKEN;
            const url = `https://api.telegram.org/bot${botToken}/answerCallbackQuery`;

            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    callback_query_id: queryId,
                    ...options
                })
            });

            return await response.json();

        } catch (error) {
            console.error('答复回调查询失败:', error);
            throw error;
        }
    }
}

module.exports = new TelegramWebhookController();
