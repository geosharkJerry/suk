/**
 * SUK奖励系统控制器
 */

const rewardService = require('../services/reward.service');
const { WatchHistory } = require('../models/WatchHistory');

class RewardController {
    /**
     * 记录观看奖励
     * POST /api/rewards/watch
     */
    async recordWatchReward(req, res) {
        try {
            const {
                dramaId,
                episodeId,
                watchDuration,
                totalDuration
            } = req.body;

            const userId = req.user.telegramId || req.user.id;
            const walletAddress = req.user.walletAddress;

            // 验证必需参数
            if (!dramaId || !episodeId || !watchDuration || !totalDuration) {
                return res.status(400).json({
                    success: false,
                    message: '缺少必需参数'
                });
            }

            // 记录奖励
            const reward = await rewardService.recordWatchReward({
                userId,
                walletAddress,
                dramaId,
                episodeId,
                watchDuration,
                totalDuration
            });

            res.json({
                success: true,
                message: '观看奖励记录成功',
                data: reward
            });

        } catch (error) {
            console.error('记录观看奖励失败:', error);
            res.status(500).json({
                success: false,
                message: error.message || '记录观看奖励失败'
            });
        }
    }

    /**
     * 获取用户奖励统计
     * GET /api/rewards/stats
     */
    async getRewardStats(req, res) {
        try {
            const userId = req.user.telegramId || req.user.id;

            const stats = await rewardService.getUserRewardStats(userId);

            res.json({
                success: true,
                data: stats
            });

        } catch (error) {
            console.error('获取奖励统计失败:', error);
            res.status(500).json({
                success: false,
                message: '获取奖励统计失败'
            });
        }
    }

    /**
     * 获取用户奖励记录
     * GET /api/rewards/records
     */
    async getRewardRecords(req, res) {
        try {
            const userId = req.user.telegramId || req.user.id;
            const {
                page = 1,
                limit = 20,
                type = 'all',
                status
            } = req.query;

            const records = await rewardService.getUserRewards(userId, {
                page: parseInt(page),
                limit: parseInt(limit),
                type,
                status
            });

            res.json({
                success: true,
                data: records
            });

        } catch (error) {
            console.error('获取奖励记录失败:', error);
            res.status(500).json({
                success: false,
                message: '获取奖励记录失败'
            });
        }
    }

    /**
     * 生成邀请码
     * POST /api/rewards/invite/code
     */
    async generateInviteCode(req, res) {
        try {
            const userId = req.user.telegramId || req.user.id;
            const walletAddress = req.user.walletAddress;

            // 检查是否已绑定钱包
            if (!walletAddress) {
                return res.status(400).json({
                    success: false,
                    message: '请先绑定钱包地址'
                });
            }

            // 获取或生成邀请码
            const inviteCode = await rewardService.getUserInviteCode(userId);

            // 生成邀请链接
            const baseUrl = process.env.WEBAPP_URL || 'https://suk.link';
            const inviteLink = `${baseUrl}/telegram-app.html?inviteCode=${inviteCode}`;

            res.json({
                success: true,
                data: {
                    inviteCode,
                    inviteLink,
                    qrCode: `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(inviteLink)}`
                }
            });

        } catch (error) {
            console.error('生成邀请码失败:', error);
            res.status(500).json({
                success: false,
                message: '生成邀请码失败'
            });
        }
    }

    /**
     * 验证并使用邀请码
     * POST /api/rewards/invite/use
     */
    async useInviteCode(req, res) {
        try {
            const { inviteCode } = req.body;
            const inviteeId = req.user.telegramId || req.user.id;

            if (!inviteCode) {
                return res.status(400).json({
                    success: false,
                    message: '请提供邀请码'
                });
            }

            // 验证邀请码
            const inviterInfo = await rewardService.validateInviteCode(inviteCode);
            
            if (!inviterInfo) {
                return res.status(404).json({
                    success: false,
                    message: '邀请码无效'
                });
            }

            // 不能邀请自己
            if (inviterInfo.inviterId === inviteeId) {
                return res.status(400).json({
                    success: false,
                    message: '不能使用自己的邀请码'
                });
            }

            // 创建邀请关系
            const relation = await rewardService.createInviteRelation({
                inviterId: inviterInfo.inviterId,
                inviterWallet: inviterInfo.inviterWallet,
                inviteeId,
                inviteCode,
                inviteSource: 'code'
            });

            res.json({
                success: true,
                message: '邀请码使用成功',
                data: relation
            });

        } catch (error) {
            console.error('使用邀请码失败:', error);
            res.status(500).json({
                success: false,
                message: error.message || '使用邀请码失败'
            });
        }
    }

    /**
     * 获取用户邀请列表
     * GET /api/rewards/invite/list
     */
    async getInviteList(req, res) {
        try {
            const userId = req.user.telegramId || req.user.id;
            const {
                page = 1,
                limit = 20,
                status
            } = req.query;

            const result = await rewardService.getUserInvites(userId, {
                page: parseInt(page),
                limit: parseInt(limit),
                status
            });

            res.json({
                success: true,
                data: result.data,
                pagination: result.pagination
            });

        } catch (error) {
            console.error('获取邀请列表失败:', error);
            res.status(500).json({
                success: false,
                message: '获取邀请列表失败'
            });
        }
    }

    /**
     * 绑定钱包地址
     * POST /api/rewards/bind-wallet
     */
    async bindWallet(req, res) {
        try {
            const { walletAddress } = req.body;
            const userId = req.user.telegramId || req.user.id;

            if (!walletAddress) {
                return res.status(400).json({
                    success: false,
                    message: '请提供钱包地址'
                });
            }

            // 验证钱包地址格式（简单验证）
            if (!/^0x[a-fA-F0-9]{40}$/.test(walletAddress)) {
                return res.status(400).json({
                    success: false,
                    message: '钱包地址格式不正确'
                });
            }

            // 绑定钱包
            await rewardService.bindWallet(userId, walletAddress);

            // 更新用户信息
            req.user.walletAddress = walletAddress;
            await req.user.save();

            res.json({
                success: true,
                message: '钱包绑定成功',
                data: {
                    walletAddress
                }
            });

        } catch (error) {
            console.error('绑定钱包失败:', error);
            res.status(500).json({
                success: false,
                message: '绑定钱包失败'
            });
        }
    }

    /**
     * 提现奖励（申请提现）
     * POST /api/rewards/withdraw
     */
    async withdrawRewards(req, res) {
        try {
            const userId = req.user.telegramId || req.user.id;
            const { amount, walletAddress } = req.body;

            if (!amount || amount <= 0) {
                return res.status(400).json({
                    success: false,
                    message: '提现金额必须大于0'
                });
            }

            if (!walletAddress) {
                return res.status(400).json({
                    success: false,
                    message: '请提供提现钱包地址'
                });
            }

            // 检查余额
            const stats = await rewardService.getUserRewardStats(userId);
            
            if (stats.totalPaid < amount) {
                return res.status(400).json({
                    success: false,
                    message: '可提现余额不足'
                });
            }

            // TODO: 实现提现逻辑（区块链交易）
            // 这里需要集成区块链服务

            res.json({
                success: true,
                message: '提现申请已提交，预计24小时内到账',
                data: {
                    amount,
                    walletAddress,
                    estimatedTime: '24小时'
                }
            });

        } catch (error) {
            console.error('提现失败:', error);
            res.status(500).json({
                success: false,
                message: '提现失败'
            });
        }
    }

    /**
     * 获取排行榜
     * GET /api/rewards/leaderboard
     */
    async getLeaderboard(req, res) {
        try {
            const {
                type = 'total', // total, watch, invite
                limit = 10
            } = req.query;

            const UserRewardStats = require('../models/Reward').UserRewardStats;

            let sortField;
            switch (type) {
                case 'watch':
                    sortField = 'watchRewards.total';
                    break;
                case 'invite':
                    sortField = 'inviteRewards.total';
                    break;
                default:
                    sortField = 'totalEarned';
            }

            const leaderboard = await UserRewardStats.find()
                .sort({ [sortField]: -1 })
                .limit(parseInt(limit))
                .select('userId totalEarned watchRewards inviteRewards')
                .lean();

            res.json({
                success: true,
                data: leaderboard
            });

        } catch (error) {
            console.error('获取排行榜失败:', error);
            res.status(500).json({
                success: false,
                message: '获取排行榜失败'
            });
        }
    }
}

module.exports = new RewardController();
