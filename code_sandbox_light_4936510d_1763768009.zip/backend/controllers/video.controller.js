/**
 * 视频播放控制器
 * 处理视频播放、播放凭证、观看历史等相关请求
 */

const AliyunVoDService = require('../services/aliyun-vod.service');
const WatchHistoryService = require('../services/watch-history.service');
const PurchaseService = require('../services/purchase.service');
const CacheService = require('../services/cache.service');
const Drama = require('../models/Drama');

class VideoController {
    /**
     * 获取视频播放凭证
     * GET /api/video/play-auth/:episodeId
     */
    async getPlayAuth(req, res) {
        try {
            const { episodeId } = req.params;
            const userId = req.user?.address || req.query.userId; // 从JWT或query获取
            
            if (!userId) {
                return res.status(401).json({
                    success: false,
                    error: '用户未登录'
                });
            }
            
            console.log(`📺 请求播放凭证: userId=${userId}, episodeId=${episodeId}`);
            
            // 1. 查找剧集信息
            const drama = await Drama.findOne(
                { 'episodes.episodeId': episodeId },
                { 'episodes.$': 1, title: 1 }
            );
            
            if (!drama || !drama.episodes || drama.episodes.length === 0) {
                return res.status(404).json({
                    success: false,
                    error: '剧集不存在'
                });
            }
            
            const episode = drama.episodes[0];
            const dramaId = drama._id;
            
            // 2. 检查是否需要购买（如果不是免费剧集）
            if (!episode.isFree) {
                const isPurchased = await PurchaseService.verifyPurchase(
                    userId,
                    dramaId.toString(),
                    episodeId
                );
                
                if (!isPurchased) {
                    return res.status(403).json({
                        success: false,
                        error: '您尚未购买此剧集',
                        needPurchase: true,
                        episodePrice: episode.sukPrice
                    });
                }
            }
            
            // 3. 检查Redis缓存
            const cacheKey = `play_auth:${userId}:${episodeId}`;
            const cachedAuth = await CacheService.get(cacheKey);
            
            if (cachedAuth) {
                console.log(`✅ 从缓存获取播放凭证: ${episodeId}`);
                
                const ttl = await CacheService.ttl(cacheKey);
                
                return res.json({
                    success: true,
                    playAuth: cachedAuth,
                    videoId: episode.videoId,
                    expiresIn: ttl,
                    fromCache: true
                });
            }
            
            // 4. 从阿里云生成新的播放凭证
            const playAuth = await AliyunVoDService.generatePlayAuth(
                episode.videoId,
                1800 // 30分钟有效期
            );
            
            // 5. 缓存播放凭证（有效期30分钟）
            await CacheService.set(cacheKey, playAuth, 1800);
            
            // 6. 获取观看历史（用于续播）
            const progressData = await WatchHistoryService.getEpisodeProgress(
                userId,
                dramaId.toString(),
                episodeId
            );
            
            console.log(`✅ 生成播放凭证成功: ${episodeId}`);
            
            res.json({
                success: true,
                playAuth,
                videoId: episode.videoId,
                expiresIn: 1800,
                fromCache: false,
                // 返回观看进度（用于续播）
                watchHistory: progressData.hasHistory ? {
                    watchProgress: progressData.watchProgress,
                    progressPercent: progressData.progressPercent,
                    lastWatchedAt: progressData.lastWatchedAt
                } : null
            });
            
        } catch (error) {
            console.error('❌ 获取播放凭证失败:', error);
            res.status(500).json({
                success: false,
                error: '获取播放凭证失败: ' + error.message
            });
        }
    }
    
    /**
     * 保存观看进度
     * POST /api/video/watch-progress
     */
    async saveWatchProgress(req, res) {
        try {
            const {
                dramaId,
                episodeId,
                watchProgress,
                totalDuration,
                videoId
            } = req.body;
            
            const userId = req.user?.address || req.body.userId;
            
            if (!userId) {
                return res.status(401).json({
                    success: false,
                    error: '用户未登录'
                });
            }
            
            // 验证参数
            if (!dramaId || !episodeId || watchProgress === undefined || !totalDuration) {
                return res.status(400).json({
                    success: false,
                    error: '缺少必要参数'
                });
            }
            
            console.log(`💾 保存观看进度: ${userId} - ${episodeId}, 进度: ${watchProgress}s/${totalDuration}s`);
            
            // 保存观看进度
            const result = await WatchHistoryService.saveWatchProgress({
                userId,
                dramaId,
                episodeId,
                watchProgress,
                totalDuration,
                videoId
            });
            
            res.json({
                success: true,
                message: '观看进度已保存',
                data: result
            });
            
        } catch (error) {
            console.error('❌ 保存观看进度失败:', error);
            res.status(500).json({
                success: false,
                error: '保存观看进度失败: ' + error.message
            });
        }
    }
    
    /**
     * 获取观看历史列表
     * GET /api/video/watch-history
     */
    async getWatchHistory(req, res) {
        try {
            const userId = req.user?.address || req.query.userId;
            
            if (!userId) {
                return res.status(401).json({
                    success: false,
                    error: '用户未登录'
                });
            }
            
            const { page = 1, limit = 20, sortBy = 'lastWatchedAt' } = req.query;
            
            console.log(`📋 获取观看历史: ${userId}, page=${page}`);
            
            const result = await WatchHistoryService.getUserWatchHistory(userId, {
                page: parseInt(page),
                limit: parseInt(limit),
                sortBy
            });
            
            res.json(result);
            
        } catch (error) {
            console.error('❌ 获取观看历史失败:', error);
            res.status(500).json({
                success: false,
                error: '获取观看历史失败: ' + error.message
            });
        }
    }
    
    /**
     * 获取剧集观看进度
     * GET /api/video/episode-progress/:dramaId/:episodeId
     */
    async getEpisodeProgress(req, res) {
        try {
            const { dramaId, episodeId } = req.params;
            const userId = req.user?.address || req.query.userId;
            
            if (!userId) {
                return res.status(401).json({
                    success: false,
                    error: '用户未登录'
                });
            }
            
            console.log(`🔍 获取剧集进度: ${episodeId}`);
            
            const result = await WatchHistoryService.getEpisodeProgress(
                userId,
                dramaId,
                episodeId
            );
            
            res.json(result);
            
        } catch (error) {
            console.error('❌ 获取剧集进度失败:', error);
            res.status(500).json({
                success: false,
                error: '获取剧集进度失败: ' + error.message
            });
        }
    }
    
    /**
     * 获取短剧观看进度
     * GET /api/video/drama-progress/:dramaId
     */
    async getDramaProgress(req, res) {
        try {
            const { dramaId } = req.params;
            const userId = req.user?.address || req.query.userId;
            
            if (!userId) {
                return res.status(401).json({
                    success: false,
                    error: '用户未登录'
                });
            }
            
            console.log(`🔍 获取短剧进度: ${dramaId}`);
            
            const result = await WatchHistoryService.getDramaProgress(userId, dramaId);
            
            res.json(result);
            
        } catch (error) {
            console.error('❌ 获取短剧进度失败:', error);
            res.status(500).json({
                success: false,
                error: '获取短剧进度失败: ' + error.message
            });
        }
    }
    
    /**
     * 继续观看推荐列表
     * GET /api/video/continue-watching
     */
    async getContinueWatching(req, res) {
        try {
            const userId = req.user?.address || req.query.userId;
            
            if (!userId) {
                return res.status(401).json({
                    success: false,
                    error: '用户未登录'
                });
            }
            
            const { limit = 10 } = req.query;
            
            console.log(`▶️  获取继续观看列表: ${userId}`);
            
            const list = await WatchHistoryService.getContinueWatchingList(
                userId,
                parseInt(limit)
            );
            
            res.json({
                success: true,
                data: list
            });
            
        } catch (error) {
            console.error('❌ 获取继续观看列表失败:', error);
            res.status(500).json({
                success: false,
                error: '获取继续观看列表失败: ' + error.message
            });
        }
    }
    
    /**
     * 删除观看历史
     * DELETE /api/video/watch-history/:historyId
     */
    async deleteWatchHistory(req, res) {
        try {
            const { historyId } = req.params;
            const userId = req.user?.address || req.body.userId;
            
            if (!userId) {
                return res.status(401).json({
                    success: false,
                    error: '用户未登录'
                });
            }
            
            console.log(`🗑️  删除观看历史: ${historyId}`);
            
            await WatchHistoryService.deleteWatchHistory(userId, historyId);
            
            res.json({
                success: true,
                message: '删除成功'
            });
            
        } catch (error) {
            console.error('❌ 删除观看历史失败:', error);
            res.status(500).json({
                success: false,
                error: '删除观看历史失败: ' + error.message
            });
        }
    }
    
    /**
     * 清空观看历史
     * DELETE /api/video/watch-history
     */
    async clearWatchHistory(req, res) {
        try {
            const userId = req.user?.address || req.body.userId;
            
            if (!userId) {
                return res.status(401).json({
                    success: false,
                    error: '用户未登录'
                });
            }
            
            console.log(`🗑️  清空观看历史: ${userId}`);
            
            const deletedCount = await WatchHistoryService.clearUserHistory(userId);
            
            res.json({
                success: true,
                message: '清空成功',
                deletedCount
            });
            
        } catch (error) {
            console.error('❌ 清空观看历史失败:', error);
            res.status(500).json({
                success: false,
                error: '清空观看历史失败: ' + error.message
            });
        }
    }
    
    /**
     * 获取观看统计
     * GET /api/video/watch-statistics
     */
    async getWatchStatistics(req, res) {
        try {
            const userId = req.user?.address || req.query.userId;
            
            if (!userId) {
                return res.status(401).json({
                    success: false,
                    error: '用户未登录'
                });
            }
            
            console.log(`📊 获取观看统计: ${userId}`);
            
            const stats = await WatchHistoryService.getUserWatchStatistics(userId);
            
            res.json({
                success: true,
                data: stats
            });
            
        } catch (error) {
            console.error('❌ 获取观看统计失败:', error);
            res.status(500).json({
                success: false,
                error: '获取观看统计失败: ' + error.message
            });
        }
    }
}

module.exports = new VideoController();
