/**
 * Telegram Mini App 控制器
 * Telegram Mini App Controller
 * 
 * 处理来自Telegram Mini App的所有API请求
 */

const WatchHistory = require('../models/WatchHistory');
const AliyunVoDService = require('../services/aliyun-vod.service');
const WatchHistoryService = require('../services/watch-history.service');

class TelegramController {
    /**
     * 获取短剧列表
     * GET /api/telegram/dramas
     */
    async getDramas(req, res) {
        try {
            const telegramUser = req.telegramUser;
            const { page = 1, limit = 20, category } = req.query;

            console.log('Telegram用户请求短剧列表:', telegramUser.id);

            // TODO: 从数据库获取短剧列表
            // const dramas = await Drama.find({ status: 'published' })
            //     .skip((page - 1) * limit)
            //     .limit(limit);

            // 临时返回模拟数据
            const mockDramas = [
                {
                    id: 'drama_001',
                    title: '霸道总裁爱上我',
                    description: '一个灰姑娘与霸道总裁的爱情故事',
                    coverUrl: 'https://via.placeholder.com/270x480?text=Drama1',
                    price: 50,
                    priceUSD: 7,
                    priceTON: 3,
                    priceStars: 100,
                    episodes: 20,
                    totalDuration: 600, // 600分钟
                    category: 'romance',
                    rating: 4.8,
                    views: 125000
                },
                {
                    id: 'drama_002',
                    title: '重生之我在古代当皇帝',
                    description: '现代人穿越到古代成为皇帝',
                    coverUrl: 'https://via.placeholder.com/270x480?text=Drama2',
                    price: 80,
                    priceUSD: 11,
                    priceTON: 5,
                    priceStars: 150,
                    episodes: 30,
                    totalDuration: 900,
                    category: 'fantasy',
                    rating: 4.6,
                    views: 98000
                },
                {
                    id: 'drama_003',
                    title: '闪婚后大佬真香了',
                    description: '闪婚后的甜蜜生活',
                    coverUrl: 'https://via.placeholder.com/270x480?text=Drama3',
                    price: 60,
                    priceUSD: 8.5,
                    priceTON: 4,
                    priceStars: 120,
                    episodes: 25,
                    totalDuration: 750,
                    category: 'romance',
                    rating: 4.9,
                    views: 156000
                },
                {
                    id: 'drama_004',
                    title: '豪门千金她不装了',
                    description: '隐藏身份的豪门千金',
                    coverUrl: 'https://via.placeholder.com/270x480?text=Drama4',
                    price: 70,
                    priceUSD: 10,
                    priceTON: 4.5,
                    priceStars: 140,
                    episodes: 28,
                    totalDuration: 840,
                    category: 'drama',
                    rating: 4.7,
                    views: 110000
                }
            ];

            res.json({
                success: true,
                data: mockDramas,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: mockDramas.length,
                    totalPages: 1
                },
                user: {
                    telegramId: telegramUser.id,
                    firstName: telegramUser.firstName,
                    isPremium: telegramUser.isPremium
                }
            });

        } catch (error) {
            console.error('获取短剧列表失败:', error);
            res.status(500).json({
                success: false,
                message: '服务器错误',
                error: process.env.NODE_ENV === 'development' ? error.message : undefined
            });
        }
    }

    /**
     * 获取短剧详情
     * GET /api/telegram/dramas/:dramaId
     */
    async getDramaDetail(req, res) {
        try {
            const { dramaId } = req.params;
            const telegramUser = req.telegramUser;

            console.log('Telegram用户请求短剧详情:', telegramUser.id, dramaId);

            // 检查用户是否已购买该剧集
            const TelegramPaymentService = require('../services/telegram-payment.service');
            const purchaseStatus = await TelegramPaymentService.checkPurchaseStatus(
                telegramUser.id.toString(),
                dramaId
            );
            const hasPurchased = purchaseStatus.purchased && purchaseStatus.type === 'full';

            // 生成完整的剧集列表（20集）
            const episodes = Array.from({ length: 20 }, (_, i) => ({
                id: `ep_${String(i + 1).padStart(3, '0')}`,
                episodeNumber: i + 1,
                title: `第${i + 1}集`,
                duration: 180, // 3分钟
                isFree: i === 0, // 第1集免费
                coverUrl: `https://via.placeholder.com/270x480?text=EP${i + 1}`
            }));

            // 模拟数据
            const mockDrama = {
                id: dramaId,
                title: '霸道总裁爱上我',
                description: '一个灰姑娘与霸道总裁的爱情故事。女主角林晓晓是一名普通的公司职员，机缘巧合下与霸道总裁陈默轩相遇。从最初的误会到逐渐了解，两人之间擦出了爱的火花。但是，来自家庭的压力、事业的考验，以及前女友的纠缠，让这段感情充满了波折。他们能否克服重重困难，最终走到一起？',
                coverUrl: 'https://via.placeholder.com/400x280?text=Drama+Cover',
                price: 50,
                pricePerEpisode: 5, // 单集价格
                priceUSD: 7,
                priceTON: 3,
                priceStars: 100,
                episodes: episodes,
                totalEpisodes: 20,
                category: 'romance',
                tags: ['都市', '爱情', '霸总', '甜宠', '高分推荐'],
                rating: 4.8,
                views: 125000,
                likes: 32000,
                comments: 5600,
                hasPurchased: hasPurchased
                director: '张导演',
                cast: [
                    {
                        name: '陈默轩',
                        role: '男主角',
                        avatar: '👨‍💼'
                    },
                    {
                        name: '林晓晓',
                        role: '女主角',
                        avatar: '👩'
                    },
                    {
                        name: '张导演',
                        role: '导演',
                        avatar: '🎬'
                    },
                    {
                        name: '李编剧',
                        role: '编剧',
                        avatar: '✍️'
                    }
                ],
                comments: [
                    {
                        user: 'Telegram用户123',
                        rating: 5,
                        text: '太好看了！强烈推荐！剧情紧凑，演员演技在线，每集都有看点。',
                        date: '2天前'
                    },
                    {
                        user: 'Telegram用户456',
                        rating: 4,
                        text: '不错的短剧，值得一看。就是更新有点慢，期待后续剧情。',
                        date: '3天前'
                    },
                    {
                        user: 'Premium用户⭐',
                        rating: 5,
                        text: '作为Premium用户，必须给5星好评！画质清晰，剧情精彩，性价比超高！',
                        date: '5天前'
                    }
                ],
                releaseDate: '2024-01-01',
                updateSchedule: '每周一、三、五更新',
                language: '中文',
                subtitles: ['中文', 'English'],
                quality: ['480P', '720P', '1080P']
            };

            res.json({
                success: true,
                data: mockDrama
            });

        } catch (error) {
            console.error('获取短剧详情失败:', error);
            res.status(500).json({
                success: false,
                message: '服务器错误'
            });
        }
    }

    /**
     * 获取剧集播放授权
     * GET /api/telegram/play-auth/:episodeId
     */
    async getPlayAuth(req, res) {
        try {
            const { episodeId } = req.params;
            const telegramUser = req.telegramUser;

            console.log('Telegram用户请求播放授权:', telegramUser.id, episodeId);

            // 解析 episodeId，提取 dramaId 和 episodeNumber
            // 假设格式为: drama_001_ep_001
            const dramaId = req.query.dramaId || episodeId.split('_ep_')[0];
            const episodeNumber = parseInt(episodeId.split('_').pop());

            // 1. 检查是否为免费剧集（第1集）
            const isFree = episodeNumber === 1;

            if (!isFree) {
                // 2. 检查用户是否已购买
                const TelegramPaymentService = require('../services/telegram-payment.service');
                const purchaseStatus = await TelegramPaymentService.checkPurchaseStatus(
                    telegramUser.id.toString(),
                    dramaId,
                    episodeId
                );

                if (!purchaseStatus.purchased) {
                    return res.status(403).json({
                        success: false,
                        message: '您尚未购买此剧集',
                        requiresPurchase: true,
                        dramaId: dramaId,
                        episodeId: episodeId
                    });
                }
            }

            // 3. 查询观看历史
            let watchHistory = null;
            try {
                const history = await WatchHistoryService.getEpisodeHistory(
                    telegramUser.id.toString(),
                    episodeId
                );
                if (history) {
                    watchHistory = {
                        watchProgress: history.watchProgress,
                        totalDuration: history.totalDuration,
                        updatedAt: history.updatedAt
                    };
                }
            } catch (err) {
                console.error('查询观看历史失败:', err);
            }

            // 4. 获取剧集的videoId
            const Drama = require('../models/Drama');
            const episodeInfo = await Drama.findEpisode(episodeId);
            
            if (!episodeInfo || !episodeInfo.episode) {
                return res.status(404).json({
                    success: false,
                    message: '剧集不存在'
                });
            }

            const videoId = episodeInfo.episode.videoId;
            
            if (!videoId) {
                return res.status(500).json({
                    success: false,
                    message: '视频资源未配置'
                });
            }

            // 5. 生成阿里云VoD播放授权
            let playAuth;
            const expiresIn = 1800; // 30分钟
            
            try {
                // 尝试从Redis缓存获取
                const redis = require('../config/redis.config');
                const cacheKey = `playauth:${videoId}`;
                const cachedAuth = await redis.get(cacheKey);
                
                if (cachedAuth) {
                    console.log('使用缓存的播放授权:', videoId);
                    playAuth = cachedAuth;
                } else {
                    // 生成新的播放授权
                    playAuth = await AliyunVoDService.generatePlayAuth(videoId, expiresIn);
                    
                    // 缓存播放授权（提前5分钟过期，避免边界问题）
                    const cacheTTL = expiresIn - 300; // 25分钟
                    await redis.setex(cacheKey, cacheTTL, playAuth);
                    console.log('生成并缓存播放授权:', videoId);
                }
            } catch (error) {
                console.error('生成播放授权失败:', error);
                return res.status(500).json({
                    success: false,
                    message: '生成播放授权失败',
                    error: error.message
                });
            }

            // 6. 返回播放授权
            res.json({
                success: true,
                playAuth: playAuth,
                videoId: videoId,
                expiresIn: expiresIn,
                watchHistory: watchHistory,
                episodeInfo: {
                    dramaId: episodeInfo.drama.dramaId,
                    dramaTitle: episodeInfo.drama.title,
                    episodeId: episodeInfo.episode.episodeId,
                    episodeNumber: episodeInfo.episode.episodeNumber,
                    episodeTitle: episodeInfo.episode.title,
                    duration: episodeInfo.episode.duration,
                    isFree: episodeInfo.episode.isFree
                },
                message: '播放授权获取成功'
            });

        } catch (error) {
            console.error('获取播放授权失败:', error);
            res.status(500).json({
                success: false,
                message: '获取播放授权失败'
            });
        }
    }

    /**
     * 保存观看进度
     * POST /api/telegram/watch-progress
     */
    async saveWatchProgress(req, res) {
        try {
            const { dramaId, episodeId, watchProgress, totalDuration, videoId } = req.body;
            const telegramUser = req.telegramUser;

            console.log('保存观看进度:', {
                userId: telegramUser.id,
                episodeId,
                progress: watchProgress
            });

            // 使用WatchHistoryService保存进度
            const result = await WatchHistoryService.saveWatchProgress({
                userId: telegramUser.id.toString(), // Telegram ID作为用户ID
                dramaId,
                episodeId,
                videoId,
                watchProgress: Math.floor(watchProgress),
                totalDuration: Math.floor(totalDuration)
            });

            res.json({
                success: true,
                data: result
            });

        } catch (error) {
            console.error('保存观看进度失败:', error);
            res.status(500).json({
                success: false,
                message: '保存观看进度失败'
            });
        }
    }

    /**
     * 获取用户观看历史
     * GET /api/telegram/watch-history
     */
    async getWatchHistory(req, res) {
        try {
            const telegramUser = req.telegramUser;
            const { page = 1, limit = 20 } = req.query;

            const result = await WatchHistoryService.getWatchHistory(
                telegramUser.id.toString(),
                parseInt(page),
                parseInt(limit)
            );

            res.json({
                success: true,
                data: result.histories,
                pagination: result.pagination
            });

        } catch (error) {
            console.error('获取观看历史失败:', error);
            res.status(500).json({
                success: false,
                message: '获取观看历史失败'
            });
        }
    }

    /**
     * 获取继续观看列表
     * GET /api/telegram/continue-watching
     */
    async getContinueWatching(req, res) {
        try {
            const telegramUser = req.telegramUser;
            const { limit = 10 } = req.query;

            const list = await WatchHistoryService.getContinueWatchingList(
                telegramUser.id.toString(),
                parseInt(limit)
            );

            res.json({
                success: true,
                data: list
            });

        } catch (error) {
            console.error('获取继续观看列表失败:', error);
            res.status(500).json({
                success: false,
                message: '获取继续观看列表失败'
            });
        }
    }

    /**
     * 创建支付发票
     * POST /api/telegram/invoice
     */
    async createInvoice(req, res) {
        try {
            const { dramaId, paymentMethod, purchaseType, episodeId } = req.body;
            const telegramUser = req.telegramUser;

            console.log('创建支付发票:', {
                userId: telegramUser.id,
                dramaId,
                paymentMethod,
                purchaseType,
                episodeId
            });

            // 获取剧集信息（需要价格）
            // TODO: 从数据库获取真实数据
            const mockDrama = {
                id: dramaId,
                title: '霸道总裁爱上我',
                price: 50,
                priceStars: 100,
                priceTON: 3,
                pricePerEpisode: 5,
                priceStarsPerEpisode: 20
            };

            // 根据购买类型确定价格
            const priceStars = purchaseType === 'single' 
                ? mockDrama.priceStarsPerEpisode 
                : mockDrama.priceStars;
            const priceTON = purchaseType === 'single'
                ? mockDrama.priceTON / 10
                : mockDrama.priceTON;
            const priceSUK = purchaseType === 'single'
                ? mockDrama.pricePerEpisode
                : mockDrama.price;

            const TelegramPaymentService = require('../services/telegram-payment.service');
            let result;
            
            switch (paymentMethod) {
                case 'stars':
                    result = await TelegramPaymentService.createStarsInvoice({
                        userId: telegramUser.id.toString(),
                        dramaId: dramaId,
                        dramaTitle: mockDrama.title,
                        priceStars: priceStars,
                        purchaseType: purchaseType,
                        episodeId: episodeId
                    });
                    break;

                case 'ton':
                    result = await TelegramPaymentService.createTonInvoice({
                        userId: telegramUser.id.toString(),
                        dramaId: dramaId,
                        dramaTitle: mockDrama.title,
                        priceTON: priceTON,
                        purchaseType: purchaseType,
                        episodeId: episodeId
                    });
                    break;

                case 'suk':
                    result = await TelegramPaymentService.createSukOrder({
                        userId: telegramUser.id.toString(),
                        dramaId: dramaId,
                        dramaTitle: mockDrama.title,
                        priceSUK: priceSUK,
                        purchaseType: purchaseType,
                        episodeId: episodeId,
                        userWallet: req.body.userWallet
                    });
                    break;

                default:
                    return res.status(400).json({
                        success: false,
                        message: '不支持的支付方式'
                    });
            }

            res.json({
                success: true,
                ...result,
                paymentMethod: paymentMethod
            });

        } catch (error) {
            console.error('创建发票失败:', error);
            res.status(500).json({
                success: false,
                message: error.message || '创建支付失败'
            });
        }
    }

    /**
     * 验证支付
     * POST /api/telegram/verify-payment
     */
    async verifyPayment(req, res) {
        try {
            const { orderId, paymentMethod, transactionHash } = req.body;
            const telegramUser = req.telegramUser;

            console.log('验证支付:', {
                userId: telegramUser.id,
                orderId,
                paymentMethod,
                txHash: transactionHash
            });

            const TelegramPaymentService = require('../services/telegram-payment.service');
            let result;

            // 根据支付方式验证
            switch (paymentMethod) {
                case 'suk':
                    if (!transactionHash) {
                        return res.status(400).json({
                            success: false,
                            message: '缺少交易哈希'
                        });
                    }
                    result = await TelegramPaymentService.verifySukPayment(orderId, transactionHash);
                    break;

                case 'stars':
                case 'ton':
                    // Stars 和 TON 通过 webhook 自动验证
                    return res.status(400).json({
                        success: false,
                        message: '该支付方式通过 webhook 自动验证'
                    });

                default:
                    return res.status(400).json({
                        success: false,
                        message: '不支持的支付方式'
                    });
            }

            res.json({
                success: true,
                message: '支付验证成功',
                ...result
            });

        } catch (error) {
            console.error('验证支付失败:', error);
            res.status(500).json({
                success: false,
                message: error.message || '验证支付失败'
            });
        }
    }

    /**
     * 获取用户资料
     * GET /api/telegram/profile
     */
    async getProfile(req, res) {
        try {
            const telegramUser = req.telegramUser;

            // TODO: 从数据库获取用户完整资料
            // const user = await User.findOne({ telegramId: telegramUser.id });

            res.json({
                success: true,
                data: {
                    telegramId: telegramUser.id,
                    firstName: telegramUser.firstName,
                    lastName: telegramUser.lastName,
                    username: telegramUser.username,
                    languageCode: telegramUser.languageCode,
                    isPremium: telegramUser.isPremium,
                    photoUrl: telegramUser.photoUrl,
                    // 额外数据
                    purchaseCount: 0, // TODO: 从数据库查询
                    watchedCount: 0,
                    favoriteCount: 0,
                    sukBalance: 0 // TODO: 从区块链查询
                }
            });

        } catch (error) {
            console.error('获取用户资料失败:', error);
            res.status(500).json({
                success: false,
                message: '获取用户资料失败'
            });
        }
    }
}

module.exports = new TelegramController();
