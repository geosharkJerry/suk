# 生产环境上线清单
# Production Launch Checklist

> **短剧平台上线发布完整指南** 🚀  
> 按顺序完成所有检查项，确保安全、稳定上线

---

## 📋 目录

- [上线前准备](#上线前准备)
- [基础设施准备](#基础设施准备)
- [安全配置](#安全配置)
- [服务配置](#服务配置)
- [部署步骤](#部署步骤)
- [上线后验证](#上线后验证)
- [监控和运维](#监控和运维)
- [应急预案](#应急预案)

---

## 上线前准备

### 1️⃣ 域名和 DNS 配置

#### 需要准备的域名

- [ ] **主域名**: `drama-platform.io`（示例）
- [ ] **API 域名**: `api.drama-platform.io`
- [ ] **CDN 域名**: `cdn.drama-platform.io`
- [ ] **监控域名**: `monitor.drama-platform.io`

#### DNS 记录配置

```bash
# A 记录（指向服务器 IP）
drama-platform.io.        A    <YOUR_SERVER_IP>
api.drama-platform.io.    A    <YOUR_SERVER_IP>
www.drama-platform.io.    A    <YOUR_SERVER_IP>

# CNAME 记录（CDN）
cdn.drama-platform.io.    CNAME  <CDN_DOMAIN>

# TXT 记录（域名验证）
drama-platform.io.        TXT   "v=spf1 ..."
```

**工具**: [CloudFlare](https://cloudflare.com) / [阿里云DNS](https://dns.aliyun.com)

---

### 2️⃣ SSL 证书

#### 选项 A: Let's Encrypt（免费，推荐）

```bash
# 安装 Certbot
sudo apt-get update
sudo apt-get install certbot python3-certbot-nginx

# 获取证书
sudo certbot certonly --nginx -d drama-platform.io -d www.drama-platform.io -d api.drama-platform.io

# 自动续期
sudo crontab -e
# 添加: 0 0 1 * * certbot renew --quiet
```

#### 选项 B: 商业证书

- [ ] 购买证书（推荐供应商：阿里云、腾讯云、Sectigo）
- [ ] 生成 CSR（证书签名请求）
- [ ] 上传证书到服务器
- [ ] 配置 Nginx

**证书存放位置**:
```
/etc/letsencrypt/live/drama-platform.io/fullchain.pem
/etc/letsencrypt/live/drama-platform.io/privkey.pem
```

---

### 3️⃣ 服务器准备

#### 服务器配置要求

**最低配置（小型）**:
- [ ] CPU: 2核
- [ ] 内存: 4GB
- [ ] 硬盘: 50GB SSD
- [ ] 带宽: 5Mbps

**推荐配置（中型）**:
- [ ] CPU: 4核
- [ ] 内存: 8GB
- [ ] 硬盘: 100GB SSD
- [ ] 带宽: 10Mbps

**生产配置（大型）**:
- [ ] CPU: 8核+
- [ ] 内存: 16GB+
- [ ] 硬盘: 200GB+ SSD
- [ ] 带宽: 20Mbps+

#### 推荐云服务商

- [ ] **阿里云 ECS** - 国内用户首选
- [ ] **腾讯云 CVM** - 国内备选
- [ ] **AWS EC2** - 国际用户
- [ ] **DigitalOcean** - 性价比高

#### 操作系统

- [ ] **推荐**: Ubuntu 22.04 LTS
- [ ] 备选: CentOS 8 / Debian 11

---

### 4️⃣ 第三方服务准备

#### 阿里云 VoD（视频点播）

- [ ] 开通阿里云账号
- [ ] 实名认证
- [ ] 开通 VoD 服务
- [ ] 创建 RAM 子账号
- [ ] 获取 AccessKey
- [ ] 配置转码模板（9:16 竖屏）
- [ ] 开启 HLS 加密
- [ ] 绑定 CDN 域名

**文档**: [阿里云 VoD 配置指南](ALIYUN_VOD_SETUP_GUIDE.md)

#### Telegram Bot

- [ ] 创建 Telegram Bot（@BotFather）
- [ ] 获取 Bot Token
- [ ] 设置 Bot 头像和描述
- [ ] 配置 WebApp URL
- [ ] 设置支付商户（Telegram Stars）
- [ ] 配置 Webhook URL

**命令**:
```bash
# 创建 Bot
/newbot

# 设置 WebApp
/mybots -> @YourBot -> Bot Settings -> Menu Button -> Edit Menu Button URL
```

#### TON 区块链

- [ ] 创建 TON 钱包
- [ ] 获取钱包地址
- [ ] 充值 TON（用于测试）
- [ ] 获取 TON Center API Key（可选）

**工具**: [Tonkeeper](https://tonkeeper.com/) / [TON Wallet](https://wallet.ton.org/)

#### 以太坊 RPC

- [ ] 注册 Infura 账号
- [ ] 创建项目
- [ ] 获取 RPC URL
- [ ] 或使用 Alchemy

**服务商**:
- [Infura](https://infura.io/)
- [Alchemy](https://www.alchemy.com/)
- [QuickNode](https://www.quicknode.com/)

---

## 基础设施准备

### 5️⃣ MongoDB 数据库

#### 选项 A: 自建（省钱）

```bash
# 安装 MongoDB 6.0
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list
sudo apt-get update
sudo apt-get install -y mongodb-org

# 启动服务
sudo systemctl start mongod
sudo systemctl enable mongod

# 创建管理员账号
mongosh
use admin
db.createUser({
  user: "admin",
  pwd: "YOUR_STRONG_PASSWORD",
  roles: ["root"]
})

# 启用认证
sudo nano /etc/mongod.conf
# 添加:
security:
  authorization: enabled

sudo systemctl restart mongod
```

#### 选项 B: 托管服务（省心）

- [ ] **MongoDB Atlas** (推荐) - 免费 512MB
- [ ] **阿里云 MongoDB**
- [ ] **腾讯云 MongoDB**

**连接字符串**:
```
mongodb://username:password@host:27017/database?authSource=admin
```

---

### 6️⃣ Redis 缓存

#### 选项 A: 自建

```bash
# 安装 Redis 7
sudo apt-get install redis-server

# 配置
sudo nano /etc/redis/redis.conf
# 修改:
bind 0.0.0.0
requirepass YOUR_REDIS_PASSWORD
maxmemory 256mb
maxmemory-policy allkeys-lru

# 重启
sudo systemctl restart redis
```

#### 选项 B: 托管服务

- [ ] **阿里云 Redis**
- [ ] **腾讯云 Redis**
- [ ] **Redis Labs**

---

### 7️⃣ 备份策略

#### MongoDB 自动备份

```bash
# 创建备份脚本
nano /opt/backup-mongodb.sh
```

```bash
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/var/backups/mongodb"
MONGO_URI="mongodb://admin:password@localhost:27017"

mkdir -p $BACKUP_DIR

# 备份
mongodump --uri="$MONGO_URI" --out="$BACKUP_DIR/backup_$DATE"

# 压缩
tar -czf "$BACKUP_DIR/backup_$DATE.tar.gz" "$BACKUP_DIR/backup_$DATE"
rm -rf "$BACKUP_DIR/backup_$DATE"

# 删除30天前的备份
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete

echo "MongoDB backup completed: backup_$DATE.tar.gz"
```

```bash
# 设置权限
chmod +x /opt/backup-mongodb.sh

# 添加定时任务
sudo crontab -e
# 每天凌晨2点备份
0 2 * * * /opt/backup-mongodb.sh >> /var/log/mongodb-backup.log 2>&1
```

#### 文件备份

- [ ] 代码备份（Git）
- [ ] 配置文件备份
- [ ] 日志备份
- [ ] 数据库备份

---

## 安全配置

### 8️⃣ 防火墙配置

```bash
# 安装 UFW
sudo apt-get install ufw

# 默认策略
sudo ufw default deny incoming
sudo ufw default allow outgoing

# 允许 SSH（重要！）
sudo ufw allow 22/tcp

# 允许 HTTP/HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# 启用防火墙
sudo ufw enable

# 查看状态
sudo ufw status
```

---

### 9️⃣ SSH 安全加固

```bash
# 创建新用户（不要用 root）
sudo adduser deploy
sudo usermod -aG sudo deploy

# 配置 SSH 密钥登录
ssh-keygen -t rsa -b 4096 -C "your_email@example.com"
ssh-copy-id deploy@your_server_ip

# 禁用密码登录和 root 登录
sudo nano /etc/ssh/sshd_config

# 修改以下配置:
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
Port 22  # 或改为其他端口

# 重启 SSH
sudo systemctl restart sshd
```

---

### 🔟 安全检查清单

- [ ] 修改所有默认密码
- [ ] 启用防火墙
- [ ] 配置 SSH 密钥认证
- [ ] 禁用 root 登录
- [ ] 安装 fail2ban（防暴力破解）
- [ ] 配置自动安全更新
- [ ] 限制 MongoDB 访问（只允许本地/内网）
- [ ] 限制 Redis 访问
- [ ] 配置 HTTPS 强制跳转
- [ ] 设置安全响应头

#### 安装 Fail2ban

```bash
sudo apt-get install fail2ban
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

---

## 服务配置

### 1️⃣1️⃣ 环境变量配置

创建生产环境配置文件:

```bash
# 在服务器上创建
nano /opt/drama-platform/.env
```

```bash
# ============================================
# 生产环境配置
# ============================================

NODE_ENV=production
PORT=3000

# 数据库
MONGODB_URI=mongodb://admin:PASSWORD@localhost:27017/short_drama_platform?authSource=admin
MONGODB_ROOT_USER=admin
MONGODB_ROOT_PASSWORD=STRONG_PASSWORD
MONGODB_DATABASE=short_drama_platform

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=STRONG_PASSWORD
REDIS_DB=0

# 阿里云 VoD
ALIYUN_ACCESS_KEY_ID=LTAI5t...
ALIYUN_ACCESS_KEY_SECRET=...
ALIYUN_VOD_REGION=cn-shanghai

# JWT
JWT_SECRET=$(openssl rand -hex 64)
JWT_EXPIRES_IN=7d

# 区块链
ETHEREUM_RPC_URL=https://mainnet.infura.io/v3/YOUR_PROJECT_ID
ETHEREUM_NETWORK=mainnet
SUK_TOKEN_CONTRACT=0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb
PLATFORM_WALLET_ADDRESS=0x...

# TON
TON_WALLET_ADDRESS=EQ...
TON_API_KEY=...
TON_NETWORK=mainnet

# Telegram Bot
TELEGRAM_BOT_TOKEN=123456:ABC-DEF...
TELEGRAM_BOT_USERNAME=YourBotUsername
TELEGRAM_WEBAPP_URL=https://drama-platform.io/telegram-app.html
TELEGRAM_WEBHOOK_URL=https://api.drama-platform.io/api/telegram/webhook

# 域名
API_BASE_URL=https://api.drama-platform.io

# 安全
CORS_ORIGIN=https://drama-platform.io,https://www.drama-platform.io
FORCE_HTTPS=true
COOKIE_SECURE=true

# 监控
SENTRY_DSN=https://...@sentry.io/...
SENTRY_ENVIRONMENT=production
```

**重要**: 
```bash
# 设置文件权限
chmod 600 /opt/drama-platform/.env
```

---

### 1️⃣2️⃣ Nginx 配置

```bash
# 安装 Nginx
sudo apt-get install nginx

# 创建配置文件
sudo nano /etc/nginx/sites-available/drama-platform
```

```nginx
# HTTP - 重定向到 HTTPS
server {
    listen 80;
    listen [::]:80;
    server_name drama-platform.io www.drama-platform.io api.drama-platform.io;
    
    # Let's Encrypt 验证
    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }
    
    # 重定向到 HTTPS
    location / {
        return 301 https://$host$request_uri;
    }
}

# HTTPS - 主站
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name drama-platform.io www.drama-platform.io;
    
    # SSL 证书
    ssl_certificate /etc/letsencrypt/live/drama-platform.io/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/drama-platform.io/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    
    # 安全头
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    
    # 静态文件根目录
    root /opt/drama-platform;
    index index.html;
    
    # 静态文件
    location / {
        try_files $uri $uri/ /index.html;
        expires 7d;
        add_header Cache-Control "public, immutable";
    }
    
    # API 代理
    location /api/ {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    # 日志
    access_log /var/log/nginx/drama-platform-access.log;
    error_log /var/log/nginx/drama-platform-error.log;
}
```

```bash
# 启用站点
sudo ln -s /etc/nginx/sites-available/drama-platform /etc/nginx/sites-enabled/

# 测试配置
sudo nginx -t

# 重启 Nginx
sudo systemctl restart nginx
```

---

### 1️⃣3️⃣ PM2 进程管理

```bash
# 安装 PM2
sudo npm install -g pm2

# 创建 ecosystem 配置（已存在）
# ecosystem.config.js

# 启动应用
cd /opt/drama-platform
pm2 start ecosystem.config.js --env production

# 保存配置
pm2 save

# 设置开机自启
pm2 startup
# 执行输出的命令

# 查看状态
pm2 status
pm2 logs
pm2 monit
```

---

## 部署步骤

### 步骤 1: 服务器初始化

```bash
# 1. 连接服务器
ssh deploy@your_server_ip

# 2. 更新系统
sudo apt-get update
sudo apt-get upgrade -y

# 3. 安装基础软件
sudo apt-get install -y git curl wget vim build-essential

# 4. 安装 Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# 5. 验证安装
node --version  # 应该是 v18.x
npm --version   # 应该是 9.x+
```

---

### 步骤 2: 安装 Docker（推荐）

```bash
# 安装 Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# 安装 Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# 添加用户到 docker 组
sudo usermod -aG docker $USER
newgrp docker

# 验证
docker --version
docker-compose --version
```

---

### 步骤 3: 部署代码

#### 方式 A: Docker 部署（推荐）

```bash
# 1. 克隆代码
cd /opt
sudo git clone https://github.com/your-username/drama-platform.git
sudo chown -R deploy:deploy drama-platform
cd drama-platform

# 2. 配置环境变量
cp .env.example .env
nano .env  # 填写生产环境配置

# 3. 启动服务
docker-compose up -d

# 4. 查看日志
docker-compose logs -f

# 5. 初始化数据库
docker-compose exec app node scripts/init-db.js --seed
```

#### 方式 B: 传统部署

```bash
# 1. 克隆代码
cd /opt
sudo git clone https://github.com/your-username/drama-platform.git
sudo chown -R deploy:deploy drama-platform
cd drama-platform

# 2. 安装依赖
npm ci --production

# 3. 配置环境变量
cp .env.example .env
nano .env

# 4. 初始化数据库
node scripts/init-db.js --seed

# 5. 启动应用（PM2）
pm2 start ecosystem.config.js --env production
pm2 save
```

---

### 步骤 4: 配置 Telegram Bot

```bash
# 1. 设置 Webhook
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://api.drama-platform.io/api/telegram/webhook",
    "allowed_updates": ["message", "callback_query", "pre_checkout_query"]
  }'

# 2. 验证 Webhook
curl "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getWebhookInfo"

# 3. 设置 Menu Button
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setChatMenuButton" \
  -H "Content-Type: application/json" \
  -d '{
    "menu_button": {
      "type": "web_app",
      "text": "打开短剧平台",
      "web_app": {
        "url": "https://drama-platform.io/telegram-app.html"
      }
    }
  }'
```

---

### 步骤 5: 启动监控

```bash
# 启动监控栈
docker-compose -f docker-compose.yml -f docker-compose.monitoring.yml up -d

# 访问监控界面
# Grafana: https://monitor.drama-platform.io:3001
# Prometheus: https://monitor.drama-platform.io:9090
```

---

## 上线后验证

### ✅ 功能测试清单

#### 1. 基础功能

- [ ] 访问主页: https://drama-platform.io
- [ ] API 健康检查: https://api.drama-platform.io/api/health
- [ ] HTTPS 正常工作
- [ ] HTTP 自动跳转到 HTTPS

#### 2. Telegram Mini App

- [ ] 打开 Telegram Bot
- [ ] 点击 Menu Button
- [ ] Mini App 正常加载
- [ ] 用户信息显示正确
- [ ] 短剧列表显示
- [ ] 分类筛选工作

#### 3. 视频播放

- [ ] 选择短剧
- [ ] 播放第1集（免费）
- [ ] 视频正常加载和播放
- [ ] 观看进度自动保存
- [ ] 续播功能工作

#### 4. 支付功能

- [ ] Telegram Stars 支付流程
  - [ ] 创建发票
  - [ ] 支付成功
  - [ ] 订单更新
  - [ ] 购买记录创建
  
- [ ] TON 支付流程
  - [ ] 生成支付链接
  - [ ] 钱包支付
  - [ ] 交易验证
  - [ ] 购买生效

- [ ] SUK Token 支付流程
  - [ ] 生成订单
  - [ ] 钱包转账
  - [ ] 交易验证
  - [ ] 购买生效

#### 5. 权限验证

- [ ] 未购买剧集无法播放
- [ ] 购买后可以正常播放
- [ ] 购买记录正确保存

#### 6. 评论功能

- [ ] 发表评论
- [ ] 评论显示
- [ ] 点赞/点踩
- [ ] 回复评论
- [ ] 删除自己的评论

---

### 📊 性能测试

```bash
# 使用 Apache Bench 测试
ab -n 1000 -c 10 https://api.drama-platform.io/api/health

# 预期结果:
# - 平均响应时间 < 100ms
# - 95% 请求 < 200ms
# - 无失败请求
```

---

### 🔍 监控检查

- [ ] Prometheus 正常抓取指标
- [ ] Grafana 仪表板显示数据
- [ ] 告警规则正常工作
- [ ] 健康检查端点响应正常

---

## 监控和运维

### 日常监控

#### 1. 查看日志

```bash
# 应用日志
pm2 logs drama-platform

# Nginx 日志
sudo tail -f /var/log/nginx/drama-platform-access.log
sudo tail -f /var/log/nginx/drama-platform-error.log

# 系统日志
sudo journalctl -u mongod -f
sudo journalctl -u redis -f
```

#### 2. 监控指标

访问 Grafana: https://monitor.drama-platform.io:3001

关注指标:
- [ ] CPU 使用率 < 80%
- [ ] 内存使用 < 80%
- [ ] 磁盘使用 < 80%
- [ ] API 响应时间 < 200ms
- [ ] 错误率 < 1%

#### 3. 数据库监控

```bash
# MongoDB 状态
mongosh -u admin -p
use short_drama_platform
db.stats()
db.serverStatus()

# Redis 状态
redis-cli -a YOUR_PASSWORD
INFO
DBSIZE
```

---

### 定期维护

#### 每天

- [ ] 查看监控仪表板
- [ ] 检查错误日志
- [ ] 检查备份是否成功

#### 每周

- [ ] 检查磁盘空间
- [ ] 清理旧日志
- [ ] 检查安全更新

```bash
# 清理日志
find /var/log -name "*.log" -mtime +7 -delete
pm2 flush
```

#### 每月

- [ ] 更新系统软件包
- [ ] 检查 SSL 证书有效期
- [ ] 测试备份恢复
- [ ] 安全审计

```bash
# 系统更新
sudo apt-get update
sudo apt-get upgrade

# 检查证书
sudo certbot certificates
```

---

## 应急预案

### 场景 1: 应用崩溃

```bash
# 1. 查看错误日志
pm2 logs drama-platform --lines 100 --err

# 2. 重启应用
pm2 restart drama-platform

# 3. 如果仍然失败，回滚到上一版本
cd /opt/drama-platform
git log --oneline -5
git checkout <previous_commit>
pm2 restart drama-platform
```

---

### 场景 2: 数据库故障

```bash
# 1. 检查 MongoDB 状态
sudo systemctl status mongod

# 2. 查看日志
sudo tail -100 /var/log/mongodb/mongod.log

# 3. 重启 MongoDB
sudo systemctl restart mongod

# 4. 如果数据损坏，从备份恢复
mongorestore --uri="mongodb://admin:password@localhost:27017" /var/backups/mongodb/latest/
```

---

### 场景 3: 高负载

```bash
# 1. 查看负载
htop
pm2 monit

# 2. 临时扩容
# - 增加 PM2 实例数
pm2 scale drama-platform 4

# 3. 长期方案
# - 升级服务器配置
# - 增加服务器节点（负载均衡）
```

---

### 场景 4: DDoS 攻击

```bash
# 1. 启用 CloudFlare 防护
# 访问 CloudFlare 控制台，开启 DDoS 防护

# 2. 限制请求频率（Nginx）
sudo nano /etc/nginx/sites-available/drama-platform
# 添加 rate limiting

# 3. 封禁恶意 IP
sudo ufw deny from <MALICIOUS_IP>
```

---

## 📞 上线支持

### 联系方式

- 📧 技术支持: support@drama-platform.io
- 🆘 紧急联系: +86-xxx-xxxx-xxxx
- 💬 Slack/Discord: #production-support

### 文档资源

- [API 文档](API.md)
- [测试文档](TESTING.md)
- [监控指南](MONITORING_GUIDE.md)
- [Docker 部署](DOCKER_DEPLOYMENT.md)

---

## ✅ 最终检查清单

在宣布正式上线前，确认：

### 基础设施
- [ ] 域名 DNS 解析正常
- [ ] SSL 证书已安装且有效
- [ ] 服务器防火墙配置正确
- [ ] MongoDB 数据库运行正常
- [ ] Redis 缓存运行正常

### 应用部署
- [ ] 代码已部署到生产环境
- [ ] 环境变量配置完整
- [ ] PM2/Docker 正常运行
- [ ] Nginx 反向代理配置正确
- [ ] 日志系统正常工作

### 第三方服务
- [ ] 阿里云 VoD 配置正确
- [ ] Telegram Bot 配置完成
- [ ] TON 区块链连接正常
- [ ] 以太坊 RPC 连接正常
- [ ] 支付功能测试通过

### 安全措施
- [ ] HTTPS 强制跳转
- [ ] 防火墙规则配置
- [ ] SSH 密钥登录
- [ ] 数据库访问限制
- [ ] 所有密码已修改

### 监控和备份
- [ ] Prometheus 监控运行
- [ ] Grafana 仪表板配置
- [ ] 告警规则生效
- [ ] 自动备份配置
- [ ] 健康检查端点正常

### 功能验证
- [ ] 所有核心功能测试通过
- [ ] 支付流程完整测试
- [ ] 视频播放正常
- [ ] 评论系统工作
- [ ] 性能测试达标

---

## 🚀 上线发布

当所有检查项都完成后：

```bash
# 1. 最后一次全面测试
npm run test:integration

# 2. 清理和优化
pm2 flush
docker system prune -f

# 3. 通知团队
# 发送上线通知邮件/消息

# 4. 宣布上线！🎉
echo "🎉 Drama Platform is now LIVE! 🚀"
```

---

**上线时间**: 2024-11-15  
**版本**: v1.2.0  
**状态**: ✅ 准备就绪

🎊 **祝上线顺利！** 🎊
