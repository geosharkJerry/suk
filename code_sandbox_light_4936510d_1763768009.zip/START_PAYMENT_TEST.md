# 🚀 开始支付流程测试
# Start Payment Flow Testing

> ⚡ 3分钟快速开始测试 Telegram Stars 支付

---

## 📋 测试前检查 (30秒)

确保以下服务正在运行:

```bash
# ✅ 检查 MongoDB
mongosh "mongodb://localhost:27017" --eval "db.version()"

# ✅ 检查后端服务
curl http://localhost:3000/api/health

# 如果后端未运行，启动它:
npm run dev
```

---

## 🎯 方法 1: 一键启动测试 (推荐)

**最简单的方式 - 自动化脚本**

```bash
# 运行快速启动脚本
bash scripts/run-payment-test.sh
```

脚本会自动:
- ✅ 检查所有前置条件
- ✅ 提供交互式选项
- ✅ 启动测试（网页或命令行）
- ✅ 显示验证命令

**选择界面**:
```
请选择测试方式:
  1) 可视化网页测试 (推荐)    ← 选这个！
  2) 命令行测试
  3) 两者都运行
```

---

## 🎨 方法 2: 可视化网页测试

**最直观的方式 - 图形界面**

### 步骤:

**1. 打开测试页面**
```bash
# 在浏览器中打开
open http://localhost:3000/payment-flow-test.html
```

**2. 配置参数** (可选，使用默认值即可)
- API URL: `http://localhost:3000`
- 测试用户 ID: `123456789`
- 测试剧集 ID: `drama_001`
- 测试剧集编号: `ep_002`

**3. 点击按钮**
```
🚀 开始完整测试
```

**4. 观看魔法发生** ✨
- 实时进度显示
- 绿色 ✅ = 通过
- 红色 ❌ = 失败
- 蓝色 ⏳ = 运行中

**5. 查看结果**
- 测试完成后自动显示总结
- 通过率、详细结果
- MongoDB 验证命令

---

## 💻 方法 3: 命令行测试

**最快速的方式 - 自动化**

```bash
# 直接运行
npm run test:payment

# 或指定参数
TELEGRAM_BOT_TOKEN="your_token" \
TEST_USER_ID="123456789" \
npm run test:payment
```

**输出示例**:
```
╔════════════════════════════════════════════════════════════╗
║          🧪 Telegram 支付流程完整测试                      ║
╚════════════════════════════════════════════════════════════╝

✅ [PASSED] 获取剧集详情（购买前）
✅ [PASSED] 尝试播放付费剧集（应该被拦截）
✅ [PASSED] 创建 Telegram Stars 发票
✅ [PASSED] 模拟支付成功回调
✅ [PASSED] 验证订单状态更新
✅ [PASSED] 验证购买记录创建
✅ [PASSED] 获取剧集详情（购买后）
✅ [PASSED] 尝试播放付费剧集（已购买）
✅ [PASSED] 测试免费剧集播放

总测试数: 9
✅ 通过: 9
❌ 失败: 0
📊 通过率: 100%

🎉 所有测试通过！支付流程正常工作！
```

---

## 📊 验证数据库 (可选)

测试完成后，验证 MongoDB 数据:

```bash
# 连接 MongoDB
mongosh "mongodb://localhost:27017/telegram-drama-dev"
```

**查询命令**:
```javascript
// 查看最新订单
db.orders.find({}).sort({ createdAt: -1 }).limit(5).pretty()

// 查看最新购买记录
db.purchases.find({}).sort({ purchasedAt: -1 }).limit(5).pretty()

// 查看特定用户的购买
db.purchases.find({ userId: "123456789" }).pretty()

// 统计测试数据
db.orders.countDocuments({ userId: "123456789" })
db.purchases.countDocuments({ userId: "123456789" })
```

**预期结果**:
- 订单状态: `completed` ✅
- 购买记录: 存在且 `isValid: true` ✅

---

## 🧹 清理测试数据 (可选)

测试完成后清理:

```javascript
// 在 MongoDB shell 中运行
db.orders.deleteMany({ 
    userId: "123456789", 
    dramaId: "drama_001" 
})

db.purchases.deleteMany({ 
    userId: "123456789", 
    dramaId: "drama_001" 
})

print("✅ 测试数据已清理")
```

---

## ❓ 遇到问题?

### 后端服务未运行
```bash
# 启动服务
npm run dev

# 等待服务启动 (约5秒)
# 验证
curl http://localhost:3000/api/health
```

### MongoDB 连接失败
```bash
# macOS
brew services start mongodb-community

# Linux
sudo systemctl start mongod

# Docker
docker run -d -p 27017:27017 mongo:6
```

### 测试失败
1. 查看详细日志
2. 检查 MongoDB 数据
3. 参考 PAYMENT_FLOW_TEST_GUIDE.md

### 脚本无法执行
```bash
# 添加执行权限
chmod +x scripts/run-payment-test.sh

# 使用 bash 运行
bash scripts/run-payment-test.sh
```

---

## 📚 更多信息

- 📖 **详细测试指南**: [PAYMENT_FLOW_TEST_GUIDE.md](PAYMENT_FLOW_TEST_GUIDE.md)
- 📖 **支付系统文档**: [PAYMENT_SYSTEM.md](PAYMENT_SYSTEM.md)
- 📖 **5分钟快速测试**: [PAYMENT_QUICK_START.md](PAYMENT_QUICK_START.md)
- 📖 **测试工具说明**: [PAYMENT_TEST_COMPLETE.md](PAYMENT_TEST_COMPLETE.md)

---

## ✅ 成功标准

测试通过意味着:

- ✅ 9个测试用例全部通过
- ✅ 通过率 ≥ 90%
- ✅ 订单正确创建和更新
- ✅ 购买记录正确存储
- ✅ 权限验证正常工作
- ✅ 无错误日志

---

## 🎉 就这么简单!

```bash
# 一行命令开始测试
bash scripts/run-payment-test.sh
```

**选择 "1) 可视化网页测试"，然后点击 "开始测试" 按钮！**

---

**⏱️ 预计耗时**: 1-2 分钟  
**🎯 成功率**: 预期 100%  
**💡 提示**: 第一次运行建议使用可视化测试

*最后更新: 2024-01-15*
