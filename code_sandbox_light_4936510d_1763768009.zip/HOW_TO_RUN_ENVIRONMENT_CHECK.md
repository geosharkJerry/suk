# 🚀 如何运行环境检查

## 三种方式，任选其一

---

## 方式 1: Node.js 自动检查脚本 ⭐ 推荐

### 优点
- ✅ 跨平台支持（Windows/macOS/Linux）
- ✅ 自动化检查 12 个关键项
- ✅ 彩色输出，易读
- ✅ 智能建议和错误提示

### 运行命令

```bash
npm run test:quick
```

### 预期输出

```
==================================================
  SUK 短剧平台 - Telegram Mini App 快速测试
==================================================

[1/12] 检查 Node.js...
✅ Node.js 已安装: v18.17.0
✅ Node.js 版本满足要求 (>= 18.0.0)

[2/12] 检查 npm...
✅ npm 已安装: v9.8.1

... (更多检查项)

==================================================
测试总结
==================================================
✅ 通过: 45
❌ 失败: 0
⚠️  警告: 0
==================================================

🎉 所有检查通过！
```

---

## 方式 2: Bash 脚本（仅 Unix 系统）

### 优点
- ✅ 原生 Shell 脚本
- ✅ 执行速度快
- ✅ 适合 CI/CD

### 运行命令

```bash
# 添加执行权限
chmod +x scripts/quick-test.sh

# 运行脚本
./scripts/quick-test.sh
```

---

## 方式 3: 可视化网页检查 🎨

### 优点
- ✅ 图形化界面
- ✅ 交互式检查清单
- ✅ 进度持久化保存
- ✅ 适合新手

### 使用方法

1. **在浏览器中打开**:
   ```bash
   # 如果服务器已启动
   open http://localhost:3000/environment-checklist.html
   
   # 或直接用浏览器打开文件
   open environment-checklist.html
   ```

2. **逐项检查**:
   - 点击每个检查项标记为完成
   - 运行提示的命令进行验证
   - 查看实时进度统计

3. **完成后**:
   - 自动显示下一步操作
   - 🎉 庆祝动画效果

---

## 🔍 检查项目详解

### 1️⃣ 基础环境（必需）

#### Node.js >= 18.0.0
```bash
node -v
# 预期: v18.17.0 或更高
```

**如果未安装**:
- macOS: `brew install node`
- Windows: https://nodejs.org/
- Linux: `curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -`

#### npm >= 9.0.0
```bash
npm -v
# 预期: 9.8.1 或更高
```

**如果版本过低**:
```bash
npm install -g npm@latest
```

---

### 2️⃣ 项目配置（必需）

#### 依赖安装
```bash
# 检查
ls node_modules/

# 安装
npm install
```

#### 环境配置
```bash
# 检查
ls .env

# 创建
cp .env.example .env

# 编辑
nano .env
```

**必需配置**:
- `TELEGRAM_BOT_TOKEN` - 从 @BotFather 获取
- `MONGODB_URI` - MongoDB 连接字符串
- `REDIS_HOST` - Redis 主机地址
- `ALIYUN_ACCESS_KEY_ID` - 阿里云密钥
- `JWT_SECRET` - JWT 签名密钥

---

### 3️⃣ 数据库服务（必需）

#### MongoDB
```bash
# 检查安装
mongod --version

# 检查运行状态
pgrep -x mongod

# 启动服务
# macOS
brew services start mongodb-community

# Linux
sudo systemctl start mongod

# 测试连接
mongosh --eval "db.adminCommand('ping')"
```

#### Redis
```bash
# 检查安装
redis-server --version

# 检查运行状态
pgrep -x redis-server

# 启动服务
# macOS
brew services start redis

# Linux
sudo systemctl start redis

# 测试连接
redis-cli ping
# 预期: PONG
```

---

### 4️⃣ 开发工具（推荐）

#### ngrok（用于 Telegram 测试）
```bash
# 检查安装
ngrok version

# 安装
# macOS
brew install ngrok/ngrok/ngrok

# 配置
ngrok config add-authtoken YOUR_TOKEN

# 使用
ngrok http 3000
```

#### Git
```bash
# 检查
git --version

# 初始化仓库
git init
```

---

## 📊 分步测试流程

### 第 1 步: 基础检查
```bash
# 运行快速测试
npm run test:quick
```

### 第 2 步: 详细测试
```bash
# 测试环境变量
npm run test:env

# 测试数据库连接
npm run test:db

# 测试 Telegram Bot（需要 Bot Token）
npm run test:telegram
```

### 第 3 步: 启动服务
```bash
# 开发模式
npm run dev

# 预期输出:
# ✅ MongoDB连接成功！
# ✅ Redis连接成功！
# 🚀 服务器运行在端口: 3000
```

### 第 4 步: 测试 API
```bash
# 新终端窗口
curl http://localhost:3000/health

# 预期响应:
# {
#   "status": "ok",
#   "mongodb": true,
#   "redis": true
# }
```

### 第 5 步: Telegram 测试准备
```bash
# 启动 ngrok
ngrok http 3000

# 记录 HTTPS URL
# 例如: https://abc123.ngrok.io
```

---

## ⚠️ 常见错误处理

### 错误 1: MongoDB 连接失败
```
❌ MongoDB连接失败: MongoServerError: Authentication failed
```

**解决方案**:
```bash
# 检查 MongoDB 状态
sudo systemctl status mongod

# 重启 MongoDB
sudo systemctl restart mongod

# 检查连接字符串
echo $MONGODB_URI
```

---

### 错误 2: Redis 连接失败
```
❌ Redis连接失败: Error: connect ECONNREFUSED 127.0.0.1:6379
```

**解决方案**:
```bash
# 检查 Redis 状态
redis-cli ping

# 启动 Redis
brew services start redis  # macOS
sudo systemctl start redis  # Linux
```

---

### 错误 3: 端口占用
```
⚠️  端口 3000 已被占用
```

**解决方案**:
```bash
# 查找占用进程
lsof -i :3000

# 停止进程
kill $(lsof -ti:3000)

# 或修改端口
echo "PORT=3001" >> .env
```

---

### 错误 4: npm 依赖问题
```
❌ 无法找到模块 'express'
```

**解决方案**:
```bash
# 清理并重新安装
rm -rf node_modules package-lock.json
npm install
```

---

## 🎯 完成检查后

### 所有检查通过 ✅

恭喜！您的环境配置完美，可以开始开发了。

**下一步**:
1. ✅ 启动服务器: `npm run dev`
2. ✅ 启动 ngrok: `ngrok http 3000`
3. ✅ 配置 Telegram Bot
4. ✅ 测试 Mini App

**参考文档**:
- 📖 `TELEGRAM_QUICK_START.md` - 3 步快速部署
- 📖 `TESTING_GUIDE.md` - 完整测试流程
- 📖 `TELEGRAM_MINI_APP_GUIDE.md` - 10 章深度教程

---

### 存在警告 ⚠️

环境基本可用，但建议解决警告项。

**常见警告**:
- ngrok 未安装（仅影响 Telegram 本地测试）
- Git 未安装（不影响开发）
- 某些配置项未填写（按需配置）

**可以继续开发，但某些功能可能受限**

---

### 存在错误 ❌

必须解决所有错误才能继续。

**检查清单**:
- [ ] Node.js >= 18.0.0
- [ ] npm >= 9.0.0
- [ ] 依赖已安装 (node_modules)
- [ ] .env 文件存在且配置正确
- [ ] MongoDB 已启动
- [ ] Redis 已启动

**逐项解决后重新运行**: `npm run test:quick`

---

## 📞 获取帮助

### 查看详细文档
```bash
# 测试指南
cat TESTING_GUIDE.md

# 环境检查说明
cat ENVIRONMENT_CHECK_RESULTS.md

# 快速命令
cat QUICK_COMMANDS.md
```

### 查看日志
```bash
# 服务器日志
npm run dev

# PM2 日志
pm2 logs drama-platform

# MongoDB 日志
sudo tail -f /var/log/mongodb/mongod.log

# Redis 日志
redis-cli MONITOR
```

### 运行专项测试
```bash
# 测试环境变量
npm run test:env

# 测试数据库
npm run test:db

# 测试 VoD 连接
npm run test:vod

# 测试 Telegram Bot
npm run test:telegram
```

---

## ✅ 总结

运行环境检查的三种方式：

| 方式 | 命令 | 适用场景 |
|------|------|----------|
| **Node.js 脚本** | `npm run test:quick` | 推荐，全平台 |
| **Bash 脚本** | `./scripts/quick-test.sh` | Unix 系统 |
| **可视化网页** | 浏览器打开 `environment-checklist.html` | 新手友好 |

**现在就开始**: 

```bash
npm run test:quick
```

---

**创建时间**: 2024-11-15  
**版本**: v1.1.0  
**项目**: SUK 短剧平台 Telegram Mini App
