# 🚀 短剧点播系统快速开始指南

## 👀 查看演示

### 1. 打开播放器演示页面
```bash
# 直接在浏览器打开
drama-player.html
```

### 2. 功能演示
- ✅ 竖屏短视频播放器
- ✅ 购买解锁功能（模拟）
- ✅ 剧集切换
- ✅ 收藏分享
- ✅ 搜索功能

---

## 📝 完整文档列表

### 核心文档

1. **📄 drama-player.html**
   - 完整的前端播放页面
   - 包含所有UI和交互逻辑
   - 可直接使用

2. **📖 DRAMA_PLAYBACK_BACKEND_API.md**
   - 后端API完整实现代码
   - 数据库设计
   - 区块链集成
   - 阿里云VoD集成

3. **📊 VIDEO_PLATFORM_COMPARISON.md**
   - 各平台详细对比
   - 成本分析
   - 方案推荐
   - 盈利模式设计

---

## 🎯 推荐实施路径

### 方案A：阿里云VoD（推荐）⭐

**优势**：
- ✅ 成熟稳定，风险低
- ✅ 开发周期短（2-3天可集成）
- ✅ 成本可控（按需付费）
- ✅ 防盗链和加密完善

**成本**：
- 存储：¥0.12/GB/月
- 转码：¥0.03-0.20/分钟（一次性）
- 流量：¥0.24/GB
- **单部100集短剧月成本**：约¥50-200

**开始步骤**：

```bash
# 1. 注册阿里云账号
https://www.aliyun.com

# 2. 开通视频点播服务
https://vod.console.aliyun.com

# 3. 获取AccessKey
https://usercenter.console.aliyun.com/#/manage/ak

# 4. 安装SDK
npm install @alicloud/vod-sdk-js @alicloud/pop-core

# 5. 集成到项目
# 参考 DRAMA_PLAYBACK_BACKEND_API.md
```

---

### 方案B：自建方案（高度定制）

**优势**：
- ✅ 完全控制
- ✅ 无平台限制
- ✅ 可定制加密方案

**成本**：
- 服务器：¥300/月
- 存储：¥100/月
- CDN：¥500/月
- 开发成本：2-3周
- **月成本**：¥900+

**不推荐原因**：
- ❌ 开发周期长
- ❌ 维护成本高
- ❌ 需要视频技术专家

---

## 🛠️ 技术实施清单

### Phase 1: 基础设置（Day 1-2）

**✅ 前端集成**
```html
<!-- 引入阿里云播放器 -->
<link rel="stylesheet" href="https://g.alicdn.com/de/prismplayer/2.15.2/skins/default/aliplayer-min.css" />
<script src="https://g.alicdn.com/de/prismplayer/2.15.2/aliplayer-min.js"></script>

<!-- 初始化播放器 -->
<script>
const player = new Aliplayer({
    id: 'player-container',
    vid: 'video-id',
    playauth: 'auth-token',
    width: '100%',
    height: '100%'
});
</script>
```

**✅ 后端设置**
```bash
# 安装依赖
npm install express mongoose redis ethers

# 配置环境变量
cp .env.example .env
# 填写阿里云密钥、数据库连接等
```

### Phase 2: 核心功能（Day 3-5）

**✅ SUK支付集成**
```javascript
// 前端调用MetaMask
const provider = new ethers.providers.Web3Provider(window.ethereum);
await provider.send("eth_requestAccounts", []);
const signer = provider.getSigner();

// 支付SUK代币
const tx = await sukContract.transfer(platformAddress, amount);
await tx.wait();

// 调用后端API记录购买
await fetch('/api/purchase/episode', {
    method: 'POST',
    body: JSON.stringify({
        episodeId,
        txHash: tx.hash,
        amount
    })
});
```

**✅ 播放凭证生成**
```javascript
// 后端生成凭证
const AliyunVoD = require('./aliyun-vod.service');

const playAuth = await AliyunVoD.generatePlayAuth(videoId, 1800);

// 返回给前端
res.json({
    playAuth,
    videoId,
    expiresIn: 1800
});
```

### Phase 3: 优化功能（Day 6-10）

**✅ 搜索功能**
```javascript
// Elasticsearch集成（可选）
const { Client } = require('@elastic/elasticsearch');
const client = new Client({ node: 'http://localhost:9200' });

// 或MongoDB文本索引
db.dramas.createIndex({ 
    title: "text", 
    description: "text" 
});

// 搜索
const results = await db.dramas.find({
    $text: { $search: keyword }
}).toArray();
```

**✅ 收藏功能**
```javascript
// 添加收藏
await db.favorites.insertOne({
    userId,
    dramaId,
    createdAt: new Date()
});

// 获取收藏列表
const favorites = await db.favorites
    .find({ userId })
    .populate('dramaId')
    .toArray();
```

**✅ 分享功能**
```javascript
// Web Share API（移动端）
if (navigator.share) {
    await navigator.share({
        title: '短剧标题',
        text: '快来观看！',
        url: shareUrl
    });
}

// 或复制链接
navigator.clipboard.writeText(shareUrl);
```

---

## 💼 数据库设计速览

### MongoDB Collections

**1. dramas（短剧表）**
```javascript
{
    _id: ObjectId,
    title: String,
    description: String,
    category: String,
    coverImage: String,
    sukPrice: Number,
    rating: Number,
    views: Number,
    episodes: [{
        episodeId: String,
        title: String,
        videoId: String, // 阿里云视频ID
        duration: Number,
        sukPrice: Number,
        isFree: Boolean
    }],
    createdAt: Date
}
```

**2. purchases（购买记录）**
```javascript
{
    _id: ObjectId,
    userId: String, // 用户钱包地址
    dramaId: ObjectId,
    episodeId: String,
    sukAmount: Number,
    txHash: String, // 区块链交易哈希
    status: String, // 'completed' | 'pending' | 'failed'
    timestamp: Date
}
```

**3. watch_history（观看历史）**
```javascript
{
    _id: ObjectId,
    userId: String,
    dramaId: ObjectId,
    episodeId: String,
    watchProgress: Number, // 观看进度（秒）
    totalDuration: Number,
    lastWatchedAt: Date
}
```

**4. favorites（收藏）**
```javascript
{
    _id: ObjectId,
    userId: String,
    dramaId: ObjectId,
    createdAt: Date
}
```

---

## 🔐 环境变量配置

**.env示例**
```bash
# 服务器
PORT=3000
NODE_ENV=production

# 数据库
MONGODB_URI=mongodb://localhost:27017/suk_drama
REDIS_URL=redis://localhost:6379

# 阿里云VoD
ALIYUN_ACCESS_KEY_ID=your_key_id
ALIYUN_ACCESS_KEY_SECRET=your_key_secret
ALIYUN_VOD_REGION=cn-shanghai

# 区块链
ETHEREUM_RPC_URL=https://mainnet.infura.io/v3/YOUR-PROJECT-ID
SUK_TOKEN_ADDRESS=0x...
PLATFORM_ADDRESS=0x... # SUK收款地址

# JWT
JWT_SECRET=your_random_secret
JWT_EXPIRES_IN=7d

# CORS
ALLOWED_ORIGINS=https://suk-protocol.com
```

---

## 📊 成本预估工具

### 计算器

```javascript
function calculateMonthlyCost(params) {
    const {
        totalEpisodes = 100,    // 剧集数
        episodeDuration = 2,    // 每集时长（分钟）
        monthlyViews = 100000,  // 月播放量
        storageGB = 10          // 存储量（GB）
    } = params;
    
    // 存储费用
    const storageCost = storageGB * 0.12; // ¥/月
    
    // 转码费用（一次性，分摊到12个月）
    const transcodeCost = (totalEpisodes * episodeDuration * 0.05) / 12;
    
    // 流量费用
    const avgSizePerView = 0.1; // GB
    const trafficCost = monthlyViews * avgSizePerView * 0.24;
    
    const total = storageCost + transcodeCost + trafficCost;
    
    return {
        storage: storageCost.toFixed(2),
        transcode: transcodeCost.toFixed(2),
        traffic: trafficCost.toFixed(2),
        total: total.toFixed(2),
        currency: 'CNY'
    };
}

// 示例
const cost = calculateMonthlyCost({
    totalEpisodes: 100,
    episodeDuration: 2,
    monthlyViews: 100000,
    storageGB: 10
});

console.log('月度成本:', cost);
// 输出: { storage: '1.20', transcode: '0.83', traffic: '240.00', total: '242.03', currency: 'CNY' }
```

---

## 🧪 测试步骤

### 1. 本地测试

```bash
# 启动MongoDB
mongod

# 启动Redis
redis-server

# 启动后端
npm run dev

# 打开前端
open drama-player.html
```

### 2. 功能测试清单

- [ ] 视频能否正常播放
- [ ] 购买流程是否顺畅
- [ ] 搜索功能是否准确
- [ ] 收藏功能是否正常
- [ ] 分享链接是否有效
- [ ] 移动端播放是否正常
- [ ] 竖屏显示是否正确
- [ ] 加载速度是否满意

### 3. 性能测试

```bash
# 使用 Apache Bench
ab -n 1000 -c 100 http://localhost:3000/api/drama/list

# 使用 Artillery
artillery quick --count 100 --num 1000 http://localhost:3000/api/drama/list
```

---

## 🚨 常见问题

### Q1: 视频无法播放？

**检查清单：**
1. 播放凭证是否过期？
2. 视频ID是否正确？
3. 阿里云密钥是否配置？
4. 用户是否已购买？

### Q2: 支付失败？

**可能原因：**
1. MetaMask未连接
2. SUK余额不足
3. Gas费不足
4. 网络拥堵

### Q3: 成本过高？

**优化建议：**
1. 购买流量包（30-50%折扣）
2. 使用CDN缓存
3. 降低视频码率
4. 启用智能压缩

---

## 📚 学习资源

### 官方文档
- [阿里云VoD文档](https://help.aliyun.com/product/29932.html)
- [Ethers.js文档](https://docs.ethers.io/)
- [MongoDB文档](https://docs.mongodb.com/)

### 视频教程
- [阿里云VoD快速入门](https://help.aliyun.com/document_detail/51235.html)
- [Web3支付集成教程](https://docs.ethers.io/v5/getting-started/)

### 社区支持
- 阿里云开发者社区
- Ethereum开发者论坛
- Stack Overflow

---

## 🎉 开始开发！

现在你已经准备好开始开发短剧点播系统了！

**推荐步骤：**
1. ✅ 阅读 [VIDEO_PLATFORM_COMPARISON.md](VIDEO_PLATFORM_COMPARISON.md)
2. ✅ 注册阿里云账号并开通VoD服务
3. ✅ 参考 [DRAMA_PLAYBACK_BACKEND_API.md](DRAMA_PLAYBACK_BACKEND_API.md) 搭建后端
4. ✅ 使用 [drama-player.html](drama-player.html) 作为前端基础
5. ✅ 测试完整购买-播放流程

**需要帮助？**
- 查看详细实施文档
- 参考代码示例
- 搜索相关技术文档

**祝开发顺利！** 🚀✨
