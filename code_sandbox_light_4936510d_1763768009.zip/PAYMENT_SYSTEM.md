# Telegram Stars 支付系统文档
# Telegram Stars Payment System Documentation

## 目录 / Table of Contents

1. [系统概述 / System Overview](#系统概述--system-overview)
2. [支付方式 / Payment Methods](#支付方式--payment-methods)
3. [数据库模型 / Database Models](#数据库模型--database-models)
4. [支付流程 / Payment Flow](#支付流程--payment-flow)
5. [API 接口 / API Endpoints](#api-接口--api-endpoints)
6. [Webhook 集成 / Webhook Integration](#webhook-集成--webhook-integration)
7. [测试指南 / Testing Guide](#测试指南--testing-guide)
8. [待完成功能 / Pending Features](#待完成功能--pending-features)

---

## 系统概述 / System Overview

本系统实现了完整的 Telegram Mini App 支付功能，支持三种支付方式：

- **Telegram Stars (XTR)** - Telegram 原生支付货币
- **TON Coin** - Telegram 区块链原生代币
- **SUK Token** - ERC-20 智能合约代币

### 核心特性 / Core Features

✅ **已实现 / Implemented:**
- Telegram Stars 发票创建和支付验证
- TON Coin 支付链接生成
- SUK Token 订单创建
- 订单自动过期（30分钟 TTL）
- 购买记录去重
- 权限验证（播放授权）
- Webhook 异步支付确认
- 退款处理（软删除）

⏳ **待实现 / Pending:**
- TON 区块链交易监控
- SUK Token 智能合约验证（需要 ethers.js）
- 阿里云 VoD 真实播放授权

---

## 支付方式 / Payment Methods

### 1. Telegram Stars (⭐ 推荐)

**特点:**
- Telegram 官方支付系统
- 无需外部钱包
- 支持 Telegram 内直接支付
- 通过 Bot API `sendInvoice` 方法创建发票

**支付流程:**
1. 后端调用 `createStarsInvoice()` 创建发票
2. Telegram Bot 发送发票消息到用户聊天
3. 用户点击支付按钮
4. Telegram 显示 `pre_checkout_query`（10秒内必须响应）
5. 支付成功后 Telegram 发送 `successful_payment` webhook
6. 后端验证并创建购买记录

**货币代码:** `XTR`  
**价格示例:** 100 Stars = ¥7 (约)

### 2. TON Coin

**特点:**
- Telegram 区块链（The Open Network）
- 使用 TON 钱包支付
- 深链接格式：`ton://transfer/{address}?amount={nanotons}&text={comment}`
- 1 TON = 1,000,000,000 nanotons

**支付流程:**
1. 后端生成 TON 支付链接
2. 前端打开 TON 钱包应用
3. 用户确认交易
4. 后端监控区块链交易（待实现）
5. 确认后创建购买记录

**货币代码:** `TON`  
**价格示例:** 3 TON = ¥50 (约)

### 3. SUK Token

**特点:**
- ERC-20 智能合约代币
- 支持 Ethereum/Polygon 等网络
- 需要 MetaMask 或 WalletConnect
- 通过智能合约交互转账

**支付流程:**
1. 后端创建订单并返回合约地址
2. 前端调用钱包进行转账
3. 用户确认交易
4. 前端提交 transaction hash
5. 后端验证区块链交易（待实现）
6. 确认后创建购买记录

**货币代码:** `SUK`  
**价格示例:** 50 SUK = ¥50 (约)

---

## 数据库模型 / Database Models

### Order Model (`backend/models/Order.js`)

订单模型，存储所有支付订单信息。

```javascript
{
    orderId: String,           // 唯一订单号 (ORDER_xxx_xxx)
    userId: String,            // Telegram 用户 ID
    dramaId: String,           // 剧集 ID
    purchaseType: String,      // 'single' | 'full'
    episodeId: String,         // 剧集 ID（单集购买时）
    paymentMethod: String,     // 'stars' | 'ton' | 'suk'
    amount: Number,            // 支付金额
    currency: String,          // 'XTR' | 'TON' | 'SUK'
    status: String,            // 'pending' | 'completed' | 'failed' | 'cancelled' | 'refunded'
    paymentId: String,         // Telegram payment charge ID
    txHash: String,            // 区块链交易哈希
    expiresAt: Date,           // 过期时间（默认30分钟）
    createdAt: Date,           // 创建时间
    completedAt: Date          // 完成时间
}
```

**重要索引:**
- `orderId` - 唯一索引
- `userId`, `dramaId` - 查询索引
- `expiresAt` - TTL 索引（自动清理过期订单）

**实例方法:**
- `markCompleted(paymentInfo)` - 标记订单完成
- `markFailed(reason)` - 标记订单失败
- `markCancelled()` - 取消订单

### Purchase Model (`backend/models/Purchase.js`)

购买记录模型，用户购买权限的永久记录。

```javascript
{
    userId: String,            // Telegram 用户 ID
    dramaId: String,           // 剧集 ID
    purchaseType: String,      // 'single' | 'full'
    episodeId: String,         // 剧集 ID（单集购买时）
    orderId: String,           // 关联订单号
    paymentMethod: String,     // 支付方式
    amount: Number,            // 支付金额
    currency: String,          // 货币类型
    isValid: Boolean,          // 是否有效（退款时设为 false）
    purchasedAt: Date          // 购买时间
}
```

**重要索引:**
- 联合唯一索引：`{userId, dramaId, purchaseType, episodeId}` + `isValid: true`
  - 防止重复购买
  - 支持软删除（退款）

**静态方法:**
- `checkPurchase(userId, dramaId, episodeId)` - 检查购买状态
  - 返回：`{ purchased: true/false, type: 'full'/'single'/null, purchase: Object }`

---

## 支付流程 / Payment Flow

### Telegram Stars 完整流程

```
┌─────────────┐         ┌──────────────┐         ┌─────────────┐
│   用户前端   │         │   后端服务器  │         │  Telegram   │
└──────┬──────┘         └───────┬──────┘         └──────┬──────┘
       │                        │                       │
       │  1. POST /invoice      │                       │
       │   {paymentMethod:      │                       │
       │    'stars'}            │                       │
       ├───────────────────────>│                       │
       │                        │                       │
       │                        │  2. sendInvoice API   │
       │                        ├──────────────────────>│
       │                        │                       │
       │                        │  3. Invoice sent      │
       │                        │<──────────────────────┤
       │                        │                       │
       │  4. {orderId, success} │                       │
       │<───────────────────────┤                       │
       │                        │                       │
       │                        │  5. User pays in chat │
       │                        │                       │
       │                        │  6. pre_checkout_query│
       │                        │<──────────────────────┤
       │                        │                       │
       │                        │  7. answerPreCheckout │
       │                        │   (< 10 seconds!)     │
       │                        ├──────────────────────>│
       │                        │                       │
       │                        │  8. successful_payment│
       │                        │<──────────────────────┤
       │                        │                       │
       │                        │  9. Update order +    │
       │                        │     Create purchase   │
       │                        │                       │
       │                        │ 10. Send success msg  │
       │                        ├──────────────────────>│
       │                        │                       │
       │ 11. Refresh page to    │                       │
       │     see purchased      │                       │
       │     content            │                       │
       │                        │                       │
```

### 权限验证流程

```javascript
// 前端播放器请求播放授权
GET /api/telegram/play-auth/ep_001?dramaId=drama_001

// 后端验证逻辑
1. 检查是否为免费剧集（第1集）
   - 是：直接返回播放授权
   - 否：继续检查

2. 调用 TelegramPaymentService.checkPurchaseStatus(userId, dramaId, episodeId)
   - 检查全集购买记录
   - 检查单集购买记录

3. 如果已购买：
   - 生成播放授权（PlayAuth）
   - 查询观看历史
   - 返回成功响应

4. 如果未购买：
   - 返回 403 Forbidden
   - requiresPurchase: true
```

---

## API 接口 / API Endpoints

### 1. 创建支付发票

**请求:**
```http
POST /api/telegram/invoice
Content-Type: application/json
X-Telegram-Init-Data: <Telegram WebApp initData>

{
    "dramaId": "drama_001",
    "paymentMethod": "stars",      // 'stars' | 'ton' | 'suk'
    "purchaseType": "full",        // 'single' | 'full'
    "episodeId": "ep_001"          // 仅单集购买时需要
}
```

**响应 (Telegram Stars):**
```json
{
    "success": true,
    "orderId": "ORDER_L3X2H8K_A7F9D2",
    "paymentMethod": "stars",
    "message": "发票已发送到您的 Telegram 聊天"
}
```

**响应 (TON):**
```json
{
    "success": true,
    "orderId": "ORDER_L3X2H8K_B9G4E6",
    "paymentMethod": "ton",
    "invoiceLink": "ton://transfer/UQ...?amount=3000000000&text=Order%3A...",
    "message": "请使用 TON 钱包完成支付"
}
```

**响应 (SUK Token):**
```json
{
    "success": true,
    "orderId": "ORDER_L3X2H8K_C2H7F1",
    "paymentMethod": "suk",
    "contractAddress": "0x1234...5678",
    "amount": 50,
    "message": "请使用钱包完成 SUK Token 支付"
}
```

### 2. 验证支付（仅 SUK Token）

**请求:**
```http
POST /api/telegram/verify-payment
Content-Type: application/json
X-Telegram-Init-Data: <Telegram WebApp initData>

{
    "orderId": "ORDER_L3X2H8K_C2H7F1",
    "paymentMethod": "suk",
    "transactionHash": "0xabcd...ef12"
}
```

**响应:**
```json
{
    "success": true,
    "message": "支付验证成功",
    "orderId": "ORDER_L3X2H8K_C2H7F1",
    "verified": true
}
```

**注意:** Stars 和 TON 通过 webhook 自动验证，不需要手动调用此接口。

### 3. 获取剧集详情（含购买状态）

**请求:**
```http
GET /api/telegram/dramas/drama_001
X-Telegram-Init-Data: <Telegram WebApp initData>
```

**响应:**
```json
{
    "success": true,
    "data": {
        "id": "drama_001",
        "title": "霸道总裁爱上我",
        "hasPurchased": true,    // ✅ 真实购买状态
        "episodes": [...],
        // ... 其他剧集信息
    }
}
```

### 4. 获取播放授权（含权限验证）

**请求:**
```http
GET /api/telegram/play-auth/ep_002?dramaId=drama_001
X-Telegram-Init-Data: <Telegram WebApp initData>
```

**响应（已购买）:**
```json
{
    "success": true,
    "playAuth": "eyJ...",
    "videoId": "abc123",
    "expiresIn": 1800,
    "watchHistory": {
        "watchProgress": 120,
        "totalDuration": 180,
        "updatedAt": "2024-01-15T10:30:00Z"
    },
    "episodeInfo": {
        "dramaId": "drama_001",
        "episodeId": "ep_002",
        "episodeNumber": 2,
        "isFree": false
    }
}
```

**响应（未购买）:**
```json
{
    "success": false,
    "message": "您尚未购买此剧集",
    "requiresPurchase": true,
    "dramaId": "drama_001",
    "episodeId": "ep_002"
}
```

---

## Webhook 集成 / Webhook Integration

### 设置 Webhook URL

使用 Telegram Bot API 设置 webhook URL：

```bash
# 开发环境（使用 ngrok）
ngrok http 3000
# 获得 URL: https://abc123.ngrok.io

# 设置 webhook
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://abc123.ngrok.io/api/telegram/webhook",
    "allowed_updates": ["message", "pre_checkout_query"]
  }'
```

### Webhook 处理器

位置：`backend/controllers/telegram-webhook.controller.js`

**处理的事件类型:**

1. **pre_checkout_query** - 支付前验证
   - **必须在 10 秒内响应**，否则支付失败
   - 验证订单有效性
   - 调用 `answerPreCheckoutQuery`

2. **successful_payment** - 支付成功
   - 验证支付金额
   - 更新订单状态
   - 创建购买记录
   - 发送成功消息给用户

3. **message.text** - Bot 命令
   - `/start` - 欢迎消息
   - `/help` - 帮助信息
   - `/wallet` - 钱包信息

### Webhook 响应示例

```javascript
// Telegram 发送的 webhook 数据
{
    "update_id": 123456789,
    "message": {
        "message_id": 1234,
        "from": {
            "id": 987654321,
            "first_name": "John"
        },
        "chat": {
            "id": 987654321,
            "type": "private"
        },
        "date": 1642345678,
        "successful_payment": {
            "currency": "XTR",
            "total_amount": 100,
            "invoice_payload": "{\"orderId\":\"ORDER_...\",\"dramaId\":\"drama_001\"}",
            "telegram_payment_charge_id": "tch_...",
            "provider_payment_charge_id": "..."
        }
    }
}
```

---

## 测试指南 / Testing Guide

### 环境准备

1. **启动 MongoDB**
```bash
mongod --dbpath=/path/to/data
```

2. **启动 Redis**
```bash
redis-server
```

3. **配置环境变量** (`.env`)
```env
# MongoDB
MONGODB_URI=mongodb://localhost:27017/telegram-drama-dev

# Telegram Bot
TELEGRAM_BOT_TOKEN=your_bot_token_here

# Telegram Mini App
WEB_APP_URL=https://your-ngrok-url.ngrok.io

# TON Wallet (可选)
TON_WALLET_ADDRESS=UQxxxxx...

# SUK Token Contract (可选)
SUK_TOKEN_CONTRACT=0x1234...5678
```

4. **启动后端服务**
```bash
cd backend
npm install
npm run dev
```

5. **启动 ngrok**
```bash
ngrok http 3000
```

6. **设置 Telegram Webhook**
```bash
# 使用 ngrok URL
curl -X POST "https://api.telegram.org/bot<TOKEN>/setWebhook" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://abc123.ngrok.io/api/telegram/webhook"}'
```

### 测试 Telegram Stars 支付

1. **在前端创建发票**
   - 打开 `telegram-drama-detail.html`
   - 点击"购买全集"按钮
   - 选择 "Telegram Stars" 支付方式

2. **检查 Telegram Bot 消息**
   - 打开与 Bot 的聊天
   - 应该收到发票消息
   - 点击 "Pay ⭐100 Stars" 按钮

3. **完成支付**
   - Telegram 显示支付确认界面
   - 点击确认支付

4. **验证结果**
   - 检查 Bot 是否发送成功消息
   - 刷新剧集详情页
   - 确认 "已购买" 标记显示

5. **检查数据库**
```javascript
// MongoDB shell
use telegram-drama-dev

// 查看订单
db.orders.find({}).pretty()

// 查看购买记录
db.purchases.find({}).pretty()
```

### 测试权限验证

1. **访问未购买的剧集**
   - 打开播放器页面
   - 尝试播放第2集（付费集）
   - 应该显示 "需要购买" 提示

2. **购买后再次访问**
   - 完成支付流程
   - 刷新播放器页面
   - 应该能正常播放

### 调试技巧

**查看 Webhook 日志:**
```bash
# 后端控制台会显示所有 webhook 请求
# 查找类似以下的日志:
# "收到 Telegram webhook:"
# "处理支付成功回调:"
```

**查看 Telegram 响应:**
```bash
# 查看 Bot API 响应
curl "https://api.telegram.org/bot<TOKEN>/getWebhookInfo"
```

**测试 pre_checkout_query 响应时间:**
```javascript
// 在 telegram-webhook.controller.js 中添加时间戳
const startTime = Date.now();
await this.answerPreCheckoutQuery(query.id, { ok: true });
console.log(`Pre-checkout 响应时间: ${Date.now() - startTime}ms`);
// 必须 < 10000ms
```

---

## 待完成功能 / Pending Features

### 1. TON 交易监控 (高优先级)

**当前状态:** 生成支付链接，但无法验证交易

**实现方案:**
```javascript
// backend/services/ton-monitor.service.js
const TonWeb = require('tonweb');

class TonMonitorService {
    async monitorTransaction(orderId, expectedAmount, comment) {
        const tonweb = new TonWeb();
        const wallet = process.env.TON_WALLET_ADDRESS;
        
        // 轮询查询最新交易
        const interval = setInterval(async () => {
            const transactions = await tonweb.getTransactions(wallet, 10);
            
            for (const tx of transactions) {
                if (tx.in_msg.message === comment && 
                    tx.in_msg.value === expectedAmount) {
                    // 找到匹配交易
                    await this.confirmPayment(orderId, tx.hash);
                    clearInterval(interval);
                }
            }
        }, 5000); // 每5秒检查一次
        
        // 30分钟后超时
        setTimeout(() => clearInterval(interval), 30 * 60 * 1000);
    }
}
```

**需要的包:**
- `tonweb` 或 `@ton/ton`

### 2. SUK Token 智能合约验证 (高优先级)

**当前状态:** 创建订单，但不验证区块链交易

**实现方案:**
```javascript
// backend/services/blockchain.service.js
const { ethers } = require('ethers');

class BlockchainService {
    async verifySukPayment(txHash, expectedAmount, recipientAddress) {
        const provider = new ethers.providers.JsonRpcProvider(
            process.env.ETHEREUM_RPC_URL
        );
        
        // 获取交易详情
        const tx = await provider.getTransaction(txHash);
        
        if (!tx) {
            throw new Error('交易不存在');
        }
        
        // 等待确认
        const receipt = await tx.wait(3); // 等待3个区块确认
        
        if (receipt.status !== 1) {
            throw new Error('交易失败');
        }
        
        // 验证 ERC-20 Transfer 事件
        const sukContract = new ethers.Contract(
            process.env.SUK_TOKEN_CONTRACT,
            ['event Transfer(address indexed from, address indexed to, uint256 value)'],
            provider
        );
        
        const transferEvent = receipt.logs
            .map(log => {
                try {
                    return sukContract.interface.parseLog(log);
                } catch {
                    return null;
                }
            })
            .find(event => event?.name === 'Transfer');
        
        if (!transferEvent) {
            throw new Error('未找到 Transfer 事件');
        }
        
        // 验证金额和接收地址
        const amount = ethers.utils.formatUnits(transferEvent.args.value, 18);
        const to = transferEvent.args.to;
        
        if (to.toLowerCase() !== recipientAddress.toLowerCase()) {
            throw new Error('接收地址不匹配');
        }
        
        if (parseFloat(amount) < expectedAmount) {
            throw new Error('金额不足');
        }
        
        return {
            verified: true,
            txHash: txHash,
            amount: amount,
            from: transferEvent.args.from,
            to: to,
            blockNumber: receipt.blockNumber
        };
    }
}
```

**需要的包:**
- `ethers` v5 或 v6

**环境变量:**
```env
ETHEREUM_RPC_URL=https://mainnet.infura.io/v3/YOUR_KEY
SUK_TOKEN_CONTRACT=0x...
SUK_RECIPIENT_ADDRESS=0x...
```

### 3. 阿里云 VoD 集成 (中优先级)

**当前状态:** 返回 mock 数据

**实现方案:**
参考 `backend/services/aliyun-vod.service.js` 中的现有方法，需要：

1. 配置阿里云 AccessKey
2. 实现视频ID映射（Episode → VideoId）
3. 调用 `generatePlayAuth()` 生成真实授权

### 4. 订单查询和历史记录

**新增 API:**
```javascript
// 查询订单状态
GET /api/telegram/orders/:orderId

// 获取用户订单历史
GET /api/telegram/orders?page=1&limit=20

// 获取购买历史
GET /api/telegram/purchases?page=1&limit=20
```

### 5. 退款功能完善

**当前实现:** 基本框架已完成

**需要补充:**
- Telegram Stars 退款 API 调用
- TON 链上退款交易
- SUK Token 合约退款

### 6. 价格管理系统

**当前状态:** 硬编码在控制器中

**改进方案:**
- 创建 `Price` 模型
- 支持动态价格配置
- 支持折扣和促销

---

## 常见问题 / FAQ

### Q1: Pre-checkout query 超时怎么办？

**A:** 必须在 10 秒内响应 `answerPreCheckoutQuery`，确保：
- 数据库查询优化（添加索引）
- 避免同步耗时操作
- 使用 Redis 缓存订单信息

### Q2: 如何测试支付而不花真钱？

**A:** Telegram Stars 支持测试环境：
1. 使用 Test Bot Token（以 `bot` 开头）
2. 在 BotFather 中启用测试支付
3. 测试环境的 Stars 是虚拟的

### Q3: Webhook 收不到回调？

**A:** 检查：
1. ngrok 是否正常运行
2. webhook URL 是否正确设置
3. 服务器防火墙是否开放
4. 使用 `getWebhookInfo` 查看错误

```bash
curl "https://api.telegram.org/bot<TOKEN>/getWebhookInfo"
```

### Q4: 如何处理重复支付？

**A:** 已实现防重复机制：
- Purchase 模型有联合唯一索引
- 订单验证时检查状态
- 创建购买记录时检查是否已存在

### Q5: 订单30分钟后自动清理吗？

**A:** 是的，通过 MongoDB TTL 索引实现：
- 仅清理 `status: 'pending'` 的订单
- 已完成的订单永久保留
- 清理操作由 MongoDB 自动执行

---

## 相关文件清单 / Related Files

### 核心服务 / Core Services
- `backend/services/telegram-payment.service.js` - 支付服务（16KB）
- `backend/services/aliyun-vod.service.js` - 阿里云VoD服务
- `backend/services/watch-history.service.js` - 观看历史服务

### 控制器 / Controllers
- `backend/controllers/telegram.controller.js` - 主控制器
- `backend/controllers/telegram-webhook.controller.js` - Webhook处理器（10KB）

### 数据模型 / Models
- `backend/models/Order.js` - 订单模型（4.6KB）
- `backend/models/Purchase.js` - 购买记录模型（5.3KB）
- `backend/models/WatchHistory.js` - 观看历史模型

### 路由 / Routes
- `backend/routes/telegram.routes.js` - API路由定义

### 前端页面 / Frontend Pages
- `telegram-app.html` - 剧集列表页（22KB）
- `telegram-drama-detail.html` - 剧集详情页（37KB）
- `telegram-player.html` - 视频播放器（34KB）

---

## 版本历史 / Version History

### v1.0.0 (2024-01-15)
- ✅ Telegram Stars 支付完整实现
- ✅ 数据库模型集成
- ✅ Webhook 处理
- ✅ 权限验证
- ✅ 购买状态检查
- ⏳ TON/SUK 待完善

---

## 联系和支持 / Contact & Support

如有问题或建议，请联系开发团队。

**文档维护:** 2024-01-15  
**最后更新:** 本次实现完成 Order/Purchase 模型集成和权限验证
