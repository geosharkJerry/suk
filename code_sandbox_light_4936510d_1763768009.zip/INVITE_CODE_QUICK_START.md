# SUK 邀请码系统 - 5分钟快速开始

> 🚀 最快速度上手邀请码系统

---

## 📋 系统组成

### 3个核心页面

1. **admin-invite-system.html** - 官方邀请码管理后台（管理员使用）
2. **invite-activation-flow.html** - 用户激活页面（用户使用）
3. **user-dashboard-enhanced.html** - 用户控制面板（用户使用）

### 3个数据表

1. **users** - 用户信息
2. **invite_codes** - 邀请码管理
3. **airdrop_records** - 空投记录

---

## 🎯 管理员快速开始（3分钟）

### 步骤1: 访问管理后台

```
https://your-domain.com/admin-invite-system.html
```

### 步骤2: 生成邀请码

填写表单：
- **邀请码数量**: 10
- **空投金额**: 5000 SUK
- **有效期**: 30 天
- **备注**: 社群活动奖励

点击 **"🎫 生成邀请码"**

### 步骤3: 分发邀请码

生成后，在列表中找到邀请码：

```
ABCD1234WXYZ
EFGH5678STUV
IJKL9012MNOP
...
```

点击 **"📋 复制邀请码"** 按钮，然后：
- 发送到 Telegram 群组
- 发布到 Twitter
- 分享到 Discord
- 或其他渠道

完成！✅

---

## 👤 用户快速开始（3分钟）

### 方式1: 邀请码激活

#### 步骤1: 获取邀请码

从官方渠道获得12位邀请码：
```
ABCD1234WXYZ
```

#### 步骤2: 访问激活页面

```
https://your-domain.com/invite-activation-flow.html
```

#### 步骤3: 连接钱包

点击 **"🦊 连接 MetaMask 钱包"**

#### 步骤4: 输入邀请码

输入：`ABCD1234WXYZ`

点击 **"🎫 激活邀请码"**

#### 步骤5: 领取空投

激活成功后，点击 **"💰 立即领取 5,000 SUK"**

完成！✅

### 方式2: 推荐购买

#### 步骤1: 获取推荐链接

已激活用户访问控制面板：
```
https://your-domain.com/user-dashboard-enhanced.html
```

点击 **"📋 复制推荐链接"**

#### 步骤2: 分享链接

将推荐链接分享给好友：
```
https://your-domain.com/invite-activation-flow.html?ref=0x1a2b...
```

#### 步骤3: 好友完成购买

好友通过链接进入 → 完成购买

#### 步骤4: 双方领取奖励

返回控制面板 → 点击 **"💰 领取 1,000 SUK"**

完成！✅

---

## 🔗 页面访问地址

### 管理员页面

```
官方邀请码管理: https://your-domain.com/admin-invite-system.html
```

### 用户页面

```
激活页面: https://your-domain.com/invite-activation-flow.html
控制面板: https://your-domain.com/user-dashboard-enhanced.html
```

### 推荐链接格式

```
https://your-domain.com/invite-activation-flow.html?ref=钱包地址
```

---

## 💡 常见问题（1分钟解答）

### Q1: 邀请码在哪里获得？
A: 官方活动、社群奖励、合作伙伴分发

### Q2: 激活需要费用吗？
A: 只需少量 Gas 费（约0.002 ETH），空投免费

### Q3: 可以重复领取吗？
A: 不可以，每个钱包只能领取一次

### Q4: 推荐奖励是多少？
A: 推荐人和被推荐人各得 1,000 SUK

### Q5: 邀请码多久过期？
A: 生成时设置，默认30天

---

## 📊 奖励对比

| 方式 | 奖励金额 | 需要购买 | 难度 |
|------|---------|---------|------|
| 邀请码激活 | 5,000 SUK | ❌ | ⭐⭐ |
| 推荐购买 | 1,000 SUK | ✅ | ⭐ |

---

## 🎁 示例邀请码

系统已预置3个测试邀请码：

```
WELCOME2024A  - 新用户欢迎空投（可用）
COMMUNITY001  - 社群活跃用户（可用）
PARTNER12345  - 合作伙伴专属（已使用）
```

---

## 📚 详细文档

需要了解更多？查看完整文档：

- 📖 [完整系统指南](INVITE_CODE_SYSTEM_GUIDE.md) - 13KB 详细说明
- 📊 [实施总结](INVITE_CODE_IMPLEMENTATION_SUMMARY.md) - 10KB 项目总结
- 📘 [主项目文档](README.md) - 完整功能说明

---

## 🚀 立即开始

### 管理员

1. 打开 `admin-invite-system.html`
2. 生成邀请码
3. 分发给用户

### 用户

1. 获取邀请码
2. 打开 `invite-activation-flow.html`
3. 激活并领取

就是这么简单！🎉

---

**💫 SUK 邀请码系统 - 让空投分发更简单！**

*最后更新: 2024-11-17*
