# SUK 前端配置快速开始

## 🚀 5 分钟快速配置

本指南帮助您在 5 分钟内完成前端配置。

## 📋 前置条件

- ✅ 已部署 SUKToken 和 SUKAirdrop 智能合约
- ✅ 拥有合约地址（例如: `0x1234...`）
- ✅ 已安装 MetaMask 钱包

## 🎯 快速步骤

### 步骤 1: 更新配置（30秒）

打开终端，运行配置脚本：

```bash
node scripts/update-frontend-config.js goerli <你的SUKToken地址> <你的SUKAirdrop地址>
```

**示例**:
```bash
node scripts/update-frontend-config.js goerli 0xABC123... 0xDEF456...
```

看到 `✅ 配置已保存` 即表示成功！

### 步骤 2: 启动测试服务器（10秒）

```bash
python -m http.server 8000
```

或使用 Node.js:
```bash
npx http-server -p 8000
```

### 步骤 3: 测试配置（2分钟）

1. 浏览器打开: `http://localhost:8000/contract-config-test.html`

2. 点击 **"连接 MetaMask"** 按钮

3. 在 MetaMask 中授权连接

4. 点击 **"全面测试"** 按钮

5. 等待测试完成，确认所有测试 ✅ 通过

### 步骤 4: 使用空投页面（1分钟）

1. 打开: `http://localhost:8000/suk-airdrop.html`

2. 点击 **"连接钱包"**

3. 查看您的空投信息

4. 如符合条件，点击 **"立即领取"**

## ✅ 完成！

恭喜！您的前端配置已完成，现在可以：
- 🎁 领取空投
- 💰 查看 SUK 余额
- 🎬 观看短剧并使用 X402 计费

## 🔧 高级配置

### 切换到主网

```bash
# 1. 部署到主网（如果还没有）
npx hardhat run scripts/1-deploy-suk-token.js --network mainnet

# 2. 更新配置
node scripts/update-frontend-config.js mainnet <主网合约地址1> <主网合约地址2>

# 3. 在代码中修改默认网络
# 编辑需要的 HTML 文件，将 'goerli' 改为 'mainnet'
```

### 自定义配置

如果需要手动配置，编辑 `js/contract-config.js`:

```javascript
networks: {
    goerli: {
        // ... 其他配置 ...
        contracts: {
            SUKToken: '0x你的合约地址',      // ← 修改这里
            SUKAirdrop: '0x你的合约地址'     // ← 修改这里
        }
    }
}
```

## 📱 在您的页面中使用

### 最简单的集成

```html
<!DOCTYPE html>
<html>
<head>
    <script src="https://cdn.jsdelivr.net/npm/ethers@5.7.2/dist/ethers.umd.min.js"></script>
    <script src="js/contract-config.js"></script>
    <script src="js/web3-contract.js"></script>
</head>
<body>
    <button onclick="connect()">连接钱包</button>
    <div id="balance"></div>
    
    <script>
        let web3Contract;
        
        async function connect() {
            // 创建实例
            web3Contract = new SUKWeb3Contract('goerli');
            
            // 连接钱包
            const address = await web3Contract.connectWallet();
            
            // 获取余额
            const balance = await web3Contract.getSUKBalance();
            
            // 显示
            document.getElementById('balance').textContent = 
                `地址: ${address}\n余额: ${balance} SUK`;
        }
    </script>
</body>
</html>
```

保存为 `test.html`，在浏览器中打开即可使用！

## 🎬 集成到短剧播放器

在 `drama-player.html` 或类似页面中添加：

```html
<!-- 在 <head> 中添加 -->
<script src="js/contract-config.js"></script>
<script src="js/web3-contract.js"></script>

<!-- 在 <script> 中添加 -->
<script>
    let web3Contract;
    let billingInterval;
    
    // 初始化
    async function initPlayer() {
        web3Contract = new SUKWeb3Contract('goerli');
        await web3Contract.connectWallet();
        startBilling();
    }
    
    // 开始计费
    function startBilling() {
        billingInterval = setInterval(async () => {
            const watchTime = 10; // 10秒
            const platformWallet = '0x你的平台钱包地址';
            
            try {
                await web3Contract.payForWatching(
                    currentDramaId,
                    watchTime,
                    platformWallet
                );
                console.log('✅ 计费成功');
            } catch (error) {
                console.error('❌ 计费失败');
                video.pause();
            }
        }, 10000); // 每10秒
    }
    
    // 页面加载时初始化
    window.onload = initPlayer;
</script>
```

## 🎁 集成空投功能

在任意页面中添加空投按钮：

```html
<button onclick="claimAirdrop()">领取空投</button>

<script>
    async function claimAirdrop() {
        try {
            // 创建实例
            const web3Contract = new SUKWeb3Contract('goerli');
            await web3Contract.connectWallet();
            
            // 检查是否可以领取
            const canClaim = await web3Contract.canClaimAirdrop();
            if (!canClaim) {
                alert('您暂时无法领取空投');
                return;
            }
            
            // 获取可领取金额
            const amount = await web3Contract.getClaimableAmount();
            
            // 确认
            if (!confirm(`您将领取 ${amount} SUK，确认吗？`)) {
                return;
            }
            
            // 领取
            const receipt = await web3Contract.claimAirdrop();
            
            alert(`🎉 领取成功！\n交易哈希: ${receipt.transactionHash}`);
            
        } catch (error) {
            alert('❌ 领取失败: ' + error.message);
        }
    }
</script>
```

## 📊 常用代码片段

### 1. 获取余额

```javascript
const balance = await web3Contract.getSUKBalance();
console.log('余额:', balance, 'SUK');
```

### 2. 转账

```javascript
const receipt = await web3Contract.transferSUK('0x接收地址', '100');
console.log('转账成功:', receipt.transactionHash);
```

### 3. 检查空投状态

```javascript
const stats = await web3Contract.getAirdropStats();
console.log('已领取:', stats.totalClaimed, 'SUK');
console.log('白名单金额:', stats.whitelistAmount, 'SUK');
console.log('公开金额:', stats.publicAmount, 'SUK');
```

### 4. 监听账户变化

```javascript
web3Contract.onAccountsChanged((accounts) => {
    console.log('账户已切换:', accounts[0]);
    // 重新加载数据
    loadUserData();
});
```

### 5. 格式化地址

```javascript
const fullAddress = '0x1234567890123456789012345678901234567890';
const shortAddress = web3Contract.formatAddress(fullAddress);
console.log(shortAddress); // 输出: 0x1234...567890
```

## ⚠️ 常见问题

### Q: 配置后页面没有变化？

**A**: 清除浏览器缓存并硬刷新（Ctrl + Shift + R）

### Q: MetaMask 连接失败？

**A**: 确保：
1. MetaMask 已安装
2. MetaMask 已解锁
3. 切换到正确的网络（Goerli/Mainnet）

### Q: 合约调用报错？

**A**: 检查：
1. 合约地址是否正确配置
2. 当前网络是否与配置匹配
3. 合约是否已成功部署

### Q: 测试页面打不开？

**A**: 确保：
1. 本地服务器正在运行
2. 访问的端口正确（默认 8000）
3. 文件路径正确

## 🔗 相关链接

- 📖 [完整配置指南](FRONTEND_CONFIG_GUIDE.md)
- 🔧 [配置完成报告](FRONTEND_CONFIG_COMPLETE.md)
- 🚀 [智能合约部署](DEPLOYMENT_STEP_BY_STEP.md)
- 🎁 [SUK 空投指南](SUK_AIRDROP_GUIDE.md)

## 🎉 现在开始使用吧！

按照上述步骤，您应该已经完成了配置。如果遇到问题：

1. 先查看 **常见问题** 部分
2. 使用 **测试工具** 诊断问题
3. 查看浏览器控制台的错误信息

祝您使用愉快！🚀
