# 🚀 开始功能验证 - 3分钟快速指南

> 快速验证SUK奖励系统集成是否正常工作

---

## ⚡ 快速开始（3步）

### 步骤1: 启动服务（30秒）

```bash
# 确保在项目根目录
cd /path/to/drama-platform

# 启动后端服务
npm start

# 或使用PM2
pm2 start ecosystem.config.js
```

**预期输出**:
```
✅ Server running on port 3000
✅ MongoDB connected successfully
```

---

### 步骤2: 打开验证工具（10秒）

**浏览器访问**:
```
http://localhost:3000/reward-system-test.html
```

**或者使用curl测试**:
```bash
curl http://localhost:3000/reward-system-test.html
# 应该返回HTML内容
```

---

### 步骤3: 运行测试（2分钟）

在验证工具页面，按顺序点击以下按钮：

#### 必测项目 ⭐

1. **测试1: 奖励中心入口**
   - 点击"开始测试"
   - 点击"直接打开奖励中心"
   - ✅ 确认奖励中心页面打开

2. **测试2: 邀请分享功能**
   - 点击"测试生成邀请码"
   - ✅ 查看邀请码（SUKXXXXX格式）
   - ⚠️ 如果显示"请先绑定钱包"，这是正常的

3. **测试3: 观看奖励记录**
   - 点击"测试记录奖励 (240s/300s)"
   - ✅ 确认奖励金额：0.792 SUK
   - ✅ 确认状态：pending

#### 可选项目 🔍

4. **测试4: 奖励统计查询**
   - 点击"获取奖励统计"
   - 查看统计数据

5. **测试5: 页面集成验证**
   - 点击"打开主页测试"
   - 在主页点击"💰 我的奖励"
   - 确认跳转正常

---

## ✅ 成功标准

### 最小通过标准（必须全部通过）

- ✅ 奖励中心页面可以打开
- ✅ 邀请码API能够响应（成功或提示绑定钱包）
- ✅ 观看奖励API正常记录并返回正确金额
- ✅ 主页的奖励按钮存在且可点击

### 预期测试结果

| 测试项 | 预期结果 | 关键指标 |
|--------|---------|---------|
| 奖励中心入口 | ✅ 通过 | 页面跳转成功 |
| 生成邀请码 | ✅ 通过 或 ⚠️ 未绑定钱包 | API响应200/400 |
| 观看奖励 | ✅ 通过 | 奖励=0.792 SUK |
| 奖励统计 | ✅ 通过 | 返回统计对象 |
| 页面集成 | ✅ 通过 | 按钮可点击 |

---

## 🔧 快速故障排除

### 问题1: 验证工具打不开

**症状**: 访问 reward-system-test.html 返回404

**解决**:
```bash
# 检查文件是否存在
ls -la reward-system-test.html

# 检查服务是否启动
curl http://localhost:3000/

# 重启服务
npm start
```

---

### 问题2: API请求全部失败

**症状**: 所有API测试都显示"请求失败"

**解决**:
```bash
# 1. 检查后端服务
pm2 status
# 或
ps aux | grep node

# 2. 检查端口占用
lsof -i :3000

# 3. 查看后端日志
pm2 logs drama-platform --lines 50
# 或
npm start  # 直接启动查看错误

# 4. 检查MongoDB
mongosh
# 执行: show dbs
```

---

### 问题3: 邀请码生成提示"未绑定钱包"

**症状**: 测试邀请码时返回400错误

**说明**: ⚠️ **这是正常的安全机制**

**原因**: 
- 邀请奖励需要钱包地址才能发放
- 系统要求用户先绑定钱包

**解决**（测试用）:
```bash
# 调用绑定钱包API
curl -X POST http://localhost:3000/api/rewards/bind-wallet \
  -H "Content-Type: application/json" \
  -H "X-Telegram-Init-Data: user=%7B%22id%22%3A123456789%7D" \
  -d '{"walletAddress": "0x1234567890abcdef"}'

# 然后重新测试生成邀请码
```

---

### 问题4: 观看奖励金额不正确

**症状**: 返回的rewardAmount不等于0.792

**检查**:
```javascript
// 计算公式
watchRatio = 240 / 300 = 0.8
rewardAmount = 0.8 × 99 × 0.01 = 0.792 SUK

// 如果结果不同，检查：
1. 后端代码中的 dramaPrice 是否为99
2. rewardRate 是否为0.01
3. 计算逻辑是否正确
```

---

## 📊 验证报告

### 快速记录卡

```
验证日期: ___________
验证人: ___________

核心功能测试:
□ 奖励中心打开      [通过/失败]
□ 邀请码生成API     [通过/失败/未绑定钱包]  
□ 观看奖励API       [通过/失败]
□ 主页按钮集成      [通过/失败]

总体评价:
□ 可以上线
□ 需要修复
□ 需要重测

备注:
_________________________________
_________________________________
```

---

## 🎯 命令速查

### 启动相关
```bash
# 启动开发服务
npm run dev

# 启动生产服务
npm start

# PM2启动
pm2 start ecosystem.config.js

# 查看PM2状态
pm2 status

# 查看日志
pm2 logs drama-platform --lines 100
```

### 测试相关
```bash
# 打开验证工具
open http://localhost:3000/reward-system-test.html

# 或者直接测试API
curl http://localhost:3000/api/rewards/stats \
  -H "X-Telegram-Init-Data: user=%7B%22id%22%3A123456789%7D"
```

### 数据库相关
```bash
# 连接MongoDB
mongosh "mongodb://localhost:27017/drama_platform"

# 查看奖励记录
db.watchrewards.find().limit(5)
db.inviterewards.find().limit(5)

# 查看统计
db.watchrewards.countDocuments()
```

---

## 📚 相关文档

### 核心文档
1. **VERIFICATION_STEPS.md** - 详细验证步骤（15-20分钟）
2. **REWARD_SYSTEM_QUICK_REFERENCE.md** - 快速参考指南
3. **SUK_REWARD_INTEGRATION_VERIFIED.md** - 完整验证报告

### 技术文档
4. **SUK_REWARD_SYSTEM_GUIDE.md** - 技术实现详解
5. **SUK_REWARD_QUICK_START.md** - 集成指南
6. **API.md** - API完整文档

---

## ✨ 验证工具特性

### reward-system-test.html 提供：

- ✅ **5大测试模块**：覆盖所有核心功能
- ✅ **实时API测试**：直接调用后端API
- ✅ **结果可视化**：清晰显示成功/失败
- ✅ **代码片段**：展示API响应JSON
- ✅ **快速链接**：一键打开相关页面

### 测试范围：

1. 奖励中心入口验证
2. 邀请码生成和使用
3. 观看奖励记录和计算
4. 奖励统计和记录查询
5. 页面集成完整性检查

---

## 🎉 预期结果

### 验证成功后，您应该看到：

✅ **测试1**: 奖励中心页面正常打开  
✅ **测试2**: 邀请码API正常响应  
✅ **测试3**: 观看奖励计算正确（0.792 SUK）  
✅ **测试4**: 统计数据正常返回  
✅ **测试5**: 主页和播放器集成完整  

### 这意味着：

🎯 **系统已100%集成完成**  
🚀 **可以进入生产部署阶段**  
💰 **用户可以开始赚取SUK奖励**  
👥 **邀请机制准备就绪**  

---

## 🔜 下一步行动

### 验证通过后：

1. **部署到测试服务器**（10分钟）
   ```bash
   git push origin main
   # 在测试服务器
   git pull
   pm2 restart drama-platform
   ```

2. **邀请用户测试**（1-2天）
   - 发送测试邀请
   - 收集用户反馈
   - 监控系统运行

3. **数据分析**（持续）
   - 查看奖励记录生成
   - 监控API调用量
   - 分析用户行为

4. **正式上线**（准备就绪时）
   - 配置生产环境
   - 开启监控告警
   - 准备运营推广

---

## 💬 需要帮助？

### 常见问题
- 📖 查看 VERIFICATION_STEPS.md 的"常见问题排查"部分
- 🔍 搜索关键字：`recordWatchReward`, `openInviteShare`, `checkAndUseInviteCode`

### 调试技巧
```javascript
// 在浏览器控制台查看
console.log('当前用户ID:', currentUser.id);
console.log('API基础URL:', API_BASE_URL);

// 在播放器页面查看
console.log('观看时长:', player.getCurrentTime());
console.log('总时长:', player.getDuration());
```

---

**工具**: reward-system-test.html  
**时间**: 3分钟快速验证  
**目标**: 确认系统100%就绪 ✅

---

**开始验证**: http://localhost:3000/reward-system-test.html  
**准备好了？让我们开始吧！** 🚀
