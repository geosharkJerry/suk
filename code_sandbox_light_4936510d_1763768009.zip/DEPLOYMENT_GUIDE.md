# 短剧平台完整部署指南
# Complete Deployment Guide

> **本指南将帮助您将短剧平台从开发环境部署到生产服务器。**

---

## 📋 目录

1. [服务器准备](#1-服务器准备)
2. [环境安装](#2-环境安装)
3. [项目部署](#3-项目部署)
4. [数据库配置](#4-数据库配置)
5. [Nginx配置](#5-nginx配置)
6. [进程管理](#6-进程管理)
7. [SSL证书配置](#7-ssl证书配置)
8. [监控和日志](#8-监控和日志)
9. [备份策略](#9-备份策略)
10. [故障排查](#10-故障排查)

---

## 1. 服务器准备

### 1.1 服务器要求

#### 最低配置（测试环境）
- CPU: 2核
- 内存: 4GB
- 硬盘: 40GB SSD
- 带宽: 5Mbps
- 操作系统: Ubuntu 20.04 LTS / CentOS 7+

#### 推荐配置（生产环境）
- CPU: 4核或更高
- 内存: 8GB或更高
- 硬盘: 100GB SSD
- 带宽: 10Mbps或更高
- 操作系统: Ubuntu 22.04 LTS（推荐）

### 1.2 购买服务器

**推荐云服务商**：
- 阿里云 ECS
- 腾讯云 CVM
- AWS EC2
- Vultr / DigitalOcean

### 1.3 初始化服务器

```bash
# 更新系统包
sudo apt update && sudo apt upgrade -y

# 安装基础工具
sudo apt install -y curl wget git vim ufw

# 创建应用用户（不使用root）
sudo adduser drama_admin
sudo usermod -aG sudo drama_admin

# 切换到应用用户
su - drama_admin

# 配置防火墙
sudo ufw allow 22      # SSH
sudo ufw allow 80      # HTTP
sudo ufw allow 443     # HTTPS
sudo ufw enable
```

---

## 2. 环境安装

### 2.1 安装Node.js

```bash
# 安装Node.js 18.x LTS
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# 验证安装
node --version   # 应显示 v18.x.x
npm --version    # 应显示 9.x.x

# 安装全局工具
sudo npm install -g pm2 yarn
```

### 2.2 安装MongoDB

```bash
# 导入MongoDB公钥
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -

# 添加MongoDB源
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list

# 安装MongoDB
sudo apt update
sudo apt install -y mongodb-org

# 启动MongoDB
sudo systemctl start mongod
sudo systemctl enable mongod

# 验证安装
mongosh --version
```

#### 配置MongoDB安全

```bash
# 连接MongoDB
mongosh

# 创建管理员用户
use admin
db.createUser({
  user: "admin",
  pwd: "your_strong_password_here",
  roles: [ { role: "root", db: "admin" } ]
})

# 创建应用数据库用户
use short_drama_platform
db.createUser({
  user: "drama_user",
  pwd: "your_database_password_here",
  roles: [ { role: "readWrite", db: "short_drama_platform" } ]
})

exit
```

启用MongoDB认证：

```bash
# 编辑配置文件
sudo nano /etc/mongod.conf

# 取消注释并修改以下行：
security:
  authorization: enabled

# 重启MongoDB
sudo systemctl restart mongod
```

### 2.3 安装Redis

```bash
# 安装Redis
sudo apt install -y redis-server

# 配置Redis
sudo nano /etc/redis/redis.conf

# 修改以下配置：
# 1. 设置密码（取消注释并修改）
requirepass your_redis_password_here

# 2. 限制访问（只允许本地访问）
bind 127.0.0.1 ::1

# 3. 持久化配置
save 900 1
save 300 10
save 60 10000

# 重启Redis
sudo systemctl restart redis-server
sudo systemctl enable redis-server

# 测试连接
redis-cli
AUTH your_redis_password_here
PING   # 应返回 PONG
exit
```

### 2.4 安装Nginx

```bash
# 安装Nginx
sudo apt install -y nginx

# 启动Nginx
sudo systemctl start nginx
sudo systemctl enable nginx

# 验证安装
sudo nginx -v
curl http://localhost   # 应看到Nginx欢迎页面
```

---

## 3. 项目部署

### 3.1 创建项目目录

```bash
# 创建应用目录
sudo mkdir -p /var/www/drama-platform
sudo chown -R drama_admin:drama_admin /var/www/drama-platform

# 进入目录
cd /var/www/drama-platform
```

### 3.2 从Git仓库克隆项目

```bash
# 克隆项目（替换为您的仓库地址）
git clone https://github.com/your-username/drama-platform.git .

# 或者使用SSH密钥
git clone git@github.com:your-username/drama-platform.git .
```

### 3.3 安装依赖

```bash
# 安装后端依赖
npm install --production

# 或使用Yarn（更快）
yarn install --production
```

### 3.4 配置环境变量

```bash
# 复制环境配置文件
cp .env.example .env

# 编辑配置文件
nano .env
```

**生产环境配置示例**：

```bash
# 服务器配置
NODE_ENV=production
PORT=3000
API_BASE_URL=https://api.your-domain.com

# 数据库配置
MONGODB_URI=mongodb://drama_user:your_database_password_here@localhost:27017/short_drama_platform
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=your_redis_password_here

# 阿里云VoD配置
ALIYUN_ACCESS_KEY_ID=your_access_key_id
ALIYUN_ACCESS_KEY_SECRET=your_access_key_secret
ALIYUN_VOD_REGION=cn-shanghai
PLAY_AUTH_TIMEOUT=1800
PLAY_AUTH_CACHE_TTL=1500

# JWT配置（生成强密钥）
JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(64).toString('hex'))")
JWT_EXPIRES_IN=7d

# 区块链配置
ETH_RPC_URL=https://mainnet.infura.io/v3/your_infura_project_id
SUK_TOKEN_CONTRACT=0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb
PLATFORM_WALLET_ADDRESS=0x_your_platform_wallet_address

# 安全配置
FORCE_HTTPS=true
COOKIE_SECURE=true
COOKIE_SAME_SITE=strict
```

设置文件权限：

```bash
chmod 600 .env
```

### 3.5 初始化数据库

```bash
# 运行数据库初始化脚本
node scripts/init-db.js

# 或创建索引
node scripts/create-indexes.js
```

### 3.6 测试应用启动

```bash
# 启动应用（测试模式）
npm start

# 在另一个终端测试API
curl http://localhost:3000/api/health

# 如果返回 {"status":"ok"}，说明启动成功
# 按 Ctrl+C 停止应用
```

---

## 4. 数据库配置

### 4.1 创建数据库初始化脚本

创建 `scripts/init-db.js`：

```javascript
const mongoose = require('mongoose');
const config = require('../backend/config/env.config');

async function initDatabase() {
    try {
        console.log('🔧 开始初始化数据库...\n');

        // 连接数据库
        await mongoose.connect(config.mongodb.uri, config.mongodb.options);
        console.log('✅ 数据库连接成功');

        // 创建WatchHistory索引
        const WatchHistory = require('../backend/models/WatchHistory');
        await WatchHistory.createIndexes();
        console.log('✅ WatchHistory索引创建成功');

        // 创建其他模型索引
        // const Drama = require('../backend/models/Drama');
        // await Drama.createIndexes();
        // console.log('✅ Drama索引创建成功');

        // 插入初始数据（可选）
        console.log('\n📊 数据库初始化完成！');

        await mongoose.disconnect();
        process.exit(0);

    } catch (error) {
        console.error('❌ 数据库初始化失败:', error);
        process.exit(1);
    }
}

initDatabase();
```

运行初始化：

```bash
node scripts/init-db.js
```

### 4.2 数据库备份脚本

创建 `scripts/backup-db.sh`：

```bash
#!/bin/bash

# 配置
BACKUP_DIR="/var/backups/drama_platform"
DB_NAME="short_drama_platform"
DATE=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="$BACKUP_DIR/mongodb_backup_$DATE.gz"

# 创建备份目录
mkdir -p $BACKUP_DIR

# 执行备份
echo "🔄 开始备份数据库..."
mongodump --uri="mongodb://drama_user:password@localhost:27017/$DB_NAME" --gzip --archive=$BACKUP_FILE

if [ $? -eq 0 ]; then
    echo "✅ 备份成功: $BACKUP_FILE"
    
    # 删除30天前的备份
    find $BACKUP_DIR -type f -name "mongodb_backup_*.gz" -mtime +30 -delete
    echo "🧹 已清理30天前的旧备份"
else
    echo "❌ 备份失败"
    exit 1
fi
```

设置定时备份：

```bash
# 添加执行权限
chmod +x scripts/backup-db.sh

# 编辑crontab
crontab -e

# 添加每天凌晨2点备份
0 2 * * * /var/www/drama-platform/scripts/backup-db.sh >> /var/log/drama_backup.log 2>&1
```

---

## 5. Nginx配置

### 5.1 创建站点配置

```bash
sudo nano /etc/nginx/sites-available/drama-platform
```

**配置内容**：

```nginx
# HTTP服务器（重定向到HTTPS）
server {
    listen 80;
    listen [::]:80;
    server_name your-domain.com www.your-domain.com;

    # 重定向到HTTPS
    return 301 https://$server_name$request_uri;
}

# HTTPS服务器
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name your-domain.com www.your-domain.com;

    # SSL证书配置
    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;

    # 安全头
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;

    # 日志文件
    access_log /var/log/nginx/drama_access.log;
    error_log /var/log/nginx/drama_error.log;

    # 上传文件大小限制
    client_max_body_size 2G;

    # API代理
    location /api/ {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        
        # 代理头
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # 超时设置
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        
        # 缓存绕过
        proxy_cache_bypass $http_upgrade;
    }

    # 静态文件
    location / {
        root /var/www/drama-platform/public;
        index index.html;
        try_files $uri $uri/ /index.html;

        # 静态资源缓存
        location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot)$ {
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }

    # 健康检查
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }

    # 拒绝访问隐藏文件
    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
}
```

### 5.2 启用站点配置

```bash
# 创建软链接
sudo ln -s /etc/nginx/sites-available/drama-platform /etc/nginx/sites-enabled/

# 测试配置
sudo nginx -t

# 重新加载Nginx
sudo systemctl reload nginx
```

### 5.3 配置API子域名（可选）

如果想使用独立的API域名（如 `api.your-domain.com`）：

```bash
sudo nano /etc/nginx/sites-available/drama-api
```

```nginx
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name api.your-domain.com;

    ssl_certificate /etc/letsencrypt/live/api.your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.your-domain.com/privkey.pem;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## 6. 进程管理

### 6.1 使用PM2管理Node.js进程

```bash
# 启动应用
pm2 start server.js --name drama-platform

# 设置环境变量
pm2 start server.js --name drama-platform --env production

# 或使用ecosystem配置文件
pm2 start ecosystem.config.js
```

### 6.2 创建PM2配置文件

创建 `ecosystem.config.js`：

```javascript
module.exports = {
  apps: [{
    name: 'drama-platform',
    script: './server.js',
    instances: 2,  // 启动2个实例（CPU核心数）
    exec_mode: 'cluster',  // 集群模式
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: './logs/pm2-error.log',
    out_file: './logs/pm2-out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    merge_logs: true,
    autorestart: true,
    max_restarts: 10,
    min_uptime: '10s',
    max_memory_restart: '1G',
    watch: false
  }]
};
```

### 6.3 PM2常用命令

```bash
# 启动应用
pm2 start ecosystem.config.js

# 查看状态
pm2 status
pm2 list

# 查看日志
pm2 logs drama-platform
pm2 logs drama-platform --lines 100

# 重启应用
pm2 restart drama-platform

# 停止应用
pm2 stop drama-platform

# 删除应用
pm2 delete drama-platform

# 保存PM2配置（开机自启）
pm2 save
pm2 startup
```

### 6.4 监控和管理界面

```bash
# 安装PM2 Plus（可选）
pm2 plus

# 或使用免费的监控面板
pm2 monit
```

---

## 7. SSL证书配置

### 7.1 使用Let's Encrypt免费证书

```bash
# 安装Certbot
sudo apt install -y certbot python3-certbot-nginx

# 获取证书（自动配置Nginx）
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# 测试自动续期
sudo certbot renew --dry-run
```

Certbot会自动添加续期任务到cron。

### 7.2 手动配置SSL证书

如果使用其他证书（如阿里云、腾讯云）：

```bash
# 创建证书目录
sudo mkdir -p /etc/nginx/ssl

# 上传证书文件
sudo nano /etc/nginx/ssl/your-domain.com.crt
sudo nano /etc/nginx/ssl/your-domain.com.key

# 设置权限
sudo chmod 600 /etc/nginx/ssl/your-domain.com.key
```

在Nginx配置中引用：

```nginx
ssl_certificate /etc/nginx/ssl/your-domain.com.crt;
ssl_certificate_key /etc/nginx/ssl/your-domain.com.key;
```

---

## 8. 监控和日志

### 8.1 配置日志轮转

创建 `/etc/logrotate.d/drama-platform`：

```
/var/www/drama-platform/logs/*.log {
    daily
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 drama_admin drama_admin
    sharedscripts
    postrotate
        pm2 reloadLogs
    endscript
}
```

测试配置：

```bash
sudo logrotate -d /etc/logrotate.d/drama-platform
```

### 8.2 安装监控工具

#### 安装Node Exporter（Prometheus监控）

```bash
# 下载Node Exporter
wget https://github.com/prometheus/node_exporter/releases/download/v1.6.1/node_exporter-1.6.1.linux-amd64.tar.gz
tar -xvf node_exporter-1.6.1.linux-amd64.tar.gz
sudo mv node_exporter-1.6.1.linux-amd64/node_exporter /usr/local/bin/

# 创建systemd服务
sudo nano /etc/systemd/system/node_exporter.service
```

```ini
[Unit]
Description=Node Exporter
After=network.target

[Service]
User=drama_admin
ExecStart=/usr/local/bin/node_exporter

[Install]
WantedBy=multi-user.target
```

```bash
# 启动服务
sudo systemctl daemon-reload
sudo systemctl start node_exporter
sudo systemctl enable node_exporter
```

### 8.3 配置Sentry错误监控（可选）

在 `.env` 中添加：

```bash
SENTRY_DSN=https://your_sentry_dsn@sentry.io/your_project_id
SENTRY_ENVIRONMENT=production
```

---

## 9. 备份策略

### 9.1 自动备份脚本

创建 `scripts/full-backup.sh`：

```bash
#!/bin/bash

BACKUP_DIR="/var/backups/drama_platform"
DATE=$(date +"%Y%m%d_%H%M%S")

# 1. 备份MongoDB
echo "🔄 备份MongoDB..."
mongodump --uri="mongodb://drama_user:password@localhost:27017/short_drama_platform" \
    --gzip --archive=$BACKUP_DIR/mongodb_$DATE.gz

# 2. 备份配置文件
echo "🔄 备份配置文件..."
tar -czf $BACKUP_DIR/config_$DATE.tar.gz /var/www/drama-platform/.env

# 3. 备份上传文件（如果有）
# tar -czf $BACKUP_DIR/uploads_$DATE.tar.gz /var/www/drama-platform/uploads

echo "✅ 备份完成！"
```

### 9.2 设置定时备份

```bash
crontab -e
```

添加：

```cron
# 每天凌晨2点全量备份
0 2 * * * /var/www/drama-platform/scripts/full-backup.sh

# 每周日凌晨3点上传备份到云存储（可选）
0 3 * * 0 /var/www/drama-platform/scripts/upload-backup-to-cloud.sh
```

---

## 10. 故障排查

### 10.1 应用无法启动

```bash
# 查看PM2日志
pm2 logs drama-platform --lines 50

# 查看系统日志
sudo journalctl -u mongod -n 50
sudo journalctl -u redis -n 50

# 检查端口占用
sudo netstat -tulpn | grep 3000
```

### 10.2 数据库连接失败

```bash
# 测试MongoDB连接
mongosh "mongodb://drama_user:password@localhost:27017/short_drama_platform"

# 检查MongoDB状态
sudo systemctl status mongod

# 查看MongoDB日志
sudo tail -f /var/log/mongodb/mongod.log
```

### 10.3 Nginx错误

```bash
# 测试Nginx配置
sudo nginx -t

# 查看Nginx错误日志
sudo tail -f /var/log/nginx/drama_error.log

# 重新加载配置
sudo systemctl reload nginx
```

### 10.4 性能问题

```bash
# 查看系统资源
htop
free -h
df -h

# 查看Node.js进程内存
pm2 monit

# 数据库查询分析
mongosh
use short_drama_platform
db.watch_histories.explain("executionStats").find({userId: "xxx"})
```

---

## ✅ 部署检查清单

完成以下所有步骤后，您的应用即可正常运行：

- [ ] 服务器环境准备完成
- [ ] Node.js、MongoDB、Redis已安装
- [ ] 项目代码已部署
- [ ] 环境变量已正确配置
- [ ] 数据库已初始化
- [ ] Nginx已配置并运行
- [ ] SSL证书已安装
- [ ] PM2进程管理已配置
- [ ] 日志轮转已配置
- [ ] 自动备份已设置
- [ ] 监控工具已安装
- [ ] 应用可通过域名正常访问

**恭喜！您的短剧平台已成功部署！🎉**

---

*最后更新时间：2024-11-15*
*文档版本：v1.0*
