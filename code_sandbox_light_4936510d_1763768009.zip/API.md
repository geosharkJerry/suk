# API 完整文档
# Complete API Documentation

> **短剧平台 API 参考文档** - v1.0.0  
> 所有 API 端点的详细说明、请求示例和响应格式

---

## 📋 目录

- [认证方式](#认证方式)
- [响应格式](#响应格式)
- [错误码](#错误码)
- [Telegram Mini App API](#telegram-mini-app-api)
- [视频播放 API](#视频播放-api)
- [支付系统 API](#支付系统-api)
- [观看历史 API](#观看历史-api)
- [健康检查 API](#健康检查-api)

---

## 认证方式

### Telegram WebApp 认证

Telegram Mini App 使用 Telegram WebApp 的 `initData` 进行身份验证。

**请求头**：
```http
Authorization: tma <initDataRaw>
```

**验证流程**：
1. 前端通过 `window.Telegram.WebApp.initData` 获取 initDataRaw
2. 将 initDataRaw 放在 Authorization header 中
3. 后端验证 HMAC-SHA256 签名
4. 解析用户信息（user_id, username 等）

**示例**：
```javascript
// 前端代码
const initData = window.Telegram.WebApp.initData;
fetch('/api/telegram/dramas', {
    headers: {
        'Authorization': `tma ${initData}`
    }
});
```

### JWT 认证（传统Web）

传统Web应用使用 JWT (JSON Web Token) 认证。

**请求头**：
```http
Authorization: Bearer <jwt_token>
```

---

## 响应格式

### 成功响应

```json
{
    "success": true,
    "data": { ... },
    "message": "操作成功"
}
```

### 错误响应

```json
{
    "success": false,
    "message": "错误描述",
    "error": "详细错误信息（开发环境）"
}
```

### 分页响应

```json
{
    "success": true,
    "data": [...],
    "pagination": {
        "page": 1,
        "limit": 20,
        "total": 100,
        "totalPages": 5
    }
}
```

---

## 错误码

| HTTP状态码 | 说明 |
|-----------|------|
| 200 | 请求成功 |
| 201 | 创建成功 |
| 204 | 删除成功（无内容） |
| 400 | 请求参数错误 |
| 401 | 未认证 |
| 403 | 无权限访问 |
| 404 | 资源不存在 |
| 409 | 资源冲突 |
| 429 | 请求过于频繁 |
| 500 | 服务器内部错误 |
| 503 | 服务暂时不可用 |

---

## Telegram Mini App API

### 1. 获取短剧列表

获取所有已发布的短剧列表，支持分页和分类筛选。

**端点**：`GET /api/telegram/dramas`

**认证**：需要 Telegram WebApp 认证

**查询参数**：
| 参数 | 类型 | 必需 | 说明 | 默认值 |
|------|------|------|------|--------|
| page | number | ❌ | 页码 | 1 |
| limit | number | ❌ | 每页数量 | 20 |
| category | string | ❌ | 分类筛选 | all |

**分类值**：
- `all` - 全部
- `romance` - 言情
- `fantasy` - 玄幻
- `drama` - 都市
- `comedy` - 喜剧
- `action` - 动作
- `thriller` - 悬疑

**请求示例**：
```http
GET /api/telegram/dramas?page=1&limit=20&category=romance
Authorization: tma query_id=xxx&user=...
```

**响应示例**：
```json
{
    "success": true,
    "data": [
        {
            "id": "drama_001",
            "title": "霸道总裁爱上我",
            "description": "一个灰姑娘与霸道总裁的爱情故事",
            "coverUrl": "https://cdn.example.com/drama1.jpg",
            "price": 50,
            "priceUSD": 7,
            "priceTON": 3,
            "priceStars": 100,
            "episodes": 20,
            "totalDuration": 600,
            "category": "romance",
            "rating": 4.8,
            "views": 125000
        }
    ],
    "pagination": {
        "page": 1,
        "limit": 20,
        "total": 45,
        "totalPages": 3
    }
}
```

---

### 2. 获取短剧详情

获取单个短剧的详细信息，包括剧集列表和用户购买状态。

**端点**：`GET /api/telegram/drama/:dramaId/detail`

**认证**：需要 Telegram WebApp 认证

**路径参数**：
| 参数 | 类型 | 说明 |
|------|------|------|
| dramaId | string | 短剧ID |

**请求示例**：
```http
GET /api/telegram/drama/drama_001/detail
Authorization: tma query_id=xxx&user=...
```

**响应示例**：
```json
{
    "success": true,
    "data": {
        "dramaId": "drama_001",
        "title": "霸道总裁爱上我",
        "description": "一个灰姑娘与霸道总裁的爱情故事...",
        "coverUrl": "https://cdn.example.com/drama1.jpg",
        "price": 50,
        "priceUSD": 7,
        "priceTON": 3,
        "priceStars": 100,
        "singleEpisodePrice": 5,
        "singleEpisodePriceTON": 0.3,
        "singleEpisodePriceStars": 10,
        "category": "romance",
        "rating": 4.8,
        "views": 125000,
        "totalEpisodes": 20,
        "totalDuration": 600,
        "cast": ["张三", "李四"],
        "director": "王五",
        "episodes": [
            {
                "episodeNumber": 1,
                "episodeId": "drama_001_ep_001",
                "title": "第1集：命运的相遇",
                "duration": 180,
                "isFree": true,
                "purchased": false
            },
            {
                "episodeNumber": 2,
                "episodeId": "drama_001_ep_002",
                "title": "第2集：意外的碰撞",
                "duration": 180,
                "isFree": false,
                "purchased": true
            }
        ],
        "purchaseStatus": {
            "hasPurchased": true,
            "purchaseType": "full",
            "purchasedEpisodes": ["drama_001_ep_002", "drama_001_ep_003"]
        }
    }
}
```

---

### 3. 获取播放授权

获取剧集的阿里云 VoD 播放授权，用于视频播放器。

**端点**：`GET /api/telegram/play-auth/:episodeId`

**认证**：需要 Telegram WebApp 认证

**路径参数**：
| 参数 | 类型 | 说明 |
|------|------|------|
| episodeId | string | 剧集ID |

**查询参数**：
| 参数 | 类型 | 必需 | 说明 |
|------|------|------|------|
| dramaId | string | ✅ | 短剧ID |

**权限检查**：
- 第1集免费，无需购买
- 其他集数需要购买（整部或单集）

**请求示例**：
```http
GET /api/telegram/play-auth/drama_001_ep_002?dramaId=drama_001
Authorization: tma query_id=xxx&user=...
```

**成功响应**：
```json
{
    "success": true,
    "playAuth": "eyJTZWN1cml0eVRva2VuIjoi...",
    "videoId": "1234567890abcdef",
    "expiresIn": 1800,
    "watchHistory": {
        "watchProgress": 65,
        "totalDuration": 180,
        "updatedAt": "2024-11-15T10:30:00Z"
    },
    "episodeInfo": {
        "dramaId": "drama_001",
        "dramaTitle": "霸道总裁爱上我",
        "episodeId": "drama_001_ep_002",
        "episodeNumber": 2,
        "episodeTitle": "第2集：意外的碰撞",
        "duration": 180,
        "isFree": false
    },
    "message": "播放授权获取成功"
}
```

**未购买错误响应**：
```json
{
    "success": false,
    "message": "您尚未购买此剧集",
    "requiresPurchase": true,
    "dramaId": "drama_001",
    "episodeId": "drama_001_ep_002"
}
```

---

### 4. 保存观看进度

自动保存用户的观看进度，用于续播功能。

**端点**：`POST /api/telegram/watch-progress`

**认证**：需要 Telegram WebApp 认证

**请求体**：
```json
{
    "dramaId": "drama_001",
    "episodeId": "drama_001_ep_002",
    "videoId": "1234567890abcdef",
    "watchProgress": 65,
    "totalDuration": 180
}
```

**响应示例**：
```json
{
    "success": true,
    "data": {
        "historyId": "64a1b2c3d4e5f6789012",
        "progressPercent": 36,
        "isCompleted": false
    },
    "message": "观看进度已保存"
}
```

---

## 支付系统 API

### 5. 创建 Telegram Stars 支付

创建 Telegram Stars 支付发票。

**端点**：`POST /api/telegram/create-stars-invoice`

**认证**：需要 Telegram WebApp 认证

**请求体**：
```json
{
    "dramaId": "drama_001",
    "dramaTitle": "霸道总裁爱上我",
    "purchaseType": "full",
    "priceStars": 100,
    "episodeId": null
}
```

**字段说明**：
| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| dramaId | string | ✅ | 短剧ID |
| dramaTitle | string | ✅ | 短剧标题 |
| purchaseType | string | ✅ | `full`(全集) 或 `single`(单集) |
| priceStars | number | ✅ | Telegram Stars 价格 |
| episodeId | string | ❌ | 单集购买时必需 |

**响应示例**：
```json
{
    "success": true,
    "orderId": "ORDER_LGX8H2_1A2B3C4D5E6F",
    "invoiceLink": null,
    "message": "发票已发送到您的 Telegram 聊天"
}
```

---

### 6. 创建 TON 支付

创建 TON 区块链支付订单。

**端点**：`POST /api/telegram/create-ton-payment`

**认证**：需要 Telegram WebApp 认证

**请求体**：
```json
{
    "dramaId": "drama_001",
    "dramaTitle": "霸道总裁爱上我",
    "purchaseType": "full",
    "priceTON": 3,
    "episodeId": null
}
```

**响应示例**：
```json
{
    "success": true,
    "orderId": "ORDER_LGX8H2_1A2B3C4D5E6F",
    "invoiceLink": "ton://transfer/EQxxx...?amount=3000000000&text=Order%3AORDER_LGX8H2_1A2B3C4D5E6F",
    "message": "请使用 TON 钱包完成支付"
}
```

---

### 7. 创建 SUK Token 支付

创建 SUK Token 支付订单。

**端点**：`POST /api/telegram/create-suk-payment`

**认证**：需要 Telegram WebApp 认证

**请求体**：
```json
{
    "dramaId": "drama_001",
    "dramaTitle": "霸道总裁爱上我",
    "purchaseType": "full",
    "priceSUK": 50,
    "userWallet": "0x1234567890abcdef...",
    "episodeId": null
}
```

**响应示例**：
```json
{
    "success": true,
    "orderId": "ORDER_LGX8H2_1A2B3C4D5E6F",
    "contractAddress": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb",
    "amount": 50,
    "message": "请使用钱包完成 SUK Token 支付"
}
```

---

### 8. 验证 TON 支付

验证 TON 区块链交易。

**端点**：`POST /api/telegram/verify-ton-payment`

**认证**：需要 Telegram WebApp 认证

**请求体**：
```json
{
    "orderId": "ORDER_LGX8H2_1A2B3C4D5E6F",
    "transactionHash": "base64_encoded_tx_hash",
    "senderAddress": "EQxxx..."
}
```

**响应示例**：
```json
{
    "success": true,
    "orderId": "ORDER_LGX8H2_1A2B3C4D5E6F",
    "verified": true,
    "transactionHash": "base64_encoded_tx_hash",
    "amount": 3,
    "message": "支付验证成功"
}
```

---

### 9. 验证 SUK Token 支付

验证 SUK Token 区块链交易。

**端点**：`POST /api/telegram/verify-suk-payment`

**认证**：需要 Telegram WebApp 认证

**请求体**：
```json
{
    "orderId": "ORDER_LGX8H2_1A2B3C4D5E6F",
    "transactionHash": "0x1234567890abcdef..."
}
```

**响应示例**：
```json
{
    "success": true,
    "orderId": "ORDER_LGX8H2_1A2B3C4D5E6F",
    "verified": true,
    "transactionHash": "0x1234567890abcdef...",
    "amount": 50,
    "blockNumber": 18234567,
    "confirmations": 12,
    "message": "支付验证成功"
}
```

---

### 10. Telegram Webhook（支付回调）

接收 Telegram Bot API 的支付成功回调。

**端点**：`POST /api/telegram/webhook`

**认证**：Telegram Bot Token 验证

**请求体**（Telegram发送）：
```json
{
    "update_id": 123456789,
    "message": {
        "message_id": 123,
        "from": {
            "id": 123456789,
            "first_name": "John"
        },
        "chat": {
            "id": 123456789,
            "type": "private"
        },
        "successful_payment": {
            "currency": "XTR",
            "total_amount": 100,
            "invoice_payload": "{\"orderId\":\"ORDER_XXX\",\"dramaId\":\"drama_001\"}",
            "telegram_payment_charge_id": "telegram_charge_id",
            "provider_payment_charge_id": "provider_charge_id"
        }
    }
}
```

**处理流程**：
1. 验证 webhook 来源
2. 解析 invoice_payload
3. 更新订单状态为 completed
4. 创建购买记录
5. 发送确认消息给用户

---

## 视频播放 API

### 11. 获取继续观看列表

获取用户未看完的剧集列表。

**端点**：`GET /api/video/continue-watching`

**认证**：需要认证（JWT 或 Telegram WebApp）

**查询参数**：
| 参数 | 类型 | 必需 | 说明 | 默认值 |
|------|------|------|------|--------|
| limit | number | ❌ | 返回数量 | 10 |

**请求示例**：
```http
GET /api/video/continue-watching?limit=10
Authorization: Bearer <jwt_token>
```

**响应示例**：
```json
{
    "success": true,
    "data": [
        {
            "dramaId": "drama_001",
            "episodeId": "drama_001_ep_002",
            "episodeTitle": "第2集：意外的碰撞",
            "watchProgress": 65,
            "totalDuration": 180,
            "progressPercent": 36,
            "lastWatchedAt": "2024-11-15T10:30:00Z",
            "coverUrl": "https://cdn.example.com/drama1.jpg"
        }
    ]
}
```

---

## 观看历史 API

### 12. 获取观看历史

获取用户的观看历史记录。

**端点**：`GET /api/video/watch-history`

**认证**：需要认证

**查询参数**：
| 参数 | 类型 | 必需 | 说明 | 默认值 |
|------|------|------|------|--------|
| page | number | ❌ | 页码 | 1 |
| limit | number | ❌ | 每页数量 | 20 |
| dramaId | string | ❌ | 筛选特定短剧 | - |

**响应示例**：
```json
{
    "success": true,
    "data": [
        {
            "dramaId": "drama_001",
            "episodeId": "drama_001_ep_002",
            "videoId": "1234567890abcdef",
            "watchProgress": 65,
            "totalDuration": 180,
            "progressPercent": 36,
            "isCompleted": false,
            "watchCount": 3,
            "firstWatchedAt": "2024-11-14T10:00:00Z",
            "lastWatchedAt": "2024-11-15T10:30:00Z"
        }
    ],
    "pagination": {
        "page": 1,
        "limit": 20,
        "total": 45,
        "totalPages": 3
    }
}
```

---

## 健康检查 API

### 13. 系统健康检查

检查系统各组件的健康状态。

**端点**：`GET /api/health`

**认证**：不需要

**响应示例**：
```json
{
    "status": "healthy",
    "timestamp": "2024-11-15T10:30:00Z",
    "services": {
        "mongodb": {
            "status": "healthy",
            "responseTime": 5
        },
        "redis": {
            "status": "healthy",
            "responseTime": 2
        },
        "aliyunVod": {
            "status": "healthy"
        },
        "tonBlockchain": {
            "status": "healthy",
            "network": "mainnet",
            "connected": true
        },
        "sukBlockchain": {
            "status": "healthy",
            "network": "mainnet",
            "chainId": 1,
            "blockNumber": 18234567
        }
    }
}
```

---

## 请求限制

为防止滥用，API 实施了请求频率限制：

| 端点类型 | 限制 | 窗口期 |
|----------|------|--------|
| 获取数据（GET） | 100次 | 15分钟 |
| 创建/更新（POST/PUT） | 50次 | 15分钟 |
| 支付相关 | 10次 | 15分钟 |

**超出限制响应**：
```json
{
    "success": false,
    "message": "请求过于频繁，请稍后再试",
    "retryAfter": 900
}
```

---

## 最佳实践

### 1. 错误处理

始终检查 `success` 字段：

```javascript
const response = await fetch('/api/telegram/dramas');
const data = await response.json();

if (!data.success) {
    console.error('API错误:', data.message);
    // 处理错误
    return;
}

// 使用数据
console.log(data.data);
```

### 2. 播放授权缓存

播放授权有效期30分钟，前端应该缓存：

```javascript
let cachedPlayAuth = null;
let authExpiry = null;

async function getPlayAuth(episodeId) {
    // 检查缓存
    if (cachedPlayAuth && authExpiry && Date.now() < authExpiry) {
        return cachedPlayAuth;
    }
    
    // 获取新的授权
    const response = await fetch(`/api/telegram/play-auth/${episodeId}`);
    const data = await response.json();
    
    if (data.success) {
        cachedPlayAuth = data.playAuth;
        authExpiry = Date.now() + (data.expiresIn - 300) * 1000; // 提前5分钟过期
        return cachedPlayAuth;
    }
}
```

### 3. 观看进度自动保存

建议每5-10秒保存一次：

```javascript
let saveTimer = null;

player.on('timeupdate', () => {
    if (saveTimer) clearTimeout(saveTimer);
    
    saveTimer = setTimeout(async () => {
        await fetch('/api/telegram/watch-progress', {
            method: 'POST',
            body: JSON.stringify({
                dramaId: currentDramaId,
                episodeId: currentEpisodeId,
                videoId: currentVideoId,
                watchProgress: Math.floor(player.currentTime()),
                totalDuration: Math.floor(player.duration())
            })
        });
    }, 5000); // 5秒延迟
});
```

### 4. 支付验证轮询

TON 和 SUK 支付需要等待区块链确认：

```javascript
async function waitForPaymentConfirmation(orderId, txHash) {
    const maxAttempts = 60; // 最多等待5分钟
    const interval = 5000; // 每5秒检查一次
    
    for (let i = 0; i < maxAttempts; i++) {
        const response = await fetch('/api/telegram/verify-ton-payment', {
            method: 'POST',
            body: JSON.stringify({ orderId, transactionHash: txHash })
        });
        
        const data = await response.json();
        
        if (data.success && data.verified) {
            return true;
        }
        
        await new Promise(resolve => setTimeout(resolve, interval));
    }
    
    throw new Error('支付确认超时');
}
```

---

## 更新日志

### v1.0.0 (2024-11-15)

#### 新增
- ✅ Telegram Mini App 完整 API
- ✅ 三种支付方式（Stars / TON / SUK）
- ✅ TON 区块链交易验证
- ✅ SUK Token 交易验证
- ✅ 阿里云 VoD 播放授权集成
- ✅ 观看历史和续播功能
- ✅ 健康检查端点

#### 改进
- ✅ 播放授权 Redis 缓存
- ✅ 请求频率限制
- ✅ 详细的错误消息

---

## 技术支持

如有问题或建议，请联系：

- 📧 Email: api-support@drama-platform.io
- 📖 文档: https://docs.drama-platform.io
- 💬 Discord: https://discord.gg/drama-platform

---

**最后更新**: 2024-11-15  
**API版本**: v1.0.0
