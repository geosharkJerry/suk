# 阿里云VoD配置完整指南
# Aliyun Video on Demand (VoD) Setup Guide

> **本指南将帮助您从零开始配置阿里云视频点播服务，并集成到短剧平台。**

---

## 📋 目录 (Table of Contents)

1. [前置准备](#1-前置准备)
2. [阿里云账号设置](#2-阿里云账号设置)
3. [开通视频点播服务](#3-开通视频点播服务)
4. [创建AccessKey](#4-创建accesskey)
5. [配置转码模板](#5-配置转码模板)
6. [配置视频加密](#6-配置视频加密)
7. [绑定CDN域名](#7-绑定cdn域名)
8. [环境变量配置](#8-环境变量配置)
9. [测试VoD集成](#9-测试vod集成)
10. [常见问题](#10-常见问题)

---

## 1. 前置准备

### 1.1 需要准备的材料

- ✅ **阿里云账号**（未注册可访问 https://www.aliyun.com 注册）
- ✅ **实名认证**（个人或企业）
- ✅ **充值至少 100 元**（用于视频存储和流量费用）
- ✅ **域名**（用于CDN加速，可选但强烈推荐）
- ✅ **ICP备案**（如果使用中国大陆CDN节点，必须）

### 1.2 费用估算（参考价格）

| 服务项目 | 计费方式 | 参考价格 |
|---------|---------|---------|
| 视频存储 | 按存储容量 | 0.12元/GB/月 |
| 视频转码 | 按转码时长 | 0.065元/分钟（H.264 HD） |
| CDN流量 | 按流量消耗 | 0.24元/GB（阶梯定价） |
| 播放次数 | 免费 | - |

**示例成本计算**：
- 100部短剧，每部20集，每集5分钟
- 总时长：10,000分钟 = 约50GB存储
- 月存储费：50GB × 0.12元 = 6元
- 初次转码费：10,000分钟 × 0.065元 = 650元（一次性）
- 月流量费（假设10,000次播放）：500GB × 0.24元 = 120元

**总计：约776元/月（首月），126元/月（后续）**

---

## 2. 阿里云账号设置

### 2.1 注册阿里云账号

1. 访问 https://www.aliyun.com
2. 点击右上角"免费注册"
3. 使用手机号或邮箱注册
4. 完成手机/邮箱验证

### 2.2 实名认证

**为什么需要实名认证？**
- 开通视频点播服务的必要条件
- 享受新用户优惠券
- 提高账号安全性

**认证步骤**：

1. 登录阿里云控制台
2. 点击右上角头像 → "实名认证"
3. 选择认证类型：
   - **个人认证**：需要身份证照片
   - **企业认证**：需要营业执照、法人身份证
4. 上传证件照片
5. 等待审核（通常1-3小时）

### 2.3 账号充值

1. 进入"费用中心" → "充值"
2. 选择充值金额（建议至少100元）
3. 选择支付方式（支付宝/微信/银行卡）
4. 完成支付

---

## 3. 开通视频点播服务

### 3.1 进入视频点播控制台

1. 登录阿里云控制台：https://vod.console.aliyun.com
2. 首次访问会提示"开通视频点播服务"
3. 点击"立即开通"

### 3.2 选择计费方式

阿里云VoD提供两种计费模式：

#### **按量付费（推荐）**
- ✅ 适合流量不稳定的业务
- ✅ 无最低消费
- ✅ 用多少付多少
- ❌ 单价略高

#### **资源包**
- ✅ 适合流量稳定的业务
- ✅ 单价更便宜
- ❌ 需要预先购买
- ❌ 用不完会浪费

**建议**：初期使用**按量付费**，业务稳定后购买资源包。

### 3.3 确认开通

1. 阅读并同意服务协议
2. 点击"立即开通"
3. 等待服务开通（即时生效）

### 3.4 验证开通成功

1. 进入视频点播控制台：https://vod.console.aliyun.com
2. 看到"概览"页面即为开通成功
3. 记录您的**服务区域**（如：华东2（上海））

---

## 4. 创建AccessKey

### 4.1 为什么需要AccessKey？

AccessKey（访问密钥）是调用阿里云API的凭证，包括：
- **AccessKey ID**：公开的标识符
- **AccessKey Secret**：私密的密钥（相当于密码）

### 4.2 创建RAM子账号（推荐方式）

**为什么使用子账号？**
- ✅ 遵循最小权限原则
- ✅ 主账号泄露不影响业务
- ✅ 可以随时禁用/删除

**创建步骤**：

#### Step 1: 进入RAM控制台
```
https://ram.console.aliyun.com/users
```

#### Step 2: 创建用户
1. 点击"创建用户"
2. 填写信息：
   - 登录名称：`vod-api-user`
   - 显示名称：`视频点播API用户`
   - 访问方式：✅ 勾选"OpenAPI调用访问"
3. 点击"确定"

#### Step 3: 保存AccessKey
⚠️ **重要：AccessKey Secret只显示一次，请立即保存！**

复制并保存：
```
AccessKey ID:     LTAI5txxxxxxxxxxxxxxxxxx
AccessKey Secret: xxxxxxxxxxxxxxxxxxxxxxxxxxx
```

#### Step 4: 授予VoD权限
1. 在用户列表中找到刚创建的用户
2. 点击"添加权限"
3. 搜索并选择：`AliyunVODFullAccess`（视频点播完全权限）
4. 点击"确定"

### 4.3 使用主账号AccessKey（不推荐）

如果暂时不想创建子账号，可以使用主账号AccessKey：

1. 访问：https://usercenter.console.aliyun.com/#/manage/ak
2. 点击"创建AccessKey"
3. 完成手机验证
4. 保存AccessKey ID和Secret

⚠️ **警告**：主账号拥有所有权限，泄露风险极高，仅用于测试！

---

## 5. 配置转码模板

### 5.1 为什么需要转码？

- ✅ 适配不同设备（手机、平板、PC）
- ✅ 优化播放流畅度
- ✅ 减少流量消耗
- ✅ **支持竖屏短剧（9:16）格式**

### 5.2 创建竖屏短剧转码模板

#### Step 1: 进入转码设置
```
视频点播控制台 → 配置管理 → 媒体处理配置 → 转码模板组
```

#### Step 2: 创建模板组
1. 点击"添加转码模板组"
2. 模板组名称：`短剧竖屏模板`

#### Step 3: 添加转码模板

**模板1: 流畅 SD（480P）**
```
名称：        短剧_流畅_480P
视频编码：    H.264
视频码率：    500 Kbps
分辨率：      540x960 (9:16竖屏)
帧率：        25 fps
音频编码：    AAC
音频码率：    64 Kbps
```

**模板2: 高清 HD（720P）**
```
名称：        短剧_高清_720P
视频编码：    H.264
视频码率：    1000 Kbps
分辨率：      810x1440 (9:16竖屏)
帧率：        25 fps
音频编码：    AAC
音频码率：    128 Kbps
```

**模板3: 超清 FHD（1080P）**
```
名称：        短剧_超清_1080P
视频编码：    H.264
视频码率：    2000 Kbps
分辨率：      1080x1920 (9:16竖屏)
帧率：        30 fps
音频编码：    AAC
音频码率：    192 Kbps
```

#### Step 4: 保存模板组
1. 点击"确定"
2. 记录**模板组ID**（形如：`ca3a8f6e49975a6f90e0xxxxxx`）

### 5.3 设置为默认模板组

1. 在模板组列表中找到刚创建的模板组
2. 点击"设置为默认"
3. 之后上传的视频会自动使用此模板转码

---

## 6. 配置视频加密

### 6.1 为什么需要加密？

- ✅ 防止视频被盗链下载
- ✅ 保护版权内容
- ✅ 仅允许授权用户观看
- ✅ 符合内容安全要求

### 6.2 选择加密方式

阿里云VoD支持两种加密方式：

| 加密方式 | 安全性 | 兼容性 | 推荐度 |
|---------|-------|-------|-------|
| **HLS标准加密** | ⭐⭐⭐ | 所有设备 | ⭐⭐⭐⭐⭐ |
| 阿里云私有加密 | ⭐⭐⭐⭐⭐ | 需专用播放器 | ⭐⭐⭐ |

**推荐使用：HLS标准加密**（已在项目中实现）

### 6.3 开启HLS加密

#### Step 1: 进入加密设置
```
视频点播控制台 → 配置管理 → 媒体处理配置 → 加密与安全
```

#### Step 2: 开启HLS加密
1. 找到"HLS标准加密"
2. 点击"开启"
3. 系统会自动生成密钥管理服务

#### Step 3: 配置密钥服务
1. 阿里云会自动创建KMS（密钥管理服务）
2. 无需手动配置，默认设置即可
3. 确认状态为"已开启"

### 6.4 在转码模板中启用加密

返回转码模板设置：
1. 编辑之前创建的"短剧竖屏模板"
2. 在每个转码模板中：
   - 加密方式：选择"HLS标准加密"
3. 保存设置

---

## 7. 绑定CDN域名

### 7.1 为什么需要CDN？

- ✅ 加速视频加载速度
- ✅ 减少源站带宽压力
- ✅ 提升用户体验
- ✅ 降低流量成本（CDN流量更便宜）

### 7.2 准备域名

**要求**：
- 已完成ICP备案（中国大陆必须）
- 可以修改DNS解析记录

**示例域名**：
- 主站：`www.your-drama-platform.com`
- CDN域名：`video.your-drama-platform.com`

### 7.3 添加CDN域名

#### Step 1: 进入域名管理
```
视频点播控制台 → 配置管理 → 分发加速配置 → 域名管理
```

#### Step 2: 添加域名
1. 点击"添加域名"
2. 填写信息：
   ```
   加速域名：   video.your-drama-platform.com
   业务类型：   视音频点播
   源站类型：   VoD域名（自动）
   加速区域：   仅中国大陆 / 全球
   ```
3. 点击"下一步"

#### Step 3: 配置CNAME
系统会分配一个CNAME记录，形如：
```
video.your-drama-platform.com.w.kunlunsl.com
```

#### Step 4: 修改DNS解析
在您的域名服务商（如阿里云、腾讯云、Cloudflare）添加CNAME记录：

```
记录类型：  CNAME
主机记录：  video
记录值：    video.your-drama-platform.com.w.kunlunsl.com
TTL：       10分钟
```

#### Step 5: 验证CNAME生效
等待5-10分钟后，执行命令验证：
```bash
nslookup video.your-drama-platform.com
```

看到返回CNAME记录即为成功。

### 7.4 配置HTTPS（推荐）

#### 申请SSL证书
1. 在阿里云SSL证书服务申请免费证书
2. 或使用Let's Encrypt免费证书

#### 上传证书到VoD
1. 视频点播控制台 → 域名管理
2. 点击您的域名 → HTTPS配置
3. 点击"修改配置"
4. 上传证书：
   - 证书名称：`video-cert`
   - 证书内容：粘贴 `.crt` 文件内容
   - 私钥内容：粘贴 `.key` 文件内容
5. 开启"强制HTTPS跳转"
6. 保存配置

---

## 8. 环境变量配置

### 8.1 复制配置文件

```bash
cd /path/to/your/project
cp .env.example .env
```

### 8.2 编辑 .env 文件

使用文本编辑器打开 `.env`：

```bash
nano .env
# 或
vim .env
```

### 8.3 填写阿里云VoD配置

根据前面步骤获取的信息填写：

```bash
# ============================================
# 阿里云VoD配置
# ============================================

# AccessKey（第4步获取）
ALIYUN_ACCESS_KEY_ID=LTAI5txxxxxxxxxxxxxxxxxx
ALIYUN_ACCESS_KEY_SECRET=xxxxxxxxxxxxxxxxxxxxxxxxxxx

# VoD服务区域（第3步记录的区域）
ALIYUN_VOD_REGION=cn-shanghai

# VoD API端点（通常不需要修改）
ALIYUN_VOD_ENDPOINT=https://vod.cn-shanghai.aliyuncs.com
ALIYUN_VOD_API_VERSION=2017-03-21

# 转码模板组ID（第5步获取，可选）
ALIYUN_VOD_TEMPLATE_GROUP_ID=ca3a8f6e49975a6f90e0xxxxxx

# 播放授权超时时间（秒）
PLAY_AUTH_TIMEOUT=1800
# 播放授权缓存时间（秒，必须小于PLAY_AUTH_TIMEOUT）
PLAY_AUTH_CACHE_TTL=1500

# 视频加密类型（0=不加密，1=HLS标准加密）
VIDEO_ENCRYPT_TYPE=1
```

### 8.4 配置其他必需项

```bash
# MongoDB数据库
MONGODB_URI=mongodb://localhost:27017/short_drama_platform

# Redis缓存
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=

# JWT密钥（务必修改！）
JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(64).toString('hex'))")

# SUK代币合约地址
SUK_TOKEN_CONTRACT=0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb

# 平台钱包地址
PLATFORM_WALLET_ADDRESS=0x_your_wallet_address_here

# 以太坊RPC节点
ETH_RPC_URL=https://mainnet.infura.io/v3/your_infura_project_id
```

### 8.5 设置文件权限（Linux/Mac）

```bash
chmod 600 .env
```

这确保只有当前用户可以读取配置文件。

### 8.6 验证配置

创建测试脚本 `scripts/test-env.js`：

```javascript
require('dotenv').config();

console.log('✅ 环境变量加载测试\n');

const requiredVars = [
    'ALIYUN_ACCESS_KEY_ID',
    'ALIYUN_ACCESS_KEY_SECRET',
    'MONGODB_URI',
    'JWT_SECRET',
    'SUK_TOKEN_CONTRACT'
];

let allValid = true;

requiredVars.forEach(varName => {
    const value = process.env[varName];
    if (!value || value.includes('your_') || value.includes('change_this')) {
        console.log(`❌ ${varName}: 未配置或使用示例值`);
        allValid = false;
    } else {
        console.log(`✅ ${varName}: 已配置`);
    }
});

console.log('\n' + (allValid ? '🎉 所有配置项已正确设置！' : '⚠️  请完成配置后再启动应用'));
```

运行测试：
```bash
node scripts/test-env.js
```

---

## 9. 测试VoD集成

### 9.1 测试视频上传

创建测试脚本 `scripts/test-vod-upload.js`：

```javascript
const AliyunVoDService = require('../backend/services/aliyun-vod.service');

async function testUpload() {
    try {
        console.log('🧪 测试阿里云VoD上传功能\n');

        const vodService = new AliyunVoDService();

        // 获取上传凭证
        console.log('1️⃣ 获取上传凭证...');
        const uploadAuth = await vodService.getUploadAuth(
            '测试视频', 
            'test-video.mp4'
        );

        console.log('✅ 上传凭证获取成功！');
        console.log('VideoId:', uploadAuth.videoId);
        console.log('UploadAddress:', uploadAuth.uploadAddress.substring(0, 50) + '...');
        console.log('UploadAuth:', uploadAuth.uploadAuth.substring(0, 50) + '...');

        console.log('\n✅ VoD上传功能测试通过！');
        console.log('💡 提示：使用阿里云客户端SDK上传视频时需要这些凭证');

    } catch (error) {
        console.error('❌ 测试失败:', error.message);
        process.exit(1);
    }
}

testUpload();
```

运行测试：
```bash
node scripts/test-vod-upload.js
```

### 9.2 测试播放授权生成

创建测试脚本 `scripts/test-vod-playauth.js`：

```javascript
const AliyunVoDService = require('../backend/services/aliyun-vod.service');

async function testPlayAuth() {
    try {
        console.log('🧪 测试播放授权生成\n');

        const vodService = new AliyunVoDService();

        // 替换为您已上传的视频ID
        const testVideoId = 'your_test_video_id_here';

        console.log('1️⃣ 生成播放授权...');
        const playAuth = await vodService.generatePlayAuth(testVideoId, 1800);

        console.log('✅ 播放授权生成成功！');
        console.log('PlayAuth:', playAuth.substring(0, 100) + '...');
        console.log('有效期: 30分钟');

        console.log('\n2️⃣ 获取视频信息...');
        const videoInfo = await vodService.getVideoInfo(testVideoId);

        console.log('✅ 视频信息获取成功！');
        console.log('视频标题:', videoInfo.title);
        console.log('视频时长:', videoInfo.duration, '秒');
        console.log('视频状态:', videoInfo.status);

        console.log('\n✅ VoD播放授权测试通过！');

    } catch (error) {
        console.error('❌ 测试失败:', error.message);
        if (error.message.includes('InvalidVideo.NotFound')) {
            console.log('💡 提示：请先上传一个测试视频，并将VideoId替换到脚本中');
        }
        process.exit(1);
    }
}

testPlayAuth();
```

运行测试：
```bash
node scripts/test-vod-playauth.js
```

### 9.3 前端播放器测试

1. 上传一个测试视频到阿里云VoD
2. 获取视频的VideoId
3. 打开 `drama-player-aliyun.html`
4. 修改测试代码：

```javascript
// 测试配置
const testConfig = {
    videoId: 'your_test_video_id',
    playAuth: 'generated_play_auth_token'
};

// 初始化播放器
const player = new Aliplayer({
    id: 'player-container',
    width: '100%',
    height: '100%',
    autoplay: true,
    vid: testConfig.videoId,
    playauth: testConfig.playAuth,
    encryptType: 1
});
```

5. 在浏览器中打开页面，验证视频是否正常播放

---

## 10. 常见问题

### 10.1 AccessKey无法使用

**问题**：调用API时返回"InvalidAccessKeyId.NotFound"

**解决方案**：
1. 检查AccessKey ID和Secret是否正确复制（注意空格）
2. 确认RAM子账号已授予`AliyunVODFullAccess`权限
3. 等待5分钟让权限生效
4. 检查AccessKey是否已被禁用或删除

### 10.2 视频上传失败

**问题**：上传视频时报错"InvalidParameter"

**解决方案**：
1. 检查视频格式是否支持（MP4、FLV、AVI等）
2. 检查视频大小是否超过限制（默认最大48.8TB）
3. 确认已开通视频点播服务
4. 检查账号余额是否充足

### 10.3 播放授权无法使用

**问题**：前端播放器报错"InvalidPlayAuth"

**解决方案**：
1. 检查PlayAuth是否已过期（默认30分钟）
2. 确认VideoId是否正确
3. 检查视频状态是否为"Normal"（转码完成）
4. 确认视频所在区域与配置的region一致

### 10.4 视频无法播放

**问题**：播放器黑屏或无限加载

**解决方案**：
1. 等待视频转码完成（新上传的视频需要3-10分钟）
2. 检查浏览器控制台是否有错误信息
3. 确认已正确加载Aliyun Prism Player SDK
4. 检查网络是否可以访问阿里云CDN
5. 如果启用了加密，确认encryptType参数正确

### 10.5 转码失败

**问题**：视频上传后状态为"转码失败"

**解决方案**：
1. 检查视频源文件是否损坏
2. 确认转码模板配置是否正确
3. 查看VoD控制台的错误日志
4. 尝试重新发起转码任务
5. 联系阿里云技术支持

### 10.6 CDN域名无法访问

**问题**：配置CDN后视频仍然无法加载

**解决方案**：
1. 检查CNAME解析是否生效（`nslookup`命令）
2. 等待DNS传播（最多24小时）
3. 确认域名已完成ICP备案
4. 检查CDN域名状态是否为"运行中"
5. 清除CDN缓存后重试

### 10.7 费用异常增长

**问题**：账单金额超出预期

**解决方案**：
1. 检查是否有恶意盗链（配置防盗链）
2. 启用CDN缓存减少回源流量
3. 优化转码模板减少码率
4. 设置费用预警（阿里云费用中心）
5. 考虑购买资源包降低单价

---

## 📞 获取帮助

### 官方文档
- 阿里云VoD文档：https://help.aliyun.com/product/29932.html
- API参考：https://help.aliyun.com/document_detail/61063.html
- SDK下载：https://help.aliyun.com/document_detail/51992.html

### 技术支持
- 工单系统：https://workorder.console.aliyun.com
- 技术论坛：https://developer.aliyun.com/ask/
- 电话支持：95187转1

### 项目支持
- GitHub Issues：（您的项目仓库地址）
- 技术文档：README.md
- 部署指南：DEPLOYMENT_GUIDE.md

---

## ✅ 配置检查清单

完成以下所有步骤后，您的阿里云VoD即可正常使用：

- [ ] 阿里云账号已注册并实名认证
- [ ] 视频点播服务已开通
- [ ] 创建了RAM子账号并获取AccessKey
- [ ] 配置了竖屏短剧转码模板
- [ ] 开启了HLS标准加密
- [ ] 绑定了CDN域名（可选但推荐）
- [ ] 配置了HTTPS证书（可选但推荐）
- [ ] `.env`文件已正确配置
- [ ] 测试脚本运行成功
- [ ] 前端播放器测试通过

**恭喜！您已完成阿里云VoD的完整配置！🎉**

---

*最后更新时间：2024-11-15*
*文档版本：v1.0*
