# SUK 空投系统 V2.0 升级指南

## 📅 更新日期
2024-11-17

## 🎯 重大更新

### 核心变化

#### 1. 空投总量调整
- **旧版本 (V1)**: 100万 SUK
- **新版本 (V2)**: **5000万 SUK** ✨

#### 2. 邀请码激活系统
全新的邀请码激活机制，替代原有的白名单系统：

- ✅ **官方邀请码生成**: 管理员统一生成邀请码
- ✅ **邀请码验证**: 用户输入邀请码进行激活
- ✅ **一次性使用**: 每个邀请码只能使用一次
- ✅ **3个月有效期**: 邀请码从生成起 90 天内有效
- ✅ **自动失效**: 过期或使用后自动失效

#### 3. 领取方式

**方式一：邀请码激活（白名单）**
- 获取条件：使用官方邀请码激活
- 奖励金额：**5,000 SUK**
- 激活流程：
  1. 获得官方邀请码
  2. 在前端页面输入邀请码
  3. 验证通过后自动加入白名单
  4. 可领取 5,000 SUK

**方式二：推荐购买（普通用户）**
- 获取条件：通过已激活用户的推荐链接投资
- 奖励金额：**1,000 SUK**
- 参与流程：
  1. 通过推荐链接访问平台
  2. 完成投资（购买 SUK 代币）
  3. 系统自动注册推荐关系
  4. 1,000 SUK 自动发送到用户钱包

---

## 📦 新增文件

### 智能合约

#### 1. contracts/SUKAirdropV2.sol (14.7 KB)
**全新的空投合约，支持邀请码系统**

核心功能：
```solidity
// 邀请码管理
generateInviteCode(string code)                    // 生成单个邀请码
batchGenerateInviteCodes(string[] codes)           // 批量生成邀请码
activateInviteCode(string code)                    // 用户激活邀请码

// 推荐关系
registerReferral(address referrer, uint256 amount) // 注册推荐关系

// 空投领取
claim()                                            // 领取空投

// 查询接口
isInviteCodeValid(string code)                     // 验证邀请码
getInviteCodeInfo(string code)                     // 获取邀请码信息
getClaimableAmount(address user)                   // 获取可领取金额
```

关键参数：
- 总空投量：50,000,000 SUK
- 白名单额度：5,000 SUK
- 推荐额度：1,000 SUK
- 邀请码有效期：90 天

### 部署脚本

#### 2. scripts/deploy-airdrop-v2.js (8.7 KB)
**部署 SUKAirdropV2 合约**

使用方法：
```bash
npx hardhat run scripts/deploy-airdrop-v2.js --network goerli
```

功能：
- 自动查找 SUKToken 地址
- 配置空投时间参数
- 部署并验证合约
- 保存部署信息

#### 3. scripts/fund-airdrop-v2.js (7.4 KB)
**向空投合约转账 5000万 SUK**

使用方法：
```bash
npx hardhat run scripts/fund-airdrop-v2.js --network goerli
```

功能：
- 自动计算需要转账的金额
- 验证余额充足
- 执行转账并确认
- 保存转账记录

### 邀请码管理

#### 4. scripts/generate-invite-codes.js (8.2 KB)
**邀请码生成和管理脚本**

使用方法：
```bash
# 生成 1000 个邀请码
node scripts/generate-invite-codes.js 1000

# 生成并部署到合约
node scripts/generate-invite-codes.js 1000 --network goerli --deploy
```

功能：
- 生成唯一随机邀请码
- 保存到 CSV 和 JSON 文件
- 批量部署到智能合约
- 避免重复和冲突

邀请码规则：
- 长度：12 位
- 字符集：大写字母和数字（排除易混淆字符）
- 示例：`ABC123XYZ789`

### 前端页面

#### 5. suk-airdrop-v2.html (25.4 KB)
**全新的空投前端页面**

功能特性：
- 🎫 邀请码输入和激活
- 👥 推荐链接生成和分享
- 📊 实时统计数据显示
- 💰 一键领取空投
- 🔗 MetaMask 钱包集成
- 📱 响应式设计

用户体验：
1. 连接 MetaMask 钱包
2. 选择参与方式：
   - 输入邀请码激活（5,000 SUK）
   - 通过推荐链接投资（1,000 SUK）
3. 完成激活或注册
4. 一键领取空投

---

## 🚀 完整部署流程

### 第一步：编译合约

```bash
npx hardhat compile
```

### 第二步：部署 SUKAirdropV2

```bash
# 部署到 Goerli 测试网
npx hardhat run scripts/deploy-airdrop-v2.js --network goerli

# 记录输出的合约地址
```

### 第三步：转账到空投合约

```bash
# 转账 5000万 SUK
npx hardhat run scripts/fund-airdrop-v2.js --network goerli
```

### 第四步：生成邀请码

```bash
# 生成 10000 个邀请码并部署
node scripts/generate-invite-codes.js 10000 --network goerli --deploy
```

### 第五步：验证合约

```bash
npx hardhat verify --network goerli <AIRDROP_ADDRESS> "<TOKEN_ADDRESS>" <START_TIME> <END_TIME>
```

### 第六步：更新前端配置

```bash
node scripts/update-frontend-config.js goerli <TOKEN_ADDRESS> <AIRDROP_ADDRESS>
```

### 第七步：启动测试

```bash
# 启动本地服务器
python -m http.server 8000

# 访问空投页面
http://localhost:8000/suk-airdrop-v2.html
```

---

## 🔧 邀请码管理

### 生成邀请码

```bash
# 生成 1000 个邀请码（仅保存文件）
node scripts/generate-invite-codes.js 1000

# 生成 1000 个邀请码并部署到合约
node scripts/generate-invite-codes.js 1000 --network goerli --deploy
```

### 邀请码文件格式

**CSV 文件** (`deployment/invite-codes/invite-codes-goerli-*.csv`):
```csv
invite_code,generated_at,status,activated_by,activated_at
ABC123XYZ789,2024-11-17T12:00:00Z,pending,,
DEF456UVW012,2024-11-17T12:00:00Z,pending,,
```

**JSON 文件** (`deployment/invite-codes/invite-codes-goerli-*.json`):
```json
{
  "total": 1000,
  "generatedAt": "2024-11-17T12:00:00Z",
  "codes": [
    {
      "code": "ABC123XYZ789",
      "status": "pending",
      "activatedBy": null,
      "activatedAt": null
    }
  ]
}
```

### 邀请码分发

1. **导出邀请码列表**
   ```bash
   cat deployment/invite-codes/invite-codes-goerli-*.csv
   ```

2. **分发给用户**
   - 通过邮件发送
   - 在社交媒体发布
   - 在官方网站展示
   - 通过客服分发

3. **追踪使用情况**
   - 查看合约事件日志
   - 更新 CSV 文件状态
   - 生成使用报告

---

## 📊 数据结构对比

### V1 (旧版本)

```javascript
{
  totalAirdrop: "1,000,000 SUK",
  whitelistAmount: "5,000 SUK",
  publicAmount: "3,000 SUK",
  mechanism: "白名单 + 公开认领"
}
```

### V2 (新版本)

```javascript
{
  totalAirdrop: "50,000,000 SUK",
  whitelistAmount: "5,000 SUK",  // 邀请码激活
  referralAmount: "1,000 SUK",   // 推荐购买
  inviteCodeValidity: "90 days",
  mechanism: "邀请码激活 + 推荐购买"
}
```

---

## 🎓 用户使用指南

### 白名单用户（邀请码激活）

1. **获取邀请码**
   - 通过官方渠道获得邀请码
   - 邀请码格式：12 位大写字母+数字

2. **激活邀请码**
   - 访问空投页面
   - 连接 MetaMask 钱包
   - 输入邀请码
   - 点击"激活邀请码"

3. **领取空投**
   - 激活成功后显示"白名单已激活"
   - 点击"立即领取 5,000 SUK"
   - 确认 MetaMask 交易
   - 5,000 SUK 发送到钱包

4. **推荐好友**
   - 获取个人推荐链接
   - 分享给好友
   - 好友通过链接投资可获得 1,000 SUK

### 普通用户（推荐购买）

1. **通过推荐链接访问**
   - 点击好友分享的推荐链接
   - 链接格式：`https://suk.link?ref=0x钱包地址`

2. **完成投资**
   - 连接 MetaMask 钱包
   - 确认推荐人信息
   - 输入投资金额
   - 点击"确认投资并注册"

3. **自动注册**
   - 系统自动记录推荐关系
   - 投资金额会被记录

4. **领取空投**
   - 注册成功后显示"推荐用户"状态
   - 点击"立即领取 1,000 SUK"
   - 确认交易
   - 1,000 SUK 发送到钱包

---

## ⚠️ 重要提示

### 邀请码安全

- ✅ 每个邀请码只能使用一次
- ✅ 邀请码有 3 个月有效期
- ✅ 过期或使用后自动失效
- ⚠️ 不要分享您的邀请码截图（防止被盗用）
- ⚠️ 通过官方渠道获取邀请码

### 推荐链接

- ✅ 推荐链接包含您的钱包地址
- ✅ 可以分享给多个好友
- ⚠️ 好友必须通过推荐链接访问并投资
- ⚠️ 投资金额会被记录在链上

### Gas 费用

- ⚠️ 激活邀请码需要支付 Gas 费
- ⚠️ 领取空投需要支付 Gas 费
- ⚠️ 确保钱包中有足够的 ETH 支付 Gas

---

## 📞 技术支持

### 常见问题

**Q: 如何获取邀请码？**
A: 通过官方渠道（社交媒体、邮件、活动等）获取

**Q: 邀请码无效怎么办？**
A: 检查邀请码是否正确，是否已过期或被使用

**Q: 可以多次领取吗？**
A: 不可以，每个地址只能领取一次

**Q: 推荐人能获得奖励吗？**
A: 推荐人不直接获得奖励，但可以帮助好友获得 1,000 SUK

**Q: 投资金额有最低要求吗？**
A: 具体最低投资金额由平台设定

### 获取帮助

- 📖 查看完整文档
- 💬 加入社区讨论
- 📧 联系客服支持
- 🐛 报告问题

---

## 🎉 总结

SUK 空投系统 V2.0 带来了重大升级：

✅ **空投总量增加 50 倍** - 从 100万 增至 5000万 SUK  
✅ **邀请码激活机制** - 更公平、更安全的分发方式  
✅ **推荐购买系统** - 激励用户参与投资和推广  
✅ **3个月有效期** - 给用户充足的激活时间  
✅ **完整的管理工具** - 邀请码生成、部署、追踪  

现在就开始部署 V2 系统，享受全新的空投体验！🚀

---

**文档版本**: V2.0  
**更新日期**: 2024-11-17  
**状态**: ✅ 就绪可用
