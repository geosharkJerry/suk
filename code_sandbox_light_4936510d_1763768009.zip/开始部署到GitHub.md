# 🚀 立即开始部署到 GitHub

> **目标仓库**: https://github.com/geosharkJerry/suk  
> **一键部署**: 3 分钟快速上线

---

## ⚡ 最快部署方式

### 方法一：一键脚本（推荐）✨

#### Windows 用户
```batch
# 双击运行
deploy-to-github.bat
```

#### macOS / Linux 用户
```bash
# 赋予执行权限并运行
chmod +x deploy-to-github.sh
./deploy-to-github.sh
```

**就是这么简单！脚本会自动完成：**
- ✅ 检查 Git 环境
- ✅ 初始化仓库（如果需要）
- ✅ 配置用户信息
- ✅ 添加远程仓库
- ✅ 提交所有文件
- ✅ 推送到 GitHub

---

### 方法二：手动命令（5 条命令）

```bash
# 1️⃣ 初始化 Git
git init

# 2️⃣ 添加远程仓库
git remote add origin https://github.com/geosharkJerry/suk.git

# 3️⃣ 添加所有文件
git add .

# 4️⃣ 提交更改
git commit -m "🚀 Deploy SUK Protocol"

# 5️⃣ 推送到 GitHub
git push -u origin main
```

---

## 🌐 连接 Cloudflare Pages（3 步骤）

### 步骤 1️⃣: 打开 Cloudflare
访问：https://dash.cloudflare.com/

### 步骤 2️⃣: 创建 Pages 项目
1. 点击 **Workers & Pages**
2. 点击 **Create application**
3. 选择 **Pages** → **Connect to Git**
4. 选择 **GitHub**
5. 选择仓库：**geosharkJerry/suk**

### 步骤 3️⃣: 配置并部署
```
项目名称: suk-protocol
生产分支: main
构建命令: [留空]
输出目录: .
```

点击 **Save and Deploy** ✨

---

## ✅ 完成！

**您的网站现已上线：**
- 🌍 生产环境: https://suk-protocol.pages.dev
- 🔗 GitHub 仓库: https://github.com/geosharkJerry/suk

---

## 📖 需要详细指南？

| 文档 | 内容 |
|------|------|
| **GITHUB_DEPLOYMENT_GUIDE.md** | 完整部署指南 (20 KB) |
| **CLOUDFLARE_快速部署指南.md** | 快速部署步骤 (6 KB) |
| **CLOUDFLARE_自定义域名配置指南.md** | 域名配置说明 (18 KB) |
| **DEPLOYMENT_TO_GITHUB_SUMMARY.md** | 部署完成总结 (19 KB) |

---

## 🚨 遇到问题？

### Git 未安装
**下载安装**: https://git-scm.com/downloads

### 推送失败
```bash
# 使用 Personal Access Token
# 1. 访问: https://github.com/settings/tokens
# 2. 生成新 token (勾选 repo 权限)
# 3. 使用 token 作为密码推送
```

### 需要帮助
- 📖 查看 `GITHUB_DEPLOYMENT_GUIDE.md`
- 🐛 提交 Issue: https://github.com/geosharkJerry/suk/issues

---

**🎉 开始您的部署之旅！**

```bash
# 一行命令开始
./deploy-to-github.sh  # macOS/Linux
deploy-to-github.bat    # Windows
```

---

*最后更新: 2024-11-20*
