# SUK奖励系统 - 快速参考指南

> 🚀 一页纸速查手册 - 5分钟掌握核心要点

---

## 🎯 系统概览

**SUK奖励系统** = 观看奖励（1%）+ 邀请奖励（7%）

```
telegram-app.html        → 奖励中心入口 + 邀请分享 + 邀请码检测
telegram-player-*.html   → 观看奖励自动记录
telegram-reward-center   → 奖励统计和管理
```

---

## 📱 主要功能

### 1. 观看奖励（1%）

**公式**: `(观看时长 / 总时长) × 单集价格 × 1%`

**示例**: 观看240秒/共300秒，单集99 SUK
```
奖励 = (240/300) × 99 × 0.01 = 0.792 SUK
```

**触发时机**:
- ✅ 视频播放结束
- ✅ 用户关闭页面（beforeunload）
- ⚠️ 至少观看5秒才记录

---

### 2. 邀请奖励（7%）

**公式**: `被邀请人购买金额 × 7%`

**示例**: 被邀请人购买129 SUK
```
邀请人奖励 = 129 × 0.07 = 9.03 SUK
```

**前置条件**:
- ⚠️ 邀请人必须绑定钱包地址
- ✅ 一键生成唯一邀请码（SUKXXXXX格式）
- ✅ Telegram原生分享

---

## 🔑 核心API

### 1. 记录观看奖励
```http
POST /api/rewards/watch
Headers: X-Telegram-Init-Data: {tg.initData}
Body: {
  "dramaId": "64a1b2c3d4e5f6",
  "episodeId": "ep001",
  "watchDuration": 240,
  "totalDuration": 300
}
```

### 2. 生成邀请码
```http
POST /api/rewards/invite/code
Headers: X-Telegram-Init-Data: {tg.initData}
Response: {
  "success": true,
  "data": {
    "inviteCode": "SUK3F2A1",
    "inviteLink": "https://your-domain.com/telegram-app.html?inviteCode=SUK3F2A1"
  }
}
```

### 3. 使用邀请码
```http
POST /api/rewards/invite/use
Headers: X-Telegram-Init-Data: {tg.initData}
Body: { "inviteCode": "SUK3F2A1" }
```

---

## 🚀 快速集成

### 后端（已完成）✅

```javascript
// server.js
const rewardRoutes = require('./backend/routes/reward.routes');
app.use('/api/rewards', rewardRoutes);
```

### 前端（已完成）✅

**主页** - telegram-app.html
```javascript
// 已有功能：
✅ 奖励中心按钮 → openRewardCenter()
✅ 邀请分享按钮 → openInviteShare()
✅ 邀请码自动检测 → checkAndUseInviteCode()
```

**播放器** - telegram-player-optimized.html
```javascript
// 已有功能：
✅ 视频结束记录 → player.on('ended')
✅ 页面离开记录 → window.addEventListener('beforeunload')
✅ 奖励Toast提示 → showRewardToast()
```

---

## 🎨 用户界面

### 主页 - 用户卡片
```
┌─────────────────────────────┐
│  👤 张三                     │
│  @zhangsan                  │
│                             │
│  [💰 我的奖励] [👥 邀请好友]  │
└─────────────────────────────┘
```

### 播放器 - 奖励Toast
```
┌─────────────────────────────┐
│  🎁  观看奖励               │
│      +0.7920 SUK           │
└─────────────────────────────┘
       ↓ 3秒后自动消失
```

### 奖励中心 - 三个标签
```
[📺 观看奖励] [👥 邀请奖励] [🎯 我的邀请]
```

---

## 🔒 安全机制

### 1. 反作弊验证（0-100评分）

```javascript
初始分数: 100
- 观看时长 > 总时长: -50分
- 观看进度 < 5%: -20分
- 1分钟内超过5次: -30分
- 待审核超过100条: -20分

评分 ≥ 50 → 待审核（pending）
评分 < 50 → 自动拒绝（rejected）
```

### 2. 重复操作防护

- ✅ 每人只能被邀请一次（inviteeId唯一索引）
- ✅ 不能邀请自己（后端验证）
- ✅ 邀请码需绑定钱包（前置检查）

---

## 📊 数据模型速览

### WatchReward（观看奖励）
```javascript
{
  userId: String,           // Telegram用户ID
  dramaId: ObjectId,       // 短剧ID
  episodeId: String,       // 集数
  watchDuration: Number,   // 观看秒数
  totalDuration: Number,   // 总秒数
  rewardAmount: Number,    // 奖励金额
  status: String,          // pending/approved/paid/rejected
  validationScore: Number  // 反作弊分数 0-100
}
```

### InviteReward（邀请奖励）
```javascript
{
  inviterId: String,        // 邀请人ID
  inviterWallet: String,    // 邀请人钱包（必需）
  inviteeId: String,       // 被邀请人ID
  purchaseAmount: Number,   // 购买金额
  rewardAmount: Number,     // 7%奖励
  status: String           // pending/approved/paid/rejected
}
```

### InviteRelation（邀请关系）
```javascript
{
  inviterId: String,
  inviteeId: String,        // 唯一索引
  inviteCode: String,       // SUKXXXXX
  status: String            // registered/bound/purchased
}
```

---

## 🧪 测试命令

### 测试观看奖励
```bash
curl -X POST http://localhost:3000/api/rewards/watch \
  -H "Content-Type: application/json" \
  -H "X-Telegram-Init-Data: user=%7B%22id%22%3A123456789%7D" \
  -d '{
    "dramaId": "64a1b2c3d4e5f6",
    "episodeId": "ep001",
    "watchDuration": 240,
    "totalDuration": 300
  }'
```

### 测试生成邀请码
```bash
curl -X POST http://localhost:3000/api/rewards/invite/code \
  -H "X-Telegram-Init-Data: user=%7B%22id%22%3A123456789%7D"
```

### 测试使用邀请码
```bash
curl -X POST http://localhost:3000/api/rewards/invite/use \
  -H "Content-Type: application/json" \
  -H "X-Telegram-Init-Data: user=%7B%22id%22%3A987654321%7D" \
  -d '{"inviteCode": "SUK3F2A1"}'
```

---

## 🔍 问题排查

### Q: 观看奖励没有记录？
```
检查清单：
[ ] 观看时长 ≥ 5秒？
[ ] player对象已初始化？
[ ] 网络控制台有错误？
[ ] 后端API服务运行正常？
[ ] MongoDB连接正常？
```

### Q: 邀请码生成失败？
```
检查清单：
[ ] 用户已绑定钱包地址？
[ ] Telegram认证数据有效？
[ ] 后端reward.routes.js已加载？
[ ] 数据库InviteRelation集合存在？
```

### Q: Toast提示不显示？
```
检查清单：
[ ] rewardAmount > 0？
[ ] status === 'pending'？
[ ] showRewardToast()函数已定义？
[ ] 浏览器控制台有错误？
```

---

## 📚 完整文档索引

| 文档 | 内容 | 大小 |
|------|------|------|
| **SUK_REWARD_SYSTEM_GUIDE.md** | 技术实现详解 | 13.4KB |
| **SUK_REWARD_QUICK_START.md** | 5分钟集成指南 | 9KB |
| **SUK_REWARD_INTEGRATION_VERIFIED.md** | 集成验证报告 | 15.6KB |
| **INTEGRATION_FINAL_SUMMARY.md** | 集成完成摘要 | 11.9KB |
| **REWARD_SYSTEM_QUICK_REFERENCE.md** | 本文档 | 快速参考 |

---

## 🎯 关键文件位置

```
backend/
  ├── models/Reward.js                   # 4个数据模型
  ├── services/reward.service.js         # 业务逻辑
  ├── controllers/reward.controller.js   # API处理器
  └── routes/reward.routes.js            # 路由注册

前端/
  ├── telegram-app.html                  # 主页（含奖励入口）
  ├── telegram-player-optimized.html     # 播放器（含奖励记录）
  └── telegram-reward-center.html        # 奖励中心
```

---

## ✅ 部署检查（30秒）

```bash
# 1. 后端服务运行？
pm2 status

# 2. MongoDB连接？
mongosh "mongodb://localhost:27017/drama_platform"

# 3. Redis运行？
redis-cli PING

# 4. 路由已注册？
curl http://localhost:3000/api/rewards/stats \
  -H "X-Telegram-Init-Data: test"

# 5. HTTPS证书（生产环境）？
curl https://your-domain.com/telegram-app.html
```

---

## 🚀 启动命令

```bash
# 开发环境
npm run dev

# 生产环境
pm2 start ecosystem.config.js --env production

# 查看日志
pm2 logs drama-platform --lines 50
```

---

## 📞 获取帮助

**遇到问题？**
1. 📖 查看完整文档：`SUK_REWARD_SYSTEM_GUIDE.md`
2. 🧪 运行测试：`curl` 命令或 Postman
3. 📝 检查日志：`pm2 logs` 或浏览器控制台
4. 🔍 搜索关键字：`recordWatchReward`, `openInviteShare`, `checkAndUseInviteCode`

---

**状态**: ✅ 系统100%完成，生产就绪  
**更新**: 2024-11-16  
**版本**: v1.3.1
