# SUK LINK 技术文档

> 🎬 全球 Web3.0 Dramafi（链剧）去中心化资产与生产力平台

---

## 📋 目录

- [平台概述](#平台概述)
- [核心架构](#核心架构)
- [三大创新引擎](#三大创新引擎)
- [技术栈](#技术栈)
- [智能合约](#智能合约)
- [API接口](#api接口)
- [SDK使用](#sdk使用)
- [部署指南](#部署指南)

---

## 🎯 平台概述

### 什么是 SUK LINK？

SUK（竖客）是全球 Web3.0 Dramafi（链剧）去中心化资产与生产力平台，致力于打造连接短剧内容与区块链资产的桥梁。

### 核心价值主张

**"链剧"** 作为创新概念，实现了短剧IP与数字资产的无缝融合，重塑了内容创作、分发与价值交换模式。

#### 资产确权
- 区块链永久记录所有权益
- NFT实现数字资产所有权
- 透明可追溯的交易历史

#### 价值流通
- 观看权、版权份额、收益权多维度流通
- 完整的NFT二级市场
- 跨平台互通（符合ERC标准）

#### 去中心化协作
- 创作者、平台、观众共同参与价值创造
- 智能合约自动化收益分配
- 社区驱动的内容生态

---

## 🏗️ 核心架构

### 系统架构图

```
┌─────────────────────────────────────────────────────────────┐
│                      SUK LINK 平台架构                        │
└─────────────────────────────────────────────────────────────┘

┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│  AI短剧引擎   │  │  RWA消费预制  │  │ IP版权私募   │
│ (生产力端)   │  │ (价值流通端)  │  │ (资产增值端) │
└──────┬───────┘  └──────┬───────┘  └──────┬───────┘
       │                 │                 │
       └─────────────────┼─────────────────┘
                         │
              ┌──────────▼──────────┐
              │   区块链核心层      │
              │  (智能合约引擎)     │
              └──────────┬──────────┘
                         │
       ┌─────────────────┼─────────────────┐
       │                 │                 │
┌──────▼───────┐  ┌──────▼──────┐  ┌──────▼───────┐
│  前端应用层   │  │  API服务层  │  │ 数据存储层   │
│  (Web/App)   │  │  (RESTful)  │  │ (Database)   │
└──────────────┘  └─────────────┘  └──────────────┘
```

### 技术分层

#### 1. 展示层（Presentation Layer）
- **Web应用** - 响应式网页应用
- **移动端** - Telegram Mini App
- **管理后台** - 内容管理和数据统计

#### 2. 业务逻辑层（Business Logic Layer）
- **用户服务** - 认证、授权、个人中心
- **内容服务** - 短剧管理、播放控制
- **交易服务** - 购买、投资、市场交易
- **激励服务** - 空投、推荐、奖励

#### 3. 区块链层（Blockchain Layer）
- **智能合约** - SUKToken、SUKAirdrop、SUKMarketplace
- **NFT合约** - 观看权NFT、IP版权NFT
- **DeFi协议** - 收益分配、流动性池

#### 4. 数据层（Data Layer）
- **关系数据库** - 用户数据、交易记录
- **文档数据库** - 短剧内容、评论互动
- **缓存层** - Redis高速缓存
- **文件存储** - IPFS分布式存储

---

## 🚀 三大创新引擎

### 1. 🤖 AI短剧引擎（生产力端）

#### 核心功能

**智能剧本生成**
- AI辅助编剧，自动生成剧本大纲
- 角色设定和对话生成
- 剧情节奏优化

**场景智能渲染**
- AI场景生成，降低拍摄成本
- 虚拟场景合成
- 特效自动添加

**一键视频制作**
- 自动化剪辑和后期处理
- 智能配音和配乐
- 多平台格式适配

**内容质量优化**
- AI优化剧情节奏
- 观众体验分析
- 内容推荐算法

#### 技术实现

```javascript
// AI 剧本生成
const generateScript = async (params) => {
    const response = await fetch('/api/ai/generate-script', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            genre: params.genre,        // 剧集类型
            episodes: params.episodes,  // 集数
            themes: params.themes,      // 主题标签
            style: params.style         // 风格偏好
        })
    });
    
    const script = await response.json();
    return script;
};

// AI 场景渲染
const renderScene = async (sceneData) => {
    const response = await fetch('/api/ai/render-scene', {
        method: 'POST',
        body: JSON.stringify({
            description: sceneData.description,
            style: sceneData.style,
            characters: sceneData.characters
        })
    });
    
    return await response.json();
};
```

#### 工作流程

```
1. 创作者输入基础设定
   ↓
2. AI生成剧本大纲
   ↓
3. 创作者审核和调整
   ↓
4. AI生成详细剧本
   ↓
5. AI渲染场景和特效
   ↓
6. 自动化剪辑和后期
   ↓
7. 成品短剧上线
```

---

### 2. 💎 RWA消费预制（价值流通端）

#### 核心概念

**RWA (Real World Assets)** - 将短剧观看权益转化为可交易的链上资产。

#### 核心功能

**观看权预制**
- 提前购买热门短剧观看权益
- 锁定优惠价格
- 避免涨价风险

**权益NFT化**
- 观看权益铸造为 NFT 资产
- 链上永久记录
- 可转让、可交易

**二级市场交易**
- 观看权益可在市场上转让
- 市场定价机制
- 流动性保证

**X402计费协议**
- 按时间点精准计费
- 跨集连续计费
- 灵活消费模式

#### 技术实现

```solidity
// 观看权 NFT 合约
contract WatchRightsNFT is ERC721 {
    struct WatchRights {
        uint256 dramaId;
        uint256[] episodes;
        uint256 validUntil;
        bool isTransferable;
    }
    
    mapping(uint256 => WatchRights) public watchRights;
    
    // 铸造观看权 NFT
    function mint(
        address to,
        uint256 dramaId,
        uint256[] memory episodes,
        uint256 validUntil
    ) external returns (uint256 tokenId) {
        tokenId = _nextTokenId++;
        watchRights[tokenId] = WatchRights({
            dramaId: dramaId,
            episodes: episodes,
            validUntil: validUntil,
            isTransferable: true
        });
        
        _safeMint(to, tokenId);
        emit WatchRightsMinted(to, tokenId, dramaId);
    }
    
    // 验证观看权限
    function hasWatchRight(
        address user,
        uint256 dramaId,
        uint256 episodeId
    ) external view returns (bool) {
        uint256[] memory tokens = tokensOfOwner(user);
        
        for (uint256 i = 0; i < tokens.length; i++) {
            WatchRights memory rights = watchRights[tokens[i]];
            if (rights.dramaId == dramaId && 
                rights.validUntil > block.timestamp) {
                for (uint256 j = 0; j < rights.episodes.length; j++) {
                    if (rights.episodes[j] == episodeId) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
```

#### 交易流程

```
1. 用户选择短剧
   ↓
2. 选择购买方式（整部/按集）
   ↓
3. 支付 SUK Token
   ↓
4. 铸造观看权 NFT
   ↓
5. NFT 发送到用户钱包
   ↓
6. 用户获得观看权限
   ↓
7. (可选) 二级市场出售
```

---

### 3. 🎬 IP版权权益私募（资产增值端）

#### 核心功能

**版权碎片化**
- IP版权拆分为可交易的份额
- 降低投资门槛
- 提高流动性

**早期私募投资**
- 优质IP项目早期融资
- 投资者参与项目成长
- 风险和收益共担

**收益分配机制**
- 自动化收益分配和结算
- 透明的收益计算
- 实时查询和提取

**版权NFT交易**
- 版权份额二级市场流通
- 市场化定价
- 退出机制

#### 技术实现

```solidity
// IP 版权份额 NFT 合约
contract IPSharesNFT is ERC1155 {
    struct IPProject {
        string dramaName;
        uint256 totalShares;
        uint256 soldShares;
        uint256 pricePerShare;
        uint256 revenueSharePercent;
        uint256 totalRevenue;
        uint256 claimedRevenue;
        mapping(address => uint256) investments;
        mapping(address => uint256) claimedByUser;
    }
    
    mapping(uint256 => IPProject) public projects;
    uint256 public nextProjectId;
    
    // 创建 IP 项目
    function createProject(
        string memory dramaName,
        uint256 totalShares,
        uint256 pricePerShare,
        uint256 revenueSharePercent
    ) external onlyOwner returns (uint256 projectId) {
        projectId = nextProjectId++;
        
        IPProject storage project = projects[projectId];
        project.dramaName = dramaName;
        project.totalShares = totalShares;
        project.pricePerShare = pricePerShare;
        project.revenueSharePercent = revenueSharePercent;
        
        emit ProjectCreated(projectId, dramaName, totalShares);
    }
    
    // 投资购买份额
    function invest(uint256 projectId, uint256 shares) external payable {
        IPProject storage project = projects[projectId];
        
        require(project.soldShares + shares <= project.totalShares, 
                "Insufficient shares");
        require(msg.value >= shares * project.pricePerShare, 
                "Insufficient payment");
        
        project.investments[msg.sender] += shares;
        project.soldShares += shares;
        
        _mint(msg.sender, projectId, shares, "");
        
        emit Investment(projectId, msg.sender, shares);
    }
    
    // 分配收益
    function distributeRevenue(uint256 projectId) external payable {
        IPProject storage project = projects[projectId];
        project.totalRevenue += msg.value;
        
        emit RevenueDistributed(projectId, msg.value);
    }
    
    // 提取收益
    function claimRevenue(uint256 projectId) external {
        IPProject storage project = projects[projectId];
        uint256 userShares = balanceOf(msg.sender, projectId);
        
        require(userShares > 0, "No shares owned");
        
        uint256 totalClaimable = (project.totalRevenue * userShares * 
                                  project.revenueSharePercent) / 
                                 (project.totalShares * 100);
        uint256 alreadyClaimed = project.claimedByUser[msg.sender];
        uint256 toClaim = totalClaimable - alreadyClaimed;
        
        require(toClaim > 0, "No revenue to claim");
        
        project.claimedByUser[msg.sender] += toClaim;
        project.claimedRevenue += toClaim;
        
        payable(msg.sender).transfer(toClaim);
        
        emit RevenueClaimed(projectId, msg.sender, toClaim);
    }
}
```

#### 投资流程

```
1. IP项目发起方创建项目
   ↓
2. 设置总份额和价格
   ↓
3. 投资者浏览项目列表
   ↓
4. 选择项目并购买份额
   ↓
5. 支付 SUK Token
   ↓
6. 铸造版权份额 NFT
   ↓
7. 短剧上线产生收益
   ↓
8. 智能合约自动分配收益
   ↓
9. 投资者查询并提取收益
   ↓
10. (可选) 二级市场出售份额
```

---

## 🛠️ 技术栈

### 前端技术

| 技术 | 用途 | 版本 |
|------|------|------|
| **HTML5** | 页面结构 | - |
| **CSS3** | 样式和布局 | - |
| **JavaScript (ES6+)** | 交互逻辑 | ES2020+ |
| **Web3.js** | 区块链交互 | 1.8.0 |
| **Ethers.js** | 以太坊库 | 5.7.0 |
| **Chart.js** | 数据可视化 | 4.0.0 |
| **Tailwind CSS** | UI框架 | 3.3.0 |

### 后端技术

| 技术 | 用途 | 版本 |
|------|------|------|
| **Node.js** | 服务器运行时 | 18.0+ |
| **Express.js** | Web框架 | 4.18.0 |
| **MongoDB** | 数据库 | 6.0 |
| **Redis** | 缓存 | 7.0 |
| **JWT** | 认证 | 9.0.0 |
| **Aliyun VoD** | 视频点播 | 2.x |

### 区块链技术

| 技术 | 用途 | 版本 |
|------|------|------|
| **Solidity** | 智能合约语言 | 0.8.20 |
| **Hardhat** | 开发框架 | 2.17.0 |
| **OpenZeppelin** | 合约库 | 4.9.0 |
| **Ethereum** | 主链 | - |
| **Polygon** | 侧链 | - |
| **IPFS** | 分布式存储 | - |

---

## 📜 智能合约

### 合约架构

```
SUK 智能合约体系
├── SUKToken.sol              (ERC20 代币合约)
├── SUKAirdrop.sol            (空投合约)
├── SUKAirdropV2.sol          (邀请码空投合约)
├── WatchRightsNFT.sol        (观看权 NFT)
├── IPSharesNFT.sol           (IP版权份额 NFT)
├── SUKMarketplace.sol        (NFT交易市场)
├── RevenueDistributor.sol    (收益分配合约)
└── Governance.sol            (治理合约)
```

### 核心合约详解

#### 1. SUKToken (ERC20)

```solidity
contract SUKToken is ERC20, Pausable, Ownable {
    uint256 public constant TOTAL_SUPPLY = 1_000_000_000 * 10**18; // 10亿
    
    mapping(address => bool) public blacklist;
    
    constructor() ERC20("SUK Token", "SUK") {
        _mint(msg.sender, TOTAL_SUPPLY);
    }
    
    // 暂停功能
    function pause() external onlyOwner {
        _pause();
    }
    
    function unpause() external onlyOwner {
        _unpause();
    }
    
    // 黑名单功能
    function addToBlacklist(address account) external onlyOwner {
        blacklist[account] = true;
    }
    
    function removeFromBlacklist(address account) external onlyOwner {
        blacklist[account] = false;
    }
    
    // 燃烧功能
    function burn(uint256 amount) external {
        _burn(msg.sender, amount);
    }
    
    // 重写转账函数
    function _beforeTokenTransfer(
        address from,
        address to,
        uint256 amount
    ) internal override whenNotPaused {
        require(!blacklist[from], "Sender is blacklisted");
        require(!blacklist[to], "Recipient is blacklisted");
        super._beforeTokenTransfer(from, to, amount);
    }
}
```

#### 2. SUKAirdropV2 (邀请码空投)

```solidity
contract SUKAirdropV2 is Ownable, Pausable {
    IERC20 public sukToken;
    
    uint256 public constant AIRDROP_AMOUNT = 5000 * 10**18;
    uint256 public constant REFERRAL_AMOUNT = 1000 * 10**18;
    
    struct InviteCode {
        bytes12 code;
        bool isValid;
        bool isUsed;
        address usedBy;
        uint256 expiresAt;
    }
    
    mapping(bytes12 => InviteCode) public inviteCodes;
    mapping(address => bool) public hasClaimed;
    mapping(address => address) public referrers;
    
    event InviteCodeGenerated(bytes12 code, uint256 expiresAt);
    event InviteCodeActivated(address indexed user, bytes12 code);
    event AirdropClaimed(address indexed user, uint256 amount);
    event ReferralClaimed(address indexed user, address indexed referrer, uint256 amount);
    
    // 生成邀请码
    function generateInviteCode(
        bytes12 code,
        uint256 validityPeriod
    ) external onlyOwner {
        require(!inviteCodes[code].isValid, "Code already exists");
        
        inviteCodes[code] = InviteCode({
            code: code,
            isValid: true,
            isUsed: false,
            usedBy: address(0),
            expiresAt: block.timestamp + validityPeriod
        });
        
        emit InviteCodeGenerated(code, inviteCodes[code].expiresAt);
    }
    
    // 激活邀请码
    function activateInviteCode(bytes12 code) external whenNotPaused {
        InviteCode storage invite = inviteCodes[code];
        
        require(invite.isValid, "Invalid code");
        require(!invite.isUsed, "Code already used");
        require(invite.expiresAt > block.timestamp, "Code expired");
        require(!hasClaimed[msg.sender], "Already claimed");
        
        invite.isUsed = true;
        invite.usedBy = msg.sender;
        
        emit InviteCodeActivated(msg.sender, code);
    }
    
    // 领取空投
    function claimAirdrop() external whenNotPaused {
        require(!hasClaimed[msg.sender], "Already claimed");
        
        hasClaimed[msg.sender] = true;
        
        require(sukToken.transfer(msg.sender, AIRDROP_AMOUNT), 
                "Transfer failed");
        
        emit AirdropClaimed(msg.sender, AIRDROP_AMOUNT);
    }
    
    // 注册推荐关系
    function registerReferral(address referrer) external {
        require(referrers[msg.sender] == address(0), "Already referred");
        require(referrer != msg.sender, "Cannot refer self");
        require(hasClaimed[referrer], "Referrer must claim first");
        
        referrers[msg.sender] = referrer;
    }
    
    // 领取推荐奖励
    function claimReferralReward() external whenNotPaused {
        address referrer = referrers[msg.sender];
        require(referrer != address(0), "No referrer");
        
        // 给被推荐人奖励
        require(sukToken.transfer(msg.sender, REFERRAL_AMOUNT), 
                "Transfer to referee failed");
        
        // 给推荐人奖励
        require(sukToken.transfer(referrer, REFERRAL_AMOUNT), 
                "Transfer to referrer failed");
        
        emit ReferralClaimed(msg.sender, referrer, REFERRAL_AMOUNT);
    }
}
```

#### 3. SUKMarketplace (NFT交易市场)

```solidity
contract SUKMarketplace is Ownable, ReentrancyGuard {
    IERC20 public sukToken;
    
    struct Listing {
        uint256 listingId;
        address seller;
        address nftContract;
        uint256 tokenId;
        uint256 price;
        bool isActive;
    }
    
    mapping(uint256 => Listing) public listings;
    uint256 public nextListingId;
    
    uint256 public platformFee = 250; // 2.5%
    uint256 public constant FEE_DENOMINATOR = 10000;
    
    event Listed(uint256 indexed listingId, address indexed seller, 
                 uint256 tokenId, uint256 price);
    event Sold(uint256 indexed listingId, address indexed buyer, 
               uint256 price);
    event Cancelled(uint256 indexed listingId);
    
    // 挂单出售
    function list(
        address nftContract,
        uint256 tokenId,
        uint256 price
    ) external nonReentrant {
        require(price > 0, "Price must be greater than 0");
        
        IERC721(nftContract).transferFrom(msg.sender, address(this), tokenId);
        
        uint256 listingId = nextListingId++;
        listings[listingId] = Listing({
            listingId: listingId,
            seller: msg.sender,
            nftContract: nftContract,
            tokenId: tokenId,
            price: price,
            isActive: true
        });
        
        emit Listed(listingId, msg.sender, tokenId, price);
    }
    
    // 购买
    function buy(uint256 listingId) external nonReentrant {
        Listing storage listing = listings[listingId];
        
        require(listing.isActive, "Listing not active");
        require(msg.sender != listing.seller, "Cannot buy own listing");
        
        uint256 fee = (listing.price * platformFee) / FEE_DENOMINATOR;
        uint256 sellerAmount = listing.price - fee;
        
        // 转账 SUK Token
        require(sukToken.transferFrom(msg.sender, listing.seller, sellerAmount),
                "Payment failed");
        require(sukToken.transferFrom(msg.sender, owner(), fee),
                "Fee payment failed");
        
        // 转移 NFT
        IERC721(listing.nftContract).transferFrom(
            address(this), 
            msg.sender, 
            listing.tokenId
        );
        
        listing.isActive = false;
        
        emit Sold(listingId, msg.sender, listing.price);
    }
    
    // 取消挂单
    function cancel(uint256 listingId) external nonReentrant {
        Listing storage listing = listings[listingId];
        
        require(listing.isActive, "Listing not active");
        require(msg.sender == listing.seller, "Not the seller");
        
        IERC721(listing.nftContract).transferFrom(
            address(this), 
            msg.sender, 
            listing.tokenId
        );
        
        listing.isActive = false;
        
        emit Cancelled(listingId);
    }
}
```

---

## 📚 API 接口文档

### 基础配置

```javascript
// API Base URL
const API_BASE_URL = 'https://api.suklink.com/v1';

// 认证 Header
const headers = {
    'Authorization': `Bearer ${jwt_token}`,
    'Content-Type': 'application/json'
};
```

### 完整 API 列表

| 分类 | 方法 | 端点 | 说明 |
|------|------|------|------|
| **短剧** | GET | `/api/dramas` | 获取短剧列表 |
| | GET | `/api/dramas/:id` | 获取短剧详情 |
| | POST | `/api/dramas/purchase` | 购买短剧 |
| **播放** | GET | `/api/video/play-auth/:episodeId` | 获取播放授权 |
| | POST | `/api/video/watch-progress` | 保存观看进度 |
| | GET | `/api/video/continue-watching` | 获取继续观看列表 |
| **IP投资** | GET | `/api/ip-investments` | 获取投资项目 |
| | POST | `/api/ip-investments/invest` | 投资IP项目 |
| | GET | `/api/ip-investments/my-list` | 我的投资列表 |
| | GET | `/api/ip-investments/revenue/:id` | 查询收益 |
| | POST | `/api/ip-investments/claim/:id` | 提取收益 |
| **市场** | POST | `/api/marketplace/list` | 挂单出售 |
| | POST | `/api/marketplace/buy/:id` | 购买挂单 |
| | DELETE | `/api/marketplace/cancel/:id` | 取消挂单 |
| | GET | `/api/marketplace/listings` | 查询挂单 |
| **邀请码** | GET | `/api/invite-codes/validate/:code` | 验证邀请码 |
| | POST | `/api/invite-codes/activate` | 激活邀请码 |
| | POST | `/api/airdrops/claim` | 领取空投 |
| **推荐** | POST | `/api/referrals/generate-link` | 生成推荐链接 |
| | GET | `/api/referrals/stats` | 推荐统计 |
| | POST | `/api/referrals/claim` | 领取推荐奖励 |
| **钱包** | GET | `/api/wallet/balance` | 获取余额 |
| | GET | `/api/wallet/transactions` | 交易历史 |
| | POST | `/api/wallet/transfer` | 转账 |

详细的 API 接口文档请参考 [README.md - API文档部分](README.md#api接口)

---

## 📦 SDK 使用指南

### 安装

```bash
npm install @suklink/sdk
```

### 快速开始

```javascript
import { SUKClient } from '@suklink/sdk';

// 初始化
const suk = new SUKClient({
    network: 'mainnet',
    apiKey: 'your_api_key',
    web3Provider: window.ethereum
});

// 连接钱包
await suk.connect();

// 获取短剧列表
const dramas = await suk.dramas.list();

// 购买短剧
const purchase = await suk.dramas.purchase('drama-001', {
    type: 'full',
    paymentMethod: 'SUK_TOKEN'
});
```

完整的 SDK 文档请参考 [README.md - SDK使用部分](README.md#sdk使用指南)

---

## 🚀 部署指南

### 环境要求

- Node.js >= 18.0.0
- MongoDB >= 6.0
- Redis >= 7.0
- Hardhat >= 2.17.0

### 智能合约部署

```bash
# 1. 安装依赖
npm install

# 2. 编译合约
npx hardhat compile

# 3. 部署到测试网
npx hardhat run scripts/deploy-all.js --network goerli

# 4. 验证合约
npx hardhat verify --network goerli <CONTRACT_ADDRESS>
```

### 前端部署

```bash
# 1. 配置环境变量
cp .env.example .env

# 2. 构建项目
npm run build

# 3. 部署到服务器
npm run deploy
```

详细部署指南请参考：
- [智能合约部署指南](DEPLOYMENT_STEP_BY_STEP.md)
- [前端配置指南](FRONTEND_CONFIG_GUIDE.md)
- [Docker部署指南](DOCKER_DEPLOYMENT.md)

---

## 📞 技术支持

- 📧 Email: tech@suklink.com
- 💬 Telegram: @SUKLinkDev
- 🐦 Twitter: @SUKLink
- 📚 文档: https://docs.suklink.com

---

**🎬 SUK LINK - 让短剧成为可投资的数字资产！**

*最后更新: 2024-11-18*
