/**
 * PM2 进程管理器配置文件
 * PM2 Ecosystem Configuration File
 * 
 * 用于生产环境部署和进程管理
 * 文档: https://pm2.keymetrics.io/docs/usage/application-declaration/
 */

module.exports = {
  apps: [
    {
      // 应用名称
      name: 'drama-platform',

      // 启动脚本
      script: './server.js',

      // 实例数量（设置为CPU核心数，或使用 'max' 自动检测）
      instances: 2,

      // 执行模式：cluster（集群）或 fork（单进程）
      exec_mode: 'cluster',

      // 监听文件变化自动重启（生产环境建议关闭）
      watch: false,

      // 忽略监听的文件/目录
      ignore_watch: [
        'node_modules',
        'logs',
        '.git',
        '*.log'
      ],

      // 环境变量
      env: {
        NODE_ENV: 'development',
        PORT: 3000
      },

      // 生产环境变量
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000
      },

      // 错误日志文件
      error_file: './logs/pm2-error.log',

      // 输出日志文件
      out_file: './logs/pm2-out.log',

      // 日志日期格式
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',

      // 合并日志（多实例时合并到同一文件）
      merge_logs: true,

      // 自动重启
      autorestart: true,

      // 最大重启次数（防止无限重启）
      max_restarts: 10,

      // 最小运行时间（防止快速崩溃循环）
      min_uptime: '10s',

      // 内存超限自动重启
      max_memory_restart: '1G',

      // 启动延迟（集群模式下错开启动时间）
      listen_timeout: 5000,

      // 关闭超时时间
      kill_timeout: 5000,

      // 优雅关闭（等待连接关闭后再退出）
      wait_ready: true,

      // 实例启动间隔（集群模式）
      instance_var: 'INSTANCE_ID',

      // Cron重启（可选，每天凌晨4点重启）
      // cron_restart: '0 4 * * *',

      // 资源限制
      // max_memory_restart: '1G',  // 内存超过1GB自动重启
      // exp_backoff_restart_delay: 100,  // 指数退避重启延迟

      // 进程管理
      vizion: false,  // 禁用版本控制元数据
      post_update: ['npm install'],  // 更新后执行的命令

      // 自定义指标监控
      // pmx: true,
      // automation: false
    }
  ],

  /**
   * 部署配置（可选）
   * 用于 pm2 deploy 命令
   */
  deploy: {
    // 生产环境部署配置
    production: {
      // SSH用户
      user: 'drama_admin',

      // 服务器地址（支持多台）
      host: ['your-server-ip'],

      // SSH端口
      ref: 'origin/main',

      // Git仓库地址
      repo: 'git@github.com:your-username/drama-platform.git',

      // 服务器上的部署路径
      path: '/var/www/drama-platform',

      // SSH密钥路径
      key: '~/.ssh/id_rsa',

      // 部署后执行的命令
      'post-deploy': 'npm install && pm2 reload ecosystem.config.js --env production',

      // 部署前执行的命令
      'pre-deploy-local': 'echo "正在部署到生产环境..."',

      // 部署设置
      'ssh_options': 'StrictHostKeyChecking=no'
    },

    // 测试环境部署配置
    staging: {
      user: 'drama_admin',
      host: ['your-staging-server-ip'],
      ref: 'origin/develop',
      repo: 'git@github.com:your-username/drama-platform.git',
      path: '/var/www/drama-platform-staging',
      'post-deploy': 'npm install && pm2 reload ecosystem.config.js --env staging'
    }
  }
};

/**
 * 使用方法：
 * 
 * 开发环境：
 *   pm2 start ecosystem.config.js
 * 
 * 生产环境：
 *   pm2 start ecosystem.config.js --env production
 * 
 * 重启应用：
 *   pm2 reload ecosystem.config.js
 *   pm2 restart drama-platform
 * 
 * 停止应用：
 *   pm2 stop drama-platform
 * 
 * 删除应用：
 *   pm2 delete drama-platform
 * 
 * 查看日志：
 *   pm2 logs drama-platform
 *   pm2 logs drama-platform --lines 100
 * 
 * 监控面板：
 *   pm2 monit
 * 
 * 保存配置（开机自启）：
 *   pm2 save
 *   pm2 startup
 * 
 * 部署到生产环境（使用deploy配置）：
 *   pm2 deploy production setup
 *   pm2 deploy production
 *   pm2 deploy production update
 * 
 * 集群扩缩容：
 *   pm2 scale drama-platform 4  （扩展到4个实例）
 *   pm2 scale drama-platform +2 （增加2个实例）
 */
