# X402 Quick Start Guide
# X402协议快速开始指南

**版本**: 1.0.0  
**预计时间**: 10分钟  
**难度**: ⭐⭐☆☆☆ 简单

---

## 🎯 目标

在10分钟内，将X402按时间点计费功能集成到您的视频播放器中。

---

## 📋 前置要求

- ✅ HTML5 video标签
- ✅ JavaScript ES6+支持
- ✅ 基础的CSS知识
- ✅ （可选）后端API支持

---

## 🚀 快速集成（3步）

### 步骤1: 引入SDK和UI组件

```html
<!DOCTYPE html>
<html>
<head>
    <title>我的X402播放器</title>
</head>
<body>
    <!-- 视频播放器 -->
    <video id="my-video" controls width="800">
        <source src="your-video.mp4" type="video/mp4">
    </video>
    
    <!-- 计费UI容器 -->
    <div id="billing-ui"></div>
    
    <!-- 引入X402 SDK -->
    <script src="js/x402-player.js"></script>
    <script src="js/x402-ui.js"></script>
</body>
</html>
```

### 步骤2: 初始化播放器

```javascript
<script>
// 创建计费UI
const billingUI = new X402UI('#billing-ui', {
    theme: 'dark',  // 或 'light'
    currency: 'SUK'
});

// 创建X402播放器
const player = new X402Player({
    videoElement: document.getElementById('my-video'),
    dramaId: '1',  // 剧集ID
    userId: 'user_123',  // 用户ID
    apiEndpoint: 'https://api.suk.link',  // API地址
    
    // 计费配置
    billingInterval: 10,  // 每10秒计费
    freeDuration: 180,    // 前3分钟免费
    
    // 回调函数
    onBillingSuccess: (data) => {
        // 计费成功，更新UI
        billingUI.update({
            totalCost: data.totalCost,
            balance: data.balance,
            progress: data.progress
        });
        console.log('计费成功:', data);
    },
    
    onBalanceWarning: (data) => {
        // 余额警告
        billingUI.showBalanceWarning(data.message);
    },
    
    onInsufficientBalance: () => {
        // 余额不足
        alert('余额不足，请充值后继续观看');
    }
});

// 绑定充值按钮
billingUI.onRecharge(() => {
    // 调用充值API
    player.recharge(100);  // 充值100 SUK
});
</script>
```

### 步骤3: 完成！🎉

就这么简单！您的播放器现在已经支持X402按时间点计费了。

---

## 🎨 演示效果

访问演示页面查看完整效果：
```
x402-player-demo.html
```

---

## ⚙️ 配置选项

### X402Player 配置

| 参数 | 类型 | 必需 | 默认值 | 说明 |
|------|------|------|--------|------|
| `videoElement` | HTMLVideoElement | ✅ | - | 视频元素 |
| `dramaId` | String | ✅ | - | 剧集ID |
| `userId` | String | ✅ | - | 用户ID |
| `apiEndpoint` | String | ✅ | - | API地址 |
| `billingInterval` | Number | ❌ | 10 | 计费间隔（秒） |
| `freeDuration` | Number | ❌ | 180 | 免费时长（秒） |

### X402UI 配置

| 参数 | 类型 | 必需 | 默认值 | 说明 |
|------|------|------|--------|------|
| `theme` | String | ❌ | 'dark' | 主题（dark/light） |
| `currency` | String | ❌ | 'SUK' | 货币单位 |
| `showProgress` | Boolean | ❌ | true | 显示进度条 |
| `showBalance` | Boolean | ❌ | true | 显示余额 |

---

## 📡 后端API接口

### 1. 开始会话

**请求**:
```
POST /api/x402/session/start
Content-Type: application/json

{
    "userId": "user_123",
    "dramaId": "1",
    "startTime": 0
}
```

**响应**:
```json
{
    "success": true,
    "data": {
        "sessionId": "session_789",
        "pricePerSecond": 0.00520833,
        "userBalance": 125.00
    }
}
```

### 2. 处理计费

**请求**:
```
POST /api/x402/billing/charge
Content-Type: application/json

{
    "sessionId": "session_789",
    "dramaId": "1",
    "startTime": 0,
    "endTime": 10,
    "clientTimestamp": 1700112300000
}
```

**响应**:
```json
{
    "success": true,
    "data": {
        "charged": 0.0521,
        "totalCost": 0.0521,
        "remainingBalance": 124.9479,
        "progress": 0.000417
    }
}
```

### 3. 结束会话

**请求**:
```
POST /api/x402/session/end
Content-Type: application/json

{
    "sessionId": "session_789",
    "finalTime": 1200,
    "reason": "user_stopped"
}
```

**响应**:
```json
{
    "success": true,
    "data": {
        "sessionSummary": {
            "duration": 1200,
            "totalCost": 6.25,
            "progress": 0.05
        }
    }
}
```

---

## 🎯 完整示例

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>X402播放器示例</title>
</head>
<body>
    <div style="max-width: 1200px; margin: 0 auto; padding: 20px;">
        <h1>X402按时间点计费播放器</h1>
        
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
            <!-- 左侧：视频 -->
            <div>
                <video id="drama-video" controls width="100%" style="border-radius: 12px;">
                    <source src="https://www.genspark.ai/api/files/s/KgsCMF4L" type="video/mp4">
                </video>
                
                <div style="margin-top: 20px;">
                    <h2>霸总的心尖宠</h2>
                    <p>⭐ 9.2分 | 📺 80集 | 💰 125 SUK</p>
                </div>
            </div>
            
            <!-- 右侧：计费UI -->
            <div id="x402-billing"></div>
        </div>
    </div>
    
    <script src="js/x402-player.js"></script>
    <script src="js/x402-ui.js"></script>
    <script>
        // 初始化UI
        const ui = new X402UI('#x402-billing');
        
        // 初始化播放器
        const player = new X402Player({
            videoElement: document.getElementById('drama-video'),
            dramaId: '1',
            userId: 'demo_user',
            apiEndpoint: '/api',
            
            onBillingSuccess: (data) => {
                ui.update({
                    totalCost: data.totalCost,
                    balance: data.balance,
                    progress: data.progress,
                    currentTime: Math.floor(player.currentTime),
                    pricePerMinute: player.pricePerSecond * 60,
                    estimatedTotal: player.totalDuration * player.pricePerSecond,
                    remainingCost: (player.totalDuration - player.currentTime) * player.pricePerSecond
                });
            },
            
            onBalanceWarning: (data) => {
                ui.showBalanceWarning(data.message);
            },
            
            onInsufficientBalance: () => {
                alert('余额不足！请充值后继续观看。');
            }
        });
        
        // 充值功能
        ui.onRecharge(() => {
            const amount = prompt('请输入充值金额（SUK）:', '100');
            if (amount) {
                player.recharge(parseFloat(amount));
            }
        });
    </script>
</body>
</html>
```

---

## 🔧 故障排除

### Q: 视频播放但不计费？
**A**: 检查以下内容：
1. 确认已正确初始化X402Player
2. 检查API端点是否正确
3. 查看浏览器控制台的错误信息
4. 确认用户ID和剧集ID有效

### Q: 计费不准确？
**A**: 可能原因：
1. billingInterval设置不当
2. 服务器时间与客户端不同步
3. 网络延迟导致的请求失败

### Q: 余额不足但视频继续播放？
**A**: 检查：
1. onInsufficientBalance回调是否正确实现
2. 确认播放器在余额不足时调用了pause()
3. 检查余额验证逻辑

---

## 📚 进阶功能

### 1. 自定义计费逻辑

```javascript
const player = new X402Player({
    // ... 其他配置
    
    // 自定义费用计算
    calculateCost: (startTime, endTime) => {
        const duration = endTime - startTime;
        let cost = duration * this.pricePerSecond;
        
        // 自定义折扣逻辑
        if (isVIPUser) {
            cost *= 0.8;  // VIP 8折
        }
        
        return cost;
    }
});
```

### 2. 添加播放统计

```javascript
const player = new X402Player({
    // ... 其他配置
    
    onTimeUpdate: (currentTime, progress) => {
        // 发送播放统计
        analytics.track('video_playing', {
            dramaId: '1',
            currentTime: currentTime,
            progress: progress
        });
    }
});
```

### 3. 会员折扣集成

```javascript
// 获取用户会员等级
const membershipLevel = await getUserMembership();

// 应用会员折扣
const discount = {
    'vip': 0.8,
    'svip': 0.6,
    'normal': 1.0
}[membershipLevel] || 1.0;

// 在UI中显示
ui.update({
    discount: discount
});
```

---

## 🎉 完成！

恭喜！您已经成功集成了X402按时间点计费系统。

**下一步**：
1. 📖 阅读完整文档：`X402_PROTOCOL_SPECIFICATION.md`
2. 🔧 探索演示页面：`x402-player-demo.html`
3. 🚀 部署到生产环境

**需要帮助？**
- 查看技术规范文档
- 访问GitHub Issues
- 联系技术支持

---

**版权所有 © 2024 SUK Protocol**  
**最后更新**: 2024-11-16
