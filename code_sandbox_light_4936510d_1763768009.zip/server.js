/**
 * 短剧平台 - 主服务器文件
 * Drama Platform - Main Server File
 * 
 * 启动Express服务器，连接数据库，初始化路由
 */

require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const redis = require('redis');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const path = require('path');

const config = require('./backend/config/env.config');

// 创建Express应用
const app = express();

// ============================================
// 中间件配置
// ============================================

// 安全头
app.use(helmet({
    contentSecurityPolicy: false, // 开发环境禁用CSP
    crossOriginEmbedderPolicy: false
}));

// CORS配置
app.use(cors({
    origin: config.server.corsOrigin,
    credentials: config.server.corsCredentials
}));

// 请求日志
if (config.env.isDevelopment) {
    app.use(morgan('dev'));
} else {
    app.use(morgan('combined'));
}

// 请求体解析
app.use(express.json({ limit: config.server.maxRequestBodySize }));
app.use(express.urlencoded({ extended: true, limit: config.server.maxRequestBodySize }));

// 静态文件服务
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(__dirname)); // 临时用于开发，生产环境应移除

// 限流
const limiter = rateLimit({
    windowMs: config.rateLimit.windowMs,
    max: config.rateLimit.maxRequests,
    message: '请求过于频繁，请稍后再试'
});
app.use('/api/', limiter);

// ============================================
// 数据库连接
// ============================================

let redisClient;

async function connectDatabases() {
    try {
        // 连接MongoDB
        console.log('📦 连接MongoDB...');
        await mongoose.connect(config.mongodb.uri, config.mongodb.options);
        console.log('✅ MongoDB连接成功');

        // 连接Redis
        console.log('📦 连接Redis...');
        redisClient = redis.createClient(config.redis.options);
        
        redisClient.on('error', (err) => {
            console.error('❌ Redis错误:', err);
        });

        redisClient.on('connect', () => {
            console.log('✅ Redis连接成功');
        });

        await redisClient.connect();

        // 导出Redis客户端供其他模块使用
        global.redisClient = redisClient;

    } catch (error) {
        console.error('❌ 数据库连接失败:', error);
        process.exit(1);
    }
}

// ============================================
// 路由配置
// ============================================

// 健康检查
app.get('/health', (req, res) => {
    res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: config.env.nodeEnv,
        mongodb: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
        redis: redisClient?.isOpen ? 'connected' : 'disconnected'
    });
});

// API路由（暂时返回占位响应，后续添加实际路由）
app.get('/api/status', (req, res) => {
    res.json({
        success: true,
        message: 'API服务运行中',
        version: '1.0.0',
        features: {
            vodPlayback: true,
            watchHistory: true,
            resumePlayback: true,
            i18n: true,
            sukPayment: true
        }
    });
});

// 视频相关API路由（占位，待实现完整控制器）
app.get('/api/video/play-auth/:episodeId', (req, res) => {
    res.json({
        success: false,
        message: '此功能需要完整的后端控制器实现',
        hint: '请参考 backend/controllers/video.controller.js'
    });
});

// 404处理
app.use((req, res) => {
    if (req.path.startsWith('/api/')) {
        res.status(404).json({
            success: false,
            message: 'API端点不存在',
            path: req.path
        });
    } else {
        // 前端路由，返回index.html（SPA支持）
        res.sendFile(path.join(__dirname, 'index.html'));
    }
});

// 错误处理
app.use((err, req, res, next) => {
    console.error('❌ 服务器错误:', err);
    
    res.status(err.status || 500).json({
        success: false,
        message: config.env.isDevelopment ? err.message : '服务器内部错误',
        error: config.env.isDevelopment ? err.stack : undefined
    });
});

// ============================================
// 启动服务器
// ============================================

async function startServer() {
    try {
        // 打印启动信息
        console.log('\n╔════════════════════════════════════════╗');
        console.log('║   短剧平台服务器启动中...              ║');
        console.log('║   Drama Platform Server Starting      ║');
        console.log('╚════════════════════════════════════════╝\n');

        // 打印配置信息
        if (config.development.debug) {
            console.log('🔧 配置信息:');
            console.log(`   环境: ${config.env.nodeEnv}`);
            console.log(`   端口: ${config.server.port}`);
            console.log(`   MongoDB: ${config.mongodb.uri.replace(/\/\/.*@/, '//***@')}`);
            console.log(`   Redis: ${config.redis.host}:${config.redis.port}`);
            console.log(`   阿里云VoD: ${config.aliyun.vod.region}`);
            console.log(`   功能开关:`);
            console.log(`     - 续播: ${config.features.resumePlayback ? '✅' : '❌'}`);
            console.log(`     - 推荐: ${config.features.recommendations ? '✅' : '❌'}`);
            console.log(`     - 评论: ${config.features.comments ? '✅' : '❌'}`);
            console.log('');
        }

        // 连接数据库
        await connectDatabases();

        // 启动HTTP服务器
        const PORT = config.server.port;
        app.listen(PORT, () => {
            console.log('\n╔════════════════════════════════════════╗');
            console.log('║   ✅ 服务器启动成功！                  ║');
            console.log('║   Server Started Successfully!        ║');
            console.log('╚════════════════════════════════════════╝\n');
            console.log(`🚀 服务器地址: http://localhost:${PORT}`);
            console.log(`📡 API端点: http://localhost:${PORT}/api`);
            console.log(`🎬 播放器: http://localhost:${PORT}/drama-player-aliyun.html`);
            console.log(`📊 健康检查: http://localhost:${PORT}/health`);
            console.log('');
            console.log('💡 提示: 按 Ctrl+C 停止服务器\n');
        });

    } catch (error) {
        console.error('\n❌ 服务器启动失败:', error);
        process.exit(1);
    }
}

// 优雅关闭
process.on('SIGTERM', async () => {
    console.log('\n📴 收到终止信号，正在关闭服务器...');
    
    try {
        await mongoose.connection.close();
        console.log('✅ MongoDB连接已关闭');
        
        if (redisClient) {
            await redisClient.quit();
            console.log('✅ Redis连接已关闭');
        }
        
        console.log('👋 服务器已安全关闭\n');
        process.exit(0);
    } catch (error) {
        console.error('❌ 关闭过程中发生错误:', error);
        process.exit(1);
    }
});

// 启动服务器
startServer();

// 导出app供测试使用
module.exports = app;
