# 测试文档
# Testing Documentation

> **短剧平台完整测试指南** - 包含所有组件的测试方法和验证步骤

---

## 📋 目录

- [测试概述](#测试概述)
- [环境准备](#环境准备)
- [自动化测试](#自动化测试)
- [功能测试](#功能测试)
- [集成测试](#集成测试)
- [性能测试](#性能测试)
- [安全测试](#安全测试)
- [故障排查](#故障排查)

---

## 测试概述

### 测试层次

```
┌─────────────────────────────────────┐
│     端到端测试 (E2E Tests)            │
│  用户完整流程：浏览→购买→观看         │
└─────────────────────────────────────┘
              ↓
┌─────────────────────────────────────┐
│     集成测试 (Integration Tests)     │
│  API接口、数据库、第三方服务集成      │
└─────────────────────────────────────┘
              ↓
┌─────────────────────────────────────┐
│     单元测试 (Unit Tests)            │
│  独立函数、服务、工具方法测试         │
└─────────────────────────────────────┘
```

### 测试工具

| 工具 | 用途 | 状态 |
|------|------|------|
| Node.js Scripts | 自动化测试脚本 | ✅ 可用 |
| HTML Test Pages | 可视化测试界面 | ✅ 可用 |
| curl / Postman | API 手动测试 | ✅ 可用 |
| MongoDB Compass | 数据库验证 | ✅ 可用 |
| Redis CLI | 缓存验证 | ✅ 可用 |

---

## 环境准备

### 1. 安装依赖

```bash
# 安装项目依赖
npm install

# 安装开发依赖
npm install --save-dev
```

### 2. 配置环境变量

```bash
# 复制环境配置
cp .env.example .env

# 编辑配置文件
nano .env
```

**必需配置项**：
- `MONGODB_URI` - MongoDB 连接字符串
- `REDIS_HOST` / `REDIS_PORT` - Redis 配置
- `ALIYUN_ACCESS_KEY_ID` / `ALIYUN_ACCESS_KEY_SECRET` - 阿里云密钥
- `TELEGRAM_BOT_TOKEN` - Telegram Bot Token
- `TON_WALLET_ADDRESS` - TON 钱包地址
- `SUK_TOKEN_CONTRACT` - SUK Token 合约地址
- `ETHEREUM_RPC_URL` - 以太坊 RPC 节点

### 3. 启动依赖服务

```bash
# 启动 MongoDB
sudo systemctl start mongod

# 启动 Redis
sudo systemctl start redis

# 验证服务状态
sudo systemctl status mongod
sudo systemctl status redis
```

---

## 自动化测试

### 快速检查（推荐）

一键检查所有核心功能：

```bash
npm run test:quick
```

**检查项目**：
- ✅ Node.js 和 npm 版本
- ✅ 项目依赖完整性
- ✅ 环境变量配置
- ✅ MongoDB 连接
- ✅ Redis 连接
- ✅ 阿里云 VoD 连接
- ✅ Telegram Bot 配置
- ✅ 项目文件完整性

**输出示例**：
```
✅ 项目依赖检查通过
✅ MongoDB 连接成功
✅ Redis 连接成功
✅ 阿里云VoD配置正确
⚠️  Telegram Bot Token 未配置
```

### 单项测试

#### 环境变量测试

```bash
npm run test:env
```

验证所有环境变量是否正确配置。

#### 数据库连接测试

```bash
npm run test:db
```

测试 MongoDB 连接、索引创建和基本操作。

#### 阿里云 VoD 测试

```bash
npm run test:vod
```

测试阿里云 VoD 服务连接和 API 调用。

#### Telegram Bot 测试

```bash
npm run test:telegram
```

测试 Telegram Bot API 连接和基本功能。

### 支付流程测试

完整的端到端支付流程测试：

```bash
npm run test:payment
```

**测试场景**：
1. 获取短剧详情（购买前）
2. 尝试未购买播放（应拒绝）
3. 创建 Stars 支付发票
4. 检查订单创建
5. 模拟支付成功回调
6. 验证购买记录创建
7. 获取短剧详情（购买后）
8. 尝试已购买播放（应成功）
9. 验证订单状态更新

**可视化测试页面**：
```bash
# 在浏览器中打开
open payment-flow-test.html
```

---

## 功能测试

### 播放器功能测试

使用专门的测试工具验证播放器所有功能：

```bash
# 在浏览器中打开
open player-test.html
```

**测试类别**（8类，30+项）：

#### 1. 基础播放功能
- [ ] 播放/暂停功能
- [ ] 进度显示准确性
- [ ] 进度条拖动
- [ ] 视频加载速度

#### 2. 控制功能
- [ ] 快进10秒
- [ ] 快退10秒
- [ ] 控制条自动隐藏（3秒）
- [ ] 控制条显示/隐藏切换

#### 3. 剧集管理
- [ ] 剧集列表显示
- [ ] 剧集切换功能
- [ ] 当前剧集高亮
- [ ] 锁定剧集显示
- [ ] 上一集/下一集按钮

#### 4. 续播功能
- [ ] 续播对话框显示
- [ ] 继续播放功能
- [ ] 重新播放功能
- [ ] 进度自动保存

#### 5. 自动播放
- [ ] 下一集提示显示
- [ ] 倒计时功能（5秒）
- [ ] 取消自动播放

#### 6. UI/UX体验
- [ ] 主题样式一致性
- [ ] 动画流畅性
- [ ] 触摸反馈
- [ ] 响应式布局

#### 7. 移动端适配
- [ ] 安全区域适配
- [ ] 横屏模式支持
- [ ] 触控区域大小

#### 8. 错误处理
- [ ] 错误提示显示
- [ ] 重试功能
- [ ] 返回功能

### Telegram Mini App 测试

#### 测试流程

1. **本地测试环境设置**

```bash
# 启动ngrok隧道
ngrok http 3000

# 记录 ngrok URL
# 例如: https://abc123.ngrok.io
```

2. **配置 Telegram Bot**

```bash
# 设置 WebApp URL
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setChatMenuButton" \
  -H "Content-Type: application/json" \
  -d '{
    "menu_button": {
      "type": "web_app",
      "text": "打开短剧平台",
      "web_app": {
        "url": "https://abc123.ngrok.io/telegram-app.html"
      }
    }
  }'
```

3. **测试检查清单**

- [ ] Mini App 正常加载
- [ ] 用户信息正确显示
- [ ] 主题适配（深色/浅色）
- [ ] 短剧列表加载
- [ ] 分类筛选功能
- [ ] 短剧详情页
- [ ] 剧集列表显示
- [ ] 购买按钮显示
- [ ] Stars 支付流程
- [ ] TON 支付流程
- [ ] SUK Token 支付流程
- [ ] 播放器启动
- [ ] 观看进度保存

---

## 集成测试

### API 集成测试

使用 curl 或 Postman 测试 API 端点。

#### 1. 获取短剧列表

```bash
curl -X GET "http://localhost:3000/api/telegram/dramas?page=1&limit=20" \
  -H "Authorization: tma query_id=xxx&user=%7B%22id%22%3A123456789%7D"
```

**预期结果**：
- HTTP 200 OK
- 返回短剧数组
- 包含分页信息

#### 2. 获取播放授权

```bash
curl -X GET "http://localhost:3000/api/telegram/play-auth/drama_001_ep_001?dramaId=drama_001" \
  -H "Authorization: tma query_id=xxx&user=%7B%22id%22%3A123456789%7D"
```

**预期结果**（第1集免费）：
- HTTP 200 OK
- 返回 playAuth token
- 返回 videoId
- expiresIn = 1800

#### 3. 保存观看进度

```bash
curl -X POST "http://localhost:3000/api/telegram/watch-progress" \
  -H "Authorization: tma query_id=xxx&user=%7B%22id%22%3A123456789%7D" \
  -H "Content-Type: application/json" \
  -d '{
    "dramaId": "drama_001",
    "episodeId": "drama_001_ep_001",
    "videoId": "test_video_id",
    "watchProgress": 60,
    "totalDuration": 180
  }'
```

**预期结果**：
- HTTP 200 OK
- 返回 historyId
- progressPercent = 33

### 区块链集成测试

#### TON 区块链测试

```bash
node -e "
const tonService = require('./backend/services/ton-blockchain.service');

(async () => {
    // 健康检查
    const health = await tonService.healthCheck();
    console.log('TON Health:', health);
    
    // 获取余额
    if (process.env.TON_WALLET_ADDRESS) {
        const balance = await tonService.getBalance();
        console.log('TON Balance:', balance);
    }
    
    // 获取最近交易
    const txs = await tonService.getRecentTransactions(null, 5);
    console.log('Recent Transactions:', txs);
})();
"
```

#### SUK Token 测试

```bash
node -e "
const sukService = require('./backend/services/suk-blockchain.service');

(async () => {
    // 健康检查
    const health = await sukService.healthCheck();
    console.log('SUK Health:', health);
    
    // 获取 Token 信息
    const info = await sukService.getTokenInfo();
    console.log('Token Info:', info);
    
    // 获取余额
    if (process.env.PLATFORM_WALLET_ADDRESS) {
        const balance = await sukService.getBalance();
        console.log('SUK Balance:', balance);
    }
})();
"
```

### 数据库集成测试

#### MongoDB 测试

```bash
# 使用 mongosh 连接
mongosh "mongodb://localhost:27017/short_drama_platform"

# 测试查询
db.orders.find().limit(5)
db.purchases.find().limit(5)
db.watchhistories.find().limit(5)

# 检查索引
db.orders.getIndexes()
db.purchases.getIndexes()

# 检查集合统计
db.orders.stats()
```

#### Redis 测试

```bash
# 连接 Redis
redis-cli

# 测试基本操作
PING
SET test_key "test_value"
GET test_key
DEL test_key

# 查看所有键
KEYS *

# 查看播放授权缓存
KEYS playauth:*

# 检查内存使用
INFO memory
```

---

## 性能测试

### 并发测试

使用 Apache Bench 或 wrk 进行压力测试：

```bash
# 安装 Apache Bench
sudo apt-get install apache2-utils

# 测试获取短剧列表接口
ab -n 1000 -c 10 http://localhost:3000/api/telegram/dramas

# -n 1000: 总请求数
# -c 10: 并发数
```

**性能指标**：
- 平均响应时间 < 100ms
- 95%请求 < 200ms
- 99%请求 < 500ms
- 无失败请求

### 播放授权缓存测试

验证 Redis 缓存是否有效减少阿里云 API 调用：

```bash
# 清空 Redis 缓存
redis-cli FLUSHDB

# 第一次请求（应调用阿里云API）
time curl -X GET "http://localhost:3000/api/telegram/play-auth/drama_001_ep_001?dramaId=drama_001"

# 第二次请求（应使用缓存）
time curl -X GET "http://localhost:3000/api/telegram/play-auth/drama_001_ep_001?dramaId=drama_001"
```

**预期结果**：
- 第一次请求：500-1000ms
- 第二次请求：< 50ms

---

## 安全测试

### 认证测试

#### 1. 无认证访问测试

```bash
# 应该返回 401 Unauthorized
curl -X GET "http://localhost:3000/api/telegram/dramas"
```

#### 2. 无效认证测试

```bash
# 应该返回 401 Unauthorized
curl -X GET "http://localhost:3000/api/telegram/dramas" \
  -H "Authorization: tma invalid_data"
```

#### 3. Telegram WebApp 数据验证

测试 HMAC-SHA256 签名验证是否正常工作。

### 权限测试

#### 未购买剧集访问测试

```bash
# 尝试访问未购买的第2集
# 应该返回 403 Forbidden
curl -X GET "http://localhost:3000/api/telegram/play-auth/drama_001_ep_002?dramaId=drama_001" \
  -H "Authorization: tma query_id=xxx&user=%7B%22id%22%3A123456789%7D"
```

**预期响应**：
```json
{
    "success": false,
    "message": "您尚未购买此剧集",
    "requiresPurchase": true
}
```

### SQL注入测试

```bash
# 尝试SQL注入
curl -X GET "http://localhost:3000/api/telegram/dramas?category='; DROP TABLE dramas;--"
```

**预期结果**：
- 查询参数被正确转义
- 无数据库错误
- 返回空结果或错误提示

---

## 故障排查

### 常见问题

#### 1. MongoDB 连接失败

**症状**：
```
❌ MongoDB 连接失败: connect ECONNREFUSED 127.0.0.1:27017
```

**解决方案**：
```bash
# 检查 MongoDB 状态
sudo systemctl status mongod

# 启动 MongoDB
sudo systemctl start mongod

# 查看日志
sudo tail -f /var/log/mongodb/mongod.log
```

#### 2. Redis 连接失败

**症状**：
```
❌ Redis 错误: connect ECONNREFUSED 127.0.0.1:6379
```

**解决方案**：
```bash
# 检查 Redis 状态
sudo systemctl status redis

# 启动 Redis
sudo systemctl start redis

# 测试连接
redis-cli ping
```

#### 3. 阿里云 VoD 认证失败

**症状**：
```
❌ InvalidAccessKeyId.NotFound
```

**解决方案**：
```bash
# 验证环境变量
echo $ALIYUN_ACCESS_KEY_ID
echo $ALIYUN_ACCESS_KEY_SECRET

# 重新测试连接
npm run test:vod
```

#### 4. Telegram Bot Token 无效

**症状**：
```
❌ Telegram Bot Token 验证失败
```

**解决方案**：
```bash
# 测试 Bot Token
curl "https://api.telegram.org/bot<YOUR_TOKEN>/getMe"

# 应该返回 Bot 信息
```

#### 5. TON/SUK 区块链连接失败

**症状**：
```
❌ TON/SUK 区块链服务未连接
```

**解决方案**：
```bash
# 检查 RPC 配置
echo $TON_NETWORK
echo $ETHEREUM_RPC_URL

# 测试连接
node -e "const service = require('./backend/services/ton-blockchain.service'); service.healthCheck().then(console.log);"
```

### 调试技巧

#### 启用详细日志

```bash
# 设置环境变量
export DEBUG=true
export LOG_LEVEL=debug

# 启动应用
npm start
```

#### 查看实时日志

```bash
# PM2 日志
pm2 logs drama-platform --lines 100

# 跟踪日志
pm2 logs drama-platform -f
```

#### 数据库查询调试

```javascript
// 在代码中添加
mongoose.set('debug', true);

// 将会打印所有 MongoDB 查询
```

---

## 测试检查清单

### 部署前检查

- [ ] 所有自动化测试通过
- [ ] API 接口正常响应
- [ ] 数据库连接稳定
- [ ] Redis 缓存工作正常
- [ ] 阿里云 VoD 集成正常
- [ ] Telegram Bot 配置正确
- [ ] TON 区块链服务正常
- [ ] SUK Token 服务正常
- [ ] 播放器功能完整
- [ ] 支付流程完整
- [ ] 性能测试通过
- [ ] 安全测试通过
- [ ] 错误处理完善
- [ ] 日志记录完整

### 生产环境检查

- [ ] HTTPS 已启用
- [ ] 环境变量安全配置
- [ ] 数据库备份自动化
- [ ] 监控告警配置
- [ ] 日志轮转配置
- [ ] CDN 配置（如需要）
- [ ] 防火墙规则配置
- [ ] Rate Limiting 启用
- [ ] 错误追踪（Sentry）配置

---

## 持续集成

### GitHub Actions 示例

```yaml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    services:
      mongodb:
        image: mongo:6.0
        ports:
          - 27017:27017
      
      redis:
        image: redis:6.0
        ports:
          - 6379:6379
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Run tests
        run: npm test
        env:
          MONGODB_URI: mongodb://localhost:27017/test
          REDIS_HOST: localhost
```

---

## 参考文档

- [API 文档](API.md) - 完整的 API 参考
- [部署指南](DEPLOYMENT_GUIDE.md) - 生产环境部署
- [快速开始](QUICK_START.md) - 快速开始指南

---

**最后更新**: 2024-11-15  
**版本**: v1.0.0
