# SUK.WTF Firebase 快速开始指南
# Firebase Quick Start Guide

> **🔥 5 分钟部署项目官网到 Firebase**

---

## 📋 准备工作（5 分钟）

### 1. 安装 Firebase CLI

```bash
# 全局安装
npm install -g firebase-tools

# 验证安装
firebase --version
```

### 2. 登录 Firebase

```bash
firebase login

# 会打开浏览器，选择 Google 账号登录
```

---

## 🚀 首次部署（5 分钟）

### 方式 A：使用部署脚本（推荐）⭐

```bash
# 1. 添加执行权限
chmod +x scripts/deploy-firebase-website.sh

# 2. 运行部署脚本
./scripts/deploy-firebase-website.sh

# 脚本会自动：
# ✅ 检查 Firebase CLI
# ✅ 验证登录状态
# ✅ 清理临时文件
# ✅ 验证关键文件
# ✅ 部署到 Firebase
# ✅ 验证部署状态
```

### 方式 B：手动部署

```bash
# 1. 初始化 Firebase（仅首次）
firebase init hosting

# 2. 选择配置
# - Public directory: . (当前目录)
# - Single-page app: N
# - Overwrite index.html: N

# 3. 部署
firebase deploy --only hosting
```

---

## ✅ 验证部署

部署完成后，访问以下地址：

```bash
# 1. Firebase 默认域名
https://YOUR-PROJECT-ID.web.app

# 2. 自定义域名（配置后）
https://suk.link
```

---

## 🌐 配置自定义域名（可选）

### 步骤 1：在 Firebase 控制台添加域名

1. 访问：https://console.firebase.google.com/
2. 选择项目
3. Hosting → 添加自定义域名
4. 输入：`suk.link`
5. 点击继续

### 步骤 2：在 GoDaddy 配置 DNS

**添加 A 记录**：

```
类型: A
名称: @
值: 151.101.1.195
TTL: 600

类型: A
名称: @
值: 151.101.65.195
TTL: 600
```

**添加 CNAME 记录（可选）**：

```
类型: CNAME
名称: www
值: suk.link
TTL: 600
```

### 步骤 3：等待 SSL 证书生成

- 通常需要 24-48 小时
- Firebase 会自动申请 Let's Encrypt 证书
- 期间可以使用 Firebase 默认域名访问

---

## 🔄 日常更新部署

### 更新网站内容后：

```bash
# 方式 1：使用部署脚本
./scripts/deploy-firebase-website.sh

# 方式 2：手动部署
firebase deploy --only hosting
```

### 预览部署（测试）：

```bash
# 创建预览链接（不影响生产）
./scripts/deploy-firebase-website.sh preview

# 或
firebase hosting:channel:deploy preview
```

---

## 📊 常用命令

```bash
# 本地预览
firebase serve

# 查看部署历史
firebase hosting:clone

# 回滚到上一版本
firebase hosting:rollback

# 查看项目列表
firebase projects:list

# 切换项目
firebase use PROJECT_ID
```

---

## 🔍 故障排查

### 问题 1：部署失败

```bash
# 重新登录
firebase logout
firebase login

# 重新部署
firebase deploy --only hosting
```

### 问题 2：自定义域名无法访问

**检查清单**：
- [ ] DNS A 记录是否正确
- [ ] 是否等待 24-48 小时
- [ ] 清除浏览器缓存

```bash
# 检查 DNS
nslookup suk.link

# 检查 HTTPS
curl -I https://suk.link
```

---

## 📚 相关文档

- 📖 **完整指南**: `FIREBASE_SETUP_COMPLETE_GUIDE.md`
- 🔧 **部署脚本**: `scripts/deploy-firebase-website.sh`
- ⚙️ **配置文件**: `firebase.json`

---

## 🎯 项目架构

```
suk.link 域名分配：
├── suk.link              → Firebase Hosting（项目官网）
├── api.suk.link          → 云服务器（后端 API）
└── monitor.suk.link      → 云服务器（监控面板）
```

**说明**：
- ✅ `suk.link` 官网部署到 Firebase（免费、快速、全球 CDN）
- ✅ `api.suk.link` 后端 API 部署到云服务器
- ✅ 两者分离，官网和 API 独立部署

---

## ✅ 检查清单

### 首次部署前

- [ ] 已安装 Firebase CLI
- [ ] 已登录 Firebase
- [ ] 已创建 Firebase 项目
- [ ] 已运行 `firebase init`
- [ ] `firebase.json` 配置正确
- [ ] 关键文件都在根目录

### 部署后验证

- [ ] Firebase 默认域名可访问
- [ ] 所有页面正常加载
- [ ] 图片正常显示
- [ ] CSS 和 JS 正常工作
- [ ] Telegram Mini App 可用

### 自定义域名配置后

- [ ] DNS A 记录已添加
- [ ] 等待 24-48 小时
- [ ] SSL 证书已生成
- [ ] HTTPS 访问正常

---

## 🎉 总结

### 完整流程

1. ✅ 安装 Firebase CLI（1 分钟）
2. ✅ 登录 Firebase（1 分钟）
3. ✅ 运行部署脚本（3 分钟）
4. ✅ 验证部署（1 分钟）

**总计**：5-10 分钟

### 后续更新

1. 修改网站内容
2. 运行 `./scripts/deploy-firebase-website.sh`
3. 等待 1-2 分钟部署完成
4. 刷新浏览器查看更新

**更新耗时**：约 2 分钟

---

**快速开始版本**: v1.0  
**更新时间**: 2024-11-16  
**域名**: suk.link  
**平台**: Firebase Hosting

🔥 **开始您的 Firebase 之旅！** 🔥
