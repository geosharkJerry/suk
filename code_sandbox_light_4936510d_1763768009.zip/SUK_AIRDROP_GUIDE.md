# SUK代币空投完整指南
# SUK Token Airdrop Complete Guide

**版本**: 1.0.0  
**日期**: 2024-11-16  
**状态**: 🟢 Ready to Deploy

---

## 📋 目录

- [空投概述](#空投概述)
- [智能合约](#智能合约)
- [部署指南](#部署指南)
- [管理操作](#管理操作)
- [用户认领流程](#用户认领流程)
- [SUK代币支付观看](#suk代币支付观看)
- [安全考虑](#安全考虑)

---

## 🎯 空投概述

### 空投参数

| 参数 | 数值 | 说明 |
|------|------|------|
| **总空投量** | 1,000,000 SUK | 100万SUK代币 |
| **白名单额度** | 5,000 SUK/地址 | 首批RWA参与者 |
| **公开额度** | 3,000 SUK/地址 | 普通用户 |
| **认领次数** | 1次/地址 | 防止重复认领 |
| **合约标准** | ERC20 | 以太坊标准代币 |

### 空投阶段

```
阶段一: 白名单认领 (提前3天)
├─ 时间: T+0 到 T+3天
├─ 对象: 首批RWA参与者
└─ 额度: 5,000 SUK/地址

阶段二: 公开认领 (持续30天)
├─ 时间: T+3天 到 T+33天
├─ 对象: 所有用户
└─ 额度: 3,000 SUK/地址

阶段三: 未认领处理
├─ 剩余代币回收
└─ 用于二期空投或生态激励
```

### 资金分配

```
100万 SUK空投分配:
├─ 白名单池: 约200个地址 × 5,000 = 1,000,000 SUK (预期)
├─ 公开池: 约267个地址 × 3,000 = 801,000 SUK (预期)
└─ 预留: 199,000 SUK (二期/补充)
```

---

## 🔐 智能合约

### 合约文件

**路径**: `contracts/SUKAirdrop.sol`

### 核心功能

```solidity
// 1. 用户认领
function claim() external nonReentrant whenNotPaused

// 2. 批量分发（管理员）
function batchClaim(address[] calldata users) external onlyOwner

// 3. 白名单管理
function addToWhitelist(address[] calldata users) external onlyOwner
function removeFromWhitelist(address[] calldata users) external onlyOwner

// 4. 查询功能
function getClaimableAmount(address user) public view returns (uint256)
function getClaimInfo(address user) external view returns (...)
function getAirdropStats() external view returns (...)

// 5. 紧急功能
function pause() external onlyOwner
function emergencyWithdraw(uint256 amount) external onlyOwner
```

### 安全特性

- ✅ **ReentrancyGuard**: 防止重入攻击
- ✅ **Pausable**: 紧急暂停功能
- ✅ **Ownable**: 权限管理
- ✅ **防重复认领**: 每地址只能认领一次
- ✅ **余额检查**: 防止超发

---

## 🚀 部署指南

### 1. 前置准备

```bash
# 安装依赖
npm install @openzeppelin/contracts
npm install hardhat
npm install @nomicfoundation/hardhat-toolbox

# 配置环境变量
cp .env.example .env
# 编辑 .env 文件，填入:
# - PRIVATE_KEY (部署者私钥)
# - INFURA_API_KEY (或其他RPC)
# - ETHERSCAN_API_KEY (合约验证)
```

### 2. 编译合约

```bash
npx hardhat compile
```

### 3. 部署脚本

创建 `scripts/deploy-airdrop.js`:

```javascript
const hre = require("hardhat");

async function main() {
    // 配置参数
    const SUK_TOKEN_ADDRESS = "0x..."; // SUK代币合约地址
    
    // 时间配置（Unix时间戳）
    const now = Math.floor(Date.now() / 1000);
    const WHITELIST_START = now + 3600;        // 1小时后开始
    const PUBLIC_START = WHITELIST_START + (3 * 24 * 3600);  // 3天后
    const END_TIME = PUBLIC_START + (30 * 24 * 3600);        // 30天后
    
    console.log("部署SUK空投合约...");
    console.log("SUK代币地址:", SUK_TOKEN_ADDRESS);
    console.log("白名单开始:", new Date(WHITELIST_START * 1000));
    console.log("公开开始:", new Date(PUBLIC_START * 1000));
    console.log("结束时间:", new Date(END_TIME * 1000));
    
    // 部署合约
    const SUKAirdrop = await hre.ethers.getContractFactory("SUKAirdrop");
    const airdrop = await SUKAirdrop.deploy(
        SUK_TOKEN_ADDRESS,
        WHITELIST_START,
        PUBLIC_START,
        END_TIME
    );
    
    await airdrop.deployed();
    
    console.log("✅ 空投合约已部署:", airdrop.address);
    
    // 转移SUK代币到合约
    console.log("\n请执行以下操作:");
    console.log("1. 转移 1,000,000 SUK 到合约地址:", airdrop.address);
    console.log("2. 添加白名单地址");
    console.log("3. 在前端配置合约地址");
    
    return airdrop.address;
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
```

### 4. 执行部署

```bash
# 测试网部署 (Goerli)
npx hardhat run scripts/deploy-airdrop.js --network goerli

# 主网部署 (需谨慎)
npx hardhat run scripts/deploy-airdrop.js --network mainnet
```

### 5. 验证合约

```bash
npx hardhat verify --network goerli AIRDROP_CONTRACT_ADDRESS \
    "SUK_TOKEN_ADDRESS" \
    "WHITELIST_START_TIME" \
    "PUBLIC_START_TIME" \
    "END_TIME"
```

---

## 🔧 管理操作

### 1. 转移SUK代币到合约

```javascript
// 使用ethers.js
const sukToken = new ethers.Contract(SUK_TOKEN_ADDRESS, ERC20_ABI, signer);
const amount = ethers.utils.parseEther("1000000"); // 100万SUK

const tx = await sukToken.transfer(AIRDROP_CONTRACT_ADDRESS, amount);
await tx.wait();

console.log("✅ 已转移 1,000,000 SUK 到空投合约");
```

### 2. 添加白名单

```javascript
// 批量添加白名单
const airdrop = new ethers.Contract(AIRDROP_ADDRESS, AIRDROP_ABI, signer);

const whitelistAddresses = [
    "0x1234...",
    "0x5678...",
    // ... 更多地址
];

// 建议每次50-100个地址
const batchSize = 50;
for (let i = 0; i < whitelistAddresses.length; i += batchSize) {
    const batch = whitelistAddresses.slice(i, i + batchSize);
    const tx = await airdrop.addToWhitelist(batch);
    await tx.wait();
    console.log(`✅ 已添加第 ${i/batchSize + 1} 批白名单`);
}
```

### 3. 从CSV导入白名单

创建 `scripts/import-whitelist.js`:

```javascript
const fs = require('fs');
const { parse } = require('csv-parse/sync');

async function importWhitelist() {
    // 读取CSV文件
    const csvData = fs.readFileSync('whitelist.csv', 'utf8');
    const records = parse(csvData, {
        columns: true,
        skip_empty_lines: true
    });
    
    // 提取地址
    const addresses = records.map(r => r.address);
    
    // 验证地址格式
    const validAddresses = addresses.filter(addr => 
        ethers.utils.isAddress(addr)
    );
    
    console.log(`有效地址: ${validAddresses.length}`);
    
    // 批量添加
    const airdrop = await ethers.getContractAt("SUKAirdrop", AIRDROP_ADDRESS);
    
    const batchSize = 50;
    for (let i = 0; i < validAddresses.length; i += batchSize) {
        const batch = validAddresses.slice(i, i + batchSize);
        await airdrop.addToWhitelist(batch);
        console.log(`批次 ${Math.floor(i/batchSize) + 1} 完成`);
    }
}

importWhitelist();
```

CSV格式 (`whitelist.csv`):
```csv
address,note
0x1234567890123456789012345678901234567890,First adopter
0xabcdefabcdefabcdefabcdefabcdefabcdefabcd,Early investor
```

### 4. 查询空投状态

```javascript
// 获取统计信息
const stats = await airdrop.getAirdropStats();
console.log("已认领:", ethers.utils.formatEther(stats.totalClaimed));
console.log("剩余:", ethers.utils.formatEther(stats.remaining));

// 检查特定地址
const claimInfo = await airdrop.getClaimInfo("0x...");
console.log("已认领:", claimInfo.claimed);
console.log("认领数量:", ethers.utils.formatEther(claimInfo.amount));
```

### 5. 紧急操作

```javascript
// 暂停空投
await airdrop.pause();

// 恢复空投
await airdrop.unpause();

// 紧急提取（空投结束后）
const remainingAmount = await sukToken.balanceOf(AIRDROP_ADDRESS);
await airdrop.emergencyWithdraw(remainingAmount);
```

---

## 👥 用户认领流程

### 前端集成

**文件**: `suk-airdrop.html`

### 认领步骤

1. **连接钱包**
   ```javascript
   const accounts = await window.ethereum.request({ 
       method: 'eth_requestAccounts' 
   });
   ```

2. **检查资格**
   ```javascript
   const claimable = await contract.getClaimableAmount(userAddress);
   const isWhitelisted = await contract.isWhitelisted(userAddress);
   ```

3. **执行认领**
   ```javascript
   const tx = await contract.claim();
   await tx.wait();
   ```

4. **确认结果**
   ```javascript
   const balance = await sukToken.balanceOf(userAddress);
   console.log("SUK余额:", ethers.utils.formatEther(balance));
   ```

---

## 🎬 SUK代币支付观看

### 集成方案

#### 方案1: 直接代币支付

```javascript
// 用户选择剧集
const dramaPrice = ethers.utils.parseEther("125"); // 125 SUK

// 授权合约使用SUK
const sukToken = new ethers.Contract(SUK_TOKEN_ADDRESS, ERC20_ABI, signer);
await sukToken.approve(DRAMA_CONTRACT_ADDRESS, dramaPrice);

// 购买剧集
const dramaContract = new ethers.Contract(DRAMA_ADDRESS, DRAMA_ABI, signer);
await dramaContract.purchaseDrama(dramaId);
```

#### 方案2: X402按时间点计费

```javascript
// 预充值SUK到观看账户
const amount = ethers.utils.parseEther("100"); // 充值100 SUK
await sukToken.approve(X402_BILLING_ADDRESS, amount);
await x402Billing.deposit(amount);

// 开始观看（自动扣费）
const player = new X402Player({
    dramaId: 1,
    userId: userAddress,
    paymentToken: "SUK"
});
```

### 后端API集成

```javascript
// Express.js 示例
app.post('/api/payment/verify-suk', async (req, res) => {
    const { userAddress, dramaId, txHash } = req.body;
    
    // 1. 验证交易
    const receipt = await provider.getTransactionReceipt(txHash);
    
    // 2. 解析日志，确认支付
    const transferEvent = sukToken.interface.parseLog(receipt.logs[0]);
    const amount = transferEvent.args.value;
    
    // 3. 授予观看权限
    await grantAccess(userAddress, dramaId);
    
    res.json({ success: true });
});
```

---

## 🛡️ 安全考虑

### 智能合约安全

1. **审计清单**
   - ✅ 重入攻击防护 (ReentrancyGuard)
   - ✅ 整数溢出防护 (Solidity 0.8+)
   - ✅ 权限控制 (Ownable)
   - ✅ 紧急暂停 (Pausable)
   - ✅ 余额验证

2. **测试覆盖**
   ```bash
   npx hardhat test
   npx hardhat coverage
   ```

3. **建议审计**
   - 推荐: CertiK, OpenZeppelin, Trail of Bits
   - 成本: $5,000 - $15,000
   - 时间: 1-2周

### 运营安全

1. **多签钱包**
   - 使用Gnosis Safe管理合约
   - 至少3/5多签
   - 关键操作需要多人确认

2. **监控系统**
   ```javascript
   // 监控异常认领
   airdrop.on("Claimed", (user, amount, isWhitelist, timestamp) => {
       // 记录日志
       console.log(`认领: ${user} - ${ethers.utils.formatEther(amount)} SUK`);
       
       // 异常检测
       if (amount > threshold) {
           alert("检测到大额认领！");
       }
   });
   ```

3. **备份恢复**
   - 定期备份白名单数据
   - 记录所有认领交易
   - 准备回滚方案

---

## 📊 数据统计

### 追踪指标

1. **认领统计**
   - 总认领数量
   - 白名单认领率
   - 公开认领率
   - 每日认领趋势

2. **用户行为**
   - 认领后观看率
   - SUK使用率
   - 用户留存率

3. **财务指标**
   - 空投成本 (Gas费用)
   - ROI (投资回报率)
   - 用户生命周期价值

### 数据导出

```javascript
// 导出所有认领记录
async function exportClaims() {
    const filter = airdrop.filters.Claimed();
    const events = await airdrop.queryFilter(filter);
    
    const claims = events.map(e => ({
        user: e.args.user,
        amount: ethers.utils.formatEther(e.args.amount),
        isWhitelist: e.args.isWhitelist,
        timestamp: new Date(e.args.timestamp * 1000),
        txHash: e.transactionHash
    }));
    
    // 保存为CSV
    const csv = objectsToCsv(claims);
    fs.writeFileSync('claims.csv', csv);
}
```

---

## 🎯 最佳实践

### 时间安排

```
建议时间线:
├─ D-7: 公告空投计划
├─ D-3: 开放白名单查询
├─ D-1: 最终测试
├─ D-0: 白名单认领开始
├─ D+3: 公开认领开始
├─ D+33: 空投结束
└─ D+35: 未认领代币回收
```

### 营销推广

1. **预热阶段**
   - 社交媒体宣传
   - KOL合作
   - 社区AMA

2. **认领阶段**
   - 每日提醒
   - 认领教程
   - 技术支持

3. **激活阶段**
   - 观看引导
   - SUK使用教程
   - 新用户奖励

### 风险管理

1. **技术风险**
   - 合约Bug → 代码审计
   - Gas费暴涨 → 预留预算
   - 网络拥堵 → 延长时间

2. **运营风险**
   - 女巫攻击 → KYC验证
   - 低认领率 → 延长期限
   - 市场波动 → 灵活调整

---

## 📞 技术支持

**合约地址**: 部署后更新  
**前端页面**: `suk-airdrop.html`  
**文档**: `SUK_AIRDROP_GUIDE.md`  

**联系方式**:
- 技术支持: tech@suk.link
- 商务合作: business@suk.link

---

## 📝 检查清单

### 部署前

- [ ] 合约代码审计完成
- [ ] 测试网充分测试
- [ ] 白名单数据准备
- [ ] 前端页面测试
- [ ] 文档完善
- [ ] 团队培训

### 部署时

- [ ] 合约成功部署
- [ ] SUK代币转入
- [ ] 白名单导入
- [ ] 前端配置更新
- [ ] 合约验证
- [ ] 监控启动

### 上线后

- [ ] 功能测试
- [ ] 第一笔认领验证
- [ ] 数据监控
- [ ] 用户反馈收集
- [ ] 持续优化

---

**版权所有 © 2024 SUK Protocol**  
**最后更新**: 2024-11-16
