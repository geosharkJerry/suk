# 🌍 SUK Protocol 多语言系统使用指南

## ✅ 已完成的功能

### 1. 支持的语言
- 🇨🇳 **中文** (Chinese - Simplified) - `zh`
- 🇺🇸 **英语** (English) - `en`
- 🇪🇸 **西班牙语** (Español) - `es`
- 🇹🇭 **泰语** (ไทย) - `th`
- 🇻🇳 **越南语** (Tiếng Việt) - `vi`
- 🇯🇵 **日语** (日本語) - `ja`

### 2. 核心文件

#### **js/i18n-translations.js** (27.5 KB)
包含所有6种语言的完整翻译数据库。

**结构示例：**
```javascript
const translations = {
    zh: {
        nav: { about: "关于", howItWorks: "工作原理", ... },
        hero: { badge: "🎬 全球Web3.0链剧资产平台", ... },
        portfolio: { title: "热门短剧RWA", ... },
        ...
    },
    en: {
        nav: { about: "About", howItWorks: "How It Works", ... },
        ...
    },
    ...
}
```

#### **js/i18n.js** (10.9 KB)
多语言系统核心引擎，自动处理语言切换和页面翻译。

**主要功能：**
- 自动检测浏览器语言
- 本地存储语言偏好设置
- 动态创建语言切换器UI
- 实时翻译页面内容
- 支持嵌套翻译键（如 `nav.about`）

### 3. 使用方法

#### A. 在HTML页面中集成

**步骤1：** 在`<head>`标签中引入必要的脚本：
```html
<link rel="stylesheet" href="css/style.css">
<script src="js/i18n-translations.js"></script>
<script src="js/i18n.js"></script>
</head>
```

**步骤2：** 为需要翻译的元素添加 `data-i18n` 属性：
```html
<!-- 导航栏 -->
<a href="#about" data-i18n="nav.about">关于</a>
<a href="#how-it-works" data-i18n="nav.howItWorks">工作原理</a>

<!-- 按钮 -->
<button data-i18n="hero.btnExplore">探索作品集</button>

<!-- 标题 -->
<h2 data-i18n="portfolio.title">热门短剧RWA</h2>

<!-- 段落 -->
<p data-i18n="about.text1">SUK Protocol由SUK基金会管理运营...</p>
```

**步骤3：** 对于包含HTML内容的元素，使用 `data-i18n-html`：
```html
<div data-i18n-html="hero.subtitle1">
    通过SUK Protocol，将竖屏短剧版权转化为链上资产（RWA）
</div>
```

### 4. 语言切换器UI

**自动生成的语言切换器包括：**
- ✅ 当前语言旗帜emoji + 语言代码
- ✅ 下拉菜单显示所有6种语言
- ✅ 当前语言标记（✓）
- ✅ 悬停效果和平滑动画
- ✅ 移动端自适应设计

**UI位置：** 自动插入到导航栏 `.nav-content` 的左侧（语言切换器在最左边）

### 5. 翻译键映射表

| 分类 | 翻译键前缀 | 示例 |
|------|-----------|------|
| 导航栏 | `nav.*` | `nav.about`, `nav.dashboard` |
| Hero区域 | `hero.*` | `hero.title1`, `hero.stat1Value` |
| 首个作品集 | `firstPortfolio.*` | `firstPortfolio.tag`, `firstPortfolio.value1` |
| 关于SUK | `about.*` | `about.title`, `about.card1Title` |
| 工作原理 | `howItWorks.*` | `howItWorks.step1Title`, `howItWorks.step1Desc` |
| 作品集展示 | `portfolio.*` | `portfolio.labelTokenPrice`, `portfolio.btnInvest` |
| 收益说明 | `earn.*` | `earn.title`, `earn.item1Title` |
| 基金会介绍 | `foundation.*` | `foundation.name`, `foundation.desc` |
| 通用术语 | `common.*` | `common.episodes`, `common.suk` |

### 6. 编程式访问

**获取翻译文本：**
```javascript
// 获取当前语言
const currentLang = window.i18n.getCurrentLanguage(); // "zh", "en", etc.

// 获取特定翻译
const translated = window.i18n.t('nav.about'); // returns "关于" or "About"
```

**手动切换语言：**
```javascript
window.i18n.changeLanguage('en'); // 切换到英语
```

### 7. 本地存储

语言偏好设置自动保存到 `localStorage`:
```javascript
localStorage.getItem('sukProtocolLang'); // "zh", "en", etc.
```

用户再次访问时，将自动恢复上次选择的语言。

---

## 📝 为新页面添加多语言支持

### 步骤清单：

1. **引入脚本文件**
   ```html
   <script src="js/i18n-translations.js"></script>
   <script src="js/i18n.js"></script>
   ```

2. **为文本元素添加标记**
   - 纯文本：`data-i18n="key.path"`
   - HTML内容：`data-i18n-html="key.path"`
   - 输入框placeholder：`data-i18n="key.path"` (自动检测)

3. **添加新的翻译键**（如果需要）
   在 `js/i18n-translations.js` 中为所有6种语言添加对应的翻译：
   ```javascript
   zh: {
       newSection: {
           title: "新标题",
           desc: "新描述"
       }
   },
   en: {
       newSection: {
           title: "New Title",
           desc: "New Description"
       }
   },
   // ... 其他语言
   ```

---

## 🎨 语言切换器样式定制

语言切换器的样式已内置在 `i18n.js` 中，如需自定义：

### 修改按钮样式
```css
.lang-btn {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 8px;
    /* 自定义样式 */
}
```

### 修改下拉菜单样式
```css
.lang-dropdown {
    background: white;
    border-radius: 12px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    /* 自定义样式 */
}
```

### 修改语言选项悬停效果
```css
.lang-option:hover {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    /* 自定义样式 */
}
```

---

## 🔧 高级功能

### 动态翻译新增内容

如果通过JavaScript动态添加内容，需要手动调用翻译：
```javascript
// 添加新内容后
document.getElementById('newContent').setAttribute('data-i18n', 'new.key');

// 手动触发翻译
window.i18n.translatePage();
```

### 检测语言变化

监听语言切换事件（需自行实现）：
```javascript
// 在 changeLanguage 方法中添加自定义回调
window.addEventListener('languageChanged', (e) => {
    console.log('Language changed to:', e.detail.language);
    // 执行自定义操作
});
```

---

## 📊 翻译完整性

### 当前翻译状态

| 页面 | 中文 | 英语 | 西班牙语 | 泰语 | 越南语 | 日语 |
|------|-----|------|---------|------|--------|------|
| **index.html** | ✅ 100% | ✅ 100% | ✅ 100% | ✅ 100% | ✅ 100% | ✅ 100% |
| drama-detail.html | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 |
| dashboard.html | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 |
| faq.html | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 |
| whitepaper.html | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 |
| auth.html | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 | ⏳ 待添加 |

---

## 🚀 性能优化

### 翻译数据大小
- **i18n-translations.js**: 27.5 KB (未压缩)
- **i18n.js**: 10.9 KB (未压缩)
- **总计**: ~38 KB

### 优化建议
1. **启用Gzip压缩** - 可减少60-70%的文件大小
2. **延迟加载** - 可按需加载特定语言的翻译
3. **缓存策略** - 利用浏览器缓存减少重复加载

---

## ❓ 常见问题

### Q1: 如何添加新语言？
在 `i18n-translations.js` 中添加新语言对象，并在 `i18n.js` 的 `supportedLanguages` 数组中注册。

### Q2: 翻译不生效怎么办？
检查：
1. 脚本引入顺序正确
2. `data-i18n` 属性值与翻译键匹配
3. 浏览器控制台是否有错误

### Q3: 如何禁用自动语言检测？
在 `i18n.js` 的构造函数中修改：
```javascript
this.currentLang = 'zh'; // 强制默认中文
```

### Q4: 数字和货币如何本地化？
当前系统主要处理文本翻译。数字和货币格式化需要额外实现：
```javascript
// 示例：货币格式化
const formatter = new Intl.NumberFormat(currentLang === 'zh' ? 'zh-CN' : 'en-US', {
    style: 'currency',
    currency: 'USD'
});
```

---

## 📞 技术支持

如需扩展或定制多语言系统，请参考：
- **翻译数据**: `js/i18n-translations.js`
- **核心引擎**: `js/i18n.js`
- **示例页面**: `index.html`

---

**最后更新**: 2025-11-15  
**版本**: 1.0.0  
**维护者**: SUK Protocol Team
