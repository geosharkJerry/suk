/**
 * 邀请码追踪统计脚本
 * 
 * 功能：
 * 1. 统计邀请码激活情况
 * 2. 追踪到期时间
 * 3. 查询领取状态
 * 4. 生成详细报告
 * 
 * 使用方法：
 * node scripts/track-invite-codes.js [--network <network>] [--export]
 * 
 * 示例：
 * node scripts/track-invite-codes.js --network goerli
 * node scripts/track-invite-codes.js --network goerli --export
 */

const fs = require('fs');
const path = require('path');
const hre = require('hardhat');

/**
 * 加载本地邀请码记录
 */
function loadLocalCodes(network) {
    const dir = path.join(__dirname, '../deployment/invite-codes');
    if (!fs.existsSync(dir)) {
        return [];
    }
    
    const files = fs.readdirSync(dir)
        .filter(f => f.includes(network) && f.endsWith('.json'))
        .sort()
        .reverse();
    
    let allCodes = [];
    
    files.forEach(file => {
        try {
            const data = JSON.parse(fs.readFileSync(path.join(dir, file)));
            if (data.codes && Array.isArray(data.codes)) {
                allCodes = allCodes.concat(data.codes.map(c => ({
                    ...c,
                    sourceFile: file
                })));
            }
        } catch (error) {
            console.warn(`⚠️  警告: 无法读取文件 ${file}`);
        }
    });
    
    return allCodes;
}

/**
 * 从合约获取邀请码状态
 */
async function getCodeStatusFromContract(contract, code) {
    try {
        const info = await contract.getInviteCodeInfo(code);
        
        return {
            exists: info.exists,
            creator: info.creator,
            createdAt: info.createdAt.toNumber(),
            expiresAt: info.expiresAt.toNumber(),
            isUsed: info.isUsed,
            usedBy: info.usedBy,
            usedAt: info.usedAt.toNumber()
        };
    } catch (error) {
        return null;
    }
}

/**
 * 检查用户是否已领取空投
 */
async function checkClaimStatus(contract, address) {
    try {
        if (address === '0x0000000000000000000000000000000000000000') {
            return { claimed: false, amount: 0, timestamp: 0 };
        }
        
        const claimInfo = await contract.getClaimInfo(address);
        
        return {
            claimed: claimInfo.claimed,
            amount: hre.ethers.utils.formatEther(claimInfo.amount),
            timestamp: claimInfo.timestamp.toNumber(),
            isWhitelist: claimInfo.isWhitelist
        };
    } catch (error) {
        return { claimed: false, amount: 0, timestamp: 0 };
    }
}

/**
 * 统计邀请码状态
 */
function generateStats(codes, now) {
    const stats = {
        total: codes.length,
        pending: 0,
        activated: 0,
        expired: 0,
        claimed: 0,
        notClaimed: 0,
        expiringSoon: 0,  // 30天内过期
        categories: {
            byMonth: {},
            byStatus: {}
        }
    };
    
    codes.forEach(code => {
        // 状态统计
        if (code.isUsed) {
            stats.activated++;
            
            if (code.claimStatus && code.claimStatus.claimed) {
                stats.claimed++;
            } else {
                stats.notClaimed++;
            }
        } else if (now > code.expiresAt * 1000) {
            stats.expired++;
        } else {
            stats.pending++;
            
            // 即将过期（30天内）
            const daysUntilExpiry = (code.expiresAt * 1000 - now) / (24 * 3600 * 1000);
            if (daysUntilExpiry <= 30) {
                stats.expiringSoon++;
            }
        }
        
        // 按月份统计
        if (code.createdAt) {
            const month = new Date(code.createdAt * 1000).toISOString().slice(0, 7);
            stats.categories.byMonth[month] = (stats.categories.byMonth[month] || 0) + 1;
        }
    });
    
    return stats;
}

/**
 * 生成详细报告
 */
function generateReport(codes, stats) {
    const now = Date.now();
    
    let report = '';
    
    report += '\n' + '='.repeat(80) + '\n';
    report += '📊 SUK 邀请码追踪报告\n';
    report += '='.repeat(80) + '\n\n';
    
    // 总体统计
    report += '📈 总体统计:\n';
    report += '─'.repeat(80) + '\n';
    report += `总邀请码数:     ${stats.total}\n`;
    report += `待使用:         ${stats.pending} (${(stats.pending / stats.total * 100).toFixed(1)}%)\n`;
    report += `已激活:         ${stats.activated} (${(stats.activated / stats.total * 100).toFixed(1)}%)\n`;
    report += `已过期:         ${stats.expired} (${(stats.expired / stats.total * 100).toFixed(1)}%)\n`;
    report += `30天内过期:     ${stats.expiringSoon}\n`;
    report += '\n';
    
    // 领取统计
    if (stats.activated > 0) {
        report += '💰 领取统计:\n';
        report += '─'.repeat(80) + '\n';
        report += `已激活用户:     ${stats.activated}\n`;
        report += `已领取空投:     ${stats.claimed} (${(stats.claimed / stats.activated * 100).toFixed(1)}%)\n`;
        report += `未领取空投:     ${stats.notClaimed} (${(stats.notClaimed / stats.activated * 100).toFixed(1)}%)\n`;
        report += '\n';
    }
    
    // 按月份统计
    if (Object.keys(stats.categories.byMonth).length > 0) {
        report += '📅 按月份统计:\n';
        report += '─'.repeat(80) + '\n';
        Object.entries(stats.categories.byMonth)
            .sort()
            .forEach(([month, count]) => {
                report += `${month}:     ${count} 个邀请码\n`;
            });
        report += '\n';
    }
    
    // 即将过期列表
    if (stats.expiringSoon > 0) {
        report += '⚠️  即将过期的邀请码 (30天内):\n';
        report += '─'.repeat(80) + '\n';
        
        codes
            .filter(c => !c.isUsed && c.expiresAt * 1000 > now)
            .map(c => ({
                ...c,
                daysLeft: Math.floor((c.expiresAt * 1000 - now) / (24 * 3600 * 1000))
            }))
            .filter(c => c.daysLeft <= 30)
            .sort((a, b) => a.daysLeft - b.daysLeft)
            .slice(0, 20)
            .forEach(code => {
                report += `${code.code}     还剩 ${code.daysLeft} 天\n`;
            });
        
        if (stats.expiringSoon > 20) {
            report += `... 还有 ${stats.expiringSoon - 20} 个即将过期的邀请码\n`;
        }
        report += '\n';
    }
    
    // 已激活但未领取列表
    if (stats.notClaimed > 0) {
        report += '🔔 已激活但未领取空投的用户:\n';
        report += '─'.repeat(80) + '\n';
        
        codes
            .filter(c => c.isUsed && c.claimStatus && !c.claimStatus.claimed)
            .slice(0, 20)
            .forEach(code => {
                const activatedDays = Math.floor((now - code.usedAt * 1000) / (24 * 3600 * 1000));
                report += `${code.code}     激活用户: ${code.usedBy.substring(0, 10)}...     已激活 ${activatedDays} 天\n`;
            });
        
        if (stats.notClaimed > 20) {
            report += `... 还有 ${stats.notClaimed - 20} 个用户未领取\n`;
        }
        report += '\n';
    }
    
    report += '='.repeat(80) + '\n';
    
    return report;
}

/**
 * 导出CSV报告
 */
function exportToCSV(codes, filename) {
    const now = Date.now();
    
    let csv = 'invite_code,status,created_at,expires_at,days_until_expiry,activated_by,activated_at,claimed,claim_amount,claim_time\n';
    
    codes.forEach(code => {
        const status = code.isUsed ? 'activated' : 
                      (now > code.expiresAt * 1000) ? 'expired' : 'pending';
        
        const daysUntilExpiry = Math.floor((code.expiresAt * 1000 - now) / (24 * 3600 * 1000));
        
        const createdAt = code.createdAt ? new Date(code.createdAt * 1000).toISOString() : '';
        const expiresAt = code.expiresAt ? new Date(code.expiresAt * 1000).toISOString() : '';
        const activatedAt = code.usedAt ? new Date(code.usedAt * 1000).toISOString() : '';
        const claimTime = (code.claimStatus && code.claimStatus.timestamp) ? 
            new Date(code.claimStatus.timestamp * 1000).toISOString() : '';
        
        csv += `${code.code},${status},${createdAt},${expiresAt},${daysUntilExpiry},`;
        csv += `${code.usedBy || ''},${activatedAt},`;
        csv += `${code.claimStatus ? code.claimStatus.claimed : false},`;
        csv += `${code.claimStatus ? code.claimStatus.amount : 0},${claimTime}\n`;
    });
    
    const filepath = path.join(__dirname, '../deployment/reports', filename);
    const dir = path.dirname(filepath);
    
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFileSync(filepath, csv);
    console.log(`\n📥 CSV报告已导出: ${filepath}`);
}

/**
 * 主函数
 */
async function main() {
    const args = process.argv.slice(2);
    
    // 解析参数
    let network = 'goerli';
    let shouldExport = false;
    
    for (let i = 0; i < args.length; i++) {
        if (args[i] === '--network' && i + 1 < args.length) {
            network = args[i + 1];
            i++;
        } else if (args[i] === '--export') {
            shouldExport = true;
        }
    }
    
    console.log('\n' + '='.repeat(80));
    console.log('🔍 SUK 邀请码追踪系统');
    console.log('='.repeat(80));
    console.log(`📍 网络: ${network}`);
    console.log('');
    
    try {
        // 1. 加载本地邀请码记录
        console.log('📂 正在加载本地邀请码记录...');
        const localCodes = loadLocalCodes(network);
        console.log(`   ✅ 已加载 ${localCodes.length} 个邀请码记录\n`);
        
        if (localCodes.length === 0) {
            console.log('⚠️  未找到邀请码记录。请先生成邀请码。\n');
            return;
        }
        
        // 2. 连接合约
        console.log('🔗 正在连接智能合约...');
        
        const deploymentDir = path.join(__dirname, '../deployment');
        const airdropFiles = fs.readdirSync(deploymentDir)
            .filter(f => f.includes('airdrop-v2') && f.includes(network) && f.endsWith('.json'))
            .sort()
            .reverse();
        
        if (airdropFiles.length === 0) {
            throw new Error(`未找到 ${network} 上的 AirdropV2 部署记录`);
        }
        
        const deployment = JSON.parse(
            fs.readFileSync(path.join(deploymentDir, airdropFiles[0]))
        );
        
        const contractAddress = deployment.airdropAddress;
        console.log(`   ✅ 合约地址: ${contractAddress}\n`);
        
        const [signer] = await hre.ethers.getSigners();
        const contract = await hre.ethers.getContractAt('SUKAirdropV2', contractAddress);
        
        // 3. 获取合约状态
        console.log('📊 正在查询合约状态...');
        
        const progressBar = (current, total) => {
            const percent = Math.floor(current / total * 100);
            const bar = '█'.repeat(Math.floor(percent / 2)) + '░'.repeat(50 - Math.floor(percent / 2));
            process.stdout.write(`\r   进度: [${bar}] ${percent}% (${current}/${total})`);
        };
        
        const enrichedCodes = [];
        
        for (let i = 0; i < localCodes.length; i++) {
            const code = localCodes[i];
            
            // 从合约获取状态
            const contractStatus = await getCodeStatusFromContract(contract, code.code);
            
            let enrichedCode = {
                code: code.code,
                sourceFile: code.sourceFile,
                ...contractStatus
            };
            
            // 如果已激活，检查领取状态
            if (contractStatus && contractStatus.isUsed) {
                const claimStatus = await checkClaimStatus(contract, contractStatus.usedBy);
                enrichedCode.claimStatus = claimStatus;
            }
            
            enrichedCodes.push(enrichedCode);
            
            progressBar(i + 1, localCodes.length);
            
            // 避免请求过快
            if ((i + 1) % 10 === 0) {
                await new Promise(resolve => setTimeout(resolve, 100));
            }
        }
        
        console.log('\n   ✅ 状态查询完成\n');
        
        // 4. 生成统计
        console.log('📈 正在生成统计报告...');
        const now = Date.now();
        const stats = generateStats(enrichedCodes, now);
        
        // 5. 显示报告
        const report = generateReport(enrichedCodes, stats);
        console.log(report);
        
        // 6. 导出CSV（如果需要）
        if (shouldExport) {
            const timestamp = Date.now();
            const filename = `invite-codes-report-${network}-${timestamp}.csv`;
            exportToCSV(enrichedCodes, filename);
        } else {
            console.log('💡 提示: 使用 --export 参数可以导出 CSV 报告\n');
        }
        
        // 7. 保存JSON报告
        const jsonReport = {
            network,
            timestamp: new Date().toISOString(),
            stats,
            codes: enrichedCodes
        };
        
        const jsonPath = path.join(
            __dirname,
            '../deployment/reports',
            `invite-codes-report-${network}-${Date.now()}.json`
        );
        
        const dir = path.dirname(jsonPath);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        
        fs.writeFileSync(jsonPath, JSON.stringify(jsonReport, null, 2));
        console.log(`💾 JSON报告已保存: ${jsonPath}\n`);
        
    } catch (error) {
        console.error('\n❌ 错误:', error.message);
        console.error(error);
        process.exit(1);
    }
}

// 执行主函数
if (require.main === module) {
    main()
        .then(() => process.exit(0))
        .catch((error) => {
            console.error(error);
            process.exit(1);
        });
}

module.exports = {
    loadLocalCodes,
    getCodeStatusFromContract,
    checkClaimStatus,
    generateStats,
    generateReport,
    exportToCSV
};
