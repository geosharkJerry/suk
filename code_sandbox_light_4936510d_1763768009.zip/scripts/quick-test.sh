#!/bin/bash

# SUK短剧平台 - Telegram Mini App 快速测试脚本
# 此脚本帮助您快速验证基本配置和服务状态

echo "======================================"
echo "  SUK Telegram Mini App 快速测试"
echo "======================================"
echo ""

# 颜色定义
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 测试计数
TESTS_PASSED=0
TESTS_FAILED=0

# 测试函数
test_pass() {
    echo -e "${GREEN}✅ $1${NC}"
    ((TESTS_PASSED++))
}

test_fail() {
    echo -e "${RED}❌ $1${NC}"
    ((TESTS_FAILED++))
}

test_warn() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# 1. 检查Node.js
echo "[1/10] 检查Node.js..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node -v)
    test_pass "Node.js已安装: $NODE_VERSION"
else
    test_fail "Node.js未安装"
    echo "请安装Node.js: https://nodejs.org/"
    exit 1
fi
echo ""

# 2. 检查npm
echo "[2/10] 检查npm..."
if command -v npm &> /dev/null; then
    NPM_VERSION=$(npm -v)
    test_pass "npm已安装: $NPM_VERSION"
else
    test_fail "npm未安装"
    exit 1
fi
echo ""

# 3. 检查依赖安装
echo "[3/10] 检查依赖..."
if [ -d "node_modules" ]; then
    test_pass "依赖已安装"
else
    test_warn "依赖未安装，正在安装..."
    npm install
    if [ $? -eq 0 ]; then
        test_pass "依赖安装成功"
    else
        test_fail "依赖安装失败"
        exit 1
    fi
fi
echo ""

# 4. 检查.env文件
echo "[4/10] 检查.env文件..."
if [ -f ".env" ]; then
    test_pass ".env文件存在"
    
    # 检查关键配置
    if grep -q "TELEGRAM_BOT_TOKEN=" .env; then
        TOKEN_VALUE=$(grep "TELEGRAM_BOT_TOKEN=" .env | cut -d '=' -f2)
        if [ -n "$TOKEN_VALUE" ] && [ "$TOKEN_VALUE" != "your_bot_token_here" ]; then
            test_pass "TELEGRAM_BOT_TOKEN已配置"
        else
            test_warn "TELEGRAM_BOT_TOKEN未配置或使用默认值"
        fi
    else
        test_warn "缺少TELEGRAM_BOT_TOKEN配置"
    fi
    
    if grep -q "MONGODB_URI=" .env; then
        test_pass "MONGODB_URI已配置"
    else
        test_warn "缺少MONGODB_URI配置"
    fi
else
    test_fail ".env文件不存在"
    echo "请复制.env.example为.env并配置"
    exit 1
fi
echo ""

# 5. 检查MongoDB
echo "[5/10] 检查MongoDB..."
if command -v mongod &> /dev/null; then
    test_pass "MongoDB已安装"
    
    # 尝试连接MongoDB
    if pgrep -x "mongod" > /dev/null; then
        test_pass "MongoDB进程正在运行"
    else
        test_warn "MongoDB进程未运行"
        echo "启动命令: brew services start mongodb-community (macOS)"
        echo "          sudo systemctl start mongod (Linux)"
    fi
else
    test_warn "MongoDB未安装或不在PATH中"
fi
echo ""

# 6. 检查Redis
echo "[6/10] 检查Redis..."
if command -v redis-server &> /dev/null; then
    test_pass "Redis已安装"
    
    # 尝试连接Redis
    if pgrep -x "redis-server" > /dev/null; then
        test_pass "Redis进程正在运行"
    else
        test_warn "Redis进程未运行"
        echo "启动命令: brew services start redis (macOS)"
        echo "          sudo systemctl start redis (Linux)"
    fi
else
    test_warn "Redis未安装或不在PATH中"
fi
echo ""

# 7. 检查ngrok
echo "[7/10] 检查ngrok..."
if command -v ngrok &> /dev/null; then
    NGROK_VERSION=$(ngrok version 2>&1 | head -n 1)
    test_pass "ngrok已安装: $NGROK_VERSION"
else
    test_warn "ngrok未安装"
    echo "安装方法: https://ngrok.com/download"
    echo "macOS: brew install ngrok/ngrok/ngrok"
fi
echo ""

# 8. 检查项目文件
echo "[8/10] 检查项目文件..."
REQUIRED_FILES=(
    "server.js"
    "telegram-app.html"
    "backend/middleware/telegram-auth.middleware.js"
    "backend/controllers/telegram.controller.js"
    "backend/routes/telegram.routes.js"
    "package.json"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        test_pass "$file"
    else
        test_fail "$file 缺失"
    fi
done
echo ""

# 9. 检查服务器端口
echo "[9/10] 检查端口占用..."
PORT=3000
if lsof -Pi :$PORT -sTCP:LISTEN -t >/dev/null 2>&1; then
    test_warn "端口 $PORT 已被占用"
    echo "运行中的进程: $(lsof -ti:$PORT | xargs ps -p | tail -n 1)"
    echo "停止命令: kill \$(lsof -ti:$PORT)"
else
    test_pass "端口 $PORT 可用"
fi
echo ""

# 10. 测试总结
echo "[10/10] 测试总结"
echo "======================================"
echo -e "${GREEN}通过: $TESTS_PASSED${NC}"
echo -e "${RED}失败: $TESTS_FAILED${NC}"
echo "======================================"
echo ""

# 最终建议
if [ $TESTS_FAILED -eq 0 ]; then
    echo -e "${GREEN}🎉 所有检查通过！${NC}"
    echo ""
    echo "下一步操作："
    echo "1. 启动服务器: npm run dev"
    echo "2. 新终端启动ngrok: ngrok http 3000"
    echo "3. 配置Telegram Bot (参考 TELEGRAM_QUICK_START.md)"
    echo "4. 测试完整流程 (参考 TESTING_GUIDE.md)"
else
    echo -e "${RED}❌ 存在 $TESTS_FAILED 个问题需要解决${NC}"
    echo ""
    echo "请参考上述错误信息进行修复"
fi

echo ""
echo "详细文档："
echo "• 快速开始: TELEGRAM_QUICK_START.md"
echo "• 完整指南: TELEGRAM_MINI_APP_GUIDE.md"
echo "• 测试指南: TESTING_GUIDE.md"
echo ""
