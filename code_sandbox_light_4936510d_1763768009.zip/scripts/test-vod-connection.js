/**
 * 阿里云VoD连接测试脚本
 * Aliyun VoD Connection Testing Script
 * 
 * 功能：
 * 1. 测试阿里云VoD服务连接
 * 2. 验证AccessKey权限
 * 3. 测试视频上传授权获取
 * 4. 测试播放授权生成（如果有测试视频）
 */

require('dotenv').config();
const AliyunVoDService = require('../backend/services/aliyun-vod.service');

console.log('╔════════════════════════════════════════╗');
console.log('║   阿里云VoD连接测试                    ║');
console.log('║   Aliyun VoD Connection Test          ║');
console.log('╚════════════════════════════════════════╝\n');

/**
 * 主测试函数
 */
async function testVoDConnection() {
    let testsPassed = 0;
    let testsFailed = 0;

    try {
        // 初始化VoD服务
        console.log('🔧 初始化阿里云VoD服务...\n');
        const vodService = new AliyunVoDService();

        // 测试1: 获取上传授权
        console.log('📤 测试1: 获取视频上传授权\n');
        try {
            const uploadAuth = await vodService.getUploadAuth(
                '测试视频 - ' + new Date().toISOString(),
                'test-video-' + Date.now() + '.mp4'
            );

            console.log('✅ 上传授权获取成功！');
            console.log(`   VideoId: ${uploadAuth.videoId}`);
            console.log(`   RequestId: ${uploadAuth.requestId}`);
            console.log(`   UploadAddress: ${uploadAuth.uploadAddress.substring(0, 50)}...`);
            console.log(`   UploadAuth: ${uploadAuth.uploadAuth.substring(0, 50)}...\n`);
            testsPassed++;

            // 保存VideoId用于后续测试
            global.testVideoId = uploadAuth.videoId;

        } catch (error) {
            console.error('❌ 上传授权获取失败！');
            console.error(`   错误: ${error.message}`);
            console.error(`   详情: ${error.data ? JSON.stringify(error.data, null, 2) : '无'}\n`);
            testsFailed++;
        }

        // 测试2: 查询视频信息
        if (global.testVideoId) {
            console.log('📹 测试2: 查询视频信息\n');
            try {
                // 等待1秒让阿里云创建视频记录
                await new Promise(resolve => setTimeout(resolve, 1000));

                const videoInfo = await vodService.getVideoInfo(global.testVideoId);

                console.log('✅ 视频信息查询成功！');
                console.log(`   VideoId: ${videoInfo.videoId}`);
                console.log(`   标题: ${videoInfo.title}`);
                console.log(`   状态: ${videoInfo.status}`);
                console.log(`   创建时间: ${videoInfo.createTime}\n`);
                testsPassed++;

            } catch (error) {
                console.error('❌ 视频信息查询失败！');
                console.error(`   错误: ${error.message}\n`);
                testsFailed++;
            }
        }

        // 测试3: 生成播放授权（需要已上传的视频）
        const existingVideoId = process.argv[2]; // 从命令行参数获取
        if (existingVideoId) {
            console.log('▶️  测试3: 生成播放授权\n');
            try {
                const playAuth = await vodService.generatePlayAuth(existingVideoId, 1800);

                console.log('✅ 播放授权生成成功！');
                console.log(`   VideoId: ${existingVideoId}`);
                console.log(`   PlayAuth: ${playAuth.substring(0, 100)}...`);
                console.log(`   过期时间: 30分钟\n`);
                testsPassed++;

                // 获取视频详细信息
                const videoInfo = await vodService.getVideoInfo(existingVideoId);
                console.log('📋 视频详细信息：');
                console.log(`   标题: ${videoInfo.title}`);
                console.log(`   时长: ${videoInfo.duration} 秒`);
                console.log(`   状态: ${videoInfo.status}`);
                console.log(`   封面: ${videoInfo.coverUrl || '（无）'}\n`);

            } catch (error) {
                console.error('❌ 播放授权生成失败！');
                console.error(`   错误: ${error.message}`);
                
                if (error.message.includes('InvalidVideo.NotFound')) {
                    console.error('   提示: 视频不存在或VideoId错误\n');
                } else if (error.message.includes('Uploading')) {
                    console.error('   提示: 视频正在上传或转码中，请稍后重试\n');
                } else {
                    console.error(`   详情: ${error.data ? JSON.stringify(error.data, null, 2) : '无'}\n`);
                }
                testsFailed++;
            }
        } else {
            console.log('ℹ️  跳过测试3: 未提供已存在的VideoId');
            console.log('   如需测试播放授权，请运行:');
            console.log('   node scripts/test-vod-connection.js YOUR_VIDEO_ID\n');
        }

        // 测试4: 删除测试视频（清理）
        if (global.testVideoId && process.argv.includes('--cleanup')) {
            console.log('🧹 测试4: 删除测试视频\n');
            try {
                await vodService.deleteVideo(global.testVideoId);
                console.log('✅ 测试视频删除成功！');
                console.log(`   VideoId: ${global.testVideoId}\n`);
                testsPassed++;

            } catch (error) {
                console.error('❌ 测试视频删除失败！');
                console.error(`   错误: ${error.message}\n`);
                testsFailed++;
            }
        } else if (global.testVideoId) {
            console.log('ℹ️  测试视频已创建但未删除');
            console.log(`   VideoId: ${global.testVideoId}`);
            console.log('   如需自动清理，请运行:');
            console.log('   node scripts/test-vod-connection.js --cleanup\n');
        }

        // 测试摘要
        console.log('═'.repeat(50));
        console.log('📊 测试摘要:\n');
        console.log(`   ✅ 通过: ${testsPassed}`);
        console.log(`   ❌ 失败: ${testsFailed}`);
        console.log(`   📈 成功率: ${Math.round((testsPassed / (testsPassed + testsFailed)) * 100)}%\n`);

        if (testsFailed === 0) {
            console.log('🎉 所有测试通过！阿里云VoD服务配置正确。\n');
            return true;
        } else {
            console.log('⚠️  部分测试失败，请检查配置。\n');
            return false;
        }

    } catch (error) {
        console.error('❌ 测试过程中发生严重错误:', error.message);
        console.error('详细信息:', error);
        return false;
    }
}

/**
 * 检查环境配置
 */
function checkEnvironment() {
    console.log('🔍 检查环境配置...\n');

    const requiredEnvVars = [
        'ALIYUN_ACCESS_KEY_ID',
        'ALIYUN_ACCESS_KEY_SECRET',
        'ALIYUN_VOD_REGION'
    ];

    let allConfigured = true;

    for (const varName of requiredEnvVars) {
        const value = process.env[varName];
        if (!value || value.includes('your_')) {
            console.error(`❌ ${varName}: 未配置或使用示例值`);
            allConfigured = false;
        } else {
            const displayValue = varName.includes('SECRET') 
                ? value.substring(0, 8) + '***' 
                : value;
            console.log(`✅ ${varName}: ${displayValue}`);
        }
    }

    console.log('');

    if (!allConfigured) {
        console.error('⚠️  环境配置不完整，无法进行测试。');
        console.error('请检查 .env 文件，参考 .env.example 进行配置。\n');
        process.exit(1);
    }

    return true;
}

/**
 * 显示帮助信息
 */
function showHelp() {
    console.log('使用方法：\n');
    console.log('1. 基本测试（测试上传授权和视频信息查询）：');
    console.log('   node scripts/test-vod-connection.js\n');
    console.log('2. 测试播放授权（需要提供已存在的VideoId）：');
    console.log('   node scripts/test-vod-connection.js YOUR_VIDEO_ID\n');
    console.log('3. 测试后自动清理（删除测试视频）：');
    console.log('   node scripts/test-vod-connection.js --cleanup\n');
    console.log('4. 完整测试（包含播放授权和清理）：');
    console.log('   node scripts/test-vod-connection.js YOUR_VIDEO_ID --cleanup\n');
}

// 命令行参数处理
if (process.argv.includes('--help') || process.argv.includes('-h')) {
    showHelp();
    process.exit(0);
}

// 执行测试
checkEnvironment();
testVoDConnection()
    .then(success => {
        process.exit(success ? 0 : 1);
    })
    .catch(error => {
        console.error('测试执行失败:', error);
        process.exit(1);
    });

/**
 * 常见错误和解决方案：
 * 
 * 1. InvalidAccessKeyId.NotFound
 *    原因: AccessKey ID不存在或已被删除
 *    解决: 重新创建AccessKey并更新 .env 文件
 * 
 * 2. SignatureDoesNotMatch
 *    原因: AccessKey Secret错误
 *    解决: 检查 .env 中的 ALIYUN_ACCESS_KEY_SECRET 是否正确
 * 
 * 3. Forbidden.RAM
 *    原因: RAM子账号权限不足
 *    解决: 在RAM控制台授予 AliyunVODFullAccess 权限
 * 
 * 4. ServiceUnavailable
 *    原因: 阿里云服务暂时不可用或Region错误
 *    解决: 检查 ALIYUN_VOD_REGION 配置，确保服务已开通
 * 
 * 5. InvalidVideo.NotFound
 *    原因: VideoId不存在或视频已被删除
 *    解决: 使用有效的VideoId或重新上传视频
 */
