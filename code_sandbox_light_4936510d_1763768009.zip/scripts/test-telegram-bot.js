/**
 * Telegram Bot 连接测试脚本
 * Telegram Bot Connection Testing Script
 * 
 * 测试Bot Token和基本功能
 */

require('dotenv').config();

console.log('╔════════════════════════════════════════╗');
console.log('║   Telegram Bot 连接测试                ║');
console.log('║   Telegram Bot Connection Test        ║');
console.log('╚════════════════════════════════════════╝\n');

/**
 * 测试Bot Token
 */
async function testBotToken() {
    console.log('🤖 测试1: 验证Bot Token\n');
    
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    
    if (!botToken) {
        console.error('❌ Bot Token未配置');
        console.log('   解决方案: 在.env文件中添加TELEGRAM_BOT_TOKEN\n');
        return false;
    }

    console.log(`   Token: ${botToken.substring(0, 10)}...${botToken.substring(botToken.length - 5)}\n`);

    try {
        // 使用fetch测试Bot API
        const response = await fetch(`https://api.telegram.org/bot${botToken}/getMe`);
        const data = await response.json();

        if (!data.ok) {
            console.error('❌ Bot Token无效');
            console.error(`   错误: ${data.description}\n`);
            return false;
        }

        const bot = data.result;
        console.log('✅ Bot Token验证成功！');
        console.log(`   Bot ID: ${bot.id}`);
        console.log(`   Bot名称: ${bot.first_name}`);
        console.log(`   Bot用户名: @${bot.username}`);
        console.log(`   是否为Bot: ${bot.is_bot ? '是' : '否'}`);
        console.log(`   支持内联: ${bot.supports_inline_queries ? '是' : '否'}\n`);

        global.botInfo = bot;
        return true;

    } catch (error) {
        console.error('❌ 连接Telegram API失败');
        console.error(`   错误: ${error.message}\n`);
        return false;
    }
}

/**
 * 测试Webhook状态
 */
async function testWebhook() {
    console.log('🔗 测试2: Webhook状态\n');
    
    const botToken = process.env.TELEGRAM_BOT_TOKEN;

    try {
        const response = await fetch(`https://api.telegram.org/bot${botToken}/getWebhookInfo`);
        const data = await response.json();

        if (!data.ok) {
            console.error('❌ 获取Webhook信息失败\n');
            return false;
        }

        const webhook = data.result;
        
        if (webhook.url) {
            console.log('✅ Webhook已设置');
            console.log(`   URL: ${webhook.url}`);
            console.log(`   待处理更新: ${webhook.pending_update_count}`);
            console.log(`   最后错误时间: ${webhook.last_error_date ? new Date(webhook.last_error_date * 1000).toISOString() : '无'}`);
            console.log(`   最后错误消息: ${webhook.last_error_message || '无'}\n`);
        } else {
            console.log('ℹ️  Webhook未设置（开发环境正常）');
            console.log('   提示: 生产环境建议设置Webhook\n');
        }

        return true;

    } catch (error) {
        console.error('❌ 获取Webhook信息失败');
        console.error(`   错误: ${error.message}\n`);
        return false;
    }
}

/**
 * 测试Bot命令
 */
async function testBotCommands() {
    console.log('📋 测试3: Bot命令\n');
    
    const botToken = process.env.TELEGRAM_BOT_TOKEN;

    try {
        const response = await fetch(`https://api.telegram.org/bot${botToken}/getMyCommands`);
        const data = await response.json();

        if (!data.ok) {
            console.error('❌ 获取Bot命令失败\n');
            return false;
        }

        const commands = data.result;
        
        if (commands.length === 0) {
            console.log('⚠️  未设置Bot命令');
            console.log('   建议: 向@BotFather发送/setcommands设置命令\n');
            console.log('   推荐命令:');
            console.log('   start - 启动短剧平台');
            console.log('   dramas - 浏览短剧');
            console.log('   profile - 我的账户');
            console.log('   help - 帮助\n');
        } else {
            console.log('✅ Bot命令已设置:');
            commands.forEach(cmd => {
                console.log(`   /${cmd.command} - ${cmd.description}`);
            });
            console.log('');
        }

        return true;

    } catch (error) {
        console.error('❌ 获取Bot命令失败');
        console.error(`   错误: ${error.message}\n`);
        return false;
    }
}

/**
 * 测试环境配置
 */
function testEnvironment() {
    console.log('⚙️  测试4: 环境配置\n');

    const configs = [
        { name: 'TELEGRAM_BOT_TOKEN', required: true },
        { name: 'TON_WALLET_ADDRESS', required: false },
        { name: 'MONGODB_URI', required: true },
        { name: 'REDIS_HOST', required: true }
    ];

    let allValid = true;

    configs.forEach(config => {
        const value = process.env[config.name];
        
        if (!value && config.required) {
            console.log(`❌ ${config.name}: 未配置（必需）`);
            allValid = false;
        } else if (!value) {
            console.log(`⚠️  ${config.name}: 未配置（可选）`);
        } else {
            const displayValue = value.length > 30 
                ? value.substring(0, 15) + '...' + value.substring(value.length - 10)
                : value;
            console.log(`✅ ${config.name}: ${displayValue}`);
        }
    });

    console.log('');
    return allValid;
}

/**
 * 生成快速设置命令
 */
function generateSetupCommands() {
    console.log('🚀 快速设置指南\n');
    
    if (!global.botInfo) {
        console.log('   请先确保Bot Token配置正确\n');
        return;
    }

    const botUsername = global.botInfo.username;

    console.log('1️⃣ 配置Bot菜单按钮（向@BotFather发送）:');
    console.log('   /mybots');
    console.log(`   选择: ${botUsername}`);
    console.log('   Bot Settings → Menu Button → Edit Menu Button URL');
    console.log('   URL: https://app.sukplatform.com/telegram-app.html');
    console.log('   按钮文字: 🎬 打开短剧平台\n');

    console.log('2️⃣ 测试Mini App:');
    console.log(`   在Telegram中打开: https://t.me/${botUsername}`);
    console.log('   点击底部菜单按钮\n');

    console.log('3️⃣ 本地开发测试（使用ngrok）:');
    console.log('   # 启动后端服务');
    console.log('   npm start');
    console.log('   ');
    console.log('   # 新终端窗口启动ngrok');
    console.log('   ngrok http 3000');
    console.log('   ');
    console.log('   # 将ngrok URL配置到@BotFather\n');
}

/**
 * 主测试函数
 */
async function runTests() {
    let testsPassed = 0;
    let testsFailed = 0;

    // 测试1: Bot Token
    if (await testBotToken()) {
        testsPassed++;
    } else {
        testsFailed++;
        console.log('⚠️  由于Bot Token无效，跳过后续测试\n');
        process.exit(1);
    }

    // 测试2: Webhook
    if (await testWebhook()) {
        testsPassed++;
    } else {
        testsFailed++;
    }

    // 测试3: Bot命令
    if (await testBotCommands()) {
        testsPassed++;
    } else {
        testsFailed++;
    }

    // 测试4: 环境配置
    if (testEnvironment()) {
        testsPassed++;
    } else {
        testsFailed++;
    }

    // 测试摘要
    console.log('═'.repeat(50));
    console.log('📊 测试摘要:\n');
    console.log(`   ✅ 通过: ${testsPassed}`);
    console.log(`   ❌ 失败: ${testsFailed}`);
    console.log(`   📈 成功率: ${Math.round((testsPassed / (testsPassed + testsFailed)) * 100)}%\n`);

    // 生成设置指南
    generateSetupCommands();

    if (testsFailed === 0) {
        console.log('🎉 所有测试通过！Telegram Bot配置正确。');
        console.log('💡 下一步: 启动Mini App服务并配置Bot菜单按钮\n');
        process.exit(0);
    } else {
        console.log('⚠️  部分测试失败，请根据上述提示修复配置。\n');
        process.exit(1);
    }
}

// 运行测试
runTests();

/**
 * 使用方法：
 * 
 * 1. 基本测试：
 *    node scripts/test-telegram-bot.js
 * 
 * 2. 在CI/CD中使用：
 *    npm run test:telegram
 */
