/**
 * SUKAirdropV2 部署脚本
 * 
 * 功能：
 * 1. 部署 SUKAirdropV2 合约
 * 2. 验证部署参数
 * 3. 保存部署信息
 * 4. 验证合约（Etherscan）
 * 
 * 使用方法：
 * npx hardhat run scripts/deploy-airdrop-v2.js --network goerli
 */

const hre = require('hardhat');
const fs = require('fs');
const path = require('path');

async function main() {
    console.log('\n' + '='.repeat(70));
    console.log('🚀 SUKAirdropV2 部署脚本');
    console.log('='.repeat(70) + '\n');
    
    const [deployer] = await hre.ethers.getSigners();
    const network = hre.network.name;
    
    console.log('📊 部署信息:');
    console.log(`   网络: ${network}`);
    console.log(`   部署者: ${deployer.address}`);
    
    const balance = await deployer.getBalance();
    console.log(`   余额: ${hre.ethers.utils.formatEther(balance)} ETH`);
    console.log('');
    
    // ========================================
    // 第一步：获取 SUKToken 地址
    // ========================================
    
    console.log('📍 第一步: 查找 SUKToken 地址...');
    
    const deploymentDir = path.join(__dirname, '../deployment');
    if (!fs.existsSync(deploymentDir)) {
        fs.mkdirSync(deploymentDir, { recursive: true });
    }
    
    const tokenFiles = fs.readdirSync(deploymentDir)
        .filter(f => f.includes('suk-token') && f.includes(network) && f.endsWith('.json'))
        .sort()
        .reverse();
    
    if (tokenFiles.length === 0) {
        throw new Error(`❌ 未找到 ${network} 上的 SUKToken 部署记录。请先部署 SUKToken。`);
    }
    
    const tokenDeployment = JSON.parse(
        fs.readFileSync(path.join(deploymentDir, tokenFiles[0]))
    );
    
    const SUK_TOKEN_ADDRESS = tokenDeployment.tokenAddress;
    console.log(`   ✅ SUKToken 地址: ${SUK_TOKEN_ADDRESS}`);
    console.log('');
    
    // ========================================
    // 第二步：配置空投时间
    // ========================================
    
    console.log('⏰ 第二步: 配置空投时间...');
    
    const now = Math.floor(Date.now() / 1000);
    
    // 从环境变量或默认值获取时间
    const AIRDROP_START_TIME = process.env.AIRDROP_START_TIME 
        ? parseInt(process.env.AIRDROP_START_TIME) 
        : now + 3600;  // 默认1小时后开始
    
    const AIRDROP_END_TIME = process.env.AIRDROP_END_TIME 
        ? parseInt(process.env.AIRDROP_END_TIME)
        : AIRDROP_START_TIME + (180 * 24 * 3600);  // 默认持续180天（6个月）
    
    console.log(`   开始时间: ${new Date(AIRDROP_START_TIME * 1000).toLocaleString()}`);
    console.log(`   结束时间: ${new Date(AIRDROP_END_TIME * 1000).toLocaleString()}`);
    console.log(`   持续时长: ${((AIRDROP_END_TIME - AIRDROP_START_TIME) / 86400).toFixed(0)} 天`);
    
    // 验证时间
    if (AIRDROP_START_TIME <= now) {
        throw new Error('❌ 开始时间必须在未来');
    }
    if (AIRDROP_END_TIME <= AIRDROP_START_TIME) {
        throw new Error('❌ 结束时间必须晚于开始时间');
    }
    
    console.log('   ✅ 时间配置验证通过');
    console.log('');
    
    // ========================================
    // 第三步：部署合约
    // ========================================
    
    console.log('🚀 第三步: 部署 SUKAirdropV2 合约...');
    console.log('   请稍候，正在编译和部署...\n');
    
    const SUKAirdropV2 = await hre.ethers.getContractFactory('SUKAirdropV2');
    const airdrop = await SUKAirdropV2.deploy(
        SUK_TOKEN_ADDRESS,
        AIRDROP_START_TIME,
        AIRDROP_END_TIME
    );
    
    await airdrop.deployed();
    
    console.log('   ✅ SUKAirdropV2 已部署!');
    console.log(`   📍 合约地址: ${airdrop.address}`);
    console.log(`   🔗 交易哈希: ${airdrop.deployTransaction.hash}`);
    console.log('');
    
    // ========================================
    // 第四步：验证部署
    // ========================================
    
    console.log('🔍 第四步: 验证部署...');
    
    try {
        const sukToken = await airdrop.sukToken();
        const airdropStartTime = await airdrop.airdropStartTime();
        const airdropEndTime = await airdrop.airdropEndTime();
        const totalAirdrop = await airdrop.TOTAL_AIRDROP_AMOUNT();
        const whitelistAmount = await airdrop.WHITELIST_AMOUNT();
        const referralAmount = await airdrop.REFERRAL_AMOUNT();
        
        console.log(`   SUK Token: ${sukToken}`);
        console.log(`   总空投量: ${hre.ethers.utils.formatEther(totalAirdrop)} SUK`);
        console.log(`   白名单额度: ${hre.ethers.utils.formatEther(whitelistAmount)} SUK`);
        console.log(`   推荐额度: ${hre.ethers.utils.formatEther(referralAmount)} SUK`);
        
        if (sukToken !== SUK_TOKEN_ADDRESS) {
            throw new Error('❌ SUKToken 地址不匹配!');
        }
        if (airdropStartTime.toNumber() !== AIRDROP_START_TIME) {
            throw new Error('❌ 开始时间不匹配!');
        }
        if (airdropEndTime.toNumber() !== AIRDROP_END_TIME) {
            throw new Error('❌ 结束时间不匹配!');
        }
        
        console.log('   ✅ 所有参数验证通过!');
        console.log('');
        
    } catch (error) {
        console.error('   ❌ 验证失败:', error.message);
        throw error;
    }
    
    // ========================================
    // 第五步：保存部署信息
    // ========================================
    
    console.log('💾 第五步: 保存部署信息...');
    
    const deploymentInfo = {
        network: network,
        chainId: hre.network.config.chainId,
        airdropAddress: airdrop.address,
        tokenAddress: SUK_TOKEN_ADDRESS,
        deployTransaction: airdrop.deployTransaction.hash,
        deployer: deployer.address,
        deployedAt: new Date().toISOString(),
        blockNumber: airdrop.deployTransaction.blockNumber,
        airdropStartTime: AIRDROP_START_TIME,
        airdropEndTime: AIRDROP_END_TIME,
        totalAirdropAmount: '50000000',  // 5000万 SUK
        whitelistAmount: '5000',         // 5000 SUK
        referralAmount: '1000',          // 1000 SUK
        inviteCodeValidity: '90 days'    // 3个月
    };
    
    const filename = `airdrop-v2-${network}-${Date.now()}.json`;
    const filepath = path.join(deploymentDir, filename);
    
    fs.writeFileSync(filepath, JSON.stringify(deploymentInfo, null, 2));
    
    console.log(`   ✅ 部署信息已保存: ${filename}`);
    console.log('');
    
    // ========================================
    // 第六步：总结
    // ========================================
    
    console.log('='.repeat(70));
    console.log('✅ SUKAirdropV2 部署成功!');
    console.log('='.repeat(70));
    console.log('');
    console.log('📋 部署摘要:');
    console.log('┌─────────────────────────────────────────────────────────────────┐');
    console.log('│ 合约信息                                                        │');
    console.log('├─────────────────────────────────────────────────────────────────┤');
    console.log(`│ 网络:        ${network.padEnd(50)} │`);
    console.log(`│ 合约地址:    ${airdrop.address.padEnd(50)} │`);
    console.log(`│ Token地址:   ${SUK_TOKEN_ADDRESS.padEnd(50)} │`);
    console.log('├─────────────────────────────────────────────────────────────────┤');
    console.log('│ 空投配置                                                        │');
    console.log('├─────────────────────────────────────────────────────────────────┤');
    console.log(`│ 总空投量:    50,000,000 SUK (5000万)                            │`);
    console.log(`│ 白名单:      5,000 SUK/地址 (邀请码激活)                        │`);
    console.log(`│ 推荐用户:    1,000 SUK/地址 (推荐购买)                          │`);
    console.log(`│ 邀请码有效期: 90 天 (3个月)                                     │`);
    console.log('└─────────────────────────────────────────────────────────────────┘');
    console.log('');
    
    console.log('🎯 下一步操作:');
    console.log('');
    console.log('1. 转账 5000万 SUK 到空投合约:');
    console.log(`   node scripts/fund-airdrop-v2.js --network ${network}`);
    console.log('');
    console.log('2. 生成邀请码:');
    console.log(`   node scripts/generate-invite-codes.js 10000 --network ${network} --deploy`);
    console.log('');
    console.log('3. 验证合约 (Etherscan):');
    console.log(`   npx hardhat verify --network ${network} ${airdrop.address} "${SUK_TOKEN_ADDRESS}" ${AIRDROP_START_TIME} ${AIRDROP_END_TIME}`);
    console.log('');
    console.log('4. 更新前端配置:');
    console.log(`   node scripts/update-frontend-config.js ${network} ${SUK_TOKEN_ADDRESS} ${airdrop.address}`);
    console.log('');
    
    // 区块浏览器链接
    const explorerUrls = {
        goerli: 'https://goerli.etherscan.io',
        sepolia: 'https://sepolia.etherscan.io',
        mainnet: 'https://etherscan.io',
        polygon: 'https://polygonscan.com',
        bsc: 'https://bscscan.com'
    };
    
    const explorerUrl = explorerUrls[network] || 'https://etherscan.io';
    console.log('🔍 查看合约:');
    console.log(`   ${explorerUrl}/address/${airdrop.address}`);
    console.log('');
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error('\n❌ 部署失败:', error);
        process.exit(1);
    });
