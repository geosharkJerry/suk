#!/usr/bin/env node

/**
 * SUK短剧平台 - 快速环境测试脚本 (Node.js版本)
 * 用于验证开发环境配置和依赖项
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// 颜色定义
const colors = {
    reset: '\x1b[0m',
    green: '\x1b[32m',
    red: '\x1b[31m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    cyan: '\x1b[36m',
    bold: '\x1b[1m'
};

// 测试计数
let testsTotal = 0;
let testsPassed = 0;
let testsFailed = 0;
let testsWarning = 0;

// 辅助函数
function log(message, color = colors.reset) {
    console.log(`${color}${message}${colors.reset}`);
}

function testPass(message) {
    log(`✅ ${message}`, colors.green);
    testsPassed++;
    testsTotal++;
}

function testFail(message) {
    log(`❌ ${message}`, colors.red);
    testsFailed++;
    testsTotal++;
}

function testWarn(message) {
    log(`⚠️  ${message}`, colors.yellow);
    testsWarning++;
    testsTotal++;
}

function testInfo(message) {
    log(`ℹ️  ${message}`, colors.cyan);
}

function header(message) {
    log(`\n${'='.repeat(50)}`, colors.bold);
    log(message, colors.bold + colors.cyan);
    log('='.repeat(50), colors.bold);
}

function section(message) {
    log(`\n${message}`, colors.bold);
}

function execCommand(command, options = {}) {
    try {
        return execSync(command, { 
            encoding: 'utf8', 
            stdio: options.silent ? 'pipe' : 'inherit',
            ...options 
        }).trim();
    } catch (error) {
        if (options.ignoreError) {
            return null;
        }
        throw error;
    }
}

// 测试函数
async function test1_NodeVersion() {
    section('[1/12] 检查 Node.js...');
    
    try {
        const version = process.version;
        const majorVersion = parseInt(version.slice(1).split('.')[0]);
        
        testPass(`Node.js 已安装: ${version}`);
        
        if (majorVersion >= 18) {
            testPass(`Node.js 版本满足要求 (>= 18.0.0)`);
        } else {
            testWarn(`Node.js 版本较低: ${version} (推荐 >= 18.0.0)`);
        }
    } catch (error) {
        testFail('Node.js 未安装或无法检测');
    }
}

async function test2_NpmVersion() {
    section('[2/12] 检查 npm...');
    
    try {
        const version = execCommand('npm -v', { silent: true });
        testPass(`npm 已安装: v${version}`);
    } catch (error) {
        testFail('npm 未安装或无法检测');
    }
}

async function test3_Dependencies() {
    section('[3/12] 检查依赖...');
    
    const nodeModulesPath = path.join(process.cwd(), 'node_modules');
    
    if (fs.existsSync(nodeModulesPath)) {
        testPass('node_modules 目录存在');
        
        // 检查关键依赖
        const criticalDeps = [
            'express',
            'mongoose',
            'redis',
            'dotenv'
        ];
        
        let missingDeps = [];
        criticalDeps.forEach(dep => {
            const depPath = path.join(nodeModulesPath, dep);
            if (fs.existsSync(depPath)) {
                testPass(`依赖已安装: ${dep}`);
            } else {
                missingDeps.push(dep);
            }
        });
        
        if (missingDeps.length > 0) {
            testWarn(`缺少依赖: ${missingDeps.join(', ')}`);
            testInfo('运行: npm install');
        }
    } else {
        testWarn('node_modules 目录不存在');
        testInfo('运行: npm install');
    }
}

async function test4_EnvFile() {
    section('[4/12] 检查 .env 文件...');
    
    const envPath = path.join(process.cwd(), '.env');
    const envExamplePath = path.join(process.cwd(), '.env.example');
    
    if (fs.existsSync(envPath)) {
        testPass('.env 文件存在');
        
        // 读取并检查关键配置
        const envContent = fs.readFileSync(envPath, 'utf8');
        const configs = {
            'TELEGRAM_BOT_TOKEN': '未配置',
            'MONGODB_URI': '未配置',
            'REDIS_HOST': '未配置',
            'ALIYUN_ACCESS_KEY_ID': '未配置',
            'JWT_SECRET': '未配置'
        };
        
        Object.keys(configs).forEach(key => {
            const regex = new RegExp(`^${key}=(.+)$`, 'm');
            const match = envContent.match(regex);
            
            if (match && match[1].trim()) {
                const value = match[1].trim();
                // 检查是否是占位符
                if (value.includes('your_') || value.includes('xxx') || value === '') {
                    testWarn(`${key}: 使用占位符或为空`);
                } else {
                    testPass(`${key}: 已配置`);
                }
            } else {
                testWarn(`${key}: 缺失`);
            }
        });
    } else {
        testFail('.env 文件不存在');
        if (fs.existsSync(envExamplePath)) {
            testInfo('运行: cp .env.example .env');
        }
    }
}

async function test5_MongoDB() {
    section('[5/12] 检查 MongoDB...');
    
    try {
        // 检查 mongod 命令
        execCommand('which mongod', { silent: true, ignoreError: true });
        testPass('MongoDB 已安装');
        
        // 检查 MongoDB 进程
        try {
            if (process.platform === 'darwin') {
                execCommand('pgrep -x mongod', { silent: true });
                testPass('MongoDB 进程正在运行');
            } else if (process.platform === 'linux') {
                execCommand('pgrep -x mongod', { silent: true });
                testPass('MongoDB 进程正在运行');
            } else {
                testInfo('无法在 Windows 上自动检测 MongoDB 进程');
            }
        } catch (error) {
            testWarn('MongoDB 进程未运行');
            if (process.platform === 'darwin') {
                testInfo('启动: brew services start mongodb-community');
            } else if (process.platform === 'linux') {
                testInfo('启动: sudo systemctl start mongod');
            }
        }
    } catch (error) {
        testWarn('MongoDB 未安装或不在 PATH 中');
        testInfo('安装指南: https://www.mongodb.com/docs/manual/installation/');
    }
}

async function test6_Redis() {
    section('[6/12] 检查 Redis...');
    
    try {
        execCommand('which redis-server', { silent: true, ignoreError: true });
        testPass('Redis 已安装');
        
        // 检查 Redis 进程
        try {
            if (process.platform === 'darwin' || process.platform === 'linux') {
                execCommand('pgrep -x redis-server', { silent: true });
                testPass('Redis 进程正在运行');
            } else {
                testInfo('无法在 Windows 上自动检测 Redis 进程');
            }
        } catch (error) {
            testWarn('Redis 进程未运行');
            if (process.platform === 'darwin') {
                testInfo('启动: brew services start redis');
            } else if (process.platform === 'linux') {
                testInfo('启动: sudo systemctl start redis');
            }
        }
    } catch (error) {
        testWarn('Redis 未安装或不在 PATH 中');
        testInfo('安装指南: https://redis.io/download');
    }
}

async function test7_Ngrok() {
    section('[7/12] 检查 ngrok...');
    
    try {
        const version = execCommand('ngrok version', { silent: true, ignoreError: true });
        if (version) {
            testPass(`ngrok 已安装: ${version.split('\n')[0]}`);
        } else {
            throw new Error('ngrok not found');
        }
    } catch (error) {
        testWarn('ngrok 未安装');
        testInfo('Telegram Mini App 需要 HTTPS，ngrok 用于本地测试');
        if (process.platform === 'darwin') {
            testInfo('安装: brew install ngrok/ngrok/ngrok');
        } else {
            testInfo('下载: https://ngrok.com/download');
        }
    }
}

async function test8_ProjectFiles() {
    section('[8/12] 检查项目文件...');
    
    const requiredFiles = [
        { path: 'server.js', name: '服务器主文件' },
        { path: 'telegram-app.html', name: 'Telegram Mini App' },
        { path: 'package.json', name: '项目配置' },
        { path: 'backend/middleware/telegram-auth.middleware.js', name: 'Telegram认证中间件' },
        { path: 'backend/controllers/telegram.controller.js', name: 'Telegram控制器' },
        { path: 'backend/routes/telegram.routes.js', name: 'Telegram路由' }
    ];
    
    requiredFiles.forEach(file => {
        const filePath = path.join(process.cwd(), file.path);
        if (fs.existsSync(filePath)) {
            testPass(`${file.name}: ${file.path}`);
        } else {
            testFail(`缺失: ${file.path}`);
        }
    });
}

async function test9_Port() {
    section('[9/12] 检查端口占用...');
    
    const port = 3000;
    
    try {
        if (process.platform === 'darwin' || process.platform === 'linux') {
            const result = execCommand(`lsof -i :${port} -sTCP:LISTEN -t`, { 
                silent: true, 
                ignoreError: true 
            });
            
            if (result && result.trim()) {
                testWarn(`端口 ${port} 已被占用`);
                testInfo(`停止进程: kill $(lsof -ti:${port})`);
            } else {
                testPass(`端口 ${port} 可用`);
            }
        } else {
            testInfo(`无法在 Windows 上自动检测端口占用`);
            testInfo(`手动检查: netstat -ano | findstr :${port}`);
        }
    } catch (error) {
        testPass(`端口 ${port} 可用`);
    }
}

async function test10_Git() {
    section('[10/12] 检查 Git...');
    
    try {
        const version = execCommand('git --version', { silent: true });
        testPass(`Git 已安装: ${version}`);
        
        // 检查是否是 Git 仓库
        try {
            execCommand('git rev-parse --git-dir', { silent: true });
            testPass('当前目录是 Git 仓库');
        } catch (error) {
            testWarn('当前目录不是 Git 仓库');
            testInfo('初始化: git init');
        }
    } catch (error) {
        testWarn('Git 未安装');
    }
}

async function test11_Documentation() {
    section('[11/12] 检查文档...');
    
    const docs = [
        'README.md',
        'TELEGRAM_QUICK_START.md',
        'TESTING_GUIDE.md',
        'TELEGRAM_MINI_APP_GUIDE.md',
        'CURRENT_STATUS.md'
    ];
    
    docs.forEach(doc => {
        const docPath = path.join(process.cwd(), doc);
        if (fs.existsSync(docPath)) {
            testPass(`文档存在: ${doc}`);
        } else {
            testWarn(`文档缺失: ${doc}`);
        }
    });
}

async function test12_PackageJson() {
    section('[12/12] 检查 package.json 脚本...');
    
    try {
        const packageJsonPath = path.join(process.cwd(), 'package.json');
        const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
        
        const requiredScripts = [
            'start',
            'dev',
            'test',
            'test:env',
            'test:db',
            'test:telegram'
        ];
        
        if (packageJson.scripts) {
            requiredScripts.forEach(script => {
                if (packageJson.scripts[script]) {
                    testPass(`脚本已定义: npm run ${script}`);
                } else {
                    testWarn(`脚本缺失: ${script}`);
                }
            });
        } else {
            testFail('package.json 中缺少 scripts 字段');
        }
    } catch (error) {
        testFail('无法读取 package.json');
    }
}

// 主函数
async function main() {
    header('SUK 短剧平台 - Telegram Mini App 快速测试');
    log('正在检查开发环境配置...\n', colors.cyan);
    
    try {
        await test1_NodeVersion();
        await test2_NpmVersion();
        await test3_Dependencies();
        await test4_EnvFile();
        await test5_MongoDB();
        await test6_Redis();
        await test7_Ngrok();
        await test8_ProjectFiles();
        await test9_Port();
        await test10_Git();
        await test11_Documentation();
        await test12_PackageJson();
        
        // 显示总结
        header('测试总结');
        log(`总计: ${testsTotal}`, colors.bold);
        log(`✅ 通过: ${testsPassed}`, colors.green);
        log(`❌ 失败: ${testsFailed}`, colors.red);
        log(`⚠️  警告: ${testsWarning}`, colors.yellow);
        log('='.repeat(50), colors.bold);
        
        // 给出建议
        console.log();
        if (testsFailed === 0 && testsWarning === 0) {
            log('🎉 所有检查通过！环境配置完美！', colors.green + colors.bold);
            console.log('\n下一步操作:');
            log('1. 启动服务器: npm run dev', colors.cyan);
            log('2. 新终端启动 ngrok: ngrok http 3000', colors.cyan);
            log('3. 配置 Telegram Bot (参考 TELEGRAM_QUICK_START.md)', colors.cyan);
            log('4. 测试完整流程 (参考 TESTING_GUIDE.md)', colors.cyan);
        } else if (testsFailed === 0) {
            log('✅ 基本检查通过，存在一些警告需要注意', colors.yellow + colors.bold);
            console.log('\n建议:');
            log('• 解决上述警告项以获得最佳体验', colors.yellow);
            log('• 可以继续开发，但某些功能可能受限', colors.yellow);
        } else {
            log('❌ 存在问题需要解决', colors.red + colors.bold);
            console.log('\n请按照上述提示修复问题后重新运行测试');
        }
        
        console.log('\n📖 详细文档:');
        log('• 快速开始: TELEGRAM_QUICK_START.md', colors.blue);
        log('• 完整指南: TELEGRAM_MINI_APP_GUIDE.md', colors.blue);
        log('• 测试指南: TESTING_GUIDE.md', colors.blue);
        log('• 命令参考: QUICK_COMMANDS.md', colors.blue);
        console.log();
        
    } catch (error) {
        console.error('\n❌ 测试过程中发生错误:', error.message);
        process.exit(1);
    }
}

// 运行测试
if (require.main === module) {
    main().catch(error => {
        console.error('Fatal error:', error);
        process.exit(1);
    });
}

module.exports = { main };
