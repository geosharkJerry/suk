/**
 * 环境变量测试脚本
 * Environment Variables Testing Script
 * 
 * 功能：
 * 1. 检查所有必需的环境变量是否已配置
 * 2. 验证环境变量值的有效性
 * 3. 提供配置建议
 */

require('dotenv').config();

console.log('╔════════════════════════════════════════╗');
console.log('║   环境变量配置检查                     ║');
console.log('║   Environment Configuration Test      ║');
console.log('╚════════════════════════════════════════╝\n');

/**
 * 必需的环境变量列表
 */
const requiredVars = {
    // 数据库配置
    'MONGODB_URI': {
        description: 'MongoDB数据库连接URI',
        example: 'mongodb://localhost:27017/short_drama_platform',
        validate: (val) => val.startsWith('mongodb://') || val.startsWith('mongodb+srv://'),
        errorMsg: '必须以 mongodb:// 或 mongodb+srv:// 开头'
    },
    
    // 阿里云VoD配置
    'ALIYUN_ACCESS_KEY_ID': {
        description: '阿里云AccessKey ID',
        example: 'LTAI5txxxxxxxxxxxxxxxxxx',
        validate: (val) => val.length > 10 && !val.includes('your_'),
        errorMsg: '请配置真实的AccessKey ID'
    },
    'ALIYUN_ACCESS_KEY_SECRET': {
        description: '阿里云AccessKey Secret',
        example: 'xxxxxxxxxxxxxxxxxxxxx',
        validate: (val) => val.length > 20 && !val.includes('your_'),
        errorMsg: '请配置真实的AccessKey Secret',
        sensitive: true
    },
    
    // JWT配置
    'JWT_SECRET': {
        description: 'JWT密钥',
        example: '使用强随机字符串',
        validate: (val) => val.length >= 32 && !val.includes('change_this'),
        errorMsg: 'JWT密钥长度至少32字符，且不能使用示例值',
        sensitive: true
    },
    
    // 区块链配置
    'SUK_TOKEN_CONTRACT': {
        description: 'SUK代币合约地址',
        example: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb',
        validate: (val) => /^0x[a-fA-F0-9]{40}$/.test(val),
        errorMsg: '必须是有效的以太坊地址格式 (0x...)'
    },
    'ETH_RPC_URL': {
        description: '以太坊RPC节点URL',
        example: 'https://mainnet.infura.io/v3/your_project_id',
        validate: (val) => val.startsWith('http') && !val.includes('your_project_id'),
        errorMsg: '请配置真实的RPC节点URL'
    }
};

/**
 * 可选但推荐的环境变量
 */
const optionalVars = {
    'REDIS_HOST': {
        description: 'Redis主机地址',
        default: 'localhost'
    },
    'REDIS_PORT': {
        description: 'Redis端口',
        default: '6379'
    },
    'REDIS_PASSWORD': {
        description: 'Redis密码（推荐设置）',
        default: '（无）',
        sensitive: true
    },
    'PLATFORM_WALLET_ADDRESS': {
        description: '平台钱包地址',
        example: '0x...'
    },
    'PLAY_AUTH_TIMEOUT': {
        description: '播放授权超时时间（秒）',
        default: '1800'
    }
};

let allValid = true;
let warnings = [];

console.log('📋 检查必需配置项：\n');

// 检查必需的环境变量
for (const [varName, config] of Object.entries(requiredVars)) {
    const value = process.env[varName];
    
    if (!value) {
        console.log(`❌ ${varName}`);
        console.log(`   说明: ${config.description}`);
        console.log(`   示例: ${config.example}`);
        console.log(`   状态: 未配置\n`);
        allValid = false;
    } else if (!config.validate(value)) {
        console.log(`⚠️  ${varName}`);
        console.log(`   说明: ${config.description}`);
        console.log(`   状态: 配置无效`);
        console.log(`   原因: ${config.errorMsg}\n`);
        allValid = false;
    } else {
        const displayValue = config.sensitive 
            ? value.substring(0, 8) + '***' 
            : (value.length > 50 ? value.substring(0, 50) + '...' : value);
        console.log(`✅ ${varName}`);
        console.log(`   值: ${displayValue}\n`);
    }
}

console.log('\n📋 检查可选配置项：\n');

// 检查可选的环境变量
for (const [varName, config] of Object.entries(optionalVars)) {
    const value = process.env[varName];
    
    if (!value) {
        console.log(`⚪ ${varName}`);
        console.log(`   说明: ${config.description}`);
        console.log(`   默认值: ${config.default || '（无）'}`);
        if (config.example) {
            console.log(`   示例: ${config.example}`);
        }
        console.log(`   状态: 使用默认值\n`);
        
        if (varName === 'REDIS_PASSWORD') {
            warnings.push('建议设置Redis密码以提高安全性');
        }
        if (varName === 'PLATFORM_WALLET_ADDRESS') {
            warnings.push('建议配置平台钱包地址以接收SUK代币');
        }
    } else {
        const displayValue = config.sensitive 
            ? '***' 
            : (value.length > 50 ? value.substring(0, 50) + '...' : value);
        console.log(`✅ ${varName}`);
        console.log(`   值: ${displayValue}\n`);
    }
}

// 环境特定检查
console.log('\n📋 环境特定检查：\n');

const nodeEnv = process.env.NODE_ENV || 'development';
console.log(`🔧 运行环境: ${nodeEnv}`);

if (nodeEnv === 'production') {
    // 生产环境额外检查
    const productionChecks = [
        {
            name: 'HTTPS强制',
            check: process.env.FORCE_HTTPS === 'true',
            message: '建议在生产环境启用HTTPS强制 (FORCE_HTTPS=true)'
        },
        {
            name: 'Cookie安全',
            check: process.env.COOKIE_SECURE === 'true',
            message: '建议在生产环境启用安全Cookie (COOKIE_SECURE=true)'
        },
        {
            name: '视频加密',
            check: process.env.VIDEO_ENCRYPT_TYPE === '1',
            message: '建议启用视频加密 (VIDEO_ENCRYPT_TYPE=1)'
        },
        {
            name: 'JWT密钥强度',
            check: process.env.JWT_SECRET && process.env.JWT_SECRET.length >= 64,
            message: '生产环境JWT密钥建议至少64字符'
        }
    ];

    console.log('\n⚙️  生产环境安全检查：\n');
    
    for (const check of productionChecks) {
        if (check.check) {
            console.log(`✅ ${check.name}: 已正确配置`);
        } else {
            console.log(`⚠️  ${check.name}: ${check.message}`);
            warnings.push(check.message);
        }
    }
}

// 配置建议
console.log('\n\n💡 配置建议：\n');

if (warnings.length > 0) {
    warnings.forEach((warning, index) => {
        console.log(`${index + 1}. ${warning}`);
    });
} else {
    console.log('✅ 所有配置建议已满足！');
}

// 生成强密钥的帮助
console.log('\n\n🔐 生成强密钥的命令：\n');
console.log('JWT_SECRET:');
console.log('  node -e "console.log(require(\'crypto\').randomBytes(64).toString(\'hex\'))"\n');

// 最终结果
console.log('\n' + '═'.repeat(50));

if (allValid && warnings.length === 0) {
    console.log('✅ 配置检查通过！所有必需配置项已正确设置。');
    console.log('🚀 您可以安全地启动应用程序。');
    process.exit(0);
} else if (allValid && warnings.length > 0) {
    console.log('⚠️  配置基本通过，但有一些建议需要注意。');
    console.log('💡 请查看上方的配置建议。');
    process.exit(0);
} else {
    console.log('❌ 配置检查失败！请修复上述问题后再启动应用。');
    console.log('📖 参考 .env.example 文件了解正确的配置格式。');
    console.log('📚 详细配置指南：ALIYUN_VOD_SETUP_GUIDE.md');
    process.exit(1);
}

/**
 * 使用方法：
 * 
 * 1. 基本检查：
 *    node scripts/test-env.js
 * 
 * 2. 在CI/CD中使用：
 *    npm run test:env
 * 
 * 3. 部署前检查：
 *    NODE_ENV=production node scripts/test-env.js
 */
