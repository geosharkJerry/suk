const hre = require("hardhat");

/**
 * 转移SUK代币到空投合约
 * 
 * 前置条件:
 * - SUK代币已部署
 * - 空投合约已部署
 * - 设置环境变量: SUK_TOKEN_ADDRESS, AIRDROP_ADDRESS
 */

async function main() {
    console.log("=".repeat(80));
    console.log("转移SUK代币到空投合约");
    console.log("=".repeat(80));
    
    // ========== 配置 ==========
    
    const SUK_TOKEN_ADDRESS = process.env.SUK_TOKEN_ADDRESS;
    const AIRDROP_ADDRESS = process.env.AIRDROP_ADDRESS;
    const AMOUNT = process.env.AMOUNT || "1000000"; // 默认100万SUK
    
    if (!SUK_TOKEN_ADDRESS || !AIRDROP_ADDRESS) {
        console.error("❌ 错误: 请设置环境变量");
        console.log("\n使用方法:");
        console.log("export SUK_TOKEN_ADDRESS=0x...");
        console.log("export AIRDROP_ADDRESS=0x...");
        console.log("export AMOUNT=1000000  # 可选，默认100万");
        console.log(`npx hardhat run scripts/3-fund-airdrop.js --network ${hre.network.name}`);
        process.exit(1);
    }
    
    const [signer] = await hre.ethers.getSigners();
    
    console.log("\n📋 配置:");
    console.log("-".repeat(80));
    console.log("网络:", hre.network.name);
    console.log("SUK代币:", SUK_TOKEN_ADDRESS);
    console.log("空投合约:", AIRDROP_ADDRESS);
    console.log("转移数量:", AMOUNT, "SUK");
    console.log("发送者:", signer.address);
    
    // ========== 连接合约 ==========
    
    console.log("\n🔗 连接合约...");
    
    const sukToken = await hre.ethers.getContractAt("SUKToken", SUK_TOKEN_ADDRESS);
    const airdrop = await hre.ethers.getContractAt("SUKAirdrop", AIRDROP_ADDRESS);
    
    // ========== 检查余额 ==========
    
    console.log("\n💰 检查余额...");
    console.log("-".repeat(80));
    
    const balance = await sukToken.balanceOf(signer.address);
    const amountWei = hre.ethers.utils.parseEther(AMOUNT);
    
    console.log("您的SUK余额:", hre.ethers.utils.formatEther(balance), "SUK");
    console.log("需要转移:", AMOUNT, "SUK");
    
    if (balance.lt(amountWei)) {
        console.error("\n❌ 错误: 余额不足");
        console.log("需要:", hre.ethers.utils.formatEther(amountWei), "SUK");
        console.log("实际:", hre.ethers.utils.formatEther(balance), "SUK");
        process.exit(1);
    }
    
    // 检查空投合约当前余额
    const airdropBalance = await sukToken.balanceOf(AIRDROP_ADDRESS);
    console.log("空投合约当前余额:", hre.ethers.utils.formatEther(airdropBalance), "SUK");
    
    // ========== 执行转账 ==========
    
    console.log("\n💸 转移SUK代币...");
    console.log("-".repeat(80));
    
    const tx = await sukToken.transfer(AIRDROP_ADDRESS, amountWei);
    console.log("交易哈希:", tx.hash);
    
    console.log("等待确认...");
    const receipt = await tx.wait();
    console.log("✅ 转账成功!");
    console.log("Gas使用:", receipt.gasUsed.toString());
    
    // ========== 验证 ==========
    
    console.log("\n🔍 验证转账...");
    console.log("-".repeat(80));
    
    const newBalance = await sukToken.balanceOf(signer.address);
    const newAirdropBalance = await sukToken.balanceOf(AIRDROP_ADDRESS);
    
    console.log("您的新余额:", hre.ethers.utils.formatEther(newBalance), "SUK");
    console.log("空投合约新余额:", hre.ethers.utils.formatEther(newAirdropBalance), "SUK");
    
    // 验证数量
    const expectedAirdropBalance = airdropBalance.add(amountWei);
    if (!newAirdropBalance.eq(expectedAirdropBalance)) {
        console.error("\n❌ 错误: 余额不匹配!");
        process.exit(1);
    }
    
    console.log("\n✅ 验证通过");
    
    // ========== 检查空投合约状态 ==========
    
    console.log("\n📊 空投合约状态:");
    console.log("-".repeat(80));
    
    const stats = await airdrop.getAirdropStats();
    console.log("合约SUK余额:", hre.ethers.utils.formatEther(stats[4]), "SUK");
    console.log("已认领:", hre.ethers.utils.formatEther(stats[0]), "SUK");
    console.log("剩余可认领:", hre.ethers.utils.formatEther(stats[3]), "SUK");
    
    // ========== 完成 ==========
    
    console.log("\n" + "=".repeat(80));
    console.log("✅ 转账完成!");
    console.log("=".repeat(80));
    
    console.log("\n📝 后续步骤:");
    console.log("-".repeat(80));
    console.log("1️⃣  导入白名单");
    console.log(`   npx hardhat run scripts/import-whitelist.js --network ${hre.network.name}`);
    console.log("\n2️⃣  更新前端配置");
    console.log("3️⃣  开始空投活动");
    console.log("\n" + "=".repeat(80) + "\n");
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error("\n❌ 转账失败:", error);
        process.exit(1);
    });
