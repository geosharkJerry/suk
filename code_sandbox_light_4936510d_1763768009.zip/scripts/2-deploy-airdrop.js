const hre = require("hardhat");
const fs = require('fs');

/**
 * 部署SUK空投合约
 * 
 * 前置条件:
 * - SUK代币已部署
 * - 设置 SUK_TOKEN_ADDRESS 环境变量
 */

async function main() {
    console.log("=".repeat(80));
    console.log("SUK空投合约部署");
    console.log("=".repeat(80));
    
    // ========== 配置参数 ==========
    
    const SUK_TOKEN_ADDRESS = process.env.SUK_TOKEN_ADDRESS;
    
    if (!SUK_TOKEN_ADDRESS || SUK_TOKEN_ADDRESS === "0x...") {
        console.error("❌ 错误: 请设置 SUK_TOKEN_ADDRESS 环境变量");
        console.log("\n使用方法:");
        console.log("export SUK_TOKEN_ADDRESS=0x...");
        console.log(`npx hardhat run scripts/2-deploy-airdrop.js --network ${hre.network.name}`);
        process.exit(1);
    }
    
    // 时间配置
    const now = Math.floor(Date.now() / 1000);
    
    // 可以通过环境变量自定义时间，否则使用默认值
    const WHITELIST_START = process.env.WHITELIST_START_TIME 
        ? parseInt(process.env.WHITELIST_START_TIME)
        : now + 3600; // 1小时后
        
    const PUBLIC_START = process.env.PUBLIC_START_TIME
        ? parseInt(process.env.PUBLIC_START_TIME)
        : WHITELIST_START + (3 * 24 * 3600); // 3天后
        
    const END_TIME = process.env.END_TIME
        ? parseInt(process.env.END_TIME)
        : PUBLIC_START + (30 * 24 * 3600); // 30天后
    
    // ========== 获取部署账户 ==========
    
    const [deployer] = await hre.ethers.getSigners();
    const balance = await deployer.getBalance();
    
    console.log("\n📋 部署配置:");
    console.log("-".repeat(80));
    console.log("网络:", hre.network.name);
    console.log("SUK代币地址:", SUK_TOKEN_ADDRESS);
    console.log("部署者:", deployer.address);
    console.log("部署者余额:", hre.ethers.utils.formatEther(balance), "ETH");
    
    console.log("\n⏰ 时间配置:");
    console.log("-".repeat(80));
    console.log("当前时间:", new Date(now * 1000).toLocaleString('zh-CN'));
    console.log("白名单开始:", new Date(WHITELIST_START * 1000).toLocaleString('zh-CN'));
    console.log("公开开始:", new Date(PUBLIC_START * 1000).toLocaleString('zh-CN'));
    console.log("结束时间:", new Date(END_TIME * 1000).toLocaleString('zh-CN'));
    
    // 验证时间
    if (WHITELIST_START >= PUBLIC_START) {
        console.error("\n❌ 错误: 白名单开始时间必须早于公开开始时间");
        process.exit(1);
    }
    
    if (PUBLIC_START >= END_TIME) {
        console.error("\n❌ 错误: 公开开始时间必须早于结束时间");
        process.exit(1);
    }
    
    // 主网确认
    if (hre.network.name === 'mainnet') {
        console.log("\n⚠️  警告: 您正在主网部署空投合约!");
        console.log("请仔细检查所有参数");
    }
    
    // ========== 验证SUK代币 ==========
    
    console.log("\n🔍 验证SUK代币合约...");
    console.log("-".repeat(80));
    
    const sukToken = await hre.ethers.getContractAt("SUKToken", SUK_TOKEN_ADDRESS);
    
    try {
        const tokenInfo = await sukToken.getTokenInfo();
        console.log("代币名称:", tokenInfo.name_);
        console.log("代币符号:", tokenInfo.symbol_);
        console.log("小数位:", tokenInfo.decimals_);
        console.log("✅ SUK代币验证通过");
    } catch (error) {
        console.error("❌ 错误: 无法连接到SUK代币合约");
        console.error(error.message);
        process.exit(1);
    }
    
    // ========== 部署空投合约 ==========
    
    console.log("\n🚀 开始部署空投合约...");
    console.log("-".repeat(80));
    
    const SUKAirdrop = await hre.ethers.getContractFactory("SUKAirdrop");
    
    console.log("部署中...");
    const airdrop = await SUKAirdrop.deploy(
        SUK_TOKEN_ADDRESS,
        WHITELIST_START,
        PUBLIC_START,
        END_TIME
    );
    
    await airdrop.deployed();
    
    console.log("✅ SUKAirdrop 已部署!");
    console.log("合约地址:", airdrop.address);
    console.log("交易哈希:", airdrop.deployTransaction.hash);
    
    // 等待确认
    console.log("\n⏳ 等待区块确认...");
    await airdrop.deployTransaction.wait(3);
    console.log("✅ 已确认");
    
    // ========== 验证部署 ==========
    
    console.log("\n🔍 验证部署...");
    console.log("-".repeat(80));
    
    const stats = await airdrop.getAirdropStats();
    const status = await airdrop.getAirdropStatus();
    
    console.log("总空投量:", hre.ethers.utils.formatEther(await airdrop.TOTAL_AIRDROP_AMOUNT()), "SUK");
    console.log("白名单额度:", hre.ethers.utils.formatEther(await airdrop.WHITELIST_AMOUNT()), "SUK");
    console.log("公开额度:", hre.ethers.utils.formatEther(await airdrop.PUBLIC_AMOUNT()), "SUK");
    console.log("已认领:", hre.ethers.utils.formatEther(stats[0]), "SUK");
    console.log("剩余:", hre.ethers.utils.formatEther(stats[3]), "SUK");
    
    console.log("\n✅ 部署验证通过");
    
    // ========== 保存部署信息 ==========
    
    const deploymentInfo = {
        network: hre.network.name,
        chainId: (await hre.ethers.provider.getNetwork()).chainId,
        airdropAddress: airdrop.address,
        sukTokenAddress: SUK_TOKEN_ADDRESS,
        whitelistStartTime: WHITELIST_START,
        publicStartTime: PUBLIC_START,
        endTime: END_TIME,
        whitelistStartDate: new Date(WHITELIST_START * 1000).toISOString(),
        publicStartDate: new Date(PUBLIC_START * 1000).toISOString(),
        endDate: new Date(END_TIME * 1000).toISOString(),
        deployer: deployer.address,
        transactionHash: airdrop.deployTransaction.hash,
        blockNumber: airdrop.deployTransaction.blockNumber,
        deployedAt: new Date().toISOString()
    };
    
    if (!fs.existsSync('./deployment')) {
        fs.mkdirSync('./deployment');
    }
    
    const filename = `deployment/airdrop-${hre.network.name}-${Date.now()}.json`;
    fs.writeFileSync(filename, JSON.stringify(deploymentInfo, null, 2));
    
    console.log("\n💾 部署信息已保存:", filename);
    
    // ========== Etherscan验证 ==========
    
    if (hre.network.name !== 'hardhat' && hre.network.name !== 'localhost') {
        console.log("\n🔍 Etherscan合约验证...");
        console.log("-".repeat(80));
        
        console.log("等待 30 秒后开始验证...");
        await new Promise(resolve => setTimeout(resolve, 30000));
        
        try {
            await hre.run("verify:verify", {
                address: airdrop.address,
                constructorArguments: [
                    SUK_TOKEN_ADDRESS,
                    WHITELIST_START,
                    PUBLIC_START,
                    END_TIME
                ]
            });
            console.log("✅ 合约验证成功");
        } catch (error) {
            console.log("⚠️  合约验证失败:", error.message);
            console.log("\n可以稍后手动验证:");
            console.log(`npx hardhat verify --network ${hre.network.name} ${airdrop.address} ${SUK_TOKEN_ADDRESS} ${WHITELIST_START} ${PUBLIC_START} ${END_TIME}`);
        }
    }
    
    // ========== 后续操作指南 ==========
    
    console.log("\n" + "=".repeat(80));
    console.log("✅ 空投合约部署完成!");
    console.log("=".repeat(80));
    
    console.log("\n📝 后续步骤:");
    console.log("-".repeat(80));
    
    console.log("\n1️⃣  转移SUK代币到空投合约");
    console.log("   数量: 1,000,000 SUK");
    console.log("   目标地址:", airdrop.address);
    console.log("   \n   使用以下命令:");
    console.log(`   export AIRDROP_ADDRESS=${airdrop.address}`);
    console.log(`   npx hardhat run scripts/3-fund-airdrop.js --network ${hre.network.name}`);
    
    console.log("\n2️⃣  添加白名单地址");
    console.log("   准备 whitelist.csv 文件");
    console.log("   \n   使用以下命令:");
    console.log(`   npx hardhat run scripts/import-whitelist.js --network ${hre.network.name}`);
    
    console.log("\n3️⃣  更新前端配置");
    console.log("   编辑 suk-airdrop.html:");
    console.log(`   AIRDROP_CONTRACT_ADDRESS = "${airdrop.address}"`);
    console.log(`   SUK_TOKEN_ADDRESS = "${SUK_TOKEN_ADDRESS}"`);
    
    console.log("\n4️⃣  测试空投功能");
    console.log("   - 测试认领");
    console.log("   - 测试白名单");
    console.log("   - 测试防重复");
    
    console.log("\n" + "=".repeat(80));
    console.log("📚 完整文档: SUK_AIRDROP_GUIDE.md");
    console.log("=".repeat(80) + "\n");
    
    return {
        airdrop: airdrop.address,
        sukToken: SUK_TOKEN_ADDRESS
    };
}

main()
    .then((addresses) => {
        console.log("\n✅ 部署成功!");
        console.log("空投合约:", addresses.airdrop);
        console.log("SUK代币:", addresses.sukToken);
        process.exit(0);
    })
    .catch((error) => {
        console.error("\n❌ 部署失败:", error);
        process.exit(1);
    });
