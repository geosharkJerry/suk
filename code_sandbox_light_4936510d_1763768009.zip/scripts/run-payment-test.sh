#!/bin/bash
################################################################################
# 支付流程测试快速启动脚本
# Payment Flow Test Quick Start Script
################################################################################

set -e  # Exit on error

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 打印带颜色的消息
print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_header() {
    echo ""
    echo "════════════════════════════════════════════════════════════"
    echo "  $1"
    echo "════════════════════════════════════════════════════════════"
    echo ""
}

################################################################################
# 1. 检查前置条件
################################################################################

print_header "🔍 检查前置条件"

# 检查 Node.js
if ! command -v node &> /dev/null; then
    print_error "Node.js 未安装"
    echo "请安装 Node.js 18+ : https://nodejs.org/"
    exit 1
fi
NODE_VERSION=$(node -v)
print_success "Node.js 已安装: $NODE_VERSION"

# 检查 npm
if ! command -v npm &> /dev/null; then
    print_error "npm 未安装"
    exit 1
fi
NPM_VERSION=$(npm -v)
print_success "npm 已安装: $NPM_VERSION"

# 检查 MongoDB
if ! command -v mongosh &> /dev/null && ! command -v mongo &> /dev/null; then
    print_warning "MongoDB shell 未找到"
    print_info "如果 MongoDB 正在运行，可以忽略此警告"
else
    print_success "MongoDB shell 已安装"
fi

# 检查 MongoDB 连接
print_info "检查 MongoDB 连接..."
if mongosh "mongodb://localhost:27017" --eval "db.version()" &> /dev/null || \
   mongo "mongodb://localhost:27017" --eval "db.version()" &> /dev/null; then
    print_success "MongoDB 连接正常"
else
    print_error "无法连接到 MongoDB (localhost:27017)"
    echo "请确保 MongoDB 正在运行:"
    echo "  macOS: brew services start mongodb-community"
    echo "  Linux: sudo systemctl start mongod"
    echo "  Docker: docker run -d -p 27017:27017 mongo:6"
    exit 1
fi

# 检查 Redis
print_info "检查 Redis 连接..."
if redis-cli ping &> /dev/null; then
    print_success "Redis 连接正常"
else
    print_warning "无法连接到 Redis (localhost:6379)"
    print_info "Redis 不是必需的，但建议启动"
fi

# 检查环境变量
if [ -z "$TELEGRAM_BOT_TOKEN" ]; then
    print_warning "TELEGRAM_BOT_TOKEN 环境变量未设置"
    print_info "测试将使用模拟数据"
fi

################################################################################
# 2. 检查后端服务
################################################################################

print_header "🚀 检查后端服务"

# 检查服务是否运行
if curl -s http://localhost:3000/api/health > /dev/null 2>&1; then
    print_success "后端服务正在运行 (http://localhost:3000)"
else
    print_warning "后端服务未运行"
    
    # 询问是否启动服务
    read -p "是否启动后端服务? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        print_info "启动后端服务..."
        
        # 检查 node_modules
        if [ ! -d "node_modules" ]; then
            print_info "安装依赖..."
            npm install
        fi
        
        # 后台启动服务
        npm run dev > backend.log 2>&1 &
        BACKEND_PID=$!
        
        print_info "等待服务启动..."
        sleep 5
        
        # 验证服务
        if curl -s http://localhost:3000/api/health > /dev/null 2>&1; then
            print_success "后端服务启动成功 (PID: $BACKEND_PID)"
            echo "日志文件: backend.log"
        else
            print_error "后端服务启动失败"
            print_info "查看日志: tail -f backend.log"
            exit 1
        fi
    else
        print_error "测试需要后端服务运行"
        echo "请在另一个终端运行: npm run dev"
        exit 1
    fi
fi

################################################################################
# 3. 选择测试方式
################################################################################

print_header "🧪 选择测试方式"

echo "请选择测试方式:"
echo "  1) 可视化网页测试 (推荐)"
echo "  2) 命令行测试"
echo "  3) 两者都运行"
echo ""
read -p "请输入选择 (1-3): " -n 1 -r
echo ""

case $REPLY in
    1)
        print_info "启动可视化网页测试..."
        
        # 检查浏览器
        if command -v open &> /dev/null; then
            # macOS
            open "http://localhost:3000/payment-flow-test.html"
        elif command -v xdg-open &> /dev/null; then
            # Linux
            xdg-open "http://localhost:3000/payment-flow-test.html"
        elif command -v start &> /dev/null; then
            # Windows
            start "http://localhost:3000/payment-flow-test.html"
        else
            print_warning "无法自动打开浏览器"
            echo "请手动打开: http://localhost:3000/payment-flow-test.html"
        fi
        
        print_success "测试页面已打开"
        print_info "在浏览器中点击 '开始完整测试' 按钮"
        ;;
        
    2)
        print_info "运行命令行测试..."
        
        # 设置环境变量（如果未设置）
        if [ -z "$TELEGRAM_BOT_TOKEN" ]; then
            read -p "请输入 Telegram Bot Token (可选，回车跳过): " BOT_TOKEN
            if [ ! -z "$BOT_TOKEN" ]; then
                export TELEGRAM_BOT_TOKEN="$BOT_TOKEN"
            fi
        fi
        
        if [ -z "$TEST_USER_ID" ]; then
            read -p "请输入测试用户 ID (默认: 123456789): " USER_ID
            export TEST_USER_ID="${USER_ID:-123456789}"
        fi
        
        # 运行测试
        npm run test:payment
        ;;
        
    3)
        print_info "运行命令行测试..."
        
        # 命令行测试
        if [ -z "$TEST_USER_ID" ]; then
            export TEST_USER_ID="123456789"
        fi
        npm run test:payment
        
        echo ""
        print_info "启动可视化网页测试..."
        
        # 打开网页
        if command -v open &> /dev/null; then
            open "http://localhost:3000/payment-flow-test.html"
        elif command -v xdg-open &> /dev/null; then
            xdg-open "http://localhost:3000/payment-flow-test.html"
        else
            echo "请手动打开: http://localhost:3000/payment-flow-test.html"
        fi
        ;;
        
    *)
        print_error "无效选择"
        exit 1
        ;;
esac

################################################################################
# 4. MongoDB 验证提示
################################################################################

print_header "📊 MongoDB 数据验证"

echo "测试完成后，可以使用以下命令验证数据:"
echo ""
echo "  mongosh \"mongodb://localhost:27017/telegram-drama-dev\""
echo ""
echo "然后运行:"
echo ""
echo "  // 查看最新订单"
echo "  db.orders.find({}).sort({ createdAt: -1 }).limit(5).pretty()"
echo ""
echo "  // 查看最新购买记录"
echo "  db.purchases.find({}).sort({ purchasedAt: -1 }).limit(5).pretty()"
echo ""
echo "  // 查看特定用户的购买"
echo "  db.purchases.find({ userId: \"123456789\" }).pretty()"
echo ""

################################################################################
# 5. 清理提示
################################################################################

print_header "🧹 清理测试数据"

echo "测试完成后，如需清理测试数据，运行:"
echo ""
echo "  mongosh \"mongodb://localhost:27017/telegram-drama-dev\""
echo ""
echo "然后执行:"
echo ""
echo "  db.orders.deleteMany({ userId: \"123456789\", dramaId: \"drama_001\" })"
echo "  db.purchases.deleteMany({ userId: \"123456789\", dramaId: \"drama_001\" })"
echo ""

################################################################################
# 结束
################################################################################

print_header "✅ 测试准备完成"

echo "相关文档:"
echo "  📖 测试指南: PAYMENT_FLOW_TEST_GUIDE.md"
echo "  📖 快速开始: PAYMENT_QUICK_START.md"
echo "  📖 完整文档: PAYMENT_SYSTEM.md"
echo ""
echo "如有问题，请查看文档或运行:"
echo "  npm run test:quick  # 快速环境检查"
echo ""

print_success "准备就绪！开始测试吧！🚀"
