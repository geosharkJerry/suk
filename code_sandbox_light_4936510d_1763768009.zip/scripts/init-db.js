/**
 * 数据库初始化脚本
 * Database Initialization Script
 * 
 * 功能：
 * 1. 连接MongoDB数据库
 * 2. 创建必要的索引
 * 3. 插入初始数据（可选）
 * 4. 验证数据库配置
 */

require('dotenv').config();
const mongoose = require('mongoose');

// 引入模型
const WatchHistory = require('../backend/models/WatchHistory');
// 根据您的项目添加其他模型
// const Drama = require('../backend/models/Drama');
// const Episode = require('../backend/models/Episode');
// const User = require('../backend/models/User');
// const Purchase = require('../backend/models/Purchase');

/**
 * 数据库连接配置
 */
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/short_drama_platform';

/**
 * 主初始化函数
 */
async function initDatabase() {
    try {
        console.log('╔════════════════════════════════════════╗');
        console.log('║   短剧平台数据库初始化脚本             ║');
        console.log('║   Database Initialization Script      ║');
        console.log('╚════════════════════════════════════════╝\n');

        // 1. 连接数据库
        console.log('🔌 连接数据库...');
        console.log(`   URI: ${MONGODB_URI.replace(/\/\/.*@/, '//***@')}`);
        
        await mongoose.connect(MONGODB_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });
        
        console.log('✅ 数据库连接成功！\n');

        // 2. 创建索引
        console.log('📊 创建数据库索引...\n');
        await createIndexes();

        // 3. 插入初始数据（可选）
        if (process.argv.includes('--seed')) {
            console.log('\n🌱 插入初始数据...\n');
            await seedData();
        }

        // 4. 验证配置
        console.log('\n🔍 验证数据库配置...\n');
        await verifyDatabase();

        console.log('\n╔════════════════════════════════════════╗');
        console.log('║   ✅ 数据库初始化完成！                ║');
        console.log('║   Database Initialization Complete!   ║');
        console.log('╚════════════════════════════════════════╝\n');

        await mongoose.disconnect();
        process.exit(0);

    } catch (error) {
        console.error('\n❌ 数据库初始化失败:', error.message);
        console.error('详细错误信息:', error);
        process.exit(1);
    }
}

/**
 * 创建数据库索引
 */
async function createIndexes() {
    const models = [
        { name: 'WatchHistory', model: WatchHistory },
        // 添加其他模型
        // { name: 'Drama', model: Drama },
        // { name: 'Episode', model: Episode },
        // { name: 'User', model: User },
        // { name: 'Purchase', model: Purchase }
    ];

    for (const { name, model } of models) {
        try {
            console.log(`   📌 创建 ${name} 索引...`);
            await model.createIndexes();
            console.log(`   ✅ ${name} 索引创建成功`);
        } catch (error) {
            console.error(`   ❌ ${name} 索引创建失败:`, error.message);
            throw error;
        }
    }
}

/**
 * 插入初始数据
 */
async function seedData() {
    try {
        // 示例：插入测试用户观看历史
        const testWatchHistory = {
            userId: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb',
            dramaId: new mongoose.Types.ObjectId(),
            episodeId: 'ep_test_001',
            videoId: 'aliyun_test_video_001',
            watchProgress: 0,
            totalDuration: 300,
            progressPercent: 0,
            isCompleted: false,
            firstWatchedAt: new Date(),
            lastWatchedAt: new Date(),
            watchCount: 1
        };

        // 检查是否已存在
        const existing = await WatchHistory.findOne({
            userId: testWatchHistory.userId,
            episodeId: testWatchHistory.episodeId
        });

        if (!existing) {
            await WatchHistory.create(testWatchHistory);
            console.log('   ✅ 测试观看历史数据插入成功');
        } else {
            console.log('   ℹ️  测试数据已存在，跳过插入');
        }

        // 添加其他初始数据
        // await insertDramas();
        // await insertEpisodes();
        // await insertUsers();

    } catch (error) {
        console.error('   ❌ 初始数据插入失败:', error.message);
        throw error;
    }
}

/**
 * 验证数据库配置
 */
async function verifyDatabase() {
    try {
        // 1. 检查连接状态
        const state = mongoose.connection.readyState;
        const states = ['disconnected', 'connected', 'connecting', 'disconnecting'];
        console.log(`   📡 连接状态: ${states[state]}`);

        // 2. 检查数据库名称
        const dbName = mongoose.connection.db.databaseName;
        console.log(`   🗄️  数据库名称: ${dbName}`);

        // 3. 列出所有集合
        const collections = await mongoose.connection.db.listCollections().toArray();
        console.log(`   📦 集合数量: ${collections.length}`);
        collections.forEach(col => {
            console.log(`      - ${col.name}`);
        });

        // 4. 检查索引
        const watchHistoryIndexes = await WatchHistory.collection.getIndexes();
        console.log(`   🔑 WatchHistory 索引数量: ${Object.keys(watchHistoryIndexes).length}`);
        Object.keys(watchHistoryIndexes).forEach(indexName => {
            console.log(`      - ${indexName}`);
        });

        // 5. 统计文档数量
        const watchHistoryCount = await WatchHistory.countDocuments();
        console.log(`   📄 WatchHistory 文档数量: ${watchHistoryCount}`);

    } catch (error) {
        console.error('   ❌ 数据库验证失败:', error.message);
        throw error;
    }
}

/**
 * 示例：插入短剧数据
 */
// async function insertDramas() {
//     const Drama = require('../backend/models/Drama');
//     
//     const sampleDramas = [
//         {
//             title: '测试短剧1',
//             description: '这是一个测试短剧',
//             coverUrl: 'https://example.com/cover1.jpg',
//             totalEpisodes: 10,
//             price: 50,
//             episodePrice: 5,
//             category: 'romance',
//             status: 'published'
//         }
//     ];
//     
//     for (const drama of sampleDramas) {
//         const existing = await Drama.findOne({ title: drama.title });
//         if (!existing) {
//             await Drama.create(drama);
//             console.log(`   ✅ 短剧 "${drama.title}" 创建成功`);
//         }
//     }
// }

/**
 * 清空数据库（危险操作！）
 * 仅用于开发环境
 */
async function dropDatabase() {
    if (process.env.NODE_ENV === 'production') {
        console.error('❌ 生产环境不允许删除数据库！');
        return;
    }

    const readline = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });

    return new Promise((resolve) => {
        readline.question('⚠️  确认要删除所有数据吗？(yes/no): ', async (answer) => {
            if (answer.toLowerCase() === 'yes') {
                await mongoose.connection.dropDatabase();
                console.log('✅ 数据库已清空');
            } else {
                console.log('❌ 操作已取消');
            }
            readline.close();
            resolve();
        });
    });
}

// 命令行参数处理
if (process.argv.includes('--drop')) {
    // 危险操作：删除数据库
    console.log('⚠️  警告：即将删除数据库！');
    mongoose.connect(MONGODB_URI, {
        useNewUrlParser: true,
        useUnifiedTopology: true
    }).then(async () => {
        await dropDatabase();
        await mongoose.disconnect();
        process.exit(0);
    });
} else {
    // 正常初始化流程
    initDatabase();
}

/**
 * 使用方法：
 * 
 * 1. 基本初始化（只创建索引）：
 *    node scripts/init-db.js
 * 
 * 2. 初始化并插入测试数据：
 *    node scripts/init-db.js --seed
 * 
 * 3. 删除数据库（仅开发环境）：
 *    node scripts/init-db.js --drop
 */
