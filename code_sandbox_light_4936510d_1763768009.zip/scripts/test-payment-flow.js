#!/usr/bin/env node
/**
 * 支付流程完整测试脚本
 * Payment Flow Complete Test Script
 * 
 * 测试完整的购买流程，从创建订单到验证购买状态
 */

const fetch = require('node-fetch');
const crypto = require('crypto');

// ========================================
// 配置
// ========================================

const config = {
    apiUrl: process.env.API_URL || 'http://localhost:3000',
    botToken: process.env.TELEGRAM_BOT_TOKEN,
    testUserId: process.env.TEST_USER_ID || '123456789',
    testDramaId: 'drama_001',
    testEpisodeId: 'ep_002'
};

// ========================================
// 工具函数
// ========================================

/**
 * 生成模拟的 Telegram initData
 */
function generateMockInitData(userId, firstName = 'Test User') {
    const authDate = Math.floor(Date.now() / 1000);
    
    const userData = {
        id: parseInt(userId),
        first_name: firstName,
        last_name: 'Tester',
        username: 'testuser',
        language_code: 'zh',
        is_premium: false
    };

    const dataCheckString = `auth_date=${authDate}\nuser=${JSON.stringify(userData)}`;
    const secretKey = crypto.createHmac('sha256', 'WebAppData').update(config.botToken).digest();
    const hash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');

    return `user=${encodeURIComponent(JSON.stringify(userData))}&auth_date=${authDate}&hash=${hash}`;
}

/**
 * API 请求封装
 */
async function apiRequest(endpoint, method = 'GET', body = null) {
    const url = `${config.apiUrl}${endpoint}`;
    const initData = generateMockInitData(config.testUserId);
    
    const options = {
        method,
        headers: {
            'Content-Type': 'application/json',
            'X-Telegram-Init-Data': initData
        }
    };

    if (body && method !== 'GET') {
        options.body = JSON.stringify(body);
    }

    console.log(`\n📡 ${method} ${endpoint}`);
    
    try {
        const response = await fetch(url, options);
        const data = await response.json();
        
        console.log(`✅ 状态码: ${response.status}`);
        console.log(`📦 响应:`, JSON.stringify(data, null, 2));
        
        return { success: response.ok, status: response.status, data };
    } catch (error) {
        console.error(`❌ 请求失败:`, error.message);
        return { success: false, error: error.message };
    }
}

/**
 * 等待指定时间
 */
function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * 打印测试标题
 */
function printTestTitle(title) {
    console.log('\n' + '='.repeat(60));
    console.log(`  ${title}`);
    console.log('='.repeat(60));
}

/**
 * 打印测试结果
 */
function printResult(passed, message) {
    const icon = passed ? '✅' : '❌';
    const status = passed ? 'PASSED' : 'FAILED';
    console.log(`\n${icon} [${status}] ${message}`);
}

// ========================================
// 测试用例
// ========================================

/**
 * 测试 1: 获取剧集详情（购买前）
 */
async function test1_GetDramaDetailBeforePurchase() {
    printTestTitle('测试 1: 获取剧集详情（购买前）');
    
    const result = await apiRequest(`/api/telegram/dramas/${config.testDramaId}`);
    
    if (result.success) {
        const hasPurchased = result.data.data?.hasPurchased;
        printResult(
            hasPurchased === false,
            `购买状态应为 false，实际为: ${hasPurchased}`
        );
        return hasPurchased === false;
    } else {
        printResult(false, '获取剧集详情失败');
        return false;
    }
}

/**
 * 测试 2: 尝试播放付费剧集（应该被拦截）
 */
async function test2_TryPlayWithoutPurchase() {
    printTestTitle('测试 2: 尝试播放付费剧集（应该被拦截）');
    
    const result = await apiRequest(
        `/api/telegram/play-auth/${config.testEpisodeId}?dramaId=${config.testDramaId}`
    );
    
    const shouldBeDenied = result.status === 403;
    printResult(
        shouldBeDenied,
        shouldBeDenied 
            ? '正确拦截未购买用户' 
            : `应该返回 403，实际返回: ${result.status}`
    );
    
    return shouldBeDenied;
}

/**
 * 测试 3: 创建 Telegram Stars 支付发票
 */
async function test3_CreateStarsInvoice() {
    printTestTitle('测试 3: 创建 Telegram Stars 支付发票');
    
    const result = await apiRequest('/api/telegram/invoice', 'POST', {
        dramaId: config.testDramaId,
        paymentMethod: 'stars',
        purchaseType: 'full'
    });
    
    if (result.success) {
        const orderId = result.data.orderId;
        printResult(
            !!orderId,
            `订单创建成功，订单号: ${orderId}`
        );
        return { success: true, orderId };
    } else {
        printResult(false, '创建发票失败');
        return { success: false };
    }
}

/**
 * 测试 4: 查询订单状态
 */
async function test4_CheckOrderStatus(orderId) {
    printTestTitle('测试 4: 查询订单状态');
    
    // 直接连接 MongoDB 查询（需要 mongoose）
    console.log(`\n📝 订单号: ${orderId}`);
    console.log(`⏳ 订单应该处于 pending 状态`);
    console.log(`💡 提示: 使用 MongoDB Compass 或命令行查询:`);
    console.log(`   db.orders.findOne({ orderId: "${orderId}" })`);
    
    return true;
}

/**
 * 测试 5: 模拟支付成功回调
 */
async function test5_SimulatePaymentCallback(orderId) {
    printTestTitle('测试 5: 模拟支付成功回调');
    
    console.log('\n⚠️  注意: 支付回调只能由 Telegram 服务器调用');
    console.log('在真实环境中，此步骤由用户在 Telegram 中完成支付后自动触发\n');
    
    const mockWebhookData = {
        update_id: Math.floor(Math.random() * 1000000),
        message: {
            message_id: Math.floor(Math.random() * 1000),
            from: {
                id: parseInt(config.testUserId),
                first_name: 'Test User',
                is_bot: false
            },
            chat: {
                id: parseInt(config.testUserId),
                type: 'private'
            },
            date: Math.floor(Date.now() / 1000),
            successful_payment: {
                currency: 'XTR',
                total_amount: 100,
                invoice_payload: JSON.stringify({
                    orderId: orderId,
                    dramaId: config.testDramaId,
                    purchaseType: 'full',
                    episodeId: null,
                    timestamp: Date.now()
                }),
                telegram_payment_charge_id: `tch_${crypto.randomBytes(16).toString('hex')}`,
                provider_payment_charge_id: `pch_${crypto.randomBytes(16).toString('hex')}`
            }
        }
    };

    console.log('📤 模拟 webhook 数据:', JSON.stringify(mockWebhookData, null, 2));
    
    const result = await fetch(`${config.apiUrl}/api/telegram/webhook`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(mockWebhookData)
    });

    console.log(`\n✅ Webhook 响应状态: ${result.status}`);
    
    if (result.status === 200) {
        console.log('⏳ 等待 2 秒处理回调...');
        await wait(2000);
        printResult(true, '支付回调处理成功');
        return true;
    } else {
        printResult(false, `Webhook 返回状态码: ${result.status}`);
        return false;
    }
}

/**
 * 测试 6: 验证订单和购买记录
 */
async function test6_VerifyOrderAndPurchase(orderId) {
    printTestTitle('测试 6: 验证订单和购买记录');
    
    console.log('\n📝 使用 MongoDB 查询验证:');
    console.log('\n1️⃣ 检查订单状态已更新为 completed:');
    console.log(`   db.orders.findOne({ orderId: "${orderId}" })`);
    console.log('   期望: status === "completed"');
    
    console.log('\n2️⃣ 检查购买记录已创建:');
    console.log(`   db.purchases.findOne({ orderId: "${orderId}" })`);
    console.log('   期望: 找到记录且 isValid === true');
    
    console.log('\n💡 提示: 打开新终端运行:');
    console.log('   mongosh "mongodb://localhost:27017/telegram-drama-dev"');
    
    return true;
}

/**
 * 测试 7: 获取剧集详情（购买后）
 */
async function test7_GetDramaDetailAfterPurchase() {
    printTestTitle('测试 7: 获取剧集详情（购买后）');
    
    const result = await apiRequest(`/api/telegram/dramas/${config.testDramaId}`);
    
    if (result.success) {
        const hasPurchased = result.data.data?.hasPurchased;
        printResult(
            hasPurchased === true,
            `购买状态应为 true，实际为: ${hasPurchased}`
        );
        return hasPurchased === true;
    } else {
        printResult(false, '获取剧集详情失败');
        return false;
    }
}

/**
 * 测试 8: 尝试播放付费剧集（应该成功）
 */
async function test8_TryPlayAfterPurchase() {
    printTestTitle('测试 8: 尝试播放付费剧集（应该成功）');
    
    const result = await apiRequest(
        `/api/telegram/play-auth/${config.testEpisodeId}?dramaId=${config.testDramaId}`
    );
    
    const shouldBeAllowed = result.status === 200;
    printResult(
        shouldBeAllowed,
        shouldBeAllowed 
            ? '成功获取播放授权' 
            : `应该返回 200，实际返回: ${result.status}`
    );
    
    return shouldBeAllowed;
}

/**
 * 测试 9: 防重复购买验证
 */
async function test9_PreventDuplicatePurchase() {
    printTestTitle('测试 9: 防重复购买验证');
    
    console.log('\n尝试为同一用户创建重复购买记录...');
    
    // 尝试再次创建发票
    const result = await apiRequest('/api/telegram/invoice', 'POST', {
        dramaId: config.testDramaId,
        paymentMethod: 'stars',
        purchaseType: 'full'
    });
    
    if (result.success) {
        console.log('\n✅ 新订单创建成功（订单可以重复创建）');
        console.log('但购买记录应该被去重保护');
        
        // 模拟支付回调
        const mockWebhookData = {
            update_id: Math.floor(Math.random() * 1000000),
            message: {
                message_id: Math.floor(Math.random() * 1000),
                from: { id: parseInt(config.testUserId), first_name: 'Test User', is_bot: false },
                chat: { id: parseInt(config.testUserId), type: 'private' },
                date: Math.floor(Date.now() / 1000),
                successful_payment: {
                    currency: 'XTR',
                    total_amount: 100,
                    invoice_payload: JSON.stringify({
                        orderId: result.data.orderId,
                        dramaId: config.testDramaId,
                        purchaseType: 'full',
                        episodeId: null,
                        timestamp: Date.now()
                    }),
                    telegram_payment_charge_id: `tch_${crypto.randomBytes(16).toString('hex')}`,
                    provider_payment_charge_id: `pch_${crypto.randomBytes(16).toString('hex')}`
                }
            }
        };

        await fetch(`${config.apiUrl}/api/telegram/webhook`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(mockWebhookData)
        });

        await wait(2000);
        
        console.log('\n💡 验证重复购买保护:');
        console.log('   运行 MongoDB 查询:');
        console.log(`   db.purchases.countDocuments({ userId: "${config.testUserId}", dramaId: "${config.testDramaId}", isValid: true })`);
        console.log('   期望结果: 1（只有一条有效购买记录）');
        
        printResult(true, '防重复购买测试完成');
        return true;
    } else {
        printResult(false, '创建订单失败');
        return false;
    }
}

/**
 * 测试 10: 免费剧集播放（无需购买）
 */
async function test10_PlayFreeEpisode() {
    printTestTitle('测试 10: 免费剧集播放（无需购买）');
    
    const result = await apiRequest(
        `/api/telegram/play-auth/ep_001?dramaId=${config.testDramaId}`
    );
    
    const shouldBeAllowed = result.status === 200;
    printResult(
        shouldBeAllowed,
        shouldBeAllowed 
            ? '免费剧集无需购买即可播放' 
            : `应该返回 200，实际返回: ${result.status}`
    );
    
    return shouldBeAllowed;
}

// ========================================
// 主测试流程
// ========================================

async function runAllTests() {
    console.log('\n');
    console.log('╔════════════════════════════════════════════════════════════╗');
    console.log('║                                                            ║');
    console.log('║          🧪 Telegram 支付流程完整测试                      ║');
    console.log('║          Payment Flow Complete Test                       ║');
    console.log('║                                                            ║');
    console.log('╚════════════════════════════════════════════════════════════╝');
    
    console.log('\n📋 测试配置:');
    console.log(`   API URL: ${config.apiUrl}`);
    console.log(`   测试用户 ID: ${config.testUserId}`);
    console.log(`   测试剧集 ID: ${config.testDramaId}`);
    console.log(`   测试剧集编号: ${config.testEpisodeId}`);
    
    if (!config.botToken) {
        console.error('\n❌ 错误: 未设置 TELEGRAM_BOT_TOKEN 环境变量');
        console.log('请设置环境变量后再运行:');
        console.log('export TELEGRAM_BOT_TOKEN="your_bot_token"');
        process.exit(1);
    }

    const results = [];
    let orderId = null;

    try {
        // 运行所有测试
        results.push(await test1_GetDramaDetailBeforePurchase());
        results.push(await test2_TryPlayWithoutPurchase());
        
        const invoiceResult = await test3_CreateStarsInvoice();
        results.push(invoiceResult.success);
        
        if (invoiceResult.success) {
            orderId = invoiceResult.orderId;
            results.push(await test4_CheckOrderStatus(orderId));
            results.push(await test5_SimulatePaymentCallback(orderId));
            results.push(await test6_VerifyOrderAndPurchase(orderId));
            results.push(await test7_GetDramaDetailAfterPurchase());
            results.push(await test8_TryPlayAfterPurchase());
            results.push(await test9_PreventDuplicatePurchase());
            results.push(await test10_PlayFreeEpisode());
        }

        // 打印测试总结
        printTestTitle('测试总结');
        
        const passed = results.filter(r => r === true).length;
        const total = results.length;
        const percentage = Math.round((passed / total) * 100);

        console.log(`\n总测试数: ${total}`);
        console.log(`✅ 通过: ${passed}`);
        console.log(`❌ 失败: ${total - passed}`);
        console.log(`📊 通过率: ${percentage}%`);

        if (percentage === 100) {
            console.log('\n🎉 所有测试通过！支付流程正常工作！');
        } else if (percentage >= 70) {
            console.log('\n⚠️  部分测试失败，但核心功能正常');
        } else {
            console.log('\n❌ 多个测试失败，请检查配置和代码');
        }

        // 数据库验证提示
        console.log('\n' + '='.repeat(60));
        console.log('📊 MongoDB 数据验证');
        console.log('='.repeat(60));
        
        console.log('\n运行以下命令验证数据库状态:');
        console.log('\nmongosh "mongodb://localhost:27017/telegram-drama-dev"');
        
        if (orderId) {
            console.log(`\n// 查看订单`);
            console.log(`db.orders.findOne({ orderId: "${orderId}" })`);
            
            console.log(`\n// 查看购买记录`);
            console.log(`db.purchases.findOne({ orderId: "${orderId}" })`);
        }
        
        console.log(`\n// 查看所有订单`);
        console.log(`db.orders.find({}).sort({ createdAt: -1 }).limit(5)`);
        
        console.log(`\n// 查看所有购买记录`);
        console.log(`db.purchases.find({}).sort({ purchasedAt: -1 }).limit(5)`);
        
        console.log('\n' + '='.repeat(60));

    } catch (error) {
        console.error('\n❌ 测试过程中出现错误:', error);
        process.exit(1);
    }
}

// 运行测试
if (require.main === module) {
    runAllTests().catch(error => {
        console.error('Fatal error:', error);
        process.exit(1);
    });
}

module.exports = { runAllTests };
