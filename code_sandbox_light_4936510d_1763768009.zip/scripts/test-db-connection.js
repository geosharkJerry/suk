/**
 * 数据库连接测试脚本
 * Database Connection Testing Script
 * 
 * 测试MongoDB和Redis连接
 */

require('dotenv').config();
const mongoose = require('mongoose');
const redis = require('redis');

console.log('╔════════════════════════════════════════╗');
console.log('║   数据库连接测试                       ║');
console.log('║   Database Connection Test            ║');
console.log('╚════════════════════════════════════════╝\n');

let testsPassed = 0;
let testsFailed = 0;

/**
 * 测试MongoDB连接
 */
async function testMongoDB() {
    console.log('📊 测试1: MongoDB连接\n');
    
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/short_drama_platform';
    
    try {
        console.log(`   连接URI: ${mongoUri.replace(/\/\/.*@/, '//***@')}`);
        
        await mongoose.connect(mongoUri, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            serverSelectionTimeoutMS: 5000
        });

        console.log('✅ MongoDB连接成功！\n');
        
        // 获取数据库信息
        const db = mongoose.connection.db;
        const dbName = db.databaseName;
        console.log(`   数据库名称: ${dbName}`);
        
        // 列出集合
        const collections = await db.listCollections().toArray();
        console.log(`   集合数量: ${collections.length}`);
        if (collections.length > 0) {
            console.log('   集合列表:');
            collections.forEach(col => {
                console.log(`     - ${col.name}`);
            });
        }
        
        // 测试写入
        console.log('\n   测试写入操作...');
        const testCollection = db.collection('_connection_test');
        await testCollection.insertOne({
            test: true,
            timestamp: new Date(),
            message: '数据库连接测试'
        });
        console.log('✅ 写入测试成功');
        
        // 测试读取
        console.log('   测试读取操作...');
        const doc = await testCollection.findOne({ test: true });
        if (doc) {
            console.log('✅ 读取测试成功');
        }
        
        // 清理测试数据
        await testCollection.deleteMany({ test: true });
        console.log('✅ 测试数据已清理\n');
        
        await mongoose.connection.close();
        testsPassed++;
        return true;

    } catch (error) {
        console.error('❌ MongoDB连接失败！');
        console.error(`   错误: ${error.message}\n`);
        
        if (error.message.includes('ECONNREFUSED')) {
            console.log('💡 提示: MongoDB服务未启动');
            console.log('   解决方案:');
            console.log('   - Linux: sudo systemctl start mongod');
            console.log('   - macOS: brew services start mongodb-community');
            console.log('   - Windows: net start MongoDB\n');
        } else if (error.message.includes('Authentication failed')) {
            console.log('💡 提示: 认证失败');
            console.log('   解决方案: 检查 .env 中的用户名和密码\n');
        }
        
        testsFailed++;
        return false;
    }
}

/**
 * 测试Redis连接
 */
async function testRedis() {
    console.log('📦 测试2: Redis连接\n');
    
    const redisHost = process.env.REDIS_HOST || 'localhost';
    const redisPort = parseInt(process.env.REDIS_PORT || '6379');
    const redisPassword = process.env.REDIS_PASSWORD || '';
    
    console.log(`   连接地址: ${redisHost}:${redisPort}`);
    console.log(`   是否设置密码: ${redisPassword ? '是' : '否'}\n`);
    
    const client = redis.createClient({
        socket: {
            host: redisHost,
            port: redisPort,
            connectTimeout: 5000
        },
        password: redisPassword || undefined
    });

    try {
        // 连接Redis
        await client.connect();
        console.log('✅ Redis连接成功！\n');

        // 测试PING
        console.log('   测试PING命令...');
        const pong = await client.ping();
        if (pong === 'PONG') {
            console.log('✅ PING测试成功');
        }

        // 测试写入
        console.log('   测试SET命令...');
        await client.set('test_key', 'test_value', { EX: 10 });
        console.log('✅ SET测试成功');

        // 测试读取
        console.log('   测试GET命令...');
        const value = await client.get('test_key');
        if (value === 'test_value') {
            console.log('✅ GET测试成功');
        }

        // 测试删除
        console.log('   测试DEL命令...');
        await client.del('test_key');
        console.log('✅ DEL测试成功');

        // 获取Redis信息
        console.log('\n   Redis服务信息:');
        const info = await client.info('server');
        const version = info.match(/redis_version:([^\r\n]+)/);
        if (version) {
            console.log(`   版本: ${version[1]}`);
        }

        console.log('');
        await client.quit();
        testsPassed++;
        return true;

    } catch (error) {
        console.error('❌ Redis连接失败！');
        console.error(`   错误: ${error.message}\n`);

        if (error.message.includes('ECONNREFUSED')) {
            console.log('💡 提示: Redis服务未启动');
            console.log('   解决方案:');
            console.log('   - Linux: sudo systemctl start redis-server');
            console.log('   - macOS: brew services start redis');
            console.log('   - Windows: redis-server.exe\n');
        } else if (error.message.includes('WRONGPASS') || error.message.includes('NOAUTH')) {
            console.log('💡 提示: 认证失败');
            console.log('   解决方案: 检查 .env 中的 REDIS_PASSWORD\n');
        }

        if (client.isOpen) {
            await client.quit();
        }
        testsFailed++;
        return false;
    }
}

/**
 * 主测试函数
 */
async function runTests() {
    try {
        await testMongoDB();
        await testRedis();

        // 测试摘要
        console.log('═'.repeat(50));
        console.log('📊 测试摘要:\n');
        console.log(`   ✅ 通过: ${testsPassed}`);
        console.log(`   ❌ 失败: ${testsFailed}`);
        console.log(`   📈 成功率: ${Math.round((testsPassed / (testsPassed + testsFailed)) * 100)}%\n`);

        if (testsFailed === 0) {
            console.log('🎉 所有数据库连接测试通过！\n');
            process.exit(0);
        } else {
            console.log('⚠️  部分测试失败，请检查数据库配置。\n');
            process.exit(1);
        }

    } catch (error) {
        console.error('❌ 测试过程中发生错误:', error);
        process.exit(1);
    }
}

// 运行测试
runTests();

/**
 * 使用方法：
 * 
 * 1. 基本测试：
 *    node scripts/test-db-connection.js
 * 
 * 2. 在CI/CD中使用：
 *    npm run test:db
 */
