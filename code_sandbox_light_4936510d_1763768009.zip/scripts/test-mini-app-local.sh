#!/bin/bash

# Telegram Mini App 本地测试快速启动脚本
# 使用方法: ./scripts/test-mini-app-local.sh

echo "======================================"
echo "🧪 Telegram Mini App 本地测试"
echo "======================================"
echo ""

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 1. 检查http-server
echo -e "${BLUE}步骤 1/4: 检查环境...${NC}"
if ! command -v http-server &> /dev/null; then
    echo -e "${YELLOW}⚠️  http-server 未安装${NC}"
    echo "正在安装 http-server..."
    npm install -g http-server
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ http-server 安装成功${NC}"
    else
        echo -e "${RED}❌ http-server 安装失败，请手动安装: npm install -g http-server${NC}"
        exit 1
    fi
else
    echo -e "${GREEN}✅ http-server 已安装${NC}"
fi
echo ""

# 2. 检查文件
echo -e "${BLUE}步骤 2/4: 检查必需文件...${NC}"
FILES=("telegram-app.html" "telegram-drama-detail.html" "test-mini-app.html")
MISSING=0

for file in "${FILES[@]}"; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✅${NC} $file"
    else
        echo -e "${RED}❌${NC} $file ${RED}(缺失)${NC}"
        MISSING=$((MISSING + 1))
    fi
done

if [ $MISSING -gt 0 ]; then
    echo -e "${RED}❌ 有 $MISSING 个文件缺失，无法继续${NC}"
    exit 1
fi
echo ""

# 3. 检查端口
echo -e "${BLUE}步骤 3/4: 检查端口 8080...${NC}"
if lsof -Pi :8080 -sTCP:LISTEN -t >/dev/null ; then
    echo -e "${YELLOW}⚠️  端口 8080 已被占用${NC}"
    echo "尝试使用端口 8888..."
    PORT=8888
else
    echo -e "${GREEN}✅ 端口 8080 可用${NC}"
    PORT=8080
fi
echo ""

# 4. 启动服务器
echo -e "${BLUE}步骤 4/4: 启动HTTP服务器...${NC}"
echo -e "${GREEN}✅ 服务器启动成功！${NC}"
echo ""

echo "======================================"
echo "📱 测试URL"
echo "======================================"
echo ""
echo -e "${GREEN}🎨 自动化测试工具:${NC}"
echo "   http://localhost:$PORT/test-mini-app.html"
echo ""
echo -e "${GREEN}📱 主页 (短剧列表):${NC}"
echo "   http://localhost:$PORT/telegram-app.html"
echo ""
echo -e "${GREEN}🎬 详情页 (第一部短剧):${NC}"
echo "   http://localhost:$PORT/telegram-drama-detail.html?id=drama-001"
echo ""
echo -e "${GREEN}🎁 免费短剧详情页:${NC}"
echo "   http://localhost:$PORT/telegram-drama-detail.html?id=drama-002"
echo ""

echo "======================================"
echo "📋 测试清单"
echo "======================================"
echo ""
echo "推荐测试流程:"
echo ""
echo "1️⃣  打开自动化测试工具"
echo "   → 点击 '▶️ 运行所有测试'"
echo "   → 查看测试结果和日志"
echo ""
echo "2️⃣  手动测试主页"
echo "   → 检查8部短剧显示"
echo "   → 测试分类筛选（6个分类）"
echo "   → 点击短剧跳转详情页"
echo ""
echo "3️⃣  手动测试详情页"
echo "   → 验证支付选项（3种）"
echo "   → 查看剧集列表（前3集免费）"
echo "   → 阅读评论（3条）"
echo "   → 测试返回按钮"
echo ""
echo "4️⃣  测试免费短剧"
echo "   → 访问第二部短剧（drama-002）"
echo "   → 确认无支付卡片"
echo "   → 所有剧集无锁定"
echo ""

echo "======================================"
echo "🔍 调试技巧"
echo "======================================"
echo ""
echo "• 打开浏览器开发者工具 (F12)"
echo "• 切换到 Console 标签"
echo "• 应该看到以下日志:"
echo "  🚀 初始化Telegram Mini App"
echo "  🔧 开发模式：使用模拟用户数据"
echo "  ✅ Mock数据加载成功: 8"
echo ""
echo "• 如果页面空白，检查:"
echo "  1. Console 是否有错误"
echo "  2. Network 是否有404"
echo "  3. 浏览器是否禁用JavaScript"
echo ""

echo "======================================"
echo "⚡ 按 Ctrl+C 停止服务器"
echo "======================================"
echo ""

# 启动服务器
http-server . -p $PORT -c-1
