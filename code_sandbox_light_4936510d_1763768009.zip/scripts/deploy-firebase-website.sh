#!/bin/bash

# ============================================
# SUK.WTF Firebase 官网部署脚本
# Firebase Website Deployment Script
# ============================================
#
# 功能：
# ✅ 部署项目官网到 Firebase Hosting
# ✅ 自动优化静态资源
# ✅ 验证部署状态
# ✅ 支持预览部署
#
# 使用方法：
# ./deploy-firebase-website.sh [preview|production]
#
# ============================================

set -e

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0;3m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_banner() {
    echo ""
    echo "╔════════════════════════════════════════════════════════╗"
    echo "║                                                        ║"
    echo "║        🔥 SUK.WTF Firebase 官网部署                   ║"
    echo "║           Firebase Website Deployment                  ║"
    echo "║                                                        ║"
    echo "║        域名: suk.link                                   ║"
    echo "║        平台: Firebase Hosting                          ║"
    echo "║                                                        ║"
    echo "╚════════════════════════════════════════════════════════╝"
    echo ""
}

# 检查 Firebase CLI
check_firebase_cli() {
    log_info "检查 Firebase CLI..."
    
    if ! command -v firebase &> /dev/null; then
        log_error "Firebase CLI 未安装"
        log_info "请运行: npm install -g firebase-tools"
        exit 1
    fi
    
    FIREBASE_VERSION=$(firebase --version)
    log_success "Firebase CLI 已安装: $FIREBASE_VERSION"
}

# 检查登录状态
check_login() {
    log_info "检查 Firebase 登录状态..."
    
    if ! firebase projects:list &> /dev/null; then
        log_error "未登录 Firebase"
        log_info "请运行: firebase login"
        exit 1
    fi
    
    log_success "已登录 Firebase"
}

# 检查项目配置
check_project() {
    log_info "检查 Firebase 项目配置..."
    
    if [ ! -f "firebase.json" ]; then
        log_error "未找到 firebase.json"
        log_info "请运行: firebase init"
        exit 1
    fi
    
    if [ ! -f ".firebaserc" ]; then
        log_error "未找到 .firebaserc"
        log_info "请运行: firebase init"
        exit 1
    fi
    
    PROJECT_ID=$(grep '"default":' .firebaserc | sed 's/.*: "\(.*\)".*/\1/')
    log_success "Firebase 项目: $PROJECT_ID"
}

# 清理临时文件
clean_temp_files() {
    log_info "清理临时文件..."
    
    # 删除 macOS .DS_Store
    find . -name ".DS_Store" -type f -delete 2>/dev/null || true
    
    # 删除编辑器临时文件
    find . -name "*~" -type f -delete 2>/dev/null || true
    find . -name "*.swp" -type f -delete 2>/dev/null || true
    
    log_success "临时文件清理完成"
}

# 验证关键文件
verify_files() {
    log_info "验证关键文件..."
    
    MISSING_FILES=()
    
    # 检查 HTML 文件
    if [ ! -f "index.html" ]; then
        MISSING_FILES+=("index.html")
    fi
    
    # 检查 Telegram Mini App
    if [ ! -f "telegram-app.html" ]; then
        log_warning "telegram-app.html 不存在（可选）"
    fi
    
    # 检查资源目录
    if [ ! -d "css" ]; then
        log_warning "css/ 目录不存在"
    fi
    
    if [ ! -d "js" ]; then
        log_warning "js/ 目录不存在"
    fi
    
    if [ ${#MISSING_FILES[@]} -gt 0 ]; then
        log_error "缺少关键文件:"
        for file in "${MISSING_FILES[@]}"; do
            echo "  ✗ $file"
        done
        exit 1
    fi
    
    log_success "关键文件验证通过"
}

# 预览部署
preview_deploy() {
    log_info "创建预览部署..."
    
    CHANNEL="preview-$(date +%Y%m%d-%H%M%S)"
    
    firebase hosting:channel:deploy "$CHANNEL" --expires 7d
    
    log_success "预览部署完成"
    log_info "预览链接将在 7 天后过期"
}

# 生产部署
production_deploy() {
    log_info "部署到生产环境..."
    
    # 确认部署
    read -p "确认部署到生产环境 suk.link? (y/n): " confirm
    if [ "$confirm" != "y" ]; then
        log_warning "部署已取消"
        exit 0
    fi
    
    # 部署 Hosting
    firebase deploy --only hosting
    
    if [ $? -eq 0 ]; then
        log_success "生产部署完成"
    else
        log_error "部署失败"
        exit 1
    fi
}

# 验证部署
verify_deployment() {
    log_info "验证部署状态..."
    
    # 获取项目 ID
    PROJECT_ID=$(grep '"default":' .firebaserc | sed 's/.*: "\(.*\)".*/\1/')
    
    # Firebase 默认域名
    FIREBASE_URL="https://$PROJECT_ID.web.app"
    
    log_info "检查 Firebase 默认域名: $FIREBASE_URL"
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$FIREBASE_URL")
    
    if [ "$HTTP_CODE" == "200" ]; then
        log_success "✓ Firebase 域名可访问 ($HTTP_CODE)"
    else
        log_warning "✗ Firebase 域名返回 HTTP $HTTP_CODE"
    fi
    
    # 自定义域名（如果配置了）
    log_info "检查自定义域名: https://suk.link"
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "https://suk.link")
    
    if [ "$HTTP_CODE" == "200" ]; then
        log_success "✓ 自定义域名可访问 ($HTTP_CODE)"
    else
        log_warning "✗ 自定义域名返回 HTTP $HTTP_CODE"
        log_info "如果刚配置自定义域名，请等待 24-48 小时 SSL 证书生成"
    fi
}

# 打印部署信息
print_summary() {
    echo ""
    echo "╔════════════════════════════════════════════════════════╗"
    echo "║                                                        ║"
    echo "║          ✅ 部署完成！Deployment Complete!            ║"
    echo "║                                                        ║"
    echo "╚════════════════════════════════════════════════════════╝"
    echo ""
    
    PROJECT_ID=$(grep '"default":' .firebaserc | sed 's/.*: "\(.*\)".*/\1/')
    
    log_info "访问地址:"
    echo "  • Firebase 域名: https://$PROJECT_ID.web.app"
    echo "  • 自定义域名: https://suk.link"
    echo ""
    
    log_info "Firebase 控制台:"
    echo "  • https://console.firebase.google.com/project/$PROJECT_ID"
    echo ""
    
    log_info "常用命令:"
    echo "  • 查看部署历史: firebase hosting:clone"
    echo "  • 回滚部署: firebase hosting:rollback"
    echo "  • 本地预览: firebase serve"
    echo ""
}

# 主函数
main() {
    print_banner
    
    # 部署模式
    MODE="${1:-production}"
    
    log_info "部署模式: $MODE"
    echo ""
    
    # 检查环境
    check_firebase_cli
    check_login
    check_project
    
    # 准备部署
    clean_temp_files
    verify_files
    
    echo ""
    
    # 执行部署
    if [ "$MODE" == "preview" ]; then
        preview_deploy
    else
        production_deploy
    fi
    
    echo ""
    
    # 验证部署
    verify_deployment
    
    # 打印总结
    print_summary
    
    log_success "🎉 SUK.WTF 官网部署完成！"
    echo ""
}

# 运行主函数
main "$@"
