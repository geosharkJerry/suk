const hre = require("hardhat");
const fs = require('fs');

/**
 * SUK空投合约部署脚本
 * 
 * 功能:
 * 1. 部署SUKAirdrop合约
 * 2. 验证部署参数
 * 3. 保存部署信息
 * 4. 输出后续操作指南
 */

async function main() {
    console.log("=".repeat(60));
    console.log("SUK空投合约部署");
    console.log("=".repeat(60));
    
    // ========== 配置参数 ==========
    
    // SUK代币合约地址 (需要先部署SUK代币)
    const SUK_TOKEN_ADDRESS = process.env.SUK_TOKEN_ADDRESS || "0x...";
    
    if (SUK_TOKEN_ADDRESS === "0x...") {
        console.error("❌ 错误: 请设置 SUK_TOKEN_ADDRESS 环境变量");
        console.log("\n使用方法:");
        console.log("export SUK_TOKEN_ADDRESS=0x...");
        console.log("npx hardhat run scripts/deploy-airdrop.js --network goerli");
        process.exit(1);
    }
    
    // 时间配置
    const now = Math.floor(Date.now() / 1000);
    
    // 开发/测试: 1小时后开始
    // 生产: 设置为具体日期
    const WHITELIST_START = now + 3600; // 1小时后
    const PUBLIC_START = WHITELIST_START + (3 * 24 * 3600); // 3天后
    const END_TIME = PUBLIC_START + (30 * 24 * 3600); // 30天后
    
    // ========== 显示配置 ==========
    
    console.log("\n📋 部署配置:");
    console.log("-".repeat(60));
    console.log("SUK代币地址:", SUK_TOKEN_ADDRESS);
    console.log("网络:", hre.network.name);
    console.log("部署者:", (await hre.ethers.getSigners())[0].address);
    console.log("\n⏰ 时间配置:");
    console.log("-".repeat(60));
    console.log("当前时间:", new Date(now * 1000).toLocaleString('zh-CN'));
    console.log("白名单开始:", new Date(WHITELIST_START * 1000).toLocaleString('zh-CN'));
    console.log("公开开始:", new Date(PUBLIC_START * 1000).toLocaleString('zh-CN'));
    console.log("结束时间:", new Date(END_TIME * 1000).toLocaleString('zh-CN'));
    
    // 确认部署
    if (hre.network.name === 'mainnet') {
        console.log("\n⚠️  警告: 您正在主网部署！");
        console.log("请仔细检查所有参数");
        // 生产环境需要手动确认
        // await confirm("确认继续部署？");
    }
    
    console.log("\n🚀 开始部署...");
    
    // ========== 部署合约 ==========
    
    const SUKAirdrop = await hre.ethers.getContractFactory("SUKAirdrop");
    
    console.log("部署SUKAirdrop合约...");
    
    const airdrop = await SUKAirdrop.deploy(
        SUK_TOKEN_ADDRESS,
        WHITELIST_START,
        PUBLIC_START,
        END_TIME
    );
    
    await airdrop.deployed();
    
    console.log("✅ SUKAirdrop合约已部署");
    console.log("合约地址:", airdrop.address);
    console.log("交易哈希:", airdrop.deployTransaction.hash);
    
    // ========== 保存部署信息 ==========
    
    const deploymentInfo = {
        network: hre.network.name,
        airdropAddress: airdrop.address,
        sukTokenAddress: SUK_TOKEN_ADDRESS,
        whitelistStartTime: WHITELIST_START,
        publicStartTime: PUBLIC_START,
        endTime: END_TIME,
        deployedAt: new Date().toISOString(),
        deployer: (await hre.ethers.getSigners())[0].address,
        transactionHash: airdrop.deployTransaction.hash
    };
    
    const filename = `deployment-airdrop-${hre.network.name}-${Date.now()}.json`;
    fs.writeFileSync(
        `deployment/${filename}`,
        JSON.stringify(deploymentInfo, null, 2)
    );
    
    console.log("\n💾 部署信息已保存:", filename);
    
    // ========== 验证合约 ==========
    
    if (hre.network.name !== 'hardhat' && hre.network.name !== 'localhost') {
        console.log("\n🔍 等待区块确认后验证合约...");
        await airdrop.deployTransaction.wait(5); // 等待5个区块
        
        try {
            await hre.run("verify:verify", {
                address: airdrop.address,
                constructorArguments: [
                    SUK_TOKEN_ADDRESS,
                    WHITELIST_START,
                    PUBLIC_START,
                    END_TIME
                ],
            });
            console.log("✅ 合约验证成功");
        } catch (error) {
            console.log("⚠️  合约验证失败:", error.message);
            console.log("可以稍后手动验证:");
            console.log(`npx hardhat verify --network ${hre.network.name} ${airdrop.address} ${SUK_TOKEN_ADDRESS} ${WHITELIST_START} ${PUBLIC_START} ${END_TIME}`);
        }
    }
    
    // ========== 后续操作指南 ==========
    
    console.log("\n" + "=".repeat(60));
    console.log("✅ 部署完成！");
    console.log("=".repeat(60));
    
    console.log("\n📝 后续操作清单:");
    console.log("-".repeat(60));
    
    console.log("\n1️⃣  转移SUK代币到空投合约");
    console.log("   数量: 1,000,000 SUK");
    console.log("   目标地址:", airdrop.address);
    console.log("   \n   使用以下命令:");
    console.log(`   npx hardhat run scripts/fund-airdrop.js --network ${hre.network.name}`);
    
    console.log("\n2️⃣  添加白名单地址");
    console.log("   准备白名单CSV文件: whitelist.csv");
    console.log("   \n   使用以下命令:");
    console.log(`   npx hardhat run scripts/import-whitelist.js --network ${hre.network.name}`);
    
    console.log("\n3️⃣  更新前端配置");
    console.log("   编辑 suk-airdrop.html");
    console.log("   更新以下变量:");
    console.log(`   AIRDROP_CONTRACT_ADDRESS = "${airdrop.address}"`);
    console.log(`   SUK_TOKEN_ADDRESS = "${SUK_TOKEN_ADDRESS}"`);
    
    console.log("\n4️⃣  测试空投功能");
    console.log("   - 测试白名单认领");
    console.log("   - 测试公开认领");
    console.log("   - 测试防重复认领");
    
    console.log("\n5️⃣  启动监控");
    console.log(`   npx hardhat run scripts/monitor-airdrop.js --network ${hre.network.name}`);
    
    console.log("\n" + "=".repeat(60));
    console.log("📚 完整文档: SUK_AIRDROP_GUIDE.md");
    console.log("=".repeat(60) + "\n");
    
    return airdrop.address;
}

// 执行部署
main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error("\n❌ 部署失败:", error);
        process.exit(1);
    });
