const hre = require("hardhat");
const fs = require('fs');
const { parse } = require('csv-parse/sync');

/**
 * 白名单导入脚本
 * 
 * 功能:
 * 1. 从CSV文件读取地址
 * 2. 验证地址格式
 * 3. 批量添加到合约
 * 4. 生成导入报告
 */

async function main() {
    console.log("=".repeat(60));
    console.log("SUK空投 - 白名单导入");
    console.log("=".repeat(60));
    
    // ========== 配置 ==========
    
    const AIRDROP_ADDRESS = process.env.AIRDROP_ADDRESS || "0x...";
    const CSV_FILE = process.env.CSV_FILE || "whitelist.csv";
    const BATCH_SIZE = parseInt(process.env.BATCH_SIZE || "50");
    const DRY_RUN = process.env.DRY_RUN === "true";
    
    if (AIRDROP_ADDRESS === "0x...") {
        console.error("❌ 错误: 请设置 AIRDROP_ADDRESS 环境变量");
        console.log("\n使用方法:");
        console.log("export AIRDROP_ADDRESS=0x...");
        console.log("npx hardhat run scripts/import-whitelist.js --network goerli");
        process.exit(1);
    }
    
    console.log("\n📋 配置:");
    console.log("-".repeat(60));
    console.log("合约地址:", AIRDROP_ADDRESS);
    console.log("CSV文件:", CSV_FILE);
    console.log("批次大小:", BATCH_SIZE);
    console.log("模拟运行:", DRY_RUN ? "是" : "否");
    console.log("网络:", hre.network.name);
    
    // ========== 读取CSV ==========
    
    if (!fs.existsSync(CSV_FILE)) {
        console.error(`\n❌ 错误: 找不到文件 ${CSV_FILE}`);
        console.log("\n请创建 whitelist.csv 文件，格式如下:");
        console.log("address,note");
        console.log("0x1234567890123456789012345678901234567890,First adopter");
        console.log("0xabcdefabcdefabcdefabcdefabcdefabcdefabcd,Early investor");
        process.exit(1);
    }
    
    console.log("\n📖 读取CSV文件...");
    
    const csvData = fs.readFileSync(CSV_FILE, 'utf8');
    const records = parse(csvData, {
        columns: true,
        skip_empty_lines: true,
        trim: true
    });
    
    console.log(`找到 ${records.length} 条记录`);
    
    // ========== 验证地址 ==========
    
    console.log("\n✅ 验证地址格式...");
    
    const validAddresses = [];
    const invalidAddresses = [];
    const duplicates = new Set();
    const seen = new Set();
    
    for (const record of records) {
        const address = record.address;
        
        if (!address) {
            invalidAddresses.push({ address: 'empty', reason: '空地址' });
            continue;
        }
        
        // 检查格式
        if (!hre.ethers.utils.isAddress(address)) {
            invalidAddresses.push({ address, reason: '格式无效' });
            continue;
        }
        
        // 检查重复
        const checksumAddress = hre.ethers.utils.getAddress(address);
        if (seen.has(checksumAddress)) {
            duplicates.add(checksumAddress);
            continue;
        }
        
        seen.add(checksumAddress);
        validAddresses.push({
            address: checksumAddress,
            note: record.note || ''
        });
    }
    
    console.log("验证结果:");
    console.log("  有效地址:", validAddresses.length);
    console.log("  无效地址:", invalidAddresses.length);
    console.log("  重复地址:", duplicates.size);
    
    if (invalidAddresses.length > 0) {
        console.log("\n⚠️  无效地址列表:");
        invalidAddresses.forEach(({ address, reason }) => {
            console.log(`  - ${address}: ${reason}`);
        });
    }
    
    if (duplicates.size > 0) {
        console.log("\n⚠️  重复地址列表:");
        duplicates.forEach(address => {
            console.log(`  - ${address}`);
        });
    }
    
    if (validAddresses.length === 0) {
        console.error("\n❌ 没有有效地址可导入");
        process.exit(1);
    }
    
    // ========== 连接合约 ==========
    
    console.log("\n🔗 连接空投合约...");
    
    const airdrop = await hre.ethers.getContractAt("SUKAirdrop", AIRDROP_ADDRESS);
    const [signer] = await hre.ethers.getSigners();
    
    console.log("签名者:", signer.address);
    
    // 检查权限
    const owner = await airdrop.owner();
    if (owner !== signer.address) {
        console.error(`\n❌ 错误: 您不是合约所有者`);
        console.log(`合约所有者: ${owner}`);
        console.log(`当前账户: ${signer.address}`);
        process.exit(1);
    }
    
    // ========== 检查已存在的白名单 ==========
    
    console.log("\n🔍 检查已存在的白名单...");
    
    const toAdd = [];
    const alreadyWhitelisted = [];
    
    for (const { address, note } of validAddresses) {
        const isWhitelisted = await airdrop.isWhitelisted(address);
        if (isWhitelisted) {
            alreadyWhitelisted.push(address);
        } else {
            toAdd.push(address);
        }
    }
    
    console.log("  已在白名单:", alreadyWhitelisted.length);
    console.log("  需要添加:", toAdd.length);
    
    if (toAdd.length === 0) {
        console.log("\n✅ 所有地址都已在白名单中");
        return;
    }
    
    // ========== 批量添加 ==========
    
    if (DRY_RUN) {
        console.log("\n🧪 模拟运行模式 - 不会实际添加");
        console.log(`将添加 ${toAdd.length} 个地址，分 ${Math.ceil(toAdd.length / BATCH_SIZE)} 批`);
        return;
    }
    
    console.log("\n📤 开始批量添加...");
    console.log(`总数: ${toAdd.length} 个地址`);
    console.log(`批次: ${Math.ceil(toAdd.length / BATCH_SIZE)}`);
    console.log(`每批: ${BATCH_SIZE} 个地址`);
    
    const results = [];
    
    for (let i = 0; i < toAdd.length; i += BATCH_SIZE) {
        const batch = toAdd.slice(i, i + BATCH_SIZE);
        const batchNum = Math.floor(i / BATCH_SIZE) + 1;
        const totalBatches = Math.ceil(toAdd.length / BATCH_SIZE);
        
        console.log(`\n批次 ${batchNum}/${totalBatches} (${batch.length} 个地址)...`);
        
        try {
            const tx = await airdrop.addToWhitelist(batch);
            console.log("  交易哈希:", tx.hash);
            
            const receipt = await tx.wait();
            console.log("  ✅ 确认 (Gas:", receipt.gasUsed.toString(), ")");
            
            results.push({
                batchNum,
                addresses: batch.length,
                txHash: tx.hash,
                gasUsed: receipt.gasUsed.toString(),
                success: true
            });
            
        } catch (error) {
            console.error("  ❌ 失败:", error.message);
            results.push({
                batchNum,
                addresses: batch.length,
                error: error.message,
                success: false
            });
        }
    }
    
    // ========== 生成报告 ==========
    
    console.log("\n" + "=".repeat(60));
    console.log("📊 导入报告");
    console.log("=".repeat(60));
    
    const successBatches = results.filter(r => r.success).length;
    const failedBatches = results.filter(r => !r.success).length;
    const totalGas = results
        .filter(r => r.success)
        .reduce((sum, r) => sum + parseInt(r.gasUsed), 0);
    
    console.log("\n总结:");
    console.log("  成功批次:", successBatches);
    console.log("  失败批次:", failedBatches);
    console.log("  总Gas消耗:", totalGas.toLocaleString());
    
    if (failedBatches > 0) {
        console.log("\n⚠️  失败的批次:");
        results.filter(r => !r.success).forEach(r => {
            console.log(`  批次 ${r.batchNum}: ${r.error}`);
        });
    }
    
    // 保存报告
    const report = {
        timestamp: new Date().toISOString(),
        network: hre.network.name,
        contract: AIRDROP_ADDRESS,
        totalAddresses: toAdd.length,
        successBatches,
        failedBatches,
        totalGas,
        batches: results
    };
    
    const reportFile = `whitelist-import-${Date.now()}.json`;
    fs.writeFileSync(reportFile, JSON.stringify(report, null, 2));
    console.log("\n💾 报告已保存:", reportFile);
    
    console.log("\n✅ 导入完成！");
    console.log("=".repeat(60) + "\n");
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error("\n❌ 导入失败:", error);
        process.exit(1);
    });
