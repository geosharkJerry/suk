/**
 * 前端配置更新脚本
 * 
 * 用途：部署智能合约后，自动更新前端配置文件中的合约地址
 * 
 * 使用方法：
 * node scripts/update-frontend-config.js <network> <tokenAddress> <airdropAddress>
 * 
 * 示例：
 * node scripts/update-frontend-config.js goerli 0x1234... 0x5678...
 */

const fs = require('fs');
const path = require('path');

// 获取命令行参数
const args = process.argv.slice(2);

if (args.length < 3) {
    console.error('❌ 参数不足！');
    console.log('\n使用方法:');
    console.log('node scripts/update-frontend-config.js <network> <tokenAddress> <airdropAddress>');
    console.log('\n示例:');
    console.log('node scripts/update-frontend-config.js goerli 0x1234... 0x5678...');
    process.exit(1);
}

const [network, tokenAddress, airdropAddress] = args;

// 验证网络
const validNetworks = ['goerli', 'sepolia', 'mainnet', 'polygon', 'bsc'];
if (!validNetworks.includes(network)) {
    console.error(`❌ 不支持的网络: ${network}`);
    console.log(`支持的网络: ${validNetworks.join(', ')}`);
    process.exit(1);
}

// 验证地址格式
const addressRegex = /^0x[a-fA-F0-9]{40}$/;
if (!addressRegex.test(tokenAddress)) {
    console.error(`❌ SUKToken 地址格式不正确: ${tokenAddress}`);
    process.exit(1);
}
if (!addressRegex.test(airdropAddress)) {
    console.error(`❌ SUKAirdrop 地址格式不正确: ${airdropAddress}`);
    process.exit(1);
}

console.log('\n📝 准备更新前端配置...\n');
console.log(`网络: ${network}`);
console.log(`SUKToken: ${tokenAddress}`);
console.log(`SUKAirdrop: ${airdropAddress}`);
console.log('');

// 读取配置文件
const configPath = path.join(__dirname, '../js/contract-config.js');
let configContent = fs.readFileSync(configPath, 'utf8');

// 查找并替换对应网络的合约地址
const networkSection = new RegExp(
    `(${network}:\\s*{[\\s\\S]*?contracts:\\s*{\\s*SUKToken:\\s*)'0x[a-fA-F0-9]{40}'([\\s\\S]*?SUKAirdrop:\\s*)'0x[a-fA-F0-9]{40}'`,
    'g'
);

const newConfig = configContent.replace(
    networkSection,
    `$1'${tokenAddress}'$2'${airdropAddress}'`
);

if (newConfig === configContent) {
    console.error('❌ 更新失败: 未找到对应网络配置');
    process.exit(1);
}

// 写入文件
fs.writeFileSync(configPath, newConfig, 'utf8');

console.log('✅ 配置文件已更新: js/contract-config.js');

// 创建部署记录
const deploymentRecord = {
    network,
    timestamp: new Date().toISOString(),
    contracts: {
        SUKToken: tokenAddress,
        SUKAirdrop: airdropAddress
    }
};

const recordPath = path.join(__dirname, '../deployment', `frontend-config-${network}-${Date.now()}.json`);

// 确保 deployment 目录存在
const deploymentDir = path.join(__dirname, '../deployment');
if (!fs.existsSync(deploymentDir)) {
    fs.mkdirSync(deploymentDir, { recursive: true });
}

fs.writeFileSync(recordPath, JSON.stringify(deploymentRecord, null, 2));

console.log(`✅ 部署记录已保存: ${recordPath.replace(__dirname + '/../', '')}`);

// 生成更新摘要
console.log('\n📊 更新摘要:\n');
console.log('┌─────────────────────────────────────────────────────────────────┐');
console.log('│ 前端配置已更新                                                 │');
console.log('├─────────────────────────────────────────────────────────────────┤');
console.log(`│ 网络:          ${network.padEnd(48)} │`);
console.log(`│ SUKToken:      ${tokenAddress.slice(0, 10)}...${tokenAddress.slice(-6).padEnd(31)} │`);
console.log(`│ SUKAirdrop:    ${airdropAddress.slice(0, 10)}...${airdropAddress.slice(-6).padEnd(31)} │`);
console.log('└─────────────────────────────────────────────────────────────────┘');

console.log('\n🎯 下一步操作:\n');
console.log('1. 打开浏览器访问: contract-config-test.html');
console.log('2. 点击"连接 MetaMask"按钮');
console.log('3. 点击"全面测试"验证配置');
console.log('4. 如果测试通过，即可在生产环境使用\n');

// 生成区块浏览器链接
const explorerUrls = {
    goerli: 'https://goerli.etherscan.io',
    sepolia: 'https://sepolia.etherscan.io',
    mainnet: 'https://etherscan.io',
    polygon: 'https://polygonscan.com',
    bsc: 'https://bscscan.com'
};

const explorerUrl = explorerUrls[network];
console.log('🔍 区块浏览器链接:\n');
console.log(`SUKToken:   ${explorerUrl}/address/${tokenAddress}`);
console.log(`SUKAirdrop: ${explorerUrl}/address/${airdropAddress}`);
console.log('');

process.exit(0);
