const hre = require("hardhat");
const fs = require('fs');

/**
 * 部署SUK代币合约
 * 
 * 步骤:
 * 1. 部署SUKToken合约
 * 2. 验证部署
 * 3. 保存部署信息
 * 4. 输出后续操作指南
 */

async function main() {
    console.log("=".repeat(80));
    console.log("SUK代币合约部署");
    console.log("=".repeat(80));
    
    // ========== 获取部署账户 ==========
    
    const [deployer] = await hre.ethers.getSigners();
    const balance = await deployer.getBalance();
    
    console.log("\n📋 部署配置:");
    console.log("-".repeat(80));
    console.log("网络:", hre.network.name);
    console.log("Chain ID:", (await hre.ethers.provider.getNetwork()).chainId);
    console.log("部署者地址:", deployer.address);
    console.log("部署者余额:", hre.ethers.utils.formatEther(balance), "ETH");
    
    // 检查余额
    const minimumBalance = hre.ethers.utils.parseEther("0.1");
    if (balance.lt(minimumBalance)) {
        console.error("\n❌ 错误: 余额不足");
        console.log("需要至少 0.1 ETH 用于部署");
        process.exit(1);
    }
    
    // 主网部署需要确认
    if (hre.network.name === 'mainnet') {
        console.log("\n⚠️  警告: 您正在主网部署!");
        console.log("这将消耗真实的ETH");
        console.log("请确保已经充分测试");
        // 生产环境需要手动确认
    }
    
    // ========== 部署SUK代币 ==========
    
    console.log("\n🚀 开始部署 SUK代币合约...");
    console.log("-".repeat(80));
    
    const SUKToken = await hre.ethers.getContractFactory("SUKToken");
    
    console.log("部署中...");
    const sukToken = await SUKToken.deploy(deployer.address);
    
    await sukToken.deployed();
    
    console.log("✅ SUKToken 已部署!");
    console.log("合约地址:", sukToken.address);
    console.log("交易哈希:", sukToken.deployTransaction.hash);
    
    // 等待确认
    console.log("\n⏳ 等待区块确认...");
    await sukToken.deployTransaction.wait(3); // 等待3个区块
    console.log("✅ 已确认");
    
    // ========== 验证部署 ==========
    
    console.log("\n🔍 验证部署...");
    console.log("-".repeat(80));
    
    const tokenInfo = await sukToken.getTokenInfo();
    const totalSupply = await sukToken.totalSupply();
    const deployerBalance = await sukToken.balanceOf(deployer.address);
    
    console.log("代币名称:", tokenInfo.name_);
    console.log("代币符号:", tokenInfo.symbol_);
    console.log("小数位数:", tokenInfo.decimals_);
    console.log("总供应量:", hre.ethers.utils.formatEther(totalSupply), "SUK");
    console.log("部署者持有:", hre.ethers.utils.formatEther(deployerBalance), "SUK");
    
    // 验证总量
    const expectedSupply = hre.ethers.utils.parseEther("1000000000"); // 10亿
    if (!totalSupply.eq(expectedSupply)) {
        console.error("\n❌ 错误: 总供应量不正确!");
        console.log("预期:", hre.ethers.utils.formatEther(expectedSupply));
        console.log("实际:", hre.ethers.utils.formatEther(totalSupply));
        process.exit(1);
    }
    
    console.log("\n✅ 部署验证通过");
    
    // ========== 保存部署信息 ==========
    
    const deploymentInfo = {
        network: hre.network.name,
        chainId: (await hre.ethers.provider.getNetwork()).chainId,
        tokenAddress: sukToken.address,
        tokenName: tokenInfo.name_,
        tokenSymbol: tokenInfo.symbol_,
        decimals: tokenInfo.decimals_,
        totalSupply: hre.ethers.utils.formatEther(totalSupply),
        deployer: deployer.address,
        deployerBalance: hre.ethers.utils.formatEther(deployerBalance),
        transactionHash: sukToken.deployTransaction.hash,
        blockNumber: sukToken.deployTransaction.blockNumber,
        deployedAt: new Date().toISOString(),
        
        // 代币分配信息
        allocations: {
            airdrop: hre.ethers.utils.formatEther(await sukToken.AIRDROP_ALLOCATION()),
            ecosystem: hre.ethers.utils.formatEther(await sukToken.ECOSYSTEM_ALLOCATION()),
            team: hre.ethers.utils.formatEther(await sukToken.TEAM_ALLOCATION()),
            investor: hre.ethers.utils.formatEther(await sukToken.INVESTOR_ALLOCATION()),
            liquidity: hre.ethers.utils.formatEther(await sukToken.LIQUIDITY_ALLOCATION()),
            reserve: hre.ethers.utils.formatEther(await sukToken.RESERVE_ALLOCATION())
        }
    };
    
    // 创建deployment目录
    if (!fs.existsSync('./deployment')) {
        fs.mkdirSync('./deployment');
    }
    
    const filename = `deployment/suk-token-${hre.network.name}-${Date.now()}.json`;
    fs.writeFileSync(filename, JSON.stringify(deploymentInfo, null, 2));
    
    console.log("\n💾 部署信息已保存:", filename);
    
    // ========== Etherscan验证 ==========
    
    if (hre.network.name !== 'hardhat' && hre.network.name !== 'localhost') {
        console.log("\n🔍 Etherscan合约验证...");
        console.log("-".repeat(80));
        
        console.log("等待 30 秒后开始验证...");
        await new Promise(resolve => setTimeout(resolve, 30000));
        
        try {
            await hre.run("verify:verify", {
                address: sukToken.address,
                constructorArguments: [deployer.address]
            });
            console.log("✅ 合约验证成功");
        } catch (error) {
            console.log("⚠️  合约验证失败:", error.message);
            console.log("\n可以稍后手动验证:");
            console.log(`npx hardhat verify --network ${hre.network.name} ${sukToken.address} ${deployer.address}`);
        }
    }
    
    // ========== 后续操作指南 ==========
    
    console.log("\n" + "=".repeat(80));
    console.log("✅ SUK代币部署完成!");
    console.log("=".repeat(80));
    
    console.log("\n📝 重要信息:");
    console.log("-".repeat(80));
    console.log("SUK代币地址:", sukToken.address);
    console.log("总供应量:", hre.ethers.utils.formatEther(totalSupply), "SUK");
    console.log("您的持有量:", hre.ethers.utils.formatEther(deployerBalance), "SUK");
    
    console.log("\n📋 代币分配计划:");
    console.log("-".repeat(80));
    console.log("空投:", deploymentInfo.allocations.airdrop, "SUK (0.1%)");
    console.log("生态:", deploymentInfo.allocations.ecosystem, "SUK (30%)");
    console.log("团队:", deploymentInfo.allocations.team, "SUK (15%)");
    console.log("投资者:", deploymentInfo.allocations.investor, "SUK (20%)");
    console.log("流动性:", deploymentInfo.allocations.liquidity, "SUK (10%)");
    console.log("储备:", deploymentInfo.allocations.reserve, "SUK (24.8%)");
    
    console.log("\n📝 后续步骤:");
    console.log("-".repeat(80));
    
    console.log("\n1️⃣  添加代币到MetaMask");
    console.log("   代币地址:", sukToken.address);
    console.log("   符号: SUK");
    console.log("   小数位: 18");
    
    console.log("\n2️⃣  转移空投代币");
    console.log("   数量: 1,000,000 SUK");
    console.log("   目标: 空投合约地址 (部署后获得)");
    console.log("   \n   使用以下环境变量:");
    console.log(`   export SUK_TOKEN_ADDRESS=${sukToken.address}`);
    
    console.log("\n3️⃣  部署空投合约");
    console.log(`   npx hardhat run scripts/2-deploy-airdrop.js --network ${hre.network.name}`);
    
    console.log("\n4️⃣  配置前端");
    console.log("   更新 suk-airdrop.html:");
    console.log(`   SUK_TOKEN_ADDRESS = "${sukToken.address}"`);
    
    console.log("\n" + "=".repeat(80));
    console.log("📚 完整文档: SUK_AIRDROP_GUIDE.md");
    console.log("=".repeat(80) + "\n");
    
    // 返回部署地址
    return {
        sukToken: sukToken.address,
        deployer: deployer.address
    };
}

// 执行部署
main()
    .then((addresses) => {
        console.log("\n✅ 部署成功!");
        console.log("SUK代币:", addresses.sukToken);
        process.exit(0);
    })
    .catch((error) => {
        console.error("\n❌ 部署失败:", error);
        process.exit(1);
    });
