/**
 * 邀请码生成脚本
 * 
 * 功能：
 * 1. 生成指定数量的唯一邀请码
 * 2. 保存到 CSV 文件
 * 3. 部署到智能合约
 * 
 * 使用方法：
 * node scripts/generate-invite-codes.js <数量> [--network <network>] [--deploy]
 * 
 * 示例：
 * node scripts/generate-invite-codes.js 1000                 # 生成1000个邀请码
 * node scripts/generate-invite-codes.js 1000 --network goerli --deploy  # 生成并部署
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const hre = require('hardhat');

// 邀请码配置
const CODE_LENGTH = 12;  // 邀请码长度
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';  // 排除易混淆字符
const BATCH_SIZE = 50;  // 批量部署每批数量

/**
 * 生成随机邀请码
 * @returns {string} 邀请码
 */
function generateCode() {
    let code = '';
    const randomBytes = crypto.randomBytes(CODE_LENGTH);
    
    for (let i = 0; i < CODE_LENGTH; i++) {
        const index = randomBytes[i] % CODE_CHARS.length;
        code += CODE_CHARS[index];
    }
    
    return code;
}

/**
 * 生成唯一邀请码集合
 * @param {number} count 数量
 * @returns {string[]} 邀请码数组
 */
function generateUniqueCodes(count) {
    const codes = new Set();
    let attempts = 0;
    const maxAttempts = count * 10;  // 防止无限循环
    
    console.log(`\n🎲 开始生成 ${count} 个邀请码...`);
    
    while (codes.size < count && attempts < maxAttempts) {
        const code = generateCode();
        codes.add(code);
        attempts++;
        
        if (codes.size % 100 === 0) {
            process.stdout.write(`\r生成进度: ${codes.size}/${count}`);
        }
    }
    
    console.log(`\r✅ 生成完成: ${codes.size}/${count} 个邀请码\n`);
    
    if (codes.size < count) {
        console.warn(`⚠️  警告: 仅生成了 ${codes.size} 个唯一邀请码（尝试了 ${attempts} 次）`);
    }
    
    return Array.from(codes);
}

/**
 * 保存邀请码到 CSV 文件
 * @param {string[]} codes 邀请码数组
 * @param {string} filename 文件名
 */
function saveToCSV(codes, filename) {
    const dir = path.join(__dirname, '../deployment/invite-codes');
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    
    const filepath = path.join(dir, filename);
    
    // CSV 头部
    let csv = 'invite_code,generated_at,status,activated_by,activated_at\n';
    
    // 添加数据行
    const timestamp = new Date().toISOString();
    codes.forEach(code => {
        csv += `${code},${timestamp},pending,,\n`;
    });
    
    fs.writeFileSync(filepath, csv);
    console.log(`💾 邀请码已保存到: ${filepath}`);
    
    return filepath;
}

/**
 * 保存邀请码到 JSON 文件（备份）
 * @param {string[]} codes 邀请码数组
 * @param {string} filename 文件名
 */
function saveToJSON(codes, filename) {
    const dir = path.join(__dirname, '../deployment/invite-codes');
    const filepath = path.join(dir, filename);
    
    const data = {
        total: codes.length,
        generatedAt: new Date().toISOString(),
        codes: codes.map(code => ({
            code,
            status: 'pending',
            activatedBy: null,
            activatedAt: null
        }))
    };
    
    fs.writeFileSync(filepath, JSON.stringify(data, null, 2));
    console.log(`💾 备份已保存到: ${filepath}`);
    
    return filepath;
}

/**
 * 部署邀请码到智能合约
 * @param {string[]} codes 邀请码数组
 * @param {string} network 网络名称
 */
async function deployToContract(codes, network) {
    console.log(`\n📤 开始部署邀请码到合约 (${network})...`);
    
    // 获取合约地址
    const deploymentFiles = fs.readdirSync(path.join(__dirname, '../deployment'))
        .filter(f => f.includes('airdrop-v2') && f.includes(network) && f.endsWith('.json'))
        .sort()
        .reverse();
    
    if (deploymentFiles.length === 0) {
        throw new Error(`❌ 未找到 ${network} 上的 AirdropV2 部署记录`);
    }
    
    const deploymentFile = deploymentFiles[0];
    const deployment = JSON.parse(
        fs.readFileSync(path.join(__dirname, '../deployment', deploymentFile))
    );
    
    const contractAddress = deployment.airdropAddress;
    console.log(`📍 合约地址: ${contractAddress}`);
    
    // 连接合约
    const [deployer] = await hre.ethers.getSigners();
    console.log(`👤 部署者: ${deployer.address}`);
    
    const SUKAirdropV2 = await hre.ethers.getContractAt('SUKAirdropV2', contractAddress);
    
    // 批量部署
    const totalBatches = Math.ceil(codes.length / BATCH_SIZE);
    let successCount = 0;
    let failCount = 0;
    
    for (let i = 0; i < codes.length; i += BATCH_SIZE) {
        const batch = codes.slice(i, Math.min(i + BATCH_SIZE, codes.length));
        const batchNum = Math.floor(i / BATCH_SIZE) + 1;
        
        try {
            console.log(`\n📦 批次 ${batchNum}/${totalBatches}: 部署 ${batch.length} 个邀请码...`);
            
            const tx = await SUKAirdropV2.batchGenerateInviteCodes(batch);
            console.log(`   交易哈希: ${tx.hash}`);
            
            const receipt = await tx.wait();
            console.log(`   ✅ Gas 使用: ${receipt.gasUsed.toString()}`);
            
            successCount += batch.length;
            
            // 避免请求过快
            if (i + BATCH_SIZE < codes.length) {
                await new Promise(resolve => setTimeout(resolve, 2000));
            }
            
        } catch (error) {
            console.error(`   ❌ 批次 ${batchNum} 失败:`, error.message);
            failCount += batch.length;
        }
    }
    
    console.log(`\n📊 部署统计:`);
    console.log(`   ✅ 成功: ${successCount} 个`);
    console.log(`   ❌ 失败: ${failCount} 个`);
    console.log(`   📈 成功率: ${(successCount / codes.length * 100).toFixed(2)}%`);
}

/**
 * 主函数
 */
async function main() {
    const args = process.argv.slice(2);
    
    // 解析参数
    let count = 1000;  // 默认生成1000个
    let network = 'goerli';  // 默认网络
    let shouldDeploy = false;
    
    for (let i = 0; i < args.length; i++) {
        if (args[i] === '--network' && i + 1 < args.length) {
            network = args[i + 1];
            i++;
        } else if (args[i] === '--deploy') {
            shouldDeploy = true;
        } else if (!isNaN(args[i])) {
            count = parseInt(args[i]);
        }
    }
    
    console.log('\n' + '='.repeat(60));
    console.log('🎫  SUK 邀请码生成器');
    console.log('='.repeat(60));
    console.log(`📊 配置信息:`);
    console.log(`   - 生成数量: ${count}`);
    console.log(`   - 邀请码长度: ${CODE_LENGTH}`);
    console.log(`   - 网络: ${network}`);
    console.log(`   - 是否部署: ${shouldDeploy ? '是' : '否'}`);
    console.log('='.repeat(60));
    
    try {
        // 1. 生成邀请码
        const codes = generateUniqueCodes(count);
        
        // 2. 保存到文件
        const timestamp = Date.now();
        const csvFile = `invite-codes-${network}-${timestamp}.csv`;
        const jsonFile = `invite-codes-${network}-${timestamp}.json`;
        
        const csvPath = saveToCSV(codes, csvFile);
        const jsonPath = saveToJSON(codes, jsonFile);
        
        // 3. 显示示例
        console.log(`\n📝 邀请码示例 (前10个):`);
        codes.slice(0, 10).forEach((code, index) => {
            console.log(`   ${(index + 1).toString().padStart(2, '0')}. ${code}`);
        });
        
        // 4. 部署到合约（如果需要）
        if (shouldDeploy) {
            await deployToContract(codes, network);
        } else {
            console.log(`\n💡 提示: 使用 --deploy 参数可以将邀请码部署到合约`);
            console.log(`   示例: node scripts/generate-invite-codes.js ${count} --network ${network} --deploy`);
        }
        
        // 5. 总结
        console.log(`\n${'='.repeat(60)}`);
        console.log('✅ 邀请码生成完成！');
        console.log(`${'='.repeat(60)}`);
        console.log(`📁 文件位置:`);
        console.log(`   CSV: ${csvPath}`);
        console.log(`   JSON: ${jsonPath}`);
        console.log(`\n🎯 下一步:`);
        if (!shouldDeploy) {
            console.log(`   1. 部署邀请码到合约:`);
            console.log(`      node scripts/deploy-invite-codes.js ${csvPath} --network ${network}`);
        }
        console.log(`   2. 分发邀请码给用户`);
        console.log(`   3. 用户使用邀请码激活空投资格`);
        console.log('');
        
    } catch (error) {
        console.error('\n❌ 错误:', error.message);
        console.error(error);
        process.exit(1);
    }
}

// 执行主函数
if (require.main === module) {
    main()
        .then(() => process.exit(0))
        .catch((error) => {
            console.error(error);
            process.exit(1);
        });
}

module.exports = {
    generateCode,
    generateUniqueCodes,
    saveToCSV,
    saveToJSON
};
