/**
 * 向 SUKAirdropV2 合约转账脚本
 * 
 * 功能：转账 5000万 SUK 到空投合约
 * 
 * 使用方法：
 * npx hardhat run scripts/fund-airdrop-v2.js --network goerli
 */

const hre = require('hardhat');
const fs = require('fs');
const path = require('path');

async function main() {
    console.log('\n' + '='.repeat(70));
    console.log('💰 向 SUKAirdropV2 合约转账');
    console.log('='.repeat(70) + '\n');
    
    const [deployer] = await hre.ethers.getSigners();
    const network = hre.network.name;
    
    console.log('📊 账户信息:');
    console.log(`   网络: ${network}`);
    console.log(`   地址: ${deployer.address}`);
    console.log('');
    
    // ========================================
    // 第一步：获取合约地址
    // ========================================
    
    console.log('📍 第一步: 查找部署信息...');
    
    const deploymentDir = path.join(__dirname, '../deployment');
    
    // 查找 Token 地址
    const tokenFiles = fs.readdirSync(deploymentDir)
        .filter(f => f.includes('suk-token') && f.includes(network) && f.endsWith('.json'))
        .sort()
        .reverse();
    
    if (tokenFiles.length === 0) {
        throw new Error(`❌ 未找到 ${network} 上的 SUKToken 部署记录`);
    }
    
    const tokenDeployment = JSON.parse(
        fs.readFileSync(path.join(deploymentDir, tokenFiles[0]))
    );
    const SUK_TOKEN_ADDRESS = tokenDeployment.tokenAddress;
    
    // 查找 Airdrop V2 地址
    const airdropFiles = fs.readdirSync(deploymentDir)
        .filter(f => f.includes('airdrop-v2') && f.includes(network) && f.endsWith('.json'))
        .sort()
        .reverse();
    
    if (airdropFiles.length === 0) {
        throw new Error(`❌ 未找到 ${network} 上的 SUKAirdropV2 部署记录`);
    }
    
    const airdropDeployment = JSON.parse(
        fs.readFileSync(path.join(deploymentDir, airdropFiles[0]))
    );
    const AIRDROP_ADDRESS = airdropDeployment.airdropAddress;
    
    console.log(`   ✅ SUKToken: ${SUK_TOKEN_ADDRESS}`);
    console.log(`   ✅ SUKAirdropV2: ${AIRDROP_ADDRESS}`);
    console.log('');
    
    // ========================================
    // 第二步：连接合约
    // ========================================
    
    console.log('🔗 第二步: 连接合约...');
    
    const sukToken = await hre.ethers.getContractAt('SUKToken', SUK_TOKEN_ADDRESS);
    const airdrop = await hre.ethers.getContractAt('SUKAirdropV2', AIRDROP_ADDRESS);
    
    console.log('   ✅ 合约已连接');
    console.log('');
    
    // ========================================
    // 第三步：检查余额
    // ========================================
    
    console.log('💰 第三步: 检查余额...');
    
    const deployerBalance = await sukToken.balanceOf(deployer.address);
    const airdropBalance = await sukToken.balanceOf(AIRDROP_ADDRESS);
    const totalAirdropAmount = await airdrop.TOTAL_AIRDROP_AMOUNT();
    
    console.log(`   部署者余额: ${hre.ethers.utils.formatEther(deployerBalance)} SUK`);
    console.log(`   空投合约当前余额: ${hre.ethers.utils.formatEther(airdropBalance)} SUK`);
    console.log(`   需要转账: ${hre.ethers.utils.formatEther(totalAirdropAmount)} SUK`);
    
    // 计算还需要转账的数量
    const remainingAmount = totalAirdropAmount.sub(airdropBalance);
    
    if (remainingAmount.lte(0)) {
        console.log('   ✅ 空投合约余额充足，无需转账');
        console.log('');
        return;
    }
    
    console.log(`   📤 实际需要转账: ${hre.ethers.utils.formatEther(remainingAmount)} SUK`);
    
    // 检查部署者余额是否足够
    if (deployerBalance.lt(remainingAmount)) {
        throw new Error(`❌ 余额不足! 需要 ${hre.ethers.utils.formatEther(remainingAmount)} SUK，但只有 ${hre.ethers.utils.formatEther(deployerBalance)} SUK`);
    }
    
    console.log('   ✅ 余额检查通过');
    console.log('');
    
    // ========================================
    // 第四步：执行转账
    // ========================================
    
    console.log('📤 第四步: 执行转账...');
    console.log('   请稍候，正在发送交易...\n');
    
    const tx = await sukToken.transfer(AIRDROP_ADDRESS, remainingAmount);
    
    console.log(`   📝 交易已提交: ${tx.hash}`);
    console.log('   ⏳ 等待确认...');
    
    const receipt = await tx.wait();
    
    console.log(`   ✅ 交易已确认!`);
    console.log(`   📦 区块号: ${receipt.blockNumber}`);
    console.log(`   ⛽ Gas 使用: ${receipt.gasUsed.toString()}`);
    console.log('');
    
    // ========================================
    // 第五步：验证转账
    // ========================================
    
    console.log('🔍 第五步: 验证转账...');
    
    const newDeployerBalance = await sukToken.balanceOf(deployer.address);
    const newAirdropBalance = await sukToken.balanceOf(AIRDROP_ADDRESS);
    
    console.log(`   部署者新余额: ${hre.ethers.utils.formatEther(newDeployerBalance)} SUK`);
    console.log(`   空投合约新余额: ${hre.ethers.utils.formatEther(newAirdropBalance)} SUK`);
    
    if (!newAirdropBalance.eq(totalAirdropAmount)) {
        throw new Error('❌ 空投合约余额不正确!');
    }
    
    console.log('   ✅ 转账验证通过!');
    console.log('');
    
    // ========================================
    // 第六步：保存记录
    // ========================================
    
    console.log('💾 第六步: 保存记录...');
    
    const fundingInfo = {
        network: network,
        tokenAddress: SUK_TOKEN_ADDRESS,
        airdropAddress: AIRDROP_ADDRESS,
        amount: hre.ethers.utils.formatEther(remainingAmount),
        transactionHash: tx.hash,
        blockNumber: receipt.blockNumber,
        gasUsed: receipt.gasUsed.toString(),
        timestamp: new Date().toISOString(),
        deployer: deployer.address
    };
    
    const filename = `airdrop-v2-funding-${network}-${Date.now()}.json`;
    const filepath = path.join(deploymentDir, filename);
    
    fs.writeFileSync(filepath, JSON.stringify(fundingInfo, null, 2));
    
    console.log(`   ✅ 记录已保存: ${filename}`);
    console.log('');
    
    // ========================================
    // 第七步：总结
    // ========================================
    
    console.log('='.repeat(70));
    console.log('✅ 转账成功!');
    console.log('='.repeat(70));
    console.log('');
    console.log('📋 转账摘要:');
    console.log('┌─────────────────────────────────────────────────────────────────┐');
    console.log(`│ 转账金额:    ${hre.ethers.utils.formatEther(remainingAmount).padEnd(50)} │`);
    console.log(`│ 空投合约:    ${AIRDROP_ADDRESS.padEnd(50)} │`);
    console.log(`│ 交易哈希:    ${tx.hash.padEnd(50)} │`);
    console.log('└─────────────────────────────────────────────────────────────────┘');
    console.log('');
    
    console.log('🎯 下一步操作:');
    console.log('');
    console.log('1. 生成邀请码:');
    console.log(`   node scripts/generate-invite-codes.js 10000 --network ${network} --deploy`);
    console.log('');
    console.log('2. 更新前端配置:');
    console.log(`   node scripts/update-frontend-config.js ${network} ${SUK_TOKEN_ADDRESS} ${AIRDROP_ADDRESS}`);
    console.log('');
    console.log('3. 测试空投功能:');
    console.log(`   访问: http://localhost:8000/suk-airdrop-v2.html`);
    console.log('');
    
    // 区块浏览器链接
    const explorerUrls = {
        goerli: 'https://goerli.etherscan.io',
        sepolia: 'https://sepolia.etherscan.io',
        mainnet: 'https://etherscan.io',
        polygon: 'https://polygonscan.com',
        bsc: 'https://bscscan.com'
    };
    
    const explorerUrl = explorerUrls[network] || 'https://etherscan.io';
    console.log('🔍 查看交易:');
    console.log(`   ${explorerUrl}/tx/${tx.hash}`);
    console.log('');
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error('\n❌ 转账失败:', error);
        process.exit(1);
    });
