/**
 * Jest 测试配置
 * Jest Test Configuration
 */

module.exports = {
    // 测试环境
    testEnvironment: 'node',
    
    // 覆盖率收集
    collectCoverageFrom: [
        'backend/**/*.js',
        '!backend/**/*.test.js',
        '!backend/**/*.spec.js',
        '!**/node_modules/**',
        '!**/vendor/**'
    ],
    
    // 覆盖率阈值
    coverageThreshold: {
        global: {
            branches: 70,
            functions: 70,
            lines: 70,
            statements: 70
        }
    },
    
    // 覆盖率报告格式
    coverageReporters: [
        'text',
        'text-summary',
        'html',
        'lcov'
    ],
    
    // 测试文件匹配模式
    testMatch: [
        '**/__tests__/**/*.js',
        '**/?(*.)+(spec|test).js'
    ],
    
    // 忽略的路径
    testPathIgnorePatterns: [
        '/node_modules/',
        '/dist/',
        '/build/'
    ],
    
    // 设置超时时间
    testTimeout: 10000,
    
    // 显示详细信息
    verbose: true,
    
    // 清除 mock
    clearMocks: true,
    
    // 重置 mock
    resetMocks: true,
    
    // 恢复 mock
    restoreMocks: true
};
