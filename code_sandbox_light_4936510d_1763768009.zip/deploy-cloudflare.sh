#!/bin/bash

# ========================================
# Cloudflare Pages 自动部署脚本
# SUK LINK - 全球Web3.0链剧资产平台
# ========================================

set -e  # 遇到错误立即退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 项目配置
PROJECT_NAME="suk-link"
BRANCH="${1:-main}"  # 默认 main 分支，可通过参数修改

# 打印彩色信息
print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_header() {
    echo ""
    echo "=========================================="
    echo -e "${BLUE}$1${NC}"
    echo "=========================================="
    echo ""
}

# ========================================
# 1. 检查环境
# ========================================
print_header "1️⃣  检查部署环境"

# 检查 Node.js
if ! command -v node &> /dev/null; then
    print_error "Node.js 未安装"
    print_info "请先安装 Node.js: https://nodejs.org/"
    exit 1
else
    print_success "Node.js 已安装: $(node --version)"
fi

# 检查 npm
if ! command -v npm &> /dev/null; then
    print_error "npm 未安装"
    exit 1
else
    print_success "npm 已安装: $(npm --version)"
fi

# 检查 Wrangler
if ! command -v wrangler &> /dev/null; then
    print_warning "Wrangler 未安装"
    print_info "正在安装 Wrangler..."
    npm install -g wrangler
    print_success "Wrangler 安装完成"
else
    print_success "Wrangler 已安装: $(wrangler --version)"
fi

# ========================================
# 2. 检查登录状态
# ========================================
print_header "2️⃣  验证 Cloudflare 登录"

if ! wrangler whoami &> /dev/null; then
    print_warning "未登录 Cloudflare"
    print_info "正在打开登录页面..."
    wrangler login
    
    # 再次检查
    if ! wrangler whoami &> /dev/null; then
        print_error "登录失败"
        exit 1
    fi
fi

print_success "已登录 Cloudflare"
wrangler whoami

# ========================================
# 3. 检查配置文件
# ========================================
print_header "3️⃣  检查配置文件"

# 检查 wrangler.toml
if [ ! -f "wrangler.toml" ]; then
    print_error "wrangler.toml 不存在"
    exit 1
else
    print_success "wrangler.toml 存在"
fi

# 检查 .cloudflare-ignore
if [ ! -f ".cloudflare-ignore" ]; then
    print_warning ".cloudflare-ignore 不存在"
else
    print_success ".cloudflare-ignore 存在"
fi

# 检查 _redirects
if [ ! -f "_redirects" ]; then
    print_warning "_redirects 不存在"
else
    print_success "_redirects 存在"
fi

# 检查 _headers
if [ ! -f "_headers" ]; then
    print_warning "_headers 不存在"
else
    print_success "_headers 存在"
fi

# 检查主页
if [ ! -f "index.html" ]; then
    print_error "index.html 不存在"
    exit 1
else
    print_success "index.html 存在"
fi

# ========================================
# 4. 清理缓存
# ========================================
print_header "4️⃣  清理本地缓存"

if [ -d ".wrangler" ]; then
    print_info "清理 .wrangler 目录..."
    rm -rf .wrangler
    print_success "缓存清理完成"
else
    print_info "无需清理缓存"
fi

# ========================================
# 5. 部署到 Cloudflare Pages
# ========================================
print_header "5️⃣  部署到 Cloudflare Pages"

print_info "项目名称: $PROJECT_NAME"
print_info "部署分支: $BRANCH"
echo ""

# 执行部署
if wrangler pages publish . \
    --project-name="$PROJECT_NAME" \
    --branch="$BRANCH"; then
    
    print_success "部署成功！"
else
    print_error "部署失败"
    exit 1
fi

# ========================================
# 6. 获取部署信息
# ========================================
print_header "6️⃣  部署信息"

print_info "获取最新部署详情..."
wrangler pages deployment list \
    --project-name="$PROJECT_NAME" \
    --limit=1

# ========================================
# 7. 验证部署
# ========================================
print_header "7️⃣  验证部署"

# 获取部署URL
DEPLOY_URL=$(wrangler pages deployment list --project-name="$PROJECT_NAME" --limit=1 | grep -o 'https://[^ ]*' | head -1)

if [ -n "$DEPLOY_URL" ]; then
    print_success "部署URL: $DEPLOY_URL"
    
    # 测试访问
    print_info "测试网站访问..."
    if curl -s -o /dev/null -w "%{http_code}" "$DEPLOY_URL" | grep -q "200"; then
        print_success "网站访问正常 (200 OK)"
    else
        print_warning "网站访问异常，请手动检查"
    fi
else
    print_warning "未能获取部署URL，请手动检查"
fi

# ========================================
# 8. 后续操作提醒
# ========================================
print_header "8️⃣  后续操作"

echo "✅ 部署完成！接下来您需要："
echo ""
echo "1️⃣  配置自定义域名："
echo "   wrangler pages domain add $PROJECT_NAME suk.link"
echo ""
echo "2️⃣  访问 Dashboard 配置："
echo "   https://dash.cloudflare.com → Workers & Pages → $PROJECT_NAME"
echo ""
echo "3️⃣  配置 DNS 记录："
echo "   • suk.link → Cloudflare Pages"
echo "   • api.suk.link → 你的VPS IP"
echo "   • www.suk.link → suk.link"
echo ""
echo "4️⃣  启用安全功能："
echo "   • SSL/TLS: Full (strict)"
echo "   • WAF: Cloudflare Managed Ruleset"
echo "   • DDoS: 自动启用"
echo ""
echo "5️⃣  测试网站功能："
echo "   • 访问主页"
echo "   • 测试API请求"
echo "   • 检查静态资源"
echo ""

# ========================================
# 完成
# ========================================
print_header "🎉 部署流程完成"

print_success "所有步骤执行完毕！"
echo ""
echo "📚 查看详细文档："
echo "   • 快速部署指南: CLOUDFLARE_MIGRATION_START.md"
echo "   • 命令速查: CLOUDFLARE_命令速查.md"
echo "   • 完整分析: CLOUDFLARE_HOSTING_ANALYSIS.md"
echo ""
echo "💬 需要帮助？"
echo "   • Cloudflare 社区: https://community.cloudflare.com/"
echo "   • 官方文档: https://developers.cloudflare.com/pages/"
echo ""

exit 0
