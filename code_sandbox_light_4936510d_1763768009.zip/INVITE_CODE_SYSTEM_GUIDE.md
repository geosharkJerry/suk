# SUK 邀请码系统完整指南

> 🎁 官方邀请码生成、用户激活、空投发放完整流程

---

## 📋 目录

- [系统概述](#系统概述)
- [功能特性](#功能特性)
- [页面说明](#页面说明)
- [管理员指南](#管理员指南)
- [用户指南](#用户指南)
- [数据库设计](#数据库设计)
- [API接口](#api接口)
- [常见问题](#常见问题)

---

## 🎯 系统概述

SUK 邀请码系统是一个完整的空投分发解决方案，通过官方邀请码和推荐链接两种方式，实现精准的空投发放和用户增长激励。

### 核心价值

- **官方可控** - 邀请码由官方生成和管理，确保空投精准发放
- **防止滥用** - 邀请码一次性使用，有效期管理，防止刷空投
- **激励增长** - 推荐奖励机制，激励用户分享和邀请
- **数据追踪** - 完整的使用记录和统计分析

### 两种参与方式

| 方式 | 奖励金额 | 获取难度 | 是否需要购买 | 适用场景 |
|------|---------|---------|------------|---------|
| **邀请码激活** | 5,000 SUK | 中等 | ❌ | 官方活动、合作伙伴、KOL推广 |
| **推荐购买** | 1,000 SUK | 较易 | ✅ | 用户增长、社交裂变 |

---

## ✨ 功能特性

### 管理员功能

- ✅ 批量生成邀请码（1-100个）
- ✅ 自定义空投金额和有效期
- ✅ 实时统计面板（总数/可用/已使用/总空投）
- ✅ 邀请码搜索和过滤
- ✅ 一键复制邀请码
- ✅ 停用无效邀请码
- ✅ 使用记录追踪

### 用户功能

- ✅ 连接 MetaMask 钱包
- ✅ 输入邀请码验证
- ✅ 一键激活邀请码
- ✅ 领取 5,000 SUK 空投
- ✅ 生成推荐链接
- ✅ 领取推荐奖励
- ✅ 查看空投和余额

### 系统功能

- ✅ 邀请码自动验证（存在性、有效性、过期检查）
- ✅ 智能状态检测和UI动态渲染
- ✅ 推荐关系自动记录
- ✅ 空投发放自动化
- ✅ 数据完整性保证

---

## 📄 页面说明

### 1. admin-invite-system.html (23KB)

**官方邀请码管理后台**

访问地址：`https://your-domain.com/admin-invite-system.html`

#### 功能模块

**统计面板**：
- 总邀请码数
- 可用邀请码
- 已使用邀请码
- 总空投金额

**生成表单**：
- 邀请码数量（1-100）
- 空投金额（默认5000 SUK）
- 有效期（1-365天）
- 备注信息

**邀请码列表**：
- 搜索框（邀请码/地址）
- 过滤标签（全部/可用/已使用/已过期）
- 邀请码详情卡片
- 操作按钮（复制/停用）

### 2. invite-activation-flow.html (29KB)

**用户激活完整流程**

访问地址：`https://your-domain.com/invite-activation-flow.html`

#### 流程步骤

**步骤1 - 连接钱包**：
- 显示空投奖励横幅（5,000 SUK）
- "连接 MetaMask 钱包"按钮
- MetaMask 连接授权

**步骤2 - 推荐检测**（如果URL有?ref=参数）：
- 显示推荐人信息
- 推荐奖励说明（1,000 SUK）
- "前往购买"按钮

**步骤3 - 输入邀请码**：
- 12位邀请码输入框
- 实时字符计数（0/12）
- 自动大写转换
- "激活邀请码"按钮

**步骤4 - 激活成功**：
- 成功提示
- 激活的邀请码显示
- "立即领取 5,000 SUK"按钮

**步骤5 - 已领取**：
- 完成状态
- 交易哈希显示
- "前往控制面板"按钮

### 3. user-dashboard-enhanced.html (26KB)

**用户控制面板**

访问地址：`https://your-domain.com/user-dashboard-enhanced.html`

#### 卡片布局

**🎁 SUK 空投卡片**：
- 状态徽章（待激活/待领取/已领取）
- 空投金额显示
- 操作按钮（激活/领取/已完成）
- 邀请码信息

**👥 推荐奖励卡片**：
- 状态徽章（待激活/可分享/待领取/已领取）
- 推荐链接生成和复制
- 推荐人信息显示
- 操作按钮

**💰 SUK 余额卡片**：
- 总余额显示
- 空投获得统计
- 推荐获得统计

---

## 👨‍💼 管理员指南

### 生成邀请码

#### 步骤1: 访问管理后台

```
https://your-domain.com/admin-invite-system.html
```

#### 步骤2: 设置参数

```
邀请码数量: 10
空投金额: 5000 SUK
有效期: 30 天
备注: 社群活动奖励
```

#### 步骤3: 点击生成

系统自动生成12位随机邀请码：
```
ABCD1234WXYZ
EFGH5678STUV
...
```

#### 步骤4: 复制和分发

- 点击"复制邀请码"按钮
- 通过社交媒体、邮件等渠道分发

### 管理邀请码

#### 搜索邀请码

在搜索框输入：
- 邀请码：`ABCD1234WXYZ`
- 使用者地址：`0x1a2b...`
- 备注关键词：`社群活动`

#### 过滤邀请码

点击过滤标签：
- **全部** - 显示所有邀请码
- **可用** - 仅显示未使用的邀请码
- **已使用** - 仅显示已使用的邀请码
- **已过期** - 仅显示已过期的邀请码

#### 停用邀请码

如果邀请码不需要了：
1. 找到对应邀请码
2. 点击"停用"按钮
3. 确认操作
4. 状态变更为"已过期"

### 统计分析

实时查看：
- 总邀请码数：100个
- 可用邀请码：75个
- 已使用：20个
- 已过期：5个
- 总空投金额：100,000 SUK

---

## 👤 用户指南

### 方式1: 邀请码激活

#### 1. 获取邀请码

从以下渠道获得12位邀请码：
- 官方 Twitter 活动
- Telegram 社群奖励
- Discord 活跃奖励
- 合作伙伴推广
- KOL 分享

#### 2. 访问激活页面

```
https://your-domain.com/invite-activation-flow.html
```

#### 3. 连接钱包

- 点击"🦊 连接 MetaMask 钱包"
- MetaMask 弹出连接请求
- 点击"连接"授权

#### 4. 输入邀请码

```
邀请码: ABCD1234WXYZ
```

- 自动转换为大写
- 实时显示字符数（12/12）
- "激活邀请码"按钮变为可点击

#### 5. 激活

- 点击"🎫 激活邀请码"
- MetaMask 弹出交易确认
- Gas 费约 0.002 ETH
- 确认交易

#### 6. 等待确认

- 显示"激活中..."加载状态
- 等待区块链确认（约30秒）
- 激活成功提示

#### 7. 领取空投

- 显示"💰 立即领取 5,000 SUK"按钮
- 点击领取按钮
- MetaMask 确认领取交易
- 等待交易确认
- 5000 SUK 到账

#### 8. 查看余额

- 自动跳转到控制面板
- 查看 SUK 余额
- 复制推荐链接分享

### 方式2: 推荐购买

#### 1. 获取推荐链接

已激活用户在控制面板：
1. 访问 `user-dashboard-enhanced.html`
2. 查看"👥 推荐奖励"卡片
3. 点击"📋 复制推荐链接"
4. 链接格式：`https://...?ref=0x1a2b...`

#### 2. 分享链接

通过以下方式分享：
- Twitter 发推
- Telegram 群组
- Discord 频道
- 微信朋友圈
- 邮件邀请

#### 3. 新用户访问

新用户点击推荐链接：
1. 自动识别推荐人地址
2. 显示推荐奖励信息
3. "🛒 前往购买"按钮

#### 4. 完成购买

- 点击"前往购买"跳转到商城
- 选择任意产品
- 完成支付
- 系统自动记录推荐关系

#### 5. 领取奖励

推荐人和被推荐人：
1. 返回控制面板
2. 查看"👥 推荐奖励"卡片
3. 点击"💰 领取 1,000 SUK"
4. 确认交易
5. 1000 SUK 到账

---

## 🗄️ 数据库设计

### users 表

用户信息管理

| 字段 | 类型 | 说明 |
|------|------|------|
| id | text | 用户唯一ID |
| wallet_address | text | 钱包地址 |
| invite_code_used | text | 使用的邀请码 |
| airdrop_claimed | bool | 是否已领取空投 |
| airdrop_amount | number | 空投金额 |
| referrer_address | text | 推荐人地址 |
| referral_earned | number | 推荐获得的SUK |
| total_suk_balance | number | SUK总余额 |
| created_at | datetime | 创建时间 |

### invite_codes 表

邀请码管理

| 字段 | 类型 | 说明 |
|------|------|------|
| id | text | 邀请码ID |
| code | text | 邀请码（12位） |
| status | text | 状态（active/used/expired） |
| airdrop_amount | number | 空投金额 |
| used_by | text | 使用者钱包地址 |
| used_at | datetime | 使用时间 |
| expires_at | datetime | 过期时间 |
| created_by | text | 创建者 |
| notes | text | 备注 |
| created_at | datetime | 创建时间 |

### airdrop_records 表

空投记录追踪

| 字段 | 类型 | 说明 |
|------|------|------|
| id | text | 记录ID |
| wallet_address | text | 接收者钱包地址 |
| airdrop_type | text | 空投类型（invite_code/referral/reward） |
| amount | number | 空投金额 |
| invite_code | text | 关联邀请码 |
| referrer_address | text | 推荐人地址 |
| tx_hash | text | 交易哈希 |
| status | text | 状态（pending/completed/failed） |
| created_at | datetime | 创建时间 |

---

## 🔌 API接口

### 1. 查询邀请码列表

```http
GET /tables/invite_codes?limit=100&sort=-created_at
```

**响应**：
```json
{
  "data": [
    {
      "id": "uuid-1",
      "code": "ABCD1234WXYZ",
      "status": "active",
      "airdrop_amount": 5000,
      "expires_at": 1735660800000,
      "created_at": 1733068800000
    }
  ],
  "total": 100,
  "page": 1,
  "limit": 100
}
```

### 2. 创建邀请码

```http
POST /tables/invite_codes
Content-Type: application/json

{
  "code": "ABCD1234WXYZ",
  "status": "active",
  "airdrop_amount": 5000,
  "expires_at": 1735660800000,
  "created_by": "Admin",
  "notes": "社群活动",
  "created_at": 1733068800000
}
```

### 3. 搜索邀请码

```http
GET /tables/invite_codes?search=ABCD1234WXYZ
```

### 4. 更新邀请码状态

```http
PATCH /tables/invite_codes/{id}
Content-Type: application/json

{
  "status": "used",
  "used_by": "0x1a2b3c4d5e6f...",
  "used_at": 1733155200000
}
```

### 5. 查询用户信息

```http
GET /tables/users?search=0x1a2b3c4d5e6f...
```

### 6. 创建用户

```http
POST /tables/users
Content-Type: application/json

{
  "wallet_address": "0x1a2b3c4d5e6f...",
  "invite_code_used": "ABCD1234WXYZ",
  "airdrop_claimed": false,
  "airdrop_amount": 5000,
  "referrer_address": "",
  "referral_earned": 0,
  "total_suk_balance": 0,
  "created_at": 1733155200000
}
```

### 7. 更新用户状态

```http
PATCH /tables/users/{id}
Content-Type: application/json

{
  "airdrop_claimed": true,
  "total_suk_balance": 5000
}
```

### 8. 记录空投

```http
POST /tables/airdrop_records
Content-Type: application/json

{
  "wallet_address": "0x1a2b3c4d5e6f...",
  "airdrop_type": "invite_code",
  "amount": 5000,
  "invite_code": "ABCD1234WXYZ",
  "tx_hash": "0xabc123...",
  "status": "completed",
  "created_at": 1733155200000
}
```

---

## ❓ 常见问题

### 管理员常见问题

**Q1: 如何批量生成邀请码？**

A: 在管理后台设置数量（最多100个），点击生成按钮即可批量创建。

**Q2: 邀请码可以重复使用吗？**

A: 不可以。每个邀请码只能使用一次，使用后状态自动变更为"已使用"。

**Q3: 如何设置邀请码有效期？**

A: 在生成时设置有效期天数（1-365天），到期自动失效。

**Q4: 可以停用某个邀请码吗？**

A: 可以。在邀请码列表中找到对应邀请码，点击"停用"按钮。

**Q5: 如何查看邀请码使用情况？**

A: 在统计面板查看总数、可用、已使用、已过期等实时数据。

### 用户常见问题

**Q1: 邀请码在哪里获得？**

A: 通过官方活动、社群奖励、合作伙伴、KOL分享等渠道获得。

**Q2: 邀请码激活需要支付费用吗？**

A: 只需要支付少量 Gas 费（约0.002 ETH），空投本身是免费的。

**Q3: 激活后多久能收到空投？**

A: 激活后立即可以领取，点击"立即领取"按钮，确认交易后即可到账。

**Q4: 可以重复领取空投吗？**

A: 不可以。每个钱包地址只能领取一次空投。

**Q5: 推荐奖励如何获得？**

A: 激活邀请码后，分享推荐链接，好友购买后您和好友各得1,000 SUK。

**Q6: 推荐链接在哪里找？**

A: 在用户控制面板的"推荐奖励"卡片中复制。

**Q7: 忘记邀请码怎么办？**

A: 邀请码需要妥善保管，遗失后无法找回，请联系发放方重新获取。

**Q8: 邀请码过期了怎么办？**

A: 过期的邀请码无法使用，请联系发放方获取新的邀请码。

---

## 🚀 快速开始

### 管理员快速开始（5分钟）

1. **访问管理后台**
   ```
   https://your-domain.com/admin-invite-system.html
   ```

2. **生成10个邀请码**
   - 数量：10
   - 金额：5000 SUK
   - 有效期：30天
   - 点击"生成邀请码"

3. **复制邀请码**
   - 在列表中找到生成的邀请码
   - 点击"复制邀请码"
   - 通过社交媒体分发

### 用户快速开始（3分钟）

1. **获取邀请码**
   ```
   ABCD1234WXYZ
   ```

2. **访问激活页面**
   ```
   https://your-domain.com/invite-activation-flow.html
   ```

3. **连接钱包 → 输入邀请码 → 激活 → 领取**

---

## 📚 相关文档

- 📖 [README.md](README.md) - 项目主文档
- 🎁 [SUK_AIRDROP_GUIDE.md](SUK_AIRDROP_GUIDE.md) - 空投系统指南
- 📊 [USER_FLOW_COMPLETE.md](USER_FLOW_COMPLETE.md) - 用户流程完成报告
- 🔧 [FRONTEND_CONFIG_GUIDE.md](FRONTEND_CONFIG_GUIDE.md) - 前端配置指南

---

## 📞 技术支持

如有问题，请联系：
- 📧 Email: support@suklink.com
- 💬 Telegram: @SUKLink
- 🐦 Twitter: @SUKLink

---

**🎉 SUK 邀请码系统 - 让空投分发更简单、更安全、更高效！**

*最后更新: 2024-11-17*
