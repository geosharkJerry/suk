# SUK奖励系统 - 快速开始

## 🚀 5分钟快速集成

### 步骤1: 后端集成（2分钟）

#### 1.1 导入路由到server.js

```javascript
// server.js

// 1. 导入奖励路由
const rewardRoutes = require('./backend/routes/reward.routes');

// 2. 注册路由（放在其他API路由之后）
app.use('/api/rewards', rewardRoutes);

// 3. 确保Telegram认证中间件已配置
```

#### 1.2 启动服务器

```bash
# 重启Node.js服务器
npm run dev

# 或使用PM2
pm2 restart drama-platform
```

**✅ 后端集成完成！**

---

### 步骤2: 前端集成（3分钟）

#### 2.1 在主页添加奖励入口

编辑 `telegram-app.html`:

```html
<!-- 在用户卡片中添加 -->
<div class="user-card" id="userCard">
    <div class="user-info">
        <!-- 现有用户信息 -->
    </div>
    
    <!-- 新增：奖励按钮 -->
    <button class="reward-btn" onclick="openRewardCenter()" style="
        margin-top: 12px;
        width: 100%;
        padding: 10px;
        background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
        color: white;
        border: none;
        border-radius: 8px;
        font-weight: 500;
        cursor: pointer;
    ">
        💰 我的奖励
    </button>
</div>

<script>
function openRewardCenter() {
    window.location.href = '/telegram-reward-center.html';
}
</script>
```

#### 2.2 在播放器中集成观看奖励

编辑 `telegram-player-optimized.html`（或你使用的播放器）:

```javascript
// 在播放器初始化后添加

let recordedReward = false;

// 方法1: 播放结束时记录
player.on('ended', async () => {
    if (!recordedReward) {
        await recordWatchReward();
        recordedReward = true;
    }
});

// 方法2: 页面关闭前记录
window.addEventListener('beforeunload', () => {
    if (!recordedReward) {
        recordWatchReward();
    }
});

// 记录观看奖励函数
async function recordWatchReward() {
    try {
        const watchDuration = Math.floor(player.getCurrentTime());
        const totalDuration = Math.floor(player.getDuration());
        
        // 至少观看5%才记录
        if (watchDuration / totalDuration < 0.05) {
            return;
        }
        
        const response = await fetch('/api/rewards/watch', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Telegram-Init-Data': tg.initData
            },
            body: JSON.stringify({
                dramaId: currentDrama._id,
                episodeId: currentEpisode.episodeId,
                watchDuration,
                totalDuration
            })
        });
        
        const result = await response.json();
        
        if (result.success && result.data.rewardAmount > 0) {
            // 显示奖励提示
            tg.showAlert(`🎉 恭喜获得 ${result.data.rewardAmount.toFixed(2)} SUK 观看奖励！`);
            
            // 或使用自定义提示
            showRewardToast(`+${result.data.rewardAmount.toFixed(2)} SUK`);
        }
    } catch (error) {
        console.error('记录观看奖励失败:', error);
    }
}

// 可选：自定义奖励提示
function showRewardToast(message) {
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        font-weight: bold;
        z-index: 9999;
        animation: slideIn 0.3s ease-out;
    `;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}
```

#### 2.3 在注册时处理邀请码

编辑 `telegram-app.html` 的初始化函数:

```javascript
async function initApp() {
    // 现有初始化代码...
    
    // 新增：检查邀请码
    await checkAndUseInviteCode();
}

async function checkAndUseInviteCode() {
    const urlParams = new URLSearchParams(window.location.search);
    const inviteCode = urlParams.get('inviteCode');
    
    if (!inviteCode) return;
    
    try {
        const response = await fetch('/api/rewards/invite/use', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Telegram-Init-Data': tg.initData
            },
            body: JSON.stringify({ inviteCode })
        });
        
        const result = await response.json();
        
        if (result.success) {
            tg.showAlert('🎉 邀请码使用成功！\n\n购买短剧后邀请人将获得7%SUK奖励，你也将享受优惠！');
        } else if (result.message !== '邀请关系已存在') {
            console.log('邀请码使用失败:', result.message);
        }
    } catch (error) {
        console.error('使用邀请码失败:', error);
    }
}
```

**✅ 前端集成完成！**

---

## 📱 测试流程

### 1. 测试奖励中心页面

```bash
# 启动服务器
http-server . -p 8080

# 浏览器打开
http://localhost:8080/telegram-reward-center.html
```

**应该看到**:
- ✅ 累计赚取、待发放、已发放统计
- ✅ 3个标签：观看奖励、邀请奖励、我的邀请
- ✅ Mock数据正常显示
- ✅ 邀请码生成（LOADING → SUKABC12）

### 2. 测试观看奖励

```javascript
// 在播放器页面Console中测试
await fetch('/api/rewards/watch', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'X-Telegram-Init-Data': 'query_id=test'
    },
    body: JSON.stringify({
        dramaId: '64a1b2c3d4e5f6',
        episodeId: 'ep001',
        watchDuration: 240,
        totalDuration: 300
    })
}).then(r => r.json()).then(console.log);

// 预期输出
{
    "success": true,
    "message": "观看奖励记录成功",
    "data": {
        "_id": "...",
        "rewardAmount": 0.792,
        "status": "pending"
    }
}
```

### 3. 测试邀请码生成

```javascript
// 测试生成邀请码
await fetch('/api/rewards/invite/code', {
    method: 'POST',
    headers: {
        'X-Telegram-Init-Data': 'query_id=test'
    }
}).then(r => r.json()).then(console.log);

// 预期输出
{
    "success": true,
    "data": {
        "inviteCode": "SUKABC12",
        "inviteLink": "https://suk.link/telegram-app.html?inviteCode=SUKABC12",
        "qrCode": "https://api.qrserver.com/..."
    }
}
```

### 4. 测试使用邀请码

```
# 打开带邀请码的链接
http://localhost:8080/telegram-app.html?inviteCode=SUKABC12

# 应该看到提示：邀请码使用成功
```

---

## 🎯 核心功能清单

### ✅ 已完成

- [x] **数据模型** (4个Model)
  - WatchReward - 观看奖励记录
  - InviteReward - 邀请奖励记录
  - InviteRelation - 邀请关系
  - UserRewardStats - 用户统计

- [x] **后端服务**
  - reward.service.js - 核心业务逻辑
  - reward.controller.js - API控制器
  - reward.routes.js - 路由配置

- [x] **前端页面**
  - telegram-reward-center.html - 奖励中心（31KB）
  - 包含3个标签（观看/邀请/我的邀请）
  - Mock数据支持离线开发

- [x] **API接口** (8个)
  - POST /api/rewards/watch - 记录观看奖励
  - GET /api/rewards/stats - 获取统计
  - GET /api/rewards/records - 获取记录
  - POST /api/rewards/invite/code - 生成邀请码
  - POST /api/rewards/invite/use - 使用邀请码
  - GET /api/rewards/invite/list - 邀请列表
  - POST /api/rewards/bind-wallet - 绑定钱包
  - POST /api/rewards/withdraw - 提现

- [x] **文档**
  - SUK_REWARD_SYSTEM_GUIDE.md - 完整指南（13KB）
  - SUK_REWARD_QUICK_START.md - 快速开始（本文件）

### ⏳ 待完成（可选）

- [ ] 播放器集成（需要修改现有播放器文件）
- [ ] 主页奖励入口（需要修改telegram-app.html）
- [ ] 数据库初始化脚本
- [ ] 单元测试

---

## 💡 使用建议

### 1. 奖励比例调整

```javascript
// backend/services/reward.service.js

// 修改观看奖励比例（默认1%）
const rewardRate = 0.01; // 改为 0.02 即2%

// 修改邀请奖励比例（默认7%）
const rewardRate = 0.07; // 改为 0.10 即10%
```

### 2. 防作弊阈值调整

```javascript
// backend/services/reward.service.js - calculateValidationScore()

// 调整观看百分比要求
if (watchPercent < 5) {  // 改为10即要求至少观看10%
    score -= 20;
}

// 调整频率限制
if (recentCount > 5) {  // 改为3即更严格的限制
    score -= 30;
}
```

### 3. 自定义邀请码格式

```javascript
// backend/services/reward.service.js - generateInviteCode()

generateInviteCode(userId) {
    // 当前格式: SUK + 5位随机字符
    const randomPart = crypto.randomBytes(3).toString('hex').toUpperCase().slice(0, 5);
    return `SUK${randomPart}`;
    
    // 自定义格式示例:
    // return `DRAMA${randomPart}`; // DRAMA + 5位
    // return `${userId.slice(-6)}`; // 用户ID后6位
}
```

---

## 🔧 故障排查

### 问题1: API返回401 Unauthorized

**原因**: Telegram认证失败

**解决**:
```javascript
// 检查是否正确传递了 X-Telegram-Init-Data
headers: {
    'X-Telegram-Init-Data': tg.initData  // 确保tg.initData有值
}

// 开发模式下可以使用测试数据
headers: {
    'X-Telegram-Init-Data': 'query_id=test'
}
```

### 问题2: 奖励金额为0

**原因**: 
1. 观看时长不足5%
2. 剧集价格为0（免费剧集）
3. 计算公式错误

**解决**:
```javascript
// 检查数据
console.log('观看时长:', watchDuration);
console.log('总时长:', totalDuration);
console.log('剧集价格:', dramaPrice);
console.log('观看百分比:', watchPercent);
```

### 问题3: 邀请码无效

**原因**: 
1. 邀请码未生成
2. 邀请关系已存在
3. 数据库连接失败

**解决**:
```bash
# 检查数据库连接
npm run test:db

# 查看邀请关系
mongo
> use short_drama_platform
> db.inviterelations.find()
```

---

## 📊 数据库查询示例

```javascript
// 查看用户奖励统计
db.userrewardstats.findOne({ userId: "123456789" })

// 查看观看奖励记录
db.watchrewards.find({ userId: "123456789" }).sort({ createdAt: -1 }).limit(10)

// 查看邀请奖励记录
db.inviterewards.find({ inviterId: "123456789" }).sort({ createdAt: -1 })

// 查看邀请关系
db.inviterelations.find({ inviterId: "123456789" })

// 统计待发放奖励
db.watchrewards.aggregate([
    { $match: { status: "pending" } },
    { $group: { _id: null, total: { $sum: "$rewardAmount" } } }
])
```

---

## 🎉 完成！

您的SUK奖励系统已经集成完成！

### 下一步

1. **测试所有功能** - 按照上面的测试流程
2. **调整奖励比例** - 根据实际需求
3. **监控数据** - 查看用户参与情况
4. **优化体验** - 根据用户反馈改进

### 需要帮助？

- 📖 查看完整文档：[SUK_REWARD_SYSTEM_GUIDE.md](SUK_REWARD_SYSTEM_GUIDE.md)
- 🐛 遇到问题：检查Console日志
- 💬 技术支持：dev@suk.link

---

**版本**: v1.0  
**最后更新**: 2025-01-16  
**预计集成时间**: 5分钟 ⚡
