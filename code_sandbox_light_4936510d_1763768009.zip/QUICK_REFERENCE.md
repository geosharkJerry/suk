# SUK 前端配置快速参考

## 🚀 一分钟快速上手

### 部署后立即配置

```bash
# 更新配置（30秒）
node scripts/update-frontend-config.js goerli <TOKEN_ADDRESS> <AIRDROP_ADDRESS>

# 启动测试（10秒）
python -m http.server 8000

# 浏览器打开（1分钟）
http://localhost:8000/contract-config-test.html
# → 点击"连接 MetaMask" → 点击"全面测试"
```

---

## 📋 常用命令

### 部署命令
```bash
# 编译
npx hardhat compile

# 部署（测试网）
npx hardhat run scripts/1-deploy-suk-token.js --network goerli
npx hardhat run scripts/2-deploy-airdrop.js --network goerli
npx hardhat run scripts/3-fund-airdrop.js --network goerli

# 验证
npx hardhat verify --network goerli <ADDRESS> <ARGS>
```

### 配置命令
```bash
# 更新配置
node scripts/update-frontend-config.js <network> <token> <airdrop>

# 示例
node scripts/update-frontend-config.js goerli 0x123... 0x456...
```

### 测试命令
```bash
# 启动服务器
python -m http.server 8000
# 或
npx http-server -p 8000

# 测试页面
http://localhost:8000/contract-config-test.html
http://localhost:8000/suk-airdrop.html
```

---

## 💻 代码片段

### 连接钱包
```javascript
const web3 = new SUKWeb3Contract('goerli');
await web3.connectWallet();
```

### 查询余额
```javascript
const balance = await web3.getSUKBalance();
console.log('余额:', balance, 'SUK');
```

### 领取空投
```javascript
const receipt = await web3.claimAirdrop();
console.log('领取成功!', receipt.transactionHash);
```

### 转账
```javascript
await web3.transferSUK('0x接收地址', '100');
```

### X402 计费
```javascript
await web3.payForWatching(dramaId, 10, platformWallet);
```

### 监听事件
```javascript
web3.onAccountsChanged((accounts) => {
    console.log('账户切换:', accounts[0]);
});
```

---

## 🔧 配置模板

### HTML 页面模板
```html
<!DOCTYPE html>
<html>
<head>
    <script src="https://cdn.jsdelivr.net/npm/ethers@5.7.2/dist/ethers.umd.min.js"></script>
    <script src="js/contract-config.js"></script>
    <script src="js/web3-contract.js"></script>
</head>
<body>
    <button onclick="connect()">连接</button>
    <script>
        const web3 = new SUKWeb3Contract('goerli');
        async function connect() {
            await web3.connectWallet();
            alert('连接成功!');
        }
    </script>
</body>
</html>
```

### .env 模板
```bash
PRIVATE_KEY=your_private_key
INFURA_API_KEY=your_infura_key
ETHERSCAN_API_KEY=your_etherscan_key
```

---

## 📞 快速链接

### 文档
- 🚀 [5分钟快速开始](FRONTEND_QUICK_START.md)
- 📖 [详细配置指南](FRONTEND_CONFIG_GUIDE.md)
- 📊 [完成报告](FRONTEND_CONFIG_COMPLETE.md)
- ✅ [部署清单](DEPLOYMENT_CHECKLIST.md)

### 工具
- 🧪 [配置测试工具](contract-config-test.html)
- 🎁 [空投页面](suk-airdrop.html)

### 脚本
- `scripts/1-deploy-suk-token.js` - 部署代币
- `scripts/2-deploy-airdrop.js` - 部署空投
- `scripts/3-fund-airdrop.js` - 转账
- `scripts/update-frontend-config.js` - 更新配置

### 配置文件
- `js/contract-config.js` - 合约配置
- `js/web3-contract.js` - Web3 工具
- `hardhat.config.js` - Hardhat 配置

---

## ❓ 快速问答

### Q: 如何切换网络?
```javascript
// 方法1: 创建时指定
const web3 = new SUKWeb3Contract('mainnet');

// 方法2: 修改默认
ContractConfig.setDefaultNetwork('mainnet');
```

### Q: 如何获取合约地址?
```javascript
const config = ContractConfig.getConfig('goerli');
console.log('Token:', config.contracts.SUKToken);
console.log('Airdrop:', config.contracts.SUKAirdrop);
```

### Q: 如何验证配置?
```javascript
if (ContractConfig.isConfigured('goerli')) {
    console.log('✅ 已配置');
} else {
    console.log('❌ 未配置');
}
```

### Q: 如何格式化地址?
```javascript
const short = web3.formatAddress('0x1234...7890');
// 输出: 0x1234...7890
```

### Q: 如何查看区块浏览器?
```javascript
const link = ContractConfig.getExplorerLink('goerli', 'SUKToken');
console.log('浏览器:', link);
```

---

## 🚨 常见错误

### 错误: "请先安装 MetaMask"
**解决**: 安装 MetaMask 浏览器插件

### 错误: "网络不匹配"
**解决**: 
```javascript
await web3.switchNetwork();
```

### 错误: "合约地址未配置"
**解决**: 
```bash
node scripts/update-frontend-config.js goerli <TOKEN> <AIRDROP>
```

### 错误: "余额不足"
**解决**: 
- 测试网: 访问 Faucet 获取测试币
- 主网: 确保钱包有足够 ETH

---

## 📊 网络信息

| 网络 | Chain ID | RPC | 浏览器 |
|------|----------|-----|--------|
| Goerli | 5 | infura.io | goerli.etherscan.io |
| Sepolia | 11155111 | infura.io | sepolia.etherscan.io |
| Mainnet | 1 | infura.io | etherscan.io |
| Polygon | 137 | polygon-rpc.com | polygonscan.com |
| BSC | 56 | bsc-dataseed1.binance.org | bscscan.com |

---

## 🎯 最佳实践

### 1. 先测试后主网
```bash
# 始终先在测试网测试
--network goerli  # 测试
--network mainnet  # 生产
```

### 2. 保护私钥
```bash
# 不要提交 .env 到 Git
echo ".env" >> .gitignore
```

### 3. 验证配置
```javascript
// 使用前先验证
if (!ContractConfig.isConfigured('goerli')) {
    throw new Error('配置未完成');
}
```

### 4. 错误处理
```javascript
try {
    await web3.claimAirdrop();
} catch (error) {
    console.error('操作失败:', error);
    alert('操作失败: ' + error.message);
}
```

### 5. 交易确认
```javascript
const tx = await contract.transfer(to, amount);
await tx.wait();  // 等待确认
console.log('交易已确认');
```

---

## 🔗 外部资源

- 📚 [Ethers.js 文档](https://docs.ethers.org/v5/)
- 🦊 [MetaMask 文档](https://docs.metamask.io/)
- ⚙️ [Hardhat 文档](https://hardhat.org/docs)
- 🔍 [Etherscan API](https://docs.etherscan.io/)
- 💧 [Goerli Faucet](https://goerlifaucet.com/)

---

**保存此文件以便随时查阅！** 📌
