# 📺 Telegram 剧集详情页使用指南

## 📋 概述

`telegram-drama-detail.html` 是 SUK 短剧平台 Telegram Mini App 的剧集详情页面，提供完整的剧集信息展示和购买功能。

---

## ✨ 核心功能

### 1️⃣ 剧集信息展示

#### 封面横幅
- ✅ 高清封面图片
- ✅ 剧集标题
- ✅ 评分、播放量、集数统计
- ✅ 渐变叠加效果

#### 统计数据卡片
- ✅ 评分（Rating）
- ✅ 播放量（Views）
- ✅ 点赞数（Likes）
- ✅ 评论数（Comments）

#### 标签系统
- ✅ 剧集分类标签（爱情、都市、甜宠等）
- ✅ 高亮显示主要标签
- ✅ 横向滚动支持

---

### 2️⃣ 购买系统

#### 价格选项
**单集购买**:
- 灵活选择想看的集数
- 适合试看用户
- 价格：5 SUK / 集

**全集购买**:
- 一次性解锁所有剧集
- 享受 50% 折扣优惠
- 价格：50 SUK（原价 100 SUK）

#### 支付方式
1. **Telegram Stars ⭐**
   - Telegram 原生支付
   - 最快捷方便
   - 价格：100 Stars

2. **TON Coin 💎**
   - Telegram 官方加密货币
   - 去中心化支付
   - 价格：3 TON

3. **SUK Token 🪙**
   - 平台原生代币
   - 享受更多权益
   - 价格：50 SUK

---

### 3️⃣ 剧集列表

#### 功能特性
- ✅ 网格化展示（4列布局）
- ✅ 正序/倒序切换
- ✅ 免费集标记（绿色边框）
- ✅ 已观看标记（蓝色背景）
- ✅ 锁定集显示（🔒图标）

#### 响应式设计
- 手机：3列
- 平板：4列
- 桌面：4列

#### 剧集状态
```javascript
免费剧集: 绿色边框 + "免费"徽章
已观看: 蓝色背景 + "▶️ 已看"
未购买: 灰色 + 🔒 锁定图标
可播放: 正常显示，可点击
```

---

### 4️⃣ 剧情简介

#### 展开/收起功能
- 默认折叠显示前 3 行
- 点击"展开全部 ▼"查看完整简介
- 点击"收起 ▲"折叠简介
- 渐变遮罩效果

---

### 5️⃣ 演职人员

#### 显示信息
- 头像（emoji 或图片）
- 姓名
- 角色（男主角、女主角、导演、编剧等）

#### 横向滚动
- 支持左右滑动查看所有成员
- 固定宽度卡片设计

---

### 6️⃣ 用户评论

#### 评论内容
- 用户名
- 评分（⭐ 星级）
- 评论文字
- 发布时间

#### 特殊标记
- Premium 用户显示 ⭐ 徽章

---

### 7️⃣ 底部操作栏

#### 两个主要按钮

**收藏按钮**:
- 点击添加/取消收藏
- 🤍 → ❤️ 状态切换
- 本地状态保存

**购买/观看按钮**:
- 未购买：显示"立即购买"，打开支付弹窗
- 已购买：显示"立即观看"，跳转到播放器

---

## 🎨 UI/UX 特性

### Telegram 主题适配

自动读取并应用 Telegram 主题颜色：
```javascript
--tg-theme-bg-color         // 背景色
--tg-theme-text-color       // 文字色
--tg-theme-hint-color       // 提示色
--tg-theme-button-color     // 按钮色
--tg-theme-secondary-bg-color // 次要背景色
```

### 深色/浅色模式
- ✅ 自动跟随 Telegram 主题
- ✅ 无缝切换
- ✅ 所有元素适配

### 动画效果
- ✅ 页面滑入动画
- ✅ 卡片悬停效果
- ✅ 按钮点击反馈
- ✅ 加载 spinner 动画

---

## 🔗 页面跳转

### 进入方式
```
从剧集列表页点击剧集卡片:
telegram-app.html → telegram-drama-detail.html?id=drama_001
```

### 跳转到播放器
```
点击剧集号:
telegram-drama-detail.html → telegram-player.html?dramaId=xxx&episodeId=xxx
```

### 返回上一页
```
点击 Telegram 返回按钮:
telegram-drama-detail.html → telegram-app.html
```

---

## 📡 API 集成

### 获取剧集详情
```javascript
GET /api/telegram/dramas/:dramaId
Headers: {
    'X-Telegram-Init-Data': tg.initData
}

Response: {
    success: true,
    data: {
        id: 'drama_001',
        title: '霸道总裁爱上我',
        description: '剧情简介...',
        coverUrl: 'https://...',
        price: 50,
        priceStars: 100,
        priceTON: 3,
        episodes: [...],
        cast: [...],
        comments: [...],
        hasPurchased: false
    }
}
```

### 创建购买订单
```javascript
POST /api/telegram/invoice
Headers: {
    'Content-Type': 'application/json',
    'X-Telegram-Init-Data': tg.initData
}
Body: {
    dramaId: 'drama_001',
    paymentMethod: 'stars', // 'stars' | 'ton' | 'suk'
    purchaseType: 'full'    // 'single' | 'full'
}

Response: {
    success: true,
    invoiceUrl: 'https://t.me/invoice/...'
}
```

---

## 🎯 用户流程

### 场景 1: 免费观看
```
1. 进入剧集详情页
2. 查看剧集信息
3. 点击"第1集"（免费）
4. 跳转到播放器
5. 开始观看
```

### 场景 2: 单集购买
```
1. 进入剧集详情页
2. 选择"单集购买"
3. 点击"立即购买"
4. 选择支付方式（Stars/TON/SUK）
5. 完成支付
6. 点击"第2集"开始观看
```

### 场景 3: 全集购买
```
1. 进入剧集详情页
2. 选择"全集购买"（默认选中）
3. 点击"立即购买"
4. 选择支付方式
5. 完成支付
6. 页面显示"✓ 已购买全集"
7. 点击任意剧集开始观看
```

### 场景 4: 已购买用户
```
1. 进入剧集详情页
2. 自动显示"✓ 已购买全集"徽章
3. 价格卡片隐藏
4. 底部按钮显示"立即观看"
5. 点击按钮或剧集号开始观看
```

---

## 🔒 权限控制

### 剧集访问规则

| 剧集类型 | 是否可看 | UI 表现 |
|---------|---------|---------|
| 第1集（免费） | ✅ 所有用户 | 绿色边框 + "免费"徽章 |
| 其他集（未购买） | ❌ 需要购买 | 灰色 + 🔒 锁定 |
| 已购买剧集 | ✅ 可观看 | 正常显示 |

### 前端验证
```javascript
function playEpisode(episodeId, canPlay) {
    if (!canPlay) {
        tg.showAlert('请先购买该剧集');
        return;
    }
    // 跳转到播放器
}
```

### 后端验证
```javascript
// 在播放授权 API 中验证购买状态
GET /api/telegram/play-auth/:episodeId
// 检查用户是否购买该剧集或整部剧
```

---

## 📱 响应式设计

### 断点设置

```css
/* 手机 */
@media (max-width: 480px) {
    .stats-grid: 2列
    .episodes-grid: 3列
}

/* 平板 */
@media (min-width: 481px) and (max-width: 768px) {
    .stats-grid: 4列
    .episodes-grid: 4列
}

/* 桌面 */
@media (min-width: 769px) {
    .stats-grid: 4列
    .episodes-grid: 4列
}
```

---

## 🚀 性能优化

### 图片加载
- ✅ 使用占位符图片
- ✅ 懒加载优化（TODO）
- ✅ 响应式图片尺寸

### 数据缓存
- ✅ API 响应缓存（浏览器缓存）
- ✅ 用户状态本地存储（收藏状态）

### 动画性能
- ✅ 使用 CSS transform
- ✅ GPU 加速
- ✅ 避免布局抖动

---

## 🐛 错误处理

### 加载失败
```
显示错误页面:
- 😕 错误图标
- "加载失败"标题
- 错误信息
- "重新加载"按钮
```

### 网络超时
```
Fetch timeout: 30秒
超时后显示错误提示
提供重试选项
```

### 支付失败
```
捕获支付错误
显示 Telegram Alert
提示用户重试
```

---

## 🧪 测试要点

### 功能测试
- [ ] 剧集详情加载正常
- [ ] 价格选项切换正常
- [ ] 剧集列表渲染正确
- [ ] 免费集可以直接播放
- [ ] 付费集显示购买提示
- [ ] 支付弹窗正常打开/关闭
- [ ] 简介展开/收起功能正常
- [ ] 排序功能正常
- [ ] 收藏功能正常

### UI 测试
- [ ] 主题颜色正确应用
- [ ] 响应式布局在各设备正常
- [ ] 动画效果流畅
- [ ] 字体大小适中
- [ ] 间距合理

### 兼容性测试
- [ ] iOS Telegram
- [ ] Android Telegram
- [ ] Telegram Web
- [ ] 不同屏幕尺寸

---

## 📝 TODO 列表

### 高优先级
- [ ] 实现真实的购买状态检查
- [ ] 集成真实的支付 API
- [ ] 添加观看历史进度显示
- [ ] 优化图片加载（懒加载）

### 中优先级
- [ ] 添加分享功能
- [ ] 实现评论点赞功能
- [ ] 添加推荐剧集
- [ ] 实现收藏同步到服务器

### 低优先级
- [ ] 添加剧集预告片
- [ ] 实现弹幕功能
- [ ] 添加下载功能
- [ ] 实现多语言支持

---

## 🔗 相关文件

### 前端文件
- `telegram-drama-detail.html` - 剧集详情页（本文件）
- `telegram-app.html` - 剧集列表页
- `telegram-player.html` - 视频播放器（待创建）

### 后端文件
- `backend/controllers/telegram.controller.js` - Telegram API 控制器
- `backend/routes/telegram.routes.js` - Telegram 路由
- `backend/middleware/telegram-auth.middleware.js` - 认证中间件

### 文档
- `TELEGRAM_MINI_APP_GUIDE.md` - 完整开发指南
- `TELEGRAM_QUICK_START.md` - 快速入门
- `TESTING_GUIDE.md` - 测试指南

---

## 💡 使用建议

### 开发环境测试
```bash
# 1. 启动服务器
npm run dev

# 2. 启动 ngrok
ngrok http 3000

# 3. 在浏览器中打开（开发测试）
http://localhost:3000/telegram-drama-detail.html?id=drama_001

# 4. 在 Telegram 中测试
https://YOUR_NGROK_URL/telegram-drama-detail.html?id=drama_001
```

### 调试技巧
```javascript
// 在浏览器控制台中测试
console.log('当前剧集:', currentDrama);
console.log('Telegram 用户:', tg.initDataUnsafe.user);
console.log('主题参数:', tg.themeParams);

// 模拟已购买状态
currentDrama.hasPurchased = true;
renderDramaDetail(currentDrama);
```

---

## 📞 获取帮助

### 查看日志
```javascript
// 浏览器控制台
// 查看 API 请求
// 查看错误信息
```

### 常见问题
1. **页面空白**: 检查 API 是否正常响应
2. **主题颜色不对**: 确认在 Telegram 中打开
3. **支付不成功**: 检查 Bot Token 配置
4. **剧集无法播放**: 检查播放器页面是否存在

---

## ✅ 总结

`telegram-drama-detail.html` 提供了完整的剧集详情展示和购买功能，包括：

- ✅ 丰富的剧集信息展示
- ✅ 灵活的购买选项
- ✅ 多种支付方式
- ✅ 完整的剧集列表
- ✅ 演职人员和评论
- ✅ Telegram 主题适配
- ✅ 响应式设计
- ✅ 流畅的用户体验

**文件大小**: 37 KB  
**创建时间**: 2024-11-15  
**版本**: v1.0.0  
**状态**: ✅ 开发完成，待测试
