# SUKRAWBOT 配置和测试指南
# @SUKRAWBOT Setup and Testing Guide

> **🤖 您的 Telegram Bot 已创建完成**  
> Bot 用户名：**@SUKRAWBOT**  
> Bot Token：`7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg`

---

## 📋 目录

- [Bot 信息](#bot-信息)
- [快速配置](#快速配置)
- [详细配置步骤](#详细配置步骤)
- [测试指南](#测试指南)
- [常见问题](#常见问题)

---

## 🤖 Bot 信息

### 基本信息

| 项目 | 值 |
|------|-----|
| **Bot 用户名** | @SUKRAWBOT |
| **Bot ID** | 7176618798 |
| **Bot Token** | `7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg` |
| **创建时间** | 2024-11-16 |

### 配置的 URLs

| 类型 | URL |
|------|-----|
| **Webhook URL** | `https://api.suk.link/api/telegram/webhook` |
| **WebApp URL** | `https://suk.link/telegram-app.html` |
| **API Base** | `https://api.suk.link` |

---

## 🚀 快速配置

### 方式 A：使用自动配置脚本（推荐）⭐

```bash
# 1. 确保服务器已部署并运行
pm2 status

# 2. 进入项目目录
cd /opt/suk-platform/deployment

# 3. 添加执行权限
chmod +x telegram-sukrawbot-config.sh

# 4. 运行配置脚本
./telegram-sukrawbot-config.sh
```

**脚本会自动完成**：
- ✅ 获取 Bot 信息
- ✅ 删除旧的 Webhook
- ✅ 设置新的 Webhook
- ✅ 验证 Webhook 配置
- ✅ 测试 Webhook 端点
- ✅ 设置 Menu Button
- ✅ 设置 Bot 描述
- ✅ 设置 Bot 命令

### 方式 B：手动配置

如果您想手动配置，请参考下面的详细步骤。

---

## 📝 详细配置步骤

### 步骤 1：设置 Webhook

```bash
curl -X POST "https://api.telegram.org/bot7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg/setWebhook" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://api.suk.link/api/telegram/webhook",
    "allowed_updates": ["message", "callback_query", "pre_checkout_query", "inline_query"],
    "drop_pending_updates": true,
    "max_connections": 100
  }'
```

**预期响应**：
```json
{
  "ok": true,
  "result": true,
  "description": "Webhook was set"
}
```

---

### 步骤 2：验证 Webhook

```bash
curl "https://api.telegram.org/bot7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg/getWebhookInfo"
```

**预期响应**：
```json
{
  "ok": true,
  "result": {
    "url": "https://api.suk.link/api/telegram/webhook",
    "has_custom_certificate": false,
    "pending_update_count": 0,
    "max_connections": 100,
    "ip_address": "YOUR_SERVER_IP"
  }
}
```

**关键检查**：
- ✅ `url` 应该是 `https://api.suk.link/api/telegram/webhook`
- ✅ `pending_update_count` 应该是 0
- ✅ 没有 `last_error_message` 字段

---

### 步骤 3：设置 Menu Button

```bash
curl -X POST "https://api.telegram.org/bot7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg/setChatMenuButton" \
  -H "Content-Type: application/json" \
  -d '{
    "menu_button": {
      "type": "web_app",
      "text": "🎬 打开短剧平台",
      "web_app": {
        "url": "https://suk.link/telegram-app.html"
      }
    }
  }'
```

**预期响应**：
```json
{
  "ok": true,
  "result": true
}
```

---

### 步骤 4：设置 Bot 描述

#### 短描述
```bash
curl -X POST "https://api.telegram.org/bot7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg/setMyShortDescription" \
  -H "Content-Type: application/json" \
  -d '{
    "short_description": "SUK短剧平台 - 观看精彩竖屏短剧，支持SUK代币支付"
  }'
```

#### 详细描述
```bash
curl -X POST "https://api.telegram.org/bot7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg/setMyDescription" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "欢迎使用 SUK 短剧平台！\n\n🎬 海量精彩竖屏短剧\n💎 支持 SUK 代币、TON 和 Telegram Stars 支付\n📱 流畅的观看体验\n🔄 观看历史自动保存\n💬 评论互动功能\n\n点击菜单按钮开始观看！"
  }'
```

---

### 步骤 5：设置 Bot 命令

```bash
curl -X POST "https://api.telegram.org/bot7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg/setMyCommands" \
  -H "Content-Type: application/json" \
  -d '{
    "commands": [
      {"command": "start", "description": "🚀 开始使用"},
      {"command": "dramas", "description": "🎬 浏览短剧"},
      {"command": "wallet", "description": "💰 我的钱包"},
      {"command": "help", "description": "❓ 帮助信息"}
    ]
  }'
```

---

## ✅ 测试指南

### 测试 1：基础连接测试

#### 1.1 测试 Bot Token

```bash
curl "https://api.telegram.org/bot7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg/getMe"
```

**预期响应**：
```json
{
  "ok": true,
  "result": {
    "id": 7176618798,
    "is_bot": true,
    "first_name": "SUKRAW",
    "username": "SUKRAWBOT",
    "can_join_groups": true,
    "can_read_all_group_messages": false,
    "supports_inline_queries": false
  }
}
```

#### 1.2 测试 Webhook 端点

```bash
# 测试 Webhook URL 是否可访问
curl -I https://api.suk.link/api/telegram/webhook

# 预期：HTTP/2 200 或 HTTP/2 405
```

---

### 测试 2：Telegram 客户端测试

#### 2.1 搜索 Bot

1. 打开 Telegram 客户端（手机或电脑）
2. 在搜索框输入：`@SUKRAWBOT`
3. 点击搜索结果中的 Bot

**预期结果**：
- ✅ 显示 Bot 名称：SUKRAW
- ✅ 显示用户名：@SUKRAWBOT
- ✅ 显示 Bot 描述

#### 2.2 启动 Bot

1. 点击 **[开始]** 按钮
2. 或发送 `/start` 命令

**预期结果**：
- ✅ Bot 自动回复欢迎消息
- ✅ 底部出现 Menu Button（🎬 打开短剧平台）

#### 2.3 测试 Menu Button

1. 点击底部的 **Menu Button**（🎬 打开短剧平台）

**预期结果**：
- ✅ 打开 Mini App：`https://suk.link/telegram-app.html`
- ✅ 显示短剧列表
- ✅ 用户信息显示正确（头像、用户名）

---

### 测试 3：Mini App 功能测试

#### 3.1 短剧列表测试

**测试项**：
- [ ] 短剧列表正常加载
- [ ] 短剧封面图片显示
- [ ] 短剧标题和描述显示
- [ ] 价格信息显示（SUK/TON/Stars）
- [ ] 分类筛选功能工作

#### 3.2 短剧详情测试

**测试项**：
- [ ] 点击短剧进入详情页
- [ ] 剧集列表显示
- [ ] 第一集显示"免费"标签
- [ ] 其他集显示价格
- [ ] 播放按钮可用

#### 3.3 视频播放测试

**测试项**：
- [ ] 点击第一集（免费）
- [ ] 视频播放器加载
- [ ] 视频正常播放
- [ ] 全屏功能正常
- [ ] 进度条可拖动
- [ ] 音量控制正常

#### 3.4 观看历史测试

**测试项**：
- [ ] 观看进度自动保存
- [ ] 关闭后重新打开
- [ ] 显示"继续观看"提示
- [ ] 自动跳转到上次位置

#### 3.5 支付功能测试（重要）

##### Telegram Stars 支付测试

**步骤**：
1. 选择付费剧集
2. 点击"购买"按钮
3. 选择 Telegram Stars 支付
4. 完成支付流程

**预期结果**：
- [ ] 显示支付金额（Stars）
- [ ] 支付界面正常弹出
- [ ] 支付成功后自动解锁
- [ ] 可以正常播放

##### TON 支付测试

**步骤**：
1. 选择付费剧集
2. 选择 TON 支付
3. 扫描二维码或复制地址
4. 完成转账

**预期结果**：
- [ ] 显示 TON 钱包地址
- [ ] 显示支付金额
- [ ] 显示二维码
- [ ] 交易验证成功
- [ ] 自动解锁内容

##### SUK Token 支付测试

**步骤**：
1. 选择付费剧集
2. 选择 SUK Token 支付
3. 在钱包中完成转账
4. 等待交易确认

**预期结果**：
- [ ] 显示钱包地址
- [ ] 显示支付金额（SUK）
- [ ] 交易验证成功
- [ ] 购买记录保存

---

### 测试 4：后端日志检查

#### 4.1 查看应用日志

```bash
# PM2 日志
pm2 logs suk-platform --lines 100

# 过滤 Telegram 相关日志
pm2 logs | grep -i telegram

# 过滤错误日志
pm2 logs --err
```

**关键日志示例**：
```
✅ Telegram webhook received
✅ User authenticated: {user_id: 123456}
✅ Payment verified: {order_id: xxx, status: completed}
```

#### 4.2 查看 Nginx 日志

```bash
# API 访问日志
tail -f /var/log/nginx/api-suk-wtf-access.log | grep telegram

# 错误日志
tail -f /var/log/nginx/api-suk-wtf-error.log
```

#### 4.3 查看数据库

```bash
# 连接 MongoDB
mongosh -u admin -p

use suk_drama

# 查看订单
db.orders.find().sort({createdAt: -1}).limit(5).pretty()

# 查看购买记录
db.purchases.find().sort({createdAt: -1}).limit(5).pretty()

# 查看观看历史
db.watchhistories.find().sort({lastWatchedAt: -1}).limit(5).pretty()
```

---

## 🔍 常见问题

### 问题 1：Webhook 设置失败

**错误信息**：`Bad Request: bad webhook: HTTPS url must be provided for webhook`

**原因**：Webhook URL 必须是 HTTPS

**解决方案**：
```bash
# 确保 SSL 证书已安装
certbot certificates

# 确保 Nginx 配置正确
nginx -t
systemctl restart nginx

# 重新设置 Webhook
./telegram-sukrawbot-config.sh
```

---

### 问题 2：Menu Button 不显示

**可能原因**：
1. Menu Button 未正确设置
2. Telegram 客户端缓存

**解决方案**：
```bash
# 1. 重新设置 Menu Button
curl -X POST "https://api.telegram.org/bot7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg/setChatMenuButton" \
  -H "Content-Type: application/json" \
  -d '{"menu_button": {"type": "web_app", "text": "🎬 打开短剧平台", "web_app": {"url": "https://suk.link/telegram-app.html"}}}'

# 2. 清除 Telegram 客户端缓存
# - 手机：设置 → 数据和存储 → 清除缓存
# - 电脑：设置 → 高级 → 管理本地存储 → 清除所有数据

# 3. 重新打开 Bot
```

---

### 问题 3：Mini App 白屏或加载失败

**检查清单**：

1. **检查 WebApp URL 是否可访问**
```bash
curl -I https://suk.link/telegram-app.html
# 预期：HTTP/2 200
```

2. **检查文件是否存在**
```bash
ls -lh /opt/suk-platform/telegram-app.html
```

3. **检查 Nginx 配置**
```bash
nginx -t
systemctl restart nginx
```

4. **查看浏览器控制台**
- 在 Telegram Desktop 中：右键 → 检查元素 → Console
- 查看是否有 JavaScript 错误

---

### 问题 4：Webhook 接收不到消息

**检查步骤**：

1. **验证 Webhook 状态**
```bash
curl "https://api.telegram.org/bot7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg/getWebhookInfo"
```

2. **检查是否有错误**
```json
{
  "last_error_message": "Connection timeout",
  "last_error_date": 1700123456
}
```

3. **检查服务器防火墙**
```bash
ufw status
# 确保 80 和 443 端口开放
```

4. **检查应用是否运行**
```bash
pm2 status
# 确保 suk-platform 状态为 online
```

5. **测试 Webhook 端点**
```bash
curl -X POST https://api.suk.link/api/telegram/webhook \
  -H "Content-Type: application/json" \
  -d '{"test": true}'
```

---

### 问题 5：支付失败

#### Telegram Stars 支付失败

**检查**：
- [ ] Bot 是否已设置支付商户
- [ ] 访问 @BotFather，发送 `/mybots` → 选择 @SUKRAWBOT → Payments

#### TON 支付失败

**检查**：
- [ ] TON 钱包地址是否正确（.env 中的 `TON_WALLET_ADDRESS`）
- [ ] TON 服务是否正常
```bash
curl https://api.suk.link/api/health/detailed | jq .services.ton
```

#### SUK Token 支付失败

**检查**：
- [ ] 以太坊 RPC 连接是否正常
- [ ] 合约地址是否正确
- [ ] 平台钱包地址是否正确
```bash
curl https://api.suk.link/api/health/detailed | jq .services.suk
```

---

## 📊 验证配置

### 快速验证脚本

```bash
# 运行验证脚本
cd /opt/suk-platform/deployment
./telegram-sukrawbot-config.sh verify
```

**输出示例**：
```
╔════════════════════════════════════════════════════════╗
║        SUKRAWBOT Telegram Bot 配置脚本                ║
╚════════════════════════════════════════════════════════╝

[INFO] 获取 Bot 基本信息...
[SUCCESS] Bot 信息获取成功
  • Bot ID: 7176618798
  • Bot 名称: SUKRAW
  • Bot 用户名: @SUKRAWBOT

[INFO] 验证 Webhook 配置...
[SUCCESS] Webhook 验证完成
  • 当前 Webhook: https://api.suk.link/api/telegram/webhook
  • 待处理更新数: 0
[SUCCESS] 无错误记录

[INFO] 测试 Webhook 端点: https://api.suk.link/api/telegram/webhook
[SUCCESS] Webhook 端点可访问 (HTTP 200)
```

---

## 🎯 完整测试清单

### 部署前检查

- [ ] 服务器已部署并运行
- [ ] SSL 证书已安装
- [ ] DNS 解析正常
- [ ] 防火墙配置正确
- [ ] 应用正常运行（`pm2 status`）
- [ ] 数据库连接正常

### Bot 配置检查

- [ ] Webhook 设置成功
- [ ] Webhook 验证通过
- [ ] Menu Button 设置成功
- [ ] Bot 描述设置成功
- [ ] Bot 命令设置成功

### 功能测试检查

- [ ] Bot 可以搜索到
- [ ] Bot 可以启动
- [ ] Menu Button 显示正常
- [ ] Mini App 可以打开
- [ ] 短剧列表加载正常
- [ ] 视频可以播放
- [ ] 支付功能正常
- [ ] 观看历史保存正常
- [ ] 评论功能正常

---

## 📞 获取帮助

如果您在配置或测试过程中遇到问题：

1. **查看日志**
```bash
pm2 logs | grep -i error
tail -f /var/log/nginx/api-suk-wtf-error.log
```

2. **运行验证脚本**
```bash
./telegram-sukrawbot-config.sh verify
```

3. **检查健康状态**
```bash
curl https://api.suk.link/api/health/detailed | jq
```

4. **联系支持**
- 提供错误日志
- 提供 Webhook 验证结果
- 提供健康检查结果

---

## 🎉 配置完成

当所有测试通过后，您的 SUKRAWBOT 就可以正式上线了！

**下一步**：
1. 上传视频到阿里云 VoD
2. 在数据库中添加短剧数据
3. 邀请用户测试
4. 收集反馈并优化

---

**文档版本**: v1.0  
**更新时间**: 2024-11-16  
**Bot**: @SUKRAWBOT  
**域名**: suk.link

🎊 **祝您使用愉快！** 🎊
