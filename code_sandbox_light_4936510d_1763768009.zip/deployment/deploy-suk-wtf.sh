#!/bin/bash

# ============================================
# SUK.WTF 一键部署脚本
# One-Click Deployment Script for suk.link
# ============================================
# 
# 使用方法：
# 1. 下载脚本：wget https://raw.githubusercontent.com/YOUR_REPO/main/deployment/deploy-suk-wtf.sh
# 2. 添加执行权限：chmod +x deploy-suk-wtf.sh
# 3. 运行：sudo ./deploy-suk-wtf.sh
#
# 该脚本会自动完成：
# ✅ 系统环境检查和更新
# ✅ 安装必需软件（Node.js, Docker, MongoDB, Redis, Nginx）
# ✅ 克隆项目代码
# ✅ 配置环境变量
# ✅ 申请 SSL 证书
# ✅ 配置 Nginx
# ✅ 启动所有服务
# ✅ 健康检查
# ============================================

set -e  # 遇到错误立即退出

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 打印横幅
print_banner() {
    echo ""
    echo "╔════════════════════════════════════════════════════════╗"
    echo "║                                                        ║"
    echo "║          SUK.WTF 短剧平台 - 一键部署脚本              ║"
    echo "║          Drama Platform Deployment Script              ║"
    echo "║                                                        ║"
    echo "║          域名: suk.link                                 ║"
    echo "║          版本: v1.2.0                                  ║"
    echo "║                                                        ║"
    echo "╚════════════════════════════════════════════════════════╝"
    echo ""
}

# 检查是否以 root 运行
check_root() {
    if [ "$EUID" -ne 0 ]; then 
        log_error "请使用 root 权限运行此脚本"
        log_info "使用命令: sudo $0"
        exit 1
    fi
    log_success "权限检查通过"
}

# 检查系统版本
check_system() {
    log_info "检查系统版本..."
    
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$NAME
        VER=$VERSION_ID
        log_success "系统: $OS $VER"
        
        # 只支持 Ubuntu 和 Debian
        if [[ "$ID" != "ubuntu" && "$ID" != "debian" ]]; then
            log_warning "此脚本仅在 Ubuntu 和 Debian 上测试过"
            read -p "是否继续? (y/n): " continue
            if [ "$continue" != "y" ]; then
                exit 1
            fi
        fi
    else
        log_error "无法识别系统版本"
        exit 1
    fi
}

# 获取服务器 IP
get_server_ip() {
    SERVER_IP=$(curl -s https://api.ipify.org)
    if [ -z "$SERVER_IP" ]; then
        SERVER_IP=$(hostname -I | awk '{print $1}')
    fi
    log_info "服务器 IP: $SERVER_IP"
}

# 获取用户输入
get_user_input() {
    log_info "需要收集以下配置信息..."
    echo ""
    
    # 邮箱（用于 SSL 证书）
    read -p "请输入您的邮箱地址（用于 SSL 证书）: " USER_EMAIL
    if [ -z "$USER_EMAIL" ]; then
        log_error "邮箱地址不能为空"
        exit 1
    fi
    
    # MongoDB 密码
    read -sp "请输入 MongoDB 管理员密码: " MONGODB_PASSWORD
    echo ""
    if [ -z "$MONGODB_PASSWORD" ]; then
        log_error "MongoDB 密码不能为空"
        exit 1
    fi
    
    # Redis 密码
    read -sp "请输入 Redis 密码: " REDIS_PASSWORD
    echo ""
    if [ -z "$REDIS_PASSWORD" ]; then
        log_error "Redis 密码不能为空"
        exit 1
    fi
    
    # 阿里云 VoD
    read -p "请输入阿里云 AccessKey ID: " ALIYUN_ACCESS_KEY_ID
    read -sp "请输入阿里云 AccessKey Secret: " ALIYUN_ACCESS_KEY_SECRET
    echo ""
    
    # Telegram Bot
    read -p "请输入 Telegram Bot Token: " TELEGRAM_BOT_TOKEN
    read -p "请输入 Telegram Bot 用户名（不含@）: " TELEGRAM_BOT_USERNAME
    
    # 区块链配置
    read -p "请输入以太坊 RPC URL (Infura/Alchemy): " ETHEREUM_RPC_URL
    read -p "请输入平台收款钱包地址（以太坊）: " PLATFORM_WALLET_ADDRESS
    read -p "请输入 TON 钱包地址: " TON_WALLET_ADDRESS
    
    echo ""
    log_success "配置信息收集完成"
}

# 更新系统
update_system() {
    log_info "更新系统软件包..."
    apt-get update -y
    apt-get upgrade -y
    log_success "系统更新完成"
}

# 安装基础工具
install_basic_tools() {
    log_info "安装基础工具..."
    apt-get install -y \
        git \
        curl \
        wget \
        vim \
        build-essential \
        ufw \
        fail2ban \
        htop \
        net-tools
    log_success "基础工具安装完成"
}

# 安装 Node.js
install_nodejs() {
    log_info "安装 Node.js 18..."
    
    if command -v node &> /dev/null; then
        NODE_VERSION=$(node -v)
        log_warning "Node.js 已安装: $NODE_VERSION"
        read -p "是否重新安装? (y/n): " reinstall
        if [ "$reinstall" != "y" ]; then
            return
        fi
    fi
    
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt-get install -y nodejs
    
    NODE_VERSION=$(node -v)
    NPM_VERSION=$(npm -v)
    log_success "Node.js 安装完成: $NODE_VERSION, npm: $NPM_VERSION"
}

# 安装 Docker
install_docker() {
    log_info "安装 Docker..."
    
    if command -v docker &> /dev/null; then
        DOCKER_VERSION=$(docker -v)
        log_warning "Docker 已安装: $DOCKER_VERSION"
        read -p "是否重新安装? (y/n): " reinstall
        if [ "$reinstall" != "y" ]; then
            return
        fi
    fi
    
    # 安装 Docker
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    rm get-docker.sh
    
    # 安装 Docker Compose
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" \
        -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    
    # 启动 Docker
    systemctl start docker
    systemctl enable docker
    
    DOCKER_VERSION=$(docker -v)
    COMPOSE_VERSION=$(docker-compose -v)
    log_success "Docker 安装完成: $DOCKER_VERSION"
    log_success "Docker Compose 安装完成: $COMPOSE_VERSION"
}

# 安装 MongoDB
install_mongodb() {
    log_info "安装 MongoDB 6.0..."
    
    # 添加 MongoDB GPG 密钥
    wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | apt-key add -
    
    # 添加 MongoDB 源
    echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu $(lsb_release -sc)/mongodb-org/6.0 multiverse" \
        | tee /etc/apt/sources.list.d/mongodb-org-6.0.list
    
    # 更新并安装
    apt-get update -y
    apt-get install -y mongodb-org
    
    # 启动 MongoDB
    systemctl start mongod
    systemctl enable mongod
    
    # 等待 MongoDB 启动
    sleep 5
    
    log_success "MongoDB 安装完成"
}

# 配置 MongoDB
configure_mongodb() {
    log_info "配置 MongoDB..."
    
    # 创建管理员账号
    mongosh <<EOF
use admin
db.createUser({
  user: "admin",
  pwd: "$MONGODB_PASSWORD",
  roles: ["root"]
})
EOF
    
    # 启用认证
    sed -i 's/#security:/security:\n  authorization: enabled/' /etc/mongod.conf
    
    # 重启 MongoDB
    systemctl restart mongod
    
    log_success "MongoDB 配置完成"
}

# 安装 Redis
install_redis() {
    log_info "安装 Redis..."
    
    apt-get install -y redis-server
    
    # 配置 Redis
    sed -i "s/^bind 127.0.0.1/bind 0.0.0.0/" /etc/redis/redis.conf
    sed -i "s/^# requirepass foobared/requirepass $REDIS_PASSWORD/" /etc/redis/redis.conf
    sed -i "s/^# maxmemory <bytes>/maxmemory 256mb/" /etc/redis/redis.conf
    sed -i "s/^# maxmemory-policy noeviction/maxmemory-policy allkeys-lru/" /etc/redis/redis.conf
    
    # 重启 Redis
    systemctl restart redis
    systemctl enable redis
    
    log_success "Redis 安装完成"
}

# 安装 Nginx
install_nginx() {
    log_info "安装 Nginx..."
    
    apt-get install -y nginx
    
    # 停止 Nginx（稍后配置后再启动）
    systemctl stop nginx
    
    log_success "Nginx 安装完成"
}

# 配置防火墙
configure_firewall() {
    log_info "配置防火墙..."
    
    # 允许必要端口
    ufw allow 22/tcp    # SSH
    ufw allow 80/tcp    # HTTP
    ufw allow 443/tcp   # HTTPS
    
    # 启用防火墙
    ufw --force enable
    
    log_success "防火墙配置完成"
}

# 克隆项目代码
clone_project() {
    log_info "克隆项目代码..."
    
    PROJECT_DIR="/opt/suk-platform"
    
    if [ -d "$PROJECT_DIR" ]; then
        log_warning "项目目录已存在: $PROJECT_DIR"
        read -p "是否删除并重新克隆? (y/n): " reclone
        if [ "$reclone" == "y" ]; then
            rm -rf "$PROJECT_DIR"
        else
            return
        fi
    fi
    
    cd /opt
    git clone https://github.com/YOUR_USERNAME/drama-platform.git suk-platform
    cd suk-platform
    
    log_success "项目代码克隆完成"
}

# 配置环境变量
configure_env() {
    log_info "配置环境变量..."
    
    PROJECT_DIR="/opt/suk-platform"
    cd "$PROJECT_DIR"
    
    # 生成 JWT Secret
    JWT_SECRET=$(openssl rand -hex 64)
    
    # 创建 .env 文件
    cat > .env <<EOF
# ============================================
# SUK.WTF 生产环境配置
# ============================================

NODE_ENV=production
PORT=3000

# 域名配置
API_BASE_URL=https://api.suk.link
WEBAPP_URL=https://suk.link
CORS_ORIGIN=https://suk.link,https://www.suk.link,https://api.suk.link

# MongoDB
MONGODB_URI=mongodb://admin:$MONGODB_PASSWORD@localhost:27017/suk_drama?authSource=admin
MONGODB_ROOT_USER=admin
MONGODB_ROOT_PASSWORD=$MONGODB_PASSWORD
MONGODB_DATABASE=suk_drama
MONGODB_POOL_SIZE=10
MONGODB_TIMEOUT=5000

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=$REDIS_PASSWORD
REDIS_DB=0
REDIS_CONNECT_TIMEOUT=10000
REDIS_KEY_PREFIX=suk_drama:

# 阿里云 VoD
ALIYUN_ACCESS_KEY_ID=$ALIYUN_ACCESS_KEY_ID
ALIYUN_ACCESS_KEY_SECRET=$ALIYUN_ACCESS_KEY_SECRET
ALIYUN_VOD_REGION=cn-shanghai

# JWT
JWT_SECRET=$JWT_SECRET
JWT_EXPIRES_IN=7d

# 以太坊
ETHEREUM_RPC_URL=$ETHEREUM_RPC_URL
ETHEREUM_NETWORK=mainnet
SUK_TOKEN_CONTRACT=0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb
PLATFORM_WALLET_ADDRESS=$PLATFORM_WALLET_ADDRESS

# TON
TON_WALLET_ADDRESS=$TON_WALLET_ADDRESS
TON_NETWORK=mainnet

# Telegram Bot
TELEGRAM_BOT_TOKEN=$TELEGRAM_BOT_TOKEN
TELEGRAM_BOT_USERNAME=$TELEGRAM_BOT_USERNAME
TELEGRAM_WEBAPP_URL=https://suk.link/telegram-app.html
TELEGRAM_WEBHOOK_URL=https://api.suk.link/api/telegram/webhook

# 安全
FORCE_HTTPS=true
COOKIE_SECURE=true

# 视频播放
PLAY_AUTH_TIMEOUT=1800
PLAY_AUTH_CACHE_TTL=1500
VIDEO_ENCRYPT_TYPE=1

# 日志
LOG_LEVEL=info
LOG_FILE=/var/log/suk-platform.log
EOF
    
    # 设置权限
    chmod 600 .env
    
    log_success "环境变量配置完成"
}

# 安装项目依赖
install_dependencies() {
    log_info "安装项目依赖..."
    
    PROJECT_DIR="/opt/suk-platform"
    cd "$PROJECT_DIR"
    
    npm ci --production
    
    log_success "项目依赖安装完成"
}

# 申请 SSL 证书
request_ssl() {
    log_info "申请 SSL 证书..."
    
    # 安装 Certbot
    apt-get install -y certbot python3-certbot-nginx
    
    # 申请证书
    certbot certonly --nginx \
        -d suk.link \
        -d www.suk.link \
        -d api.suk.link \
        -d monitor.suk.link \
        --email "$USER_EMAIL" \
        --agree-tos \
        --non-interactive \
        --no-eff-email
    
    # 设置自动续期
    echo "0 2 * * * certbot renew --quiet --post-hook 'systemctl reload nginx'" | crontab -
    
    log_success "SSL 证书申请完成"
}

# 配置 Nginx
configure_nginx() {
    log_info "配置 Nginx..."
    
    PROJECT_DIR="/opt/suk-platform"
    
    # 复制 Nginx 配置
    cp "$PROJECT_DIR/deployment/nginx-suk-wtf.conf" /etc/nginx/sites-available/suk.link
    
    # 删除默认配置
    rm -f /etc/nginx/sites-enabled/default
    
    # 启用配置
    ln -sf /etc/nginx/sites-available/suk.link /etc/nginx/sites-enabled/
    
    # 测试配置
    nginx -t
    
    # 重启 Nginx
    systemctl restart nginx
    systemctl enable nginx
    
    log_success "Nginx 配置完成"
}

# 初始化数据库
initialize_database() {
    log_info "初始化数据库..."
    
    PROJECT_DIR="/opt/suk-platform"
    cd "$PROJECT_DIR"
    
    node scripts/init-db.js --seed
    
    log_success "数据库初始化完成"
}

# 启动应用
start_application() {
    log_info "启动应用..."
    
    PROJECT_DIR="/opt/suk-platform"
    cd "$PROJECT_DIR"
    
    # 安装 PM2
    npm install -g pm2
    
    # 启动应用
    pm2 start ecosystem.config.js --env production
    
    # 保存配置
    pm2 save
    
    # 设置开机自启
    pm2 startup systemd -u root --hp /root
    
    log_success "应用启动完成"
}

# 配置 Telegram Webhook
configure_telegram() {
    log_info "配置 Telegram Webhook..."
    
    # 等待应用完全启动
    sleep 10
    
    # 检测是否是 SUKRAWBOT
    if [ "$TELEGRAM_BOT_USERNAME" == "SUKRAWBOT" ]; then
        log_info "检测到 SUKRAWBOT，使用专用配置..."
        
        # 使用专用配置脚本
        if [ -f "$PROJECT_DIR/deployment/telegram-sukrawbot-config.sh" ]; then
            cd "$PROJECT_DIR/deployment"
            chmod +x telegram-sukrawbot-config.sh
            ./telegram-sukrawbot-config.sh
        else
            log_warning "未找到 SUKRAWBOT 专用配置脚本，使用通用配置"
        fi
    else
        # 通用 Telegram 配置
        # 设置 Webhook
        curl -X POST "https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/setWebhook" \
            -H "Content-Type: application/json" \
            -d "{
                \"url\": \"https://api.suk.link/api/telegram/webhook\",
                \"allowed_updates\": [\"message\", \"callback_query\", \"pre_checkout_query\"]
            }"
        
        # 设置 Menu Button
        curl -X POST "https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/setChatMenuButton" \
            -H "Content-Type: application/json" \
            -d "{
                \"menu_button\": {
                    \"type\": \"web_app\",
                    \"text\": \"🎬 打开短剧平台\",
                    \"web_app\": {
                        \"url\": \"https://suk.link/telegram-app.html\"
                    }
                }
            }"
    fi
    
    log_success "Telegram Webhook 配置完成"
}

# 健康检查
health_check() {
    log_info "执行健康检查..."
    
    # 等待服务启动
    sleep 5
    
    # 检查主站
    if curl -f -s https://suk.link > /dev/null; then
        log_success "✓ 主站正常: https://suk.link"
    else
        log_error "✗ 主站异常: https://suk.link"
    fi
    
    # 检查 API
    if curl -f -s https://api.suk.link/api/health > /dev/null; then
        log_success "✓ API 正常: https://api.suk.link/api/health"
    else
        log_error "✗ API 异常: https://api.suk.link/api/health"
    fi
    
    # 检查 MongoDB
    if systemctl is-active --quiet mongod; then
        log_success "✓ MongoDB 运行中"
    else
        log_error "✗ MongoDB 未运行"
    fi
    
    # 检查 Redis
    if systemctl is-active --quiet redis; then
        log_success "✓ Redis 运行中"
    else
        log_error "✗ Redis 未运行"
    fi
    
    # 检查 Nginx
    if systemctl is-active --quiet nginx; then
        log_success "✓ Nginx 运行中"
    else
        log_error "✗ Nginx 未运行"
    fi
}

# 打印部署总结
print_summary() {
    echo ""
    echo "╔════════════════════════════════════════════════════════╗"
    echo "║                                                        ║"
    echo "║              🎉 部署完成！Deployment Complete!         ║"
    echo "║                                                        ║"
    echo "╚════════════════════════════════════════════════════════╝"
    echo ""
    log_info "访问地址:"
    echo "  • 主站: https://suk.link"
    echo "  • API: https://api.suk.link"
    echo "  • 监控: https://monitor.suk.link:3001"
    echo "  • Telegram Bot: @$TELEGRAM_BOT_USERNAME"
    echo ""
    log_info "服务状态:"
    echo "  • 查看应用日志: pm2 logs"
    echo "  • 查看应用状态: pm2 status"
    echo "  • 查看 Nginx 日志: tail -f /var/log/nginx/suk-wtf-access.log"
    echo ""
    log_info "下一步:"
    echo "  1. 在 Telegram 搜索并打开您的 Bot"
    echo "  2. 点击 Menu Button 测试 Mini App"
    echo "  3. 访问 https://suk.link 测试网站"
    echo "  4. 上传视频到阿里云 VoD"
    echo "  5. 在数据库中添加短剧数据"
    echo ""
    log_success "部署完成！祝您使用愉快！🚀"
    echo ""
}

# ============================================
# 主函数
# ============================================
main() {
    print_banner
    check_root
    check_system
    get_server_ip
    get_user_input
    
    log_info "开始部署..."
    echo ""
    
    update_system
    install_basic_tools
    install_nodejs
    install_docker
    install_mongodb
    configure_mongodb
    install_redis
    install_nginx
    configure_firewall
    clone_project
    configure_env
    install_dependencies
    request_ssl
    configure_nginx
    initialize_database
    start_application
    configure_telegram
    health_check
    print_summary
}

# 运行主函数
main
