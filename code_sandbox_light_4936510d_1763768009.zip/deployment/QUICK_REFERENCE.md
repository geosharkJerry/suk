# SUK.WTF 快速参考手册
# Quick Reference Guide for suk.link

> **🚀 最常用命令和配置速查表**

---

## 📋 目录

- [域名配置](#域名配置)
- [常用命令](#常用命令)
- [服务管理](#服务管理)
- [日志查看](#日志查看)
- [监控查看](#监控查看)
- [故障排查](#故障排查)
- [备份恢复](#备份恢复)

---

## 🌐 域名配置

### 域名列表

| 域名 | 用途 | 指向 |
|------|------|------|
| `suk.link` | 主站 | Nginx → 静态文件 |
| `www.suk.link` | 主站（别名） | 重定向到 suk.link |
| `api.suk.link` | API 服务 | Nginx → Node.js:3000 |
| `monitor.suk.link` | 监控面板 | Nginx → Grafana:3001 |

### DNS 配置（GoDaddy）

```
类型: A   | 名称: @       | 值: YOUR_SERVER_IP | TTL: 600
类型: A   | 名称: www     | 值: YOUR_SERVER_IP | TTL: 600
类型: A   | 名称: api     | 值: YOUR_SERVER_IP | TTL: 600
类型: A   | 名称: monitor | 值: YOUR_SERVER_IP | TTL: 600
```

---

## ⚡ 常用命令

### 一键部署

```bash
# 下载部署脚本
wget https://raw.githubusercontent.com/YOUR_REPO/main/deployment/deploy-suk-wtf.sh

# 执行部署
sudo bash deploy-suk-wtf.sh
```

### 手动部署关键步骤

```bash
# 1. 克隆代码
cd /opt
git clone https://github.com/YOUR_REPO/drama-platform.git suk-platform
cd suk-platform

# 2. 配置环境
cp .env.example .env
nano .env  # 填写配置

# 3. 安装依赖
npm ci --production

# 4. 初始化数据库
node scripts/init-db.js --seed

# 5. 启动应用
pm2 start ecosystem.config.js --env production
pm2 save

# 6. 配置 Nginx
cp deployment/nginx-suk-wtf.conf /etc/nginx/sites-available/suk.link
ln -s /etc/nginx/sites-available/suk.link /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

---

## 🔧 服务管理

### PM2（应用进程）

```bash
# 查看状态
pm2 status

# 查看日志
pm2 logs
pm2 logs suk-platform --lines 100

# 重启应用
pm2 restart suk-platform

# 停止应用
pm2 stop suk-platform

# 删除应用
pm2 delete suk-platform

# 重新加载（无停机）
pm2 reload suk-platform

# 监控
pm2 monit
```

### Nginx

```bash
# 测试配置
nginx -t

# 重启
systemctl restart nginx

# 重载配置（无停机）
systemctl reload nginx

# 查看状态
systemctl status nginx

# 启停
systemctl stop nginx
systemctl start nginx
```

### MongoDB

```bash
# 状态
systemctl status mongod

# 重启
systemctl restart mongod

# 连接
mongosh -u admin -p

# 查看数据库
mongosh -u admin -p
use suk_drama
show collections
db.stats()
```

### Redis

```bash
# 状态
systemctl status redis

# 重启
systemctl restart redis

# 连接
redis-cli -a YOUR_PASSWORD

# 查看信息
redis-cli -a YOUR_PASSWORD INFO
redis-cli -a YOUR_PASSWORD DBSIZE

# 清空缓存
redis-cli -a YOUR_PASSWORD FLUSHDB
```

### Docker（如使用 Docker 部署）

```bash
# 查看容器
docker-compose ps

# 查看日志
docker-compose logs -f

# 重启服务
docker-compose restart

# 停止所有服务
docker-compose down

# 启动所有服务
docker-compose up -d

# 重建容器
docker-compose up -d --build
```

---

## 📊 日志查看

### 应用日志

```bash
# PM2 日志
pm2 logs suk-platform --lines 50

# 实时日志
pm2 logs --lines 100 --raw

# 错误日志
pm2 logs --err

# 清空日志
pm2 flush
```

### Nginx 日志

```bash
# 访问日志
tail -f /var/log/nginx/suk-wtf-access.log

# 错误日志
tail -f /var/log/nginx/suk-wtf-error.log

# API 日志
tail -f /var/log/nginx/api-suk-wtf-access.log

# 查看最近100行
tail -n 100 /var/log/nginx/suk-wtf-access.log
```

### 系统日志

```bash
# MongoDB 日志
tail -f /var/log/mongodb/mongod.log

# Redis 日志
tail -f /var/log/redis/redis-server.log

# 系统日志
journalctl -u mongod -f
journalctl -u redis -f
journalctl -u nginx -f
```

---

## 📈 监控查看

### 访问监控界面

```bash
# Grafana（监控面板）
https://monitor.suk.link:3001
账号: admin
密码: admin（首次登录需修改）

# Prometheus（指标数据）
https://monitor.suk.link:9090
```

### 健康检查 API

```bash
# 基础健康检查
curl https://api.suk.link/api/health

# 详细健康检查
curl https://api.suk.link/api/health/detailed | jq

# 系统指标
curl https://api.suk.link/api/health/metrics | jq

# Kubernetes 就绪探针
curl https://api.suk.link/api/health/ready

# Kubernetes 存活探针
curl https://api.suk.link/api/health/live
```

### 系统资源监控

```bash
# CPU 和内存
htop

# 磁盘使用
df -h

# 内存详情
free -h

# 网络连接
netstat -tlnp

# 进程查看
ps aux | grep node
ps aux | grep nginx
```

---

## 🔍 故障排查

### 应用无法启动

```bash
# 1. 查看错误日志
pm2 logs --err --lines 50

# 2. 检查端口占用
netstat -tlnp | grep :3000

# 3. 检查环境变量
cat /opt/suk-platform/.env

# 4. 手动启动查看详细错误
cd /opt/suk-platform
node server.js

# 5. 检查依赖
npm ls
```

### 网站无法访问

```bash
# 1. 检查 Nginx 状态
systemctl status nginx
nginx -t

# 2. 检查 DNS 解析
nslookup suk.link
dig suk.link +short

# 3. 检查防火墙
ufw status
iptables -L

# 4. 检查端口监听
netstat -tlnp | grep :80
netstat -tlnp | grep :443

# 5. 测试本地访问
curl http://localhost
curl http://localhost:3000/api/health
```

### SSL 证书问题

```bash
# 查看证书信息
certbot certificates

# 测试证书
openssl s_client -connect suk.link:443 -servername suk.link

# 重新申请证书
certbot delete --cert-name suk.link
certbot certonly --nginx -d suk.link -d www.suk.link -d api.suk.link

# 手动续期
certbot renew

# 测试续期
certbot renew --dry-run
```

### 数据库连接失败

```bash
# MongoDB
# 1. 检查服务状态
systemctl status mongod

# 2. 查看日志
tail -50 /var/log/mongodb/mongod.log

# 3. 测试连接
mongosh -u admin -p

# 4. 检查配置
cat /etc/mongod.conf

# Redis
# 1. 检查服务状态
systemctl status redis

# 2. 测试连接
redis-cli -a YOUR_PASSWORD PING

# 3. 检查配置
cat /etc/redis/redis.conf
```

### Telegram Webhook 失败

```bash
# 查看 Webhook 状态
curl "https://api.telegram.org/bot<YOUR_TOKEN>/getWebhookInfo"

# 删除 Webhook
curl -X POST "https://api.telegram.org/bot<YOUR_TOKEN>/deleteWebhook"

# 重新设置 Webhook
curl -X POST "https://api.telegram.org/bot<YOUR_TOKEN>/setWebhook" \
  -d "url=https://api.suk.link/api/telegram/webhook"

# 测试 Webhook 端点
curl https://api.suk.link/api/telegram/webhook
```

---

## 💾 备份恢复

### 手动备份

```bash
# 执行备份脚本
/opt/backup-suk-wtf.sh

# 查看备份文件
ls -lh /var/backups/suk-wtf/
```

### 自动备份设置

```bash
# 添加定时任务
crontab -e

# 每天凌晨2点自动备份
0 2 * * * /opt/backup-suk-wtf.sh >> /var/log/suk-backup.log 2>&1
```

### 恢复备份

```bash
# 1. 停止应用
pm2 stop all
systemctl stop mongod

# 2. 恢复 MongoDB
mongorestore \
  --uri="mongodb://admin:PASSWORD@localhost:27017" \
  --gzip \
  /var/backups/suk-wtf/backup_YYYYMMDD_HHMMSS/mongodb/

# 3. 恢复 Redis
cp /var/backups/suk-wtf/backup_YYYYMMDD_HHMMSS/redis/dump.rdb /var/lib/redis/
chown redis:redis /var/lib/redis/dump.rdb

# 4. 恢复配置文件
cp /var/backups/suk-wtf/backup_YYYYMMDD_HHMMSS/configs/.env /opt/suk-platform/

# 5. 重启服务
systemctl start mongod
pm2 restart all
```

---

## 🔐 安全检查

### 定期检查清单

```bash
# 1. 更新系统
apt-get update && apt-get upgrade -y

# 2. 检查 SSL 证书有效期
certbot certificates

# 3. 检查防火墙规则
ufw status

# 4. 检查失败登录
grep "Failed password" /var/log/auth.log | tail -20

# 5. 检查磁盘空间
df -h

# 6. 检查备份状态
ls -lh /var/backups/suk-wtf/

# 7. 检查应用状态
pm2 status
systemctl status nginx mongod redis
```

---

## 📞 紧急联系

### 关键文件位置

```
项目目录: /opt/suk-platform
配置文件: /opt/suk-platform/.env
Nginx配置: /etc/nginx/sites-available/suk.link
SSL证书: /etc/letsencrypt/live/suk.link/
备份目录: /var/backups/suk-wtf/
日志目录: /var/log/nginx/, /var/log/mongodb/
```

### 紧急重启

```bash
# 快速重启所有服务
systemctl restart nginx mongod redis && pm2 restart all

# 如果问题严重，重启服务器
reboot
```

---

## 🎯 性能优化

### 清理操作

```bash
# 清理 PM2 日志
pm2 flush

# 清理 Nginx 日志
truncate -s 0 /var/log/nginx/*.log

# 清理旧日志
find /var/log -name "*.log" -mtime +7 -delete

# 清理 Docker（如使用）
docker system prune -af
```

### 数据库优化

```bash
# MongoDB 索引优化
mongosh -u admin -p
use suk_drama
db.getCollectionNames().forEach(function(col) {
    print(col + ":");
    printjson(db[col].getIndexes());
});

# Redis 内存优化
redis-cli -a YOUR_PASSWORD INFO memory
```

---

## 📚 完整文档

详细文档请参考：

- 📖 **部署指南**: `/opt/suk-platform/deployment/SUK_WTF_DEPLOYMENT_GUIDE.md`
- 📖 **API文档**: `/opt/suk-platform/API.md`
- 📖 **测试指南**: `/opt/suk-platform/TESTING.md`
- 📖 **监控指南**: `/opt/suk-platform/MONITORING_GUIDE.md`

---

**快速参考版本**: v1.0  
**更新时间**: 2024-11-16  
**适用域名**: suk.link
