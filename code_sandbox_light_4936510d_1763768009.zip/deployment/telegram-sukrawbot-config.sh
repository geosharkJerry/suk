#!/bin/bash

# ============================================
# SUKRAWBOT Telegram Bot 配置脚本
# Telegram Bot Configuration for SUKRAWBOT
# ============================================
#
# Bot 信息：
# - Bot 用户名: @SUKRAWBOT
# - Bot Token: 7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg
#
# 功能：
# ✅ 设置 Webhook
# ✅ 配置 Menu Button
# ✅ 设置 Bot 描述和头像
# ✅ 验证配置
# ============================================

set -e

# Bot 配置
BOT_TOKEN="7176618798:AAH2S-UovntgnE8XyGxITQLmogcD9xdqEGg"
BOT_USERNAME="SUKRAWBOT"
WEBHOOK_URL="https://api.suk.link/api/telegram/webhook"
WEBAPP_URL="https://suk.link/telegram-app.html"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_banner() {
    echo ""
    echo "╔════════════════════════════════════════════════════════╗"
    echo "║                                                        ║"
    echo "║        SUKRAWBOT Telegram Bot 配置脚本                ║"
    echo "║        Bot Configuration Script                        ║"
    echo "║                                                        ║"
    echo "║        Bot: @SUKRAWBOT                                 ║"
    echo "║        Domain: suk.link                                 ║"
    echo "║                                                        ║"
    echo "╚════════════════════════════════════════════════════════╝"
    echo ""
}

# 获取 Bot 信息
get_bot_info() {
    log_info "获取 Bot 基本信息..."
    
    RESPONSE=$(curl -s "https://api.telegram.org/bot${BOT_TOKEN}/getMe")
    
    if echo "$RESPONSE" | grep -q '"ok":true'; then
        BOT_ID=$(echo "$RESPONSE" | grep -o '"id":[0-9]*' | head -1 | cut -d':' -f2)
        BOT_NAME=$(echo "$RESPONSE" | grep -o '"first_name":"[^"]*"' | cut -d'"' -f4)
        
        log_success "Bot 信息获取成功"
        echo "  • Bot ID: $BOT_ID"
        echo "  • Bot 名称: $BOT_NAME"
        echo "  • Bot 用户名: @$BOT_USERNAME"
    else
        log_error "无法获取 Bot 信息，请检查 Token 是否正确"
        echo "$RESPONSE"
        exit 1
    fi
    echo ""
}

# 删除旧的 Webhook（如果存在）
delete_webhook() {
    log_info "删除旧的 Webhook 配置..."
    
    RESPONSE=$(curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/deleteWebhook")
    
    if echo "$RESPONSE" | grep -q '"ok":true'; then
        log_success "旧 Webhook 已删除"
    else
        log_warning "删除 Webhook 失败或无旧配置"
    fi
    echo ""
}

# 设置新的 Webhook
set_webhook() {
    log_info "设置新的 Webhook: $WEBHOOK_URL"
    
    RESPONSE=$(curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/setWebhook" \
        -H "Content-Type: application/json" \
        -d "{
            \"url\": \"$WEBHOOK_URL\",
            \"allowed_updates\": [\"message\", \"callback_query\", \"pre_checkout_query\", \"inline_query\"],
            \"drop_pending_updates\": true,
            \"max_connections\": 100
        }")
    
    if echo "$RESPONSE" | grep -q '"ok":true'; then
        log_success "Webhook 设置成功"
        echo "  • URL: $WEBHOOK_URL"
        echo "  • 允许的更新类型: message, callback_query, pre_checkout_query, inline_query"
    else
        log_error "Webhook 设置失败"
        echo "$RESPONSE"
        exit 1
    fi
    echo ""
}

# 验证 Webhook
verify_webhook() {
    log_info "验证 Webhook 配置..."
    
    RESPONSE=$(curl -s "https://api.telegram.org/bot${BOT_TOKEN}/getWebhookInfo")
    
    if echo "$RESPONSE" | grep -q '"ok":true'; then
        WEBHOOK_SET=$(echo "$RESPONSE" | grep -o '"url":"[^"]*"' | cut -d'"' -f4)
        PENDING_COUNT=$(echo "$RESPONSE" | grep -o '"pending_update_count":[0-9]*' | cut -d':' -f2)
        LAST_ERROR=$(echo "$RESPONSE" | grep -o '"last_error_message":"[^"]*"' | cut -d'"' -f4)
        
        log_success "Webhook 验证完成"
        echo "  • 当前 Webhook: $WEBHOOK_SET"
        echo "  • 待处理更新数: ${PENDING_COUNT:-0}"
        
        if [ -n "$LAST_ERROR" ]; then
            log_warning "上次错误: $LAST_ERROR"
        else
            log_success "无错误记录"
        fi
    else
        log_error "无法获取 Webhook 信息"
        echo "$RESPONSE"
    fi
    echo ""
}

# 测试 Webhook 端点
test_webhook_endpoint() {
    log_info "测试 Webhook 端点: $WEBHOOK_URL"
    
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$WEBHOOK_URL")
    
    if [ "$HTTP_CODE" == "200" ] || [ "$HTTP_CODE" == "405" ]; then
        log_success "Webhook 端点可访问 (HTTP $HTTP_CODE)"
    else
        log_error "Webhook 端点不可访问 (HTTP $HTTP_CODE)"
        log_warning "请确保服务器已启动并且 Nginx 配置正确"
    fi
    echo ""
}

# 设置 Menu Button
set_menu_button() {
    log_info "设置 Menu Button（菜单按钮）..."
    
    RESPONSE=$(curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/setChatMenuButton" \
        -H "Content-Type: application/json" \
        -d "{
            \"menu_button\": {
                \"type\": \"web_app\",
                \"text\": \"🎬 打开短剧平台\",
                \"web_app\": {
                    \"url\": \"$WEBAPP_URL\"
                }
            }
        }")
    
    if echo "$RESPONSE" | grep -q '"ok":true'; then
        log_success "Menu Button 设置成功"
        echo "  • 按钮文字: 🎬 打开短剧平台"
        echo "  • WebApp URL: $WEBAPP_URL"
    else
        log_error "Menu Button 设置失败"
        echo "$RESPONSE"
        exit 1
    fi
    echo ""
}

# 设置 Bot 描述
set_bot_description() {
    log_info "设置 Bot 描述..."
    
    # 设置短描述
    RESPONSE=$(curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/setMyShortDescription" \
        -H "Content-Type: application/json" \
        -d '{
            "short_description": "SUK短剧平台 - 观看精彩竖屏短剧，支持SUK代币支付"
        }')
    
    if echo "$RESPONSE" | grep -q '"ok":true'; then
        log_success "短描述设置成功"
    fi
    
    # 设置详细描述
    RESPONSE=$(curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/setMyDescription" \
        -H "Content-Type: application/json" \
        -d '{
            "description": "欢迎使用 SUK 短剧平台！\n\n🎬 海量精彩竖屏短剧\n💎 支持 SUK 代币、TON 和 Telegram Stars 支付\n📱 流畅的观看体验\n🔄 观看历史自动保存\n💬 评论互动功能\n\n点击菜单按钮开始观看！"
        }')
    
    if echo "$RESPONSE" | grep -q '"ok":true'; then
        log_success "详细描述设置成功"
    fi
    echo ""
}

# 设置 Bot 命令
set_bot_commands() {
    log_info "设置 Bot 命令..."
    
    RESPONSE=$(curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/setMyCommands" \
        -H "Content-Type: application/json" \
        -d '{
            "commands": [
                {"command": "start", "description": "🚀 开始使用"},
                {"command": "dramas", "description": "🎬 浏览短剧"},
                {"command": "wallet", "description": "💰 我的钱包"},
                {"command": "help", "description": "❓ 帮助信息"}
            ]
        }')
    
    if echo "$RESPONSE" | grep -q '"ok":true'; then
        log_success "Bot 命令设置成功"
        echo "  • /start - 开始使用"
        echo "  • /dramas - 浏览短剧"
        echo "  • /wallet - 我的钱包"
        echo "  • /help - 帮助信息"
    else
        log_warning "Bot 命令设置失败（可选功能）"
    fi
    echo ""
}

# 发送测试消息
send_test_message() {
    log_info "发送测试消息..."
    echo ""
    log_warning "请在 Telegram 中搜索并打开 @SUKRAWBOT"
    log_warning "点击 [开始] 按钮，然后查看是否收到测试消息"
    echo ""
    read -p "按回车键继续..."
}

# 打印配置总结
print_summary() {
    echo ""
    echo "╔════════════════════════════════════════════════════════╗"
    echo "║                                                        ║"
    echo "║          ✅ SUKRAWBOT 配置完成！                       ║"
    echo "║                                                        ║"
    echo "╚════════════════════════════════════════════════════════╝"
    echo ""
    
    log_info "配置总结："
    echo ""
    echo "🤖 Bot 信息："
    echo "  • 用户名: @SUKRAWBOT"
    echo "  • Bot ID: 7176618798"
    echo ""
    echo "🔗 配置的 URLs："
    echo "  • Webhook: https://api.suk.link/api/telegram/webhook"
    echo "  • WebApp: https://suk.link/telegram-app.html"
    echo ""
    echo "✅ 已完成配置："
    echo "  • Webhook 设置"
    echo "  • Menu Button 配置"
    echo "  • Bot 描述设置"
    echo "  • Bot 命令设置"
    echo ""
    
    log_info "下一步："
    echo "  1. 在 Telegram 搜索 @SUKRAWBOT"
    echo "  2. 点击 [开始] 按钮"
    echo "  3. 点击底部 Menu Button（🎬 打开短剧平台）"
    echo "  4. 测试 Mini App 是否正常加载"
    echo ""
    
    log_info "测试命令："
    echo "  • 验证配置: ./telegram-sukrawbot-config.sh verify"
    echo "  • 查看日志: pm2 logs | grep telegram"
    echo ""
    
    log_success "配置完成！祝您使用愉快！🎉"
    echo ""
}

# 仅验证配置
verify_only() {
    print_banner
    get_bot_info
    verify_webhook
    test_webhook_endpoint
}

# 主函数
main() {
    # 检查是否是验证模式
    if [ "$1" == "verify" ]; then
        verify_only
        exit 0
    fi
    
    print_banner
    
    log_info "开始配置 SUKRAWBOT..."
    echo ""
    
    # 执行配置步骤
    get_bot_info
    delete_webhook
    set_webhook
    verify_webhook
    test_webhook_endpoint
    set_menu_button
    set_bot_description
    set_bot_commands
    
    # 打印总结
    print_summary
}

# 运行主函数
main "$@"
