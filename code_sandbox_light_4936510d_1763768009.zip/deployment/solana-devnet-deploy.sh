#!/bin/bash

################################################################################
# SUK Protocol - Solana Devnet Deployment Script
# 
# This script deploys all Solana smart contracts to Devnet
# Usage: ./solana-devnet-deploy.sh
################################################################################

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print functions
print_header() {
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}  $1${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ $1${NC}"
}

# Check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

################################################################################
# Step 1: Environment Check
################################################################################

print_header "Step 1: Checking Environment"

# Check Solana CLI
if ! command_exists solana; then
    print_error "Solana CLI not found. Please install it first:"
    echo "  sh -c \"\$(curl -sSfL https://release.solana.com/stable/install)\""
    exit 1
fi
print_success "Solana CLI found: $(solana --version)"

# Check Anchor CLI
if ! command_exists anchor; then
    print_error "Anchor CLI not found. Please install it first:"
    echo "  cargo install --git https://github.com/coral-xyz/anchor anchor-cli --locked"
    exit 1
fi
print_success "Anchor CLI found: $(anchor --version)"

# Check Node.js
if ! command_exists node; then
    print_error "Node.js not found. Please install Node.js 16+"
    exit 1
fi
print_success "Node.js found: $(node --version)"

# Check if we're in the right directory
if [ ! -d "contracts/solana" ]; then
    print_error "Please run this script from the project root directory"
    exit 1
fi

################################################################################
# Step 2: Configure Solana CLI
################################################################################

print_header "Step 2: Configuring Solana CLI"

# Set to devnet
solana config set --url https://api.devnet.solana.com
print_success "Set cluster to Devnet"

# Get wallet info
WALLET_ADDRESS=$(solana address)
print_info "Wallet Address: $WALLET_ADDRESS"

# Check balance
BALANCE=$(solana balance | awk '{print $1}')
print_info "Current Balance: $BALANCE SOL"

# Request airdrop if balance is low
if (( $(echo "$BALANCE < 5" | bc -l) )); then
    print_warning "Balance is low. Requesting airdrop..."
    solana airdrop 2
    sleep 5
    BALANCE=$(solana balance | awk '{print $1}')
    print_success "New Balance: $BALANCE SOL"
fi

################################################################################
# Step 3: Deploy SUK Token Program
################################################################################

print_header "Step 3: Deploying SUK Token Program"

cd contracts/solana/suk_token

print_info "Building SUK Token program..."
anchor build

print_info "Deploying SUK Token program..."
anchor deploy --provider.cluster devnet

# Get program ID
PROGRAM_ID=$(solana address -k target/deploy/suk_token-keypair.json)
print_success "SUK Token Program deployed!"
print_success "Program ID: $PROGRAM_ID"

# Update Anchor.toml with program ID
print_info "Updating Anchor.toml..."
sed -i.bak "s/suk_token = \".*\"/suk_token = \"$PROGRAM_ID\"/" Anchor.toml
rm Anchor.toml.bak

# Initialize the token
print_info "Initializing SUK Token..."
if [ -f "scripts/deploy.ts" ]; then
    ts-node scripts/deploy.ts
    print_success "SUK Token initialized!"
else
    print_warning "Deploy script not found. Please run initialization manually."
fi

cd ../../..

################################################################################
# Step 4: Deploy Drama IP Staking Program
################################################################################

print_header "Step 4: Deploying Drama IP Staking Program"

cd contracts/solana/drama_ip_staking

print_info "Building Drama IP Staking program..."
anchor build

print_info "Deploying Drama IP Staking program..."
anchor deploy --provider.cluster devnet

# Get program ID
STAKING_PROGRAM_ID=$(solana address -k target/deploy/drama_ip_staking-keypair.json)
print_success "Drama IP Staking Program deployed!"
print_success "Program ID: $STAKING_PROGRAM_ID"

# Update Anchor.toml
print_info "Updating Anchor.toml..."
sed -i.bak "s/drama_ip_staking = \".*\"/drama_ip_staking = \"$STAKING_PROGRAM_ID\"/" Anchor.toml
rm Anchor.toml.bak

# Initialize if deploy script exists
if [ -f "scripts/deploy.ts" ]; then
    print_info "Initializing Drama IP Staking..."
    ts-node scripts/deploy.ts
    print_success "Drama IP Staking initialized!"
fi

cd ../../..

################################################################################
# Step 5: Save Deployment Info
################################################################################

print_header "Step 5: Saving Deployment Information"

# Create deployment info file
DEPLOY_INFO_FILE="deployment/solana-devnet-deployment.json"
mkdir -p deployment

cat > $DEPLOY_INFO_FILE << EOF
{
  "network": "devnet",
  "cluster": "https://api.devnet.solana.com",
  "deploymentDate": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "deployer": "$WALLET_ADDRESS",
  "programs": {
    "sukToken": {
      "programId": "$PROGRAM_ID",
      "idl": "contracts/solana/suk_token/target/idl/suk_token.json"
    },
    "dramaIpStaking": {
      "programId": "$STAKING_PROGRAM_ID",
      "idl": "contracts/solana/drama_ip_staking/target/idl/drama_ip_staking.json"
    }
  },
  "explorer": {
    "sukToken": "https://explorer.solana.com/address/$PROGRAM_ID?cluster=devnet",
    "dramaIpStaking": "https://explorer.solana.com/address/$STAKING_PROGRAM_ID?cluster=devnet"
  }
}
EOF

print_success "Deployment info saved to: $DEPLOY_INFO_FILE"

################################################################################
# Step 6: Verify Deployment
################################################################################

print_header "Step 6: Verifying Deployment"

print_info "Verifying SUK Token Program..."
if solana program show $PROGRAM_ID > /dev/null 2>&1; then
    print_success "SUK Token Program verified!"
else
    print_error "SUK Token Program verification failed"
fi

print_info "Verifying Drama IP Staking Program..."
if solana program show $STAKING_PROGRAM_ID > /dev/null 2>&1; then
    print_success "Drama IP Staking Program verified!"
else
    print_error "Drama IP Staking Program verification failed"
fi

################################################################################
# Deployment Summary
################################################################################

print_header "Deployment Summary"

echo ""
echo -e "${GREEN}✓ All programs deployed successfully!${NC}"
echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}Network:${NC} Devnet"
echo -e "${YELLOW}Cluster:${NC} https://api.devnet.solana.com"
echo -e "${YELLOW}Deployer:${NC} $WALLET_ADDRESS"
echo ""
echo -e "${YELLOW}SUK Token Program:${NC}"
echo -e "  Program ID: ${GREEN}$PROGRAM_ID${NC}"
echo -e "  Explorer: https://explorer.solana.com/address/$PROGRAM_ID?cluster=devnet"
echo ""
echo -e "${YELLOW}Drama IP Staking Program:${NC}"
echo -e "  Program ID: ${GREEN}$STAKING_PROGRAM_ID${NC}"
echo -e "  Explorer: https://explorer.solana.com/address/$STAKING_PROGRAM_ID?cluster=devnet"
echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${GREEN}Next Steps:${NC}"
echo "1. Update frontend config with deployed program IDs"
echo "2. Test all functionality on Devnet"
echo "3. Prepare for mainnet deployment"
echo ""
echo -e "${YELLOW}Deployment info saved to:${NC} $DEPLOY_INFO_FILE"
echo ""

print_success "Deployment complete!"
