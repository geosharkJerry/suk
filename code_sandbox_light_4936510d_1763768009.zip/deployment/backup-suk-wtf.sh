#!/bin/bash

# ============================================
# SUK.WTF 自动备份脚本
# Automatic Backup Script for suk.link
# ============================================
#
# 功能：
# ✅ MongoDB 数据库备份
# ✅ Redis 数据备份
# ✅ 配置文件备份
# ✅ 日志文件备份
# ✅ 自动压缩
# ✅ 自动清理（保留最近30天）
#
# 使用方法：
# 1. 设置执行权限：chmod +x backup-suk-wtf.sh
# 2. 手动运行：./backup-suk-wtf.sh
# 3. 或添加到crontab定时执行：
#    crontab -e
#    添加：0 2 * * * /opt/backup-suk-wtf.sh >> /var/log/suk-backup.log 2>&1
#
# ============================================

set -e

# 配置
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_ROOT="/var/backups/suk-wtf"
BACKUP_DIR="$BACKUP_ROOT/backup_$DATE"
PROJECT_DIR="/opt/suk-platform"
RETENTION_DAYS=30

# MongoDB 配置（从 .env 读取）
if [ -f "$PROJECT_DIR/.env" ]; then
    source <(grep -E '^MONGODB_URI|^MONGODB_ROOT_PASSWORD' "$PROJECT_DIR/.env" | sed 's/^/export /')
fi

# Redis 配置
REDIS_PASSWORD=$(grep REDIS_PASSWORD "$PROJECT_DIR/.env" | cut -d '=' -f2)

# 日志函数
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# 创建备份目录
create_backup_dir() {
    log "创建备份目录: $BACKUP_DIR"
    mkdir -p "$BACKUP_DIR"/{mongodb,redis,configs,logs}
}

# 备份 MongoDB
backup_mongodb() {
    log "开始备份 MongoDB..."
    
    mongodump \
        --uri="$MONGODB_URI" \
        --out="$BACKUP_DIR/mongodb" \
        --gzip
    
    if [ $? -eq 0 ]; then
        log "MongoDB 备份成功"
    else
        log "ERROR: MongoDB 备份失败"
        return 1
    fi
}

# 备份 Redis
backup_redis() {
    log "开始备份 Redis..."
    
    # 触发 Redis 保存
    redis-cli -a "$REDIS_PASSWORD" SAVE
    
    # 复制 RDB 文件
    cp /var/lib/redis/dump.rdb "$BACKUP_DIR/redis/" 2>/dev/null || true
    
    if [ $? -eq 0 ]; then
        log "Redis 备份成功"
    else
        log "WARNING: Redis 备份失败或未找到 dump.rdb"
    fi
}

# 备份配置文件
backup_configs() {
    log "开始备份配置文件..."
    
    # .env 文件
    cp "$PROJECT_DIR/.env" "$BACKUP_DIR/configs/" 2>/dev/null || true
    
    # Nginx 配置
    cp /etc/nginx/sites-available/suk.link "$BACKUP_DIR/configs/" 2>/dev/null || true
    
    # PM2 配置
    cp "$PROJECT_DIR/ecosystem.config.js" "$BACKUP_DIR/configs/" 2>/dev/null || true
    
    # MongoDB 配置
    cp /etc/mongod.conf "$BACKUP_DIR/configs/" 2>/dev/null || true
    
    # Redis 配置
    cp /etc/redis/redis.conf "$BACKUP_DIR/configs/" 2>/dev/null || true
    
    log "配置文件备份完成"
}

# 备份日志文件
backup_logs() {
    log "开始备份日志文件..."
    
    # Nginx 日志（只备份最近7天）
    find /var/log/nginx -name "*suk-wtf*.log*" -mtime -7 -exec cp {} "$BACKUP_DIR/logs/" \;
    
    # 应用日志
    if [ -f /var/log/suk-platform.log ]; then
        cp /var/log/suk-platform.log "$BACKUP_DIR/logs/"
    fi
    
    # PM2 日志
    if [ -d /root/.pm2/logs ]; then
        cp /root/.pm2/logs/*.log "$BACKUP_DIR/logs/" 2>/dev/null || true
    fi
    
    log "日志文件备份完成"
}

# 压缩备份
compress_backup() {
    log "开始压缩备份文件..."
    
    cd "$BACKUP_ROOT"
    tar -czf "backup_$DATE.tar.gz" "backup_$DATE"
    
    # 删除未压缩的目录
    rm -rf "backup_$DATE"
    
    # 计算大小
    BACKUP_SIZE=$(du -h "backup_$DATE.tar.gz" | cut -f1)
    log "备份文件已压缩: backup_$DATE.tar.gz ($BACKUP_SIZE)"
}

# 清理旧备份
cleanup_old_backups() {
    log "清理旧备份文件（保留最近 $RETENTION_DAYS 天）..."
    
    find "$BACKUP_ROOT" -name "backup_*.tar.gz" -mtime +$RETENTION_DAYS -delete
    
    REMAINING_BACKUPS=$(find "$BACKUP_ROOT" -name "backup_*.tar.gz" | wc -l)
    log "剩余备份文件数: $REMAINING_BACKUPS"
}

# 备份状态检查
check_backup_status() {
    log "检查备份完整性..."
    
    BACKUP_FILE="$BACKUP_ROOT/backup_$DATE.tar.gz"
    
    if [ -f "$BACKUP_FILE" ]; then
        SIZE=$(stat -c%s "$BACKUP_FILE")
        if [ $SIZE -gt 1024 ]; then
            log "✅ 备份文件有效: $BACKUP_FILE"
            log "✅ 文件大小: $(du -h $BACKUP_FILE | cut -f1)"
            return 0
        else
            log "❌ 备份文件太小，可能不完整"
            return 1
        fi
    else
        log "❌ 备份文件不存在"
        return 1
    fi
}

# 发送通知（可选）
send_notification() {
    local STATUS=$1
    local MESSAGE=$2
    
    # 可以集成邮件、Slack、企业微信等通知
    # 这里是示例，需要根据实际情况配置
    
    # 示例：写入系统日志
    logger -t suk-backup "$MESSAGE"
}

# 主函数
main() {
    log "============================================"
    log "开始 SUK.WTF 备份任务"
    log "============================================"
    
    # 检查必需工具
    if ! command -v mongodump &> /dev/null; then
        log "ERROR: mongodump 未安装，请先安装 mongodb-database-tools"
        exit 1
    fi
    
    # 创建备份目录
    create_backup_dir
    
    # 执行备份
    backup_mongodb
    backup_redis
    backup_configs
    backup_logs
    
    # 压缩备份
    compress_backup
    
    # 清理旧备份
    cleanup_old_backups
    
    # 检查备份状态
    if check_backup_status; then
        log "✅ 备份任务完成"
        send_notification "SUCCESS" "SUK.WTF 备份成功: backup_$DATE.tar.gz"
    else
        log "❌ 备份任务失败"
        send_notification "FAILED" "SUK.WTF 备份失败"
        exit 1
    fi
    
    log "============================================"
}

# 运行主函数
main
