# SUK Protocol 部署自动化指南

本文档提供 SUK Protocol 智能合约在测试网和主网的完整部署自动化指南。

---

## 📋 目录

1. [部署架构概览](#部署架构概览)
2. [前置条件](#前置条件)
3. [Solana Devnet 部署](#solana-devnet-部署)
4. [Ethereum Sepolia 部署](#ethereum-sepolia-部署)
5. [主网部署流程](#主网部署流程)
6. [部署后验证](#部署后验证)
7. [回滚策略](#回滚策略)
8. [常见问题](#常见问题)

---

## 部署架构概览

SUK Protocol 采用**双链部署**策略：

```
┌─────────────────────────────────────────────────────────┐
│                    SUK Protocol                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────────────┐        ┌──────────────────┐     │
│  │   Solana Chain   │        │  Ethereum Chain  │     │
│  │    (主链)         │        │    (副链)         │     │
│  ├──────────────────┤        ├──────────────────┤     │
│  │ • SUK Token      │        │ • SUK Token      │     │
│  │   (SPL)          │        │   (ERC20)        │     │
│  │                  │        │                  │     │
│  │ • Drama IP       │        │ • Drama IP       │     │
│  │   Staking        │        │   Staking        │     │
│  └──────────────────┘        └──────────────────┘     │
│                                                         │
│  低成本 • 高速度           成熟生态 • 高流动性          │
└─────────────────────────────────────────────────────────┘
```

### 部署顺序

1. **Solana Devnet** → 快速迭代测试
2. **Ethereum Sepolia** → DeFi 生态测试
3. **Solana Mainnet** → 主链正式上线
4. **Ethereum Mainnet** → 副链正式上线

---

## 前置条件

### 通用要求

- **操作系统**: Linux / macOS / WSL
- **Node.js**: v16+ 
- **Git**: 最新版本
- **终端**: Bash shell

### Solana 部署要求

```bash
# 安装 Solana CLI
sh -c "$(curl -sSfL https://release.solana.com/stable/install)"

# 安装 Anchor CLI
cargo install --git https://github.com/coral-xyz/anchor anchor-cli --locked

# 安装 TypeScript
npm install -g typescript ts-node

# 验证安装
solana --version    # v1.17+
anchor --version    # v0.29+
```

### Ethereum 部署要求

```bash
# 安装 Hardhat
cd contracts/ethereum
npm install

# 验证安装
npx hardhat --version  # v2.19+
```

### 资金准备

#### Solana Devnet
```bash
# 获取 Devnet SOL (免费)
solana config set --url devnet
solana airdrop 2
```

#### Ethereum Sepolia
- 获取测试 ETH:
  - https://sepoliafaucet.com/
  - https://faucet.quicknode.com/ethereum/sepolia
- 最少需要: **0.5 ETH**

---

## Solana Devnet 部署

### 步骤 1: 配置钱包

```bash
# 创建新钱包 (首次部署)
solana-keygen new --outfile ~/.config/solana/devnet.json

# 或导入现有钱包
solana-keygen recover --outfile ~/.config/solana/devnet.json

# 设置为默认钱包
solana config set --keypair ~/.config/solana/devnet.json

# 查看钱包地址
solana address
```

### 步骤 2: 获取测试 SOL

```bash
# 切换到 Devnet
solana config set --url devnet

# 请求空投 (每次 2 SOL)
solana airdrop 2

# 查看余额
solana balance
# 预期: 至少 5 SOL 用于部署
```

### 步骤 3: 运行自动化部署脚本

```bash
# 从项目根目录执行
chmod +x deployment/solana-devnet-deploy.sh
./deployment/solana-devnet-deploy.sh
```

### 脚本执行内容

1. ✅ 环境检查 (Solana CLI, Anchor, Node.js)
2. ✅ 配置 Devnet RPC
3. ✅ 检查钱包余额
4. ✅ 构建 SUK Token 程序
5. ✅ 部署 SUK Token 程序
6. ✅ 初始化 SUK Token
7. ✅ 构建 Drama IP Staking 程序
8. ✅ 部署 Drama IP Staking 程序
9. ✅ 保存部署信息
10. ✅ 验证部署结果

### 预期输出

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Deployment Summary
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✓ All programs deployed successfully!

═══════════════════════════════════════════════════════════
Network: Devnet
Cluster: https://api.devnet.solana.com
Deployer: 7xJ9...K4mP

SUK Token Program:
  Program ID: ABC123...XYZ789
  Explorer: https://explorer.solana.com/address/ABC123...?cluster=devnet

Drama IP Staking Program:
  Program ID: DEF456...UVW012
  Explorer: https://explorer.solana.com/address/DEF456...?cluster=devnet

═══════════════════════════════════════════════════════════

Deployment info saved to: deployment/solana-devnet-deployment.json
```

### 步骤 4: 验证部署

```bash
# 查看 SUK Token 程序
solana program show <SUK_TOKEN_PROGRAM_ID>

# 查看 Drama IP Staking 程序
solana program show <STAKING_PROGRAM_ID>

# 测试程序调用
cd contracts/solana/suk_token
anchor test
```

---

## Ethereum Sepolia 部署

### 步骤 1: 配置环境变量

```bash
cd contracts/ethereum

# 创建 .env 文件
cat > .env << 'EOF'
# Ethereum Sepolia Configuration
SEPOLIA_RPC_URL=https://eth-sepolia.g.alchemy.com/v2/YOUR_ALCHEMY_KEY
PRIVATE_KEY=YOUR_PRIVATE_KEY_HERE

# Etherscan API Key
ETHERSCAN_API_KEY=YOUR_ETHERSCAN_API_KEY

# Token Configuration
INITIAL_SUPPLY=1000000000
MAX_SUPPLY=10000000000
EOF

# 编辑 .env 文件，填入真实值
nano .env
```

### 步骤 2: 获取所需密钥

#### Alchemy RPC URL
1. 访问 https://www.alchemy.com/
2. 注册并创建 Sepolia 应用
3. 复制 HTTPS URL

#### Private Key
```bash
# MetaMask: 账户详情 → 导出私钥
# 注意: 永远不要泄露主网私钥!
```

#### Etherscan API Key
1. 访问 https://etherscan.io/
2. 注册并创建 API Key
3. 用于合约验证

### 步骤 3: 运行自动化部署脚本

```bash
# 从项目根目录执行
chmod +x deployment/ethereum-sepolia-deploy.sh
./deployment/ethereum-sepolia-deploy.sh
```

### 脚本执行内容

1. ✅ 环境检查 (Node.js, npm)
2. ✅ 验证 .env 配置
3. ✅ 安装依赖
4. ✅ 编译智能合约
5. ✅ 部署 SUK Token
6. ✅ 在 Etherscan 验证 SUK Token
7. ✅ 部署 Drama IP Staking
8. ✅ 在 Etherscan 验证 Drama IP Staking
9. ✅ 配置合约权限
10. ✅ 保存部署信息

### 预期输出

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Deployment Summary
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✓ All contracts deployed successfully!

═══════════════════════════════════════════════════════════
Network: Sepolia Testnet
Chain ID: 11155111
Deployer: 0x1234...5678

SUK Token:
  Address: 0xABCD...EFGH
  Explorer: https://sepolia.etherscan.io/address/0xABCD...EFGH
  Initial Supply: 1,000,000,000 SUK
  Max Supply: 10,000,000,000 SUK

Drama IP Staking:
  Address: 0xIJKL...MNOP
  Explorer: https://sepolia.etherscan.io/address/0xIJKL...MNOP

═══════════════════════════════════════════════════════════

Deployment info saved to: deployment/ethereum-sepolia-deployment.json
```

### 步骤 4: 验证部署

```bash
# 查看合约源码
npx hardhat verify --network sepolia <CONTRACT_ADDRESS>

# 测试合约交互
cd contracts/ethereum
npx hardhat test --network sepolia
```

---

## 主网部署流程

### ⚠️ 主网部署前检查清单

- [ ] 所有测试网功能已验证
- [ ] 合约已通过第三方审计
- [ ] 多签钱包已配置
- [ ] 应急暂停机制已测试
- [ ] 团队成员已确认部署参数
- [ ] 足够的主网 SOL/ETH 准备就绪
- [ ] 部署钱包私钥安全存储
- [ ] 回滚方案已准备

### Solana Mainnet 部署

```bash
# 1. 切换到主网
solana config set --url mainnet-beta

# 2. 确认钱包余额 (至少 10 SOL)
solana balance

# 3. 执行部署 (手动确认每一步)
cd contracts/solana/suk_token
anchor build
anchor deploy --provider.cluster mainnet

# 4. 记录 Program ID
PROGRAM_ID=$(solana address -k target/deploy/suk_token-keypair.json)
echo $PROGRAM_ID

# 5. 初始化程序
ts-node scripts/deploy.ts

# 6. 重复步骤部署 Drama IP Staking
```

### Ethereum Mainnet 部署

```bash
# 1. 更新 .env 为主网配置
MAINNET_RPC_URL=https://eth-mainnet.g.alchemy.com/v2/YOUR_KEY
PRIVATE_KEY=YOUR_MAINNET_PRIVATE_KEY

# 2. 确认钱包余额 (至少 2 ETH)
npx hardhat run scripts/check-balance.js --network mainnet

# 3. 执行部署
cd contracts/ethereum
npx hardhat run scripts/deploy-suk-token.js --network mainnet

# 4. 验证合约
npx hardhat verify --network mainnet <CONTRACT_ADDRESS> <CONSTRUCTOR_ARGS>

# 5. 部署 Staking 合约
npx hardhat run scripts/deploy-drama-staking.js --network mainnet
```

### 部署成本估算

| 网络 | SUK Token | Drama Staking | 总计 |
|------|-----------|---------------|------|
| **Solana Devnet** | 5 SOL | 5 SOL | 10 SOL |
| **Solana Mainnet** | 8 SOL | 8 SOL | 16 SOL |
| **Ethereum Sepolia** | 0.1 ETH | 0.15 ETH | 0.25 ETH |
| **Ethereum Mainnet** | 0.5-2 ETH | 0.8-3 ETH | 1.3-5 ETH |

*主网成本受 Gas 价格波动影响，建议在 Gas 较低时部署*

---

## 部署后验证

### 功能测试清单

#### SUK Token 测试

```bash
# Solana
□ 铸造代币
□ 转账代币
□ 销毁代币
□ 查询余额
□ 暂停/恢复

# Ethereum
□ Transfer
□ Approve
□ TransferFrom
□ Burn
□ Mint (需权限)
□ Pause/Unpause
```

#### Drama IP Staking 测试

```bash
□ 提交质押申请
□ KYC 审核 (管理员)
□ 投资剧集
□ 分配收益
□ 提取收益
□ 查询质押信息
□ 紧急暂停
```

### 自动化测试脚本

```bash
# Solana
cd contracts/solana/suk_token
anchor test --skip-local-validator

# Ethereum
cd contracts/ethereum
npx hardhat test --network sepolia
```

---

## 回滚策略

### Solana 程序升级

```bash
# 1. 构建新版本
anchor build

# 2. 升级程序 (保留 Program ID)
anchor upgrade <PROGRAM_ID> target/deploy/suk_token.so

# 3. 验证升级
solana program show <PROGRAM_ID>
```

### Ethereum 合约升级

SUK Protocol 合约**不可升级**，使用以下策略：

1. **暂停机制**: 发现问题立即暂停合约
2. **重新部署**: 部署修复后的新合约
3. **数据迁移**: 使用脚本迁移用户数据
4. **前端更新**: 更新前端指向新合约

```solidity
// 紧急暂停
await sukToken.pause();

// 部署新合约
await deploy("SUKTokenV2");

// 迁移数据
await migrateData(oldContract, newContract);
```

---

## 常见问题

### Q1: Solana 部署失败: "Insufficient funds"

**解决方案**:
```bash
# 检查余额
solana balance

# 请求空投 (Devnet)
solana airdrop 2

# 主网: 购买 SOL 并转账
```

### Q2: Ethereum 部署 Gas 费过高

**解决方案**:
```bash
# 查看当前 Gas 价格
npx hardhat run scripts/check-gas.js

# 设置最大 Gas 费
npx hardhat run scripts/deploy.js --max-fee-per-gas 50
```

### Q3: Etherscan 验证失败

**解决方案**:
```bash
# 1. 确认 API Key 正确
echo $ETHERSCAN_API_KEY

# 2. 手动验证
npx hardhat verify --network sepolia \
  --constructor-args args.js \
  <CONTRACT_ADDRESS>

# 3. 等待几分钟后重试
```

### Q4: Anchor 程序初始化失败

**解决方案**:
```bash
# 检查程序是否已部署
solana program show <PROGRAM_ID>

# 检查 Anchor.toml 配置
cat Anchor.toml

# 重新初始化
anchor migrate
```

### Q5: 前端连接测试网合约失败

**解决方案**:
```javascript
// 确认前端配置文件使用正确的合约地址
// frontend/config/contracts.js
const CONTRACTS = {
  solana: {
    network: 'devnet',
    sukToken: 'YOUR_DEPLOYED_PROGRAM_ID',
    dramaStaking: 'YOUR_DEPLOYED_PROGRAM_ID'
  },
  ethereum: {
    network: 'sepolia',
    chainId: 11155111,
    sukToken: '0xYOUR_CONTRACT_ADDRESS',
    dramaStaking: '0xYOUR_CONTRACT_ADDRESS'
  }
};
```

---

## 部署时间表

### 测试网部署 (1 周)

- **Day 1-2**: Solana Devnet 部署 + 测试
- **Day 3-4**: Ethereum Sepolia 部署 + 测试
- **Day 5-6**: 集成测试 + Bug 修复
- **Day 7**: 完整功能验收测试

### 主网部署 (2-3 周)

- **Week 1**: 最终测试网验证
- **Week 2**: 合约审计 + 修复
- **Week 3**: 主网部署 + 监控

---

## 联系支持

部署过程中遇到问题:

- 📧 Email: dev@sukprotocol.io
- 💬 Discord: https://discord.gg/sukprotocol
- 📖 文档: https://docs.sukprotocol.io

---

**最后更新**: 2025-06-18  
**版本**: v1.0.0
