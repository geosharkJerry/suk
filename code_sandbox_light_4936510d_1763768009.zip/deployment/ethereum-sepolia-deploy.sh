#!/bin/bash

################################################################################
# SUK Protocol - Ethereum Sepolia Testnet Deployment Script
# 
# This script deploys all Ethereum smart contracts to Sepolia Testnet
# Usage: ./ethereum-sepolia-deploy.sh
################################################################################

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Print functions
print_header() {
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}  $1${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ $1${NC}"
}

# Check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

################################################################################
# Step 1: Environment Check
################################################################################

print_header "Step 1: Checking Environment"

# Check Node.js
if ! command_exists node; then
    print_error "Node.js not found. Please install Node.js 16+"
    exit 1
fi
print_success "Node.js found: $(node --version)"

# Check npm
if ! command_exists npm; then
    print_error "npm not found. Please install npm"
    exit 1
fi
print_success "npm found: $(npm --version)"

# Check if we're in the right directory
if [ ! -d "contracts/ethereum" ]; then
    print_error "Please run this script from the project root directory"
    exit 1
fi

################################################################################
# Step 2: Check Environment Variables
################################################################################

print_header "Step 2: Checking Environment Variables"

# Check for .env file
if [ ! -f "contracts/ethereum/.env" ]; then
    print_error ".env file not found in contracts/ethereum/"
    print_info "Creating .env template..."
    
    cat > contracts/ethereum/.env << 'EOF'
# Ethereum Sepolia Configuration
SEPOLIA_RPC_URL=https://eth-sepolia.g.alchemy.com/v2/YOUR_ALCHEMY_KEY
PRIVATE_KEY=YOUR_PRIVATE_KEY_HERE

# Etherscan API Key (for contract verification)
ETHERSCAN_API_KEY=YOUR_ETHERSCAN_API_KEY

# SUK Token Configuration
INITIAL_SUPPLY=1000000000  # 1 billion SUK
MAX_SUPPLY=10000000000      # 10 billion SUK
EOF
    
    print_warning "Please edit contracts/ethereum/.env with your configuration"
    exit 1
fi

print_success ".env file found"

# Load environment variables
set -a
source contracts/ethereum/.env
set +a

# Verify required variables
if [ -z "$SEPOLIA_RPC_URL" ] || [ "$SEPOLIA_RPC_URL" == "YOUR_ALCHEMY_KEY" ]; then
    print_error "SEPOLIA_RPC_URL not configured in .env"
    exit 1
fi

if [ -z "$PRIVATE_KEY" ] || [ "$PRIVATE_KEY" == "YOUR_PRIVATE_KEY_HERE" ]; then
    print_error "PRIVATE_KEY not configured in .env"
    exit 1
fi

print_success "Environment variables verified"

################################################################################
# Step 3: Install Dependencies
################################################################################

print_header "Step 3: Installing Dependencies"

cd contracts/ethereum

if [ ! -d "node_modules" ]; then
    print_info "Installing npm packages..."
    npm install
    print_success "Dependencies installed"
else
    print_success "Dependencies already installed"
fi

################################################################################
# Step 4: Compile Contracts
################################################################################

print_header "Step 4: Compiling Smart Contracts"

print_info "Cleaning previous builds..."
npx hardhat clean

print_info "Compiling contracts..."
npx hardhat compile

print_success "Contracts compiled successfully"

################################################################################
# Step 5: Deploy SUK Token Contract
################################################################################

print_header "Step 5: Deploying SUK Token Contract"

print_info "Deploying SUK Token to Sepolia..."
npx hardhat run scripts/deploy-suk-token.js --network sepolia > /tmp/suk_deploy.log 2>&1

# Extract contract address from deploy log
SUK_TOKEN_ADDRESS=$(grep "Deployed to:" /tmp/suk_deploy.log | awk '{print $3}')

if [ -z "$SUK_TOKEN_ADDRESS" ]; then
    print_error "Failed to deploy SUK Token"
    cat /tmp/suk_deploy.log
    exit 1
fi

print_success "SUK Token deployed!"
print_success "Contract Address: $SUK_TOKEN_ADDRESS"

# Wait for contract to be indexed
print_info "Waiting for contract to be indexed (30s)..."
sleep 30

################################################################################
# Step 6: Verify SUK Token on Etherscan
################################################################################

print_header "Step 6: Verifying SUK Token on Etherscan"

if [ -n "$ETHERSCAN_API_KEY" ] && [ "$ETHERSCAN_API_KEY" != "YOUR_ETHERSCAN_API_KEY" ]; then
    print_info "Verifying contract on Etherscan..."
    
    # Calculate constructor arguments
    INITIAL_SUPPLY_WEI="1000000000000000000000000000"  # 1B * 10^18
    MAX_SUPPLY_WEI="10000000000000000000000000000"     # 10B * 10^18
    
    npx hardhat verify --network sepolia \
        --constructor-args <(echo "module.exports = ['$INITIAL_SUPPLY_WEI', '$MAX_SUPPLY_WEI'];") \
        $SUK_TOKEN_ADDRESS || print_warning "Verification failed or already verified"
    
    print_success "Contract verification completed"
else
    print_warning "Etherscan API key not configured. Skipping verification."
fi

################################################################################
# Step 7: Deploy Drama IP Staking Contract
################################################################################

print_header "Step 7: Deploying Drama IP Staking Contract"

# Create deploy script for DramaIPStaking if it doesn't exist
if [ ! -f "scripts/deploy-drama-staking.js" ]; then
    print_info "Creating Drama IP Staking deploy script..."
    
    cat > scripts/deploy-drama-staking.js << 'EOFJS'
const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  
  console.log("Deploying Drama IP Staking with account:", deployer.address);
  console.log("Account balance:", (await deployer.getBalance()).toString());

  // Get SUK Token address from environment or previous deployment
  const sukTokenAddress = process.env.SUK_TOKEN_ADDRESS;
  
  if (!sukTokenAddress) {
    throw new Error("SUK_TOKEN_ADDRESS not set");
  }

  // Deploy Drama IP Staking
  const DramaIPStaking = await hre.ethers.getContractFactory("DramaIPStaking");
  const dramaStaking = await DramaIPStaking.deploy(sukTokenAddress);

  await dramaStaking.deployed();

  console.log("Drama IP Staking deployed to:", dramaStaking.address);
  console.log("SUK Token:", sukTokenAddress);
  
  // Verify deployment
  const platform = await dramaStaking.platform();
  console.log("Platform address:", platform);
  
  return dramaStaking.address;
}

main()
  .then((address) => {
    process.exit(0);
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
EOFJS
fi

print_info "Deploying Drama IP Staking to Sepolia..."
SUK_TOKEN_ADDRESS=$SUK_TOKEN_ADDRESS npx hardhat run scripts/deploy-drama-staking.js --network sepolia > /tmp/staking_deploy.log 2>&1

# Extract contract address
STAKING_ADDRESS=$(grep "Drama IP Staking deployed to:" /tmp/staking_deploy.log | awk '{print $6}')

if [ -z "$STAKING_ADDRESS" ]; then
    print_error "Failed to deploy Drama IP Staking"
    cat /tmp/staking_deploy.log
    exit 1
fi

print_success "Drama IP Staking deployed!"
print_success "Contract Address: $STAKING_ADDRESS"

# Wait for indexing
print_info "Waiting for contract to be indexed (30s)..."
sleep 30

################################################################################
# Step 8: Verify Drama IP Staking on Etherscan
################################################################################

print_header "Step 8: Verifying Drama IP Staking on Etherscan"

if [ -n "$ETHERSCAN_API_KEY" ] && [ "$ETHERSCAN_API_KEY" != "YOUR_ETHERSCAN_API_KEY" ]; then
    print_info "Verifying contract on Etherscan..."
    
    npx hardhat verify --network sepolia \
        --constructor-args <(echo "module.exports = ['$SUK_TOKEN_ADDRESS'];") \
        $STAKING_ADDRESS || print_warning "Verification failed or already verified"
    
    print_success "Contract verification completed"
else
    print_warning "Etherscan API key not configured. Skipping verification."
fi

cd ../..

################################################################################
# Step 9: Save Deployment Info
################################################################################

print_header "Step 9: Saving Deployment Information"

DEPLOY_INFO_FILE="deployment/ethereum-sepolia-deployment.json"
mkdir -p deployment

# Get deployer address
DEPLOYER_ADDRESS=$(cd contracts/ethereum && npx hardhat run --network sepolia scripts/get-address.js 2>/dev/null || echo "Unknown")

cat > $DEPLOY_INFO_FILE << EOF
{
  "network": "sepolia",
  "chainId": 11155111,
  "rpcUrl": "https://eth-sepolia.g.alchemy.com/v2/...",
  "deploymentDate": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "deployer": "$DEPLOYER_ADDRESS",
  "contracts": {
    "sukToken": {
      "address": "$SUK_TOKEN_ADDRESS",
      "abi": "contracts/ethereum/artifacts/contracts/SUKToken.sol/SUKToken.json"
    },
    "dramaIpStaking": {
      "address": "$STAKING_ADDRESS",
      "abi": "contracts/ethereum/artifacts/contracts/DramaIPStaking.sol/DramaIPStaking.json"
    }
  },
  "explorer": {
    "sukToken": "https://sepolia.etherscan.io/address/$SUK_TOKEN_ADDRESS",
    "dramaIpStaking": "https://sepolia.etherscan.io/address/$STAKING_ADDRESS"
  },
  "tokenConfig": {
    "name": "SUK Token",
    "symbol": "SUK",
    "decimals": 18,
    "initialSupply": "1000000000000000000000000000",
    "maxSupply": "10000000000000000000000000000"
  }
}
EOF

print_success "Deployment info saved to: $DEPLOY_INFO_FILE"

################################################################################
# Step 10: Grant Initial Roles (Optional)
################################################################################

print_header "Step 10: Configuring Contract Permissions"

print_info "Setting up initial roles..."

# Create role setup script if needed
cat > contracts/ethereum/scripts/setup-roles.js << 'EOFJS'
const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  
  const sukTokenAddress = process.env.SUK_TOKEN_ADDRESS;
  const stakingAddress = process.env.STAKING_ADDRESS;
  
  const SUKToken = await hre.ethers.getContractAt("SUKToken", sukTokenAddress);
  const DramaStaking = await hre.ethers.getContractAt("DramaIPStaking", stakingAddress);
  
  // Grant MINTER_ROLE to staking contract
  const MINTER_ROLE = await SUKToken.MINTER_ROLE();
  const tx1 = await SUKToken.grantRole(MINTER_ROLE, stakingAddress);
  await tx1.wait();
  console.log("✓ Granted MINTER_ROLE to Drama Staking");
  
  console.log("✓ Role setup complete");
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
EOFJS

SUK_TOKEN_ADDRESS=$SUK_TOKEN_ADDRESS STAKING_ADDRESS=$STAKING_ADDRESS \
  npx hardhat run --network sepolia contracts/ethereum/scripts/setup-roles.js

print_success "Contract permissions configured"

################################################################################
# Deployment Summary
################################################################################

print_header "Deployment Summary"

echo ""
echo -e "${GREEN}✓ All contracts deployed successfully!${NC}"
echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}Network:${NC} Sepolia Testnet"
echo -e "${YELLOW}Chain ID:${NC} 11155111"
echo -e "${YELLOW}Deployer:${NC} $DEPLOYER_ADDRESS"
echo ""
echo -e "${YELLOW}SUK Token:${NC}"
echo -e "  Address: ${GREEN}$SUK_TOKEN_ADDRESS${NC}"
echo -e "  Explorer: https://sepolia.etherscan.io/address/$SUK_TOKEN_ADDRESS"
echo -e "  Initial Supply: 1,000,000,000 SUK"
echo -e "  Max Supply: 10,000,000,000 SUK"
echo ""
echo -e "${YELLOW}Drama IP Staking:${NC}"
echo -e "  Address: ${GREEN}$STAKING_ADDRESS${NC}"
echo -e "  Explorer: https://sepolia.etherscan.io/address/$STAKING_ADDRESS"
echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${GREEN}Next Steps:${NC}"
echo "1. Update frontend config with deployed contract addresses"
echo "2. Add Sepolia ETH to test accounts"
echo "3. Test all functionality on Sepolia"
echo "4. Prepare for mainnet deployment"
echo ""
echo -e "${YELLOW}Get Sepolia ETH:${NC}"
echo "  https://sepoliafaucet.com/"
echo "  https://faucet.quicknode.com/ethereum/sepolia"
echo ""
echo -e "${YELLOW}Deployment info saved to:${NC} $DEPLOY_INFO_FILE"
echo ""

print_success "Deployment complete!"
