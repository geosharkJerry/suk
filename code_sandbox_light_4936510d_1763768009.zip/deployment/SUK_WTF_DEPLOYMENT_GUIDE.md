# SUK.WTF 生产环境部署指南
# Production Deployment Guide for suk.link

> **短剧平台完整部署手册** - 针对 suk.link 域名  
> **完整一键部署流程** - 从零到上线只需30分钟

---

## 📋 目录

- [前置准备](#前置准备)
- [快速部署](#快速部署)
- [详细配置步骤](#详细配置步骤)
- [DNS配置](#dns配置)
- [SSL证书配置](#ssl证书配置)
- [服务器部署](#服务器部署)
- [验证和测试](#验证和测试)

---

## 🎯 前置准备

### ✅ 已完成
- [x] 域名购买：**suk.link**（GoDaddy）
- [x] 代码开发：100%完成
- [x] 文档准备：完整

### 🔲 待准备

#### 1. 服务器（必需）
```
推荐配置：
- CPU: 4核
- 内存: 8GB
- 硬盘: 100GB SSD
- 带宽: 10Mbps
- 系统: Ubuntu 22.04 LTS

推荐云服务商：
✅ 阿里云 ECS（国内首选）
✅ 腾讯云 CVM（国内备选）
✅ AWS EC2（国际用户）
✅ DigitalOcean（性价比高）
```

#### 2. 第三方服务账号（必需）

**阿里云 VoD（视频点播）**：
- [ ] 开通账号并实名认证
- [ ] 开通VoD服务
- [ ] 创建RAM子账号
- [ ] 获取AccessKey ID和Secret

**Telegram Bot**：
- [ ] 通过 @BotFather 创建Bot
- [ ] 获取Bot Token
- [ ] 配置支付商户

**区块链服务**：
- [ ] TON钱包地址
- [ ] 以太坊钱包地址
- [ ] Infura/Alchemy RPC URL

---

## 🚀 快速部署（推荐）

使用我们提供的一键部署脚本，30分钟完成上线：

```bash
# 1. 下载部署脚本
wget https://raw.githubusercontent.com/YOUR_REPO/main/deployment/deploy-suk-wtf.sh

# 2. 添加执行权限
chmod +x deploy-suk-wtf.sh

# 3. 运行部署脚本
sudo ./deploy-suk-wtf.sh

# 脚本会自动完成：
# ✅ 系统环境检查和安装
# ✅ Docker和Docker Compose安装
# ✅ 代码克隆和配置
# ✅ SSL证书申请
# ✅ Nginx配置
# ✅ 服务启动
# ✅ 健康检查
```

---

## 📝 详细配置步骤

如果您想手动逐步部署，请按以下步骤操作：

---

## 🌐 DNS 配置

### 步骤1：登录 GoDaddy DNS 管理

1. 访问：https://dcc.godaddy.com/manage/suk.link/dns
2. 点击 **DNS** → **管理DNS记录**

### 步骤2：添加 A 记录

将以下记录添加到您的DNS配置中（假设服务器IP为 `123.45.67.89`）：

| 类型 | 名称 | 值 | TTL |
|------|------|-----|-----|
| A | @ | 123.45.67.89 | 600 |
| A | www | 123.45.67.89 | 600 |
| A | api | 123.45.67.89 | 600 |
| A | monitor | 123.45.67.89 | 600 |

**GoDaddy DNS 配置界面**：

```
类型：A
名称：@
值：123.45.67.89（您的服务器IP）
TTL：10分钟

类型：A
名称：www
值：123.45.67.89
TTL：10分钟

类型：A
名称：api
值：123.45.67.89
TTL：10分钟

类型：A
名称：monitor
值：123.45.67.89
TTL：10分钟
```

### 步骤3：验证 DNS 解析

等待5-10分钟后，验证DNS是否生效：

```bash
# 检查主域名
nslookup suk.link

# 检查子域名
nslookup api.suk.link
nslookup www.suk.link
nslookup monitor.suk.link

# 或使用 dig
dig suk.link +short
dig api.suk.link +short
```

**预期输出**：应该显示您的服务器IP地址

---

## 🔒 SSL 证书配置

### 选项 A：Let's Encrypt（免费，推荐）

#### 1. 安装 Certbot

```bash
# 更新系统
sudo apt-get update

# 安装 Certbot 和 Nginx 插件
sudo apt-get install -y certbot python3-certbot-nginx
```

#### 2. 申请证书

```bash
# 为 suk.link 域名申请证书（包含所有子域名）
sudo certbot certonly --nginx \
  -d suk.link \
  -d www.suk.link \
  -d api.suk.link \
  -d monitor.suk.link \
  --email your-email@example.com \
  --agree-tos \
  --no-eff-email

# 证书会保存在：
# /etc/letsencrypt/live/suk.link/fullchain.pem
# /etc/letsencrypt/live/suk.link/privkey.pem
```

#### 3. 设置自动续期

```bash
# 测试自动续期
sudo certbot renew --dry-run

# 添加定时任务（每天凌晨2点检查）
sudo crontab -e

# 添加以下行：
0 2 * * * certbot renew --quiet --post-hook "systemctl reload nginx"
```

### 选项 B：通配符证书（推荐生产环境）

```bash
# 申请通配符证书（需要DNS验证）
sudo certbot certonly --manual \
  --preferred-challenges=dns \
  -d suk.link \
  -d "*.suk.link" \
  --email your-email@example.com \
  --agree-tos

# 按提示在 GoDaddy 添加 TXT 记录：
# 名称：_acme-challenge
# 类型：TXT
# 值：certbot 提供的验证字符串
# TTL：10分钟

# 等待DNS生效（5-10分钟），然后按回车继续
```

---

## 💻 服务器部署

### 步骤1：连接服务器

```bash
# SSH连接到服务器
ssh root@123.45.67.89

# 或使用密钥
ssh -i your-key.pem ubuntu@123.45.67.89
```

### 步骤2：系统初始化

```bash
# 更新系统
apt-get update && apt-get upgrade -y

# 安装基础工具
apt-get install -y \
  git \
  curl \
  wget \
  vim \
  build-essential \
  ufw \
  fail2ban

# 安装 Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt-get install -y nodejs

# 验证安装
node --version  # v18.x
npm --version   # 9.x+
```

### 步骤3：安装 Docker

```bash
# 安装 Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# 安装 Docker Compose
curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" \
  -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

# 验证
docker --version
docker-compose --version
```

### 步骤4：克隆项目代码

```bash
# 创建部署目录
mkdir -p /opt
cd /opt

# 克隆代码（替换为您的仓库地址）
git clone https://github.com/YOUR_USERNAME/drama-platform.git suk-platform
cd suk-platform

# 设置权限
chown -R $USER:$USER /opt/suk-platform
```

### 步骤5：配置环境变量

```bash
# 复制环境配置模板
cp .env.example .env

# 编辑配置文件
nano .env
```

**填写以下关键配置**：

```bash
# ============================================
# SUK.WTF 生产环境配置
# ============================================

NODE_ENV=production
PORT=3000

# 域名配置
API_BASE_URL=https://api.suk.link
WEBAPP_URL=https://suk.link
CORS_ORIGIN=https://suk.link,https://www.suk.link,https://api.suk.link

# MongoDB
MONGODB_URI=mongodb://admin:YOUR_STRONG_PASSWORD@localhost:27017/suk_drama?authSource=admin
MONGODB_ROOT_USER=admin
MONGODB_ROOT_PASSWORD=YOUR_STRONG_PASSWORD
MONGODB_DATABASE=suk_drama

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=YOUR_REDIS_PASSWORD

# 阿里云 VoD
ALIYUN_ACCESS_KEY_ID=LTAI5t...
ALIYUN_ACCESS_KEY_SECRET=...
ALIYUN_VOD_REGION=cn-shanghai

# JWT
JWT_SECRET=$(openssl rand -hex 64)
JWT_EXPIRES_IN=7d

# 以太坊
ETHEREUM_RPC_URL=https://mainnet.infura.io/v3/YOUR_PROJECT_ID
ETHEREUM_NETWORK=mainnet
SUK_TOKEN_CONTRACT=0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb
PLATFORM_WALLET_ADDRESS=0x...

# TON
TON_WALLET_ADDRESS=EQ...
TON_NETWORK=mainnet

# Telegram Bot
TELEGRAM_BOT_TOKEN=123456:ABC-DEF...
TELEGRAM_BOT_USERNAME=YourBotUsername
TELEGRAM_WEBAPP_URL=https://suk.link/telegram-app.html
TELEGRAM_WEBHOOK_URL=https://api.suk.link/api/telegram/webhook

# 安全
FORCE_HTTPS=true
COOKIE_SECURE=true
```

**保护配置文件**：
```bash
chmod 600 .env
```

### 步骤6：安装 Nginx

```bash
# 安装 Nginx
apt-get install -y nginx

# 创建配置文件
nano /etc/nginx/sites-available/suk.link
```

**复制以下配置**（使用我们提供的优化配置）：

```nginx
# 该配置文件已在 deployment/nginx-suk-wtf.conf 中
# 直接复制使用：
cp /opt/suk-platform/deployment/nginx-suk-wtf.conf /etc/nginx/sites-available/suk.link
```

**启用配置**：
```bash
# 删除默认配置
rm /etc/nginx/sites-enabled/default

# 启用 suk.link 配置
ln -s /etc/nginx/sites-available/suk.link /etc/nginx/sites-enabled/

# 测试配置
nginx -t

# 重启 Nginx
systemctl restart nginx
```

### 步骤7：配置防火墙

```bash
# 配置 UFW
ufw default deny incoming
ufw default allow outgoing

# 允许必要端口
ufw allow 22/tcp    # SSH
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS

# 启用防火墙
ufw enable

# 查看状态
ufw status
```

### 步骤8：启动服务

#### 方式 A：Docker 部署（推荐）

```bash
cd /opt/suk-platform

# 构建并启动服务
docker-compose up -d

# 查看日志
docker-compose logs -f

# 查看运行状态
docker-compose ps
```

#### 方式 B：PM2 部署

```bash
cd /opt/suk-platform

# 安装依赖
npm ci --production

# 安装 PM2
npm install -g pm2

# 启动应用
pm2 start ecosystem.config.js --env production

# 保存配置
pm2 save

# 设置开机自启
pm2 startup
# 执行输出的命令

# 查看状态
pm2 status
pm2 logs
```

### 步骤9：初始化数据库

```bash
# Docker 方式
docker-compose exec app node scripts/init-db.js --seed

# PM2 方式
node scripts/init-db.js --seed
```

### 步骤10：配置 Telegram Webhook

```bash
# 设置 Webhook
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://api.suk.link/api/telegram/webhook",
    "allowed_updates": ["message", "callback_query", "pre_checkout_query"]
  }'

# 验证 Webhook
curl "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getWebhookInfo"

# 预期输出应该显示：
# "url": "https://api.suk.link/api/telegram/webhook"
# "has_custom_certificate": false
# "pending_update_count": 0
```

### 步骤11：设置 Telegram Menu Button

```bash
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setChatMenuButton" \
  -H "Content-Type: application/json" \
  -d '{
    "menu_button": {
      "type": "web_app",
      "text": "打开短剧平台",
      "web_app": {
        "url": "https://suk.link/telegram-app.html"
      }
    }
  }'
```

---

## ✅ 验证和测试

### 1. 基础健康检查

```bash
# 检查主站
curl -I https://suk.link
# 预期：HTTP/2 200

# 检查 API
curl https://api.suk.link/api/health
# 预期：{"status":"healthy","timestamp":"..."}

# 详细健康检查
curl https://api.suk.link/api/health/detailed
```

### 2. DNS 验证

```bash
# 检查所有域名解析
for domain in suk.link www.suk.link api.suk.link monitor.suk.link; do
  echo "Checking $domain:"
  dig $domain +short
  echo ""
done
```

### 3. SSL 证书验证

```bash
# 检查证书
openssl s_client -connect suk.link:443 -servername suk.link </dev/null 2>/dev/null | openssl x509 -noout -dates

# 在线检查（推荐）
# 访问：https://www.ssllabs.com/ssltest/analyze.html?d=suk.link
```

### 4. 服务状态检查

```bash
# Docker 方式
docker-compose ps
docker-compose logs --tail=50

# PM2 方式
pm2 status
pm2 logs --lines 50
```

### 5. 数据库连接测试

```bash
# MongoDB
mongosh -u admin -p
use suk_drama
db.stats()

# Redis
redis-cli -a YOUR_PASSWORD
PING
INFO
```

### 6. Telegram Bot 测试

1. 在 Telegram 搜索您的 Bot
2. 点击 **开始** 按钮
3. 点击 **Menu Button**
4. 应该打开 Mini App：`https://suk.link/telegram-app.html`
5. 检查是否正确显示短剧列表

### 7. 功能完整性测试清单

**核心功能**：
- [ ] 主页加载：https://suk.link
- [ ] Telegram Mini App 加载
- [ ] 短剧列表显示
- [ ] 视频播放功能
- [ ] 观看历史保存
- [ ] 续播功能

**支付功能**：
- [ ] Telegram Stars 支付流程
- [ ] TON 支付流程
- [ ] SUK Token 支付流程
- [ ] 购买记录正确保存

**区块链验证**：
- [ ] TON 交易验证
- [ ] SUK Token 交易验证
- [ ] 购买状态更新

**评论系统**：
- [ ] 发表评论
- [ ] 点赞/点踩
- [ ] 多级回复
- [ ] 删除评论

---

## 🔧 故障排查

### 问题 1：域名无法访问

```bash
# 检查 DNS
nslookup suk.link

# 检查 Nginx
systemctl status nginx
nginx -t

# 检查端口
netstat -tlnp | grep :80
netstat -tlnp | grep :443

# 检查防火墙
ufw status
```

### 问题 2：SSL 证书错误

```bash
# 重新申请证书
sudo certbot delete --cert-name suk.link
sudo certbot certonly --nginx -d suk.link -d www.suk.link -d api.suk.link

# 检查证书有效期
sudo certbot certificates
```

### 问题 3：应用无法启动

```bash
# 查看日志
docker-compose logs --tail=100
# 或
pm2 logs --lines 100

# 检查环境变量
cat .env

# 检查端口占用
netstat -tlnp | grep :3000

# 重启服务
docker-compose restart
# 或
pm2 restart all
```

### 问题 4：数据库连接失败

```bash
# 检查 MongoDB
systemctl status mongod
sudo tail -50 /var/log/mongodb/mongod.log

# 检查 Redis
systemctl status redis
redis-cli -a YOUR_PASSWORD PING

# 重启数据库
systemctl restart mongod
systemctl restart redis
```

### 问题 5：Telegram Webhook 失败

```bash
# 检查 Webhook 状态
curl "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getWebhookInfo"

# 删除旧 Webhook
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/deleteWebhook"

# 重新设置
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook" \
  -d "url=https://api.suk.link/api/telegram/webhook"

# 测试 Webhook 端点
curl https://api.suk.link/api/telegram/webhook
```

---

## 📊 监控和维护

### 启动监控系统

```bash
cd /opt/suk-platform

# 启动 Prometheus + Grafana
docker-compose -f docker-compose.yml -f docker-compose.monitoring.yml up -d

# 访问监控界面
# Grafana: https://monitor.suk.link:3001
# 默认账号：admin / admin（首次登录需修改密码）

# Prometheus: https://monitor.suk.link:9090
```

### 定期备份

```bash
# 创建备份脚本
cp /opt/suk-platform/deployment/backup-suk-wtf.sh /opt/
chmod +x /opt/backup-suk-wtf.sh

# 添加定时任务
crontab -e
# 添加：每天凌晨2点备份
0 2 * * * /opt/backup-suk-wtf.sh >> /var/log/suk-backup.log 2>&1
```

### 日常维护命令

```bash
# 查看应用日志
docker-compose logs -f app
# 或
pm2 logs

# 查看 Nginx 日志
tail -f /var/log/nginx/suk-wtf-access.log
tail -f /var/log/nginx/suk-wtf-error.log

# 查看系统资源
htop
df -h
free -h

# 更新代码
cd /opt/suk-platform
git pull
docker-compose restart
# 或
pm2 restart all
```

---

## 🎉 完成检查清单

在宣布正式上线前，确认以下所有项目：

### 基础设施
- [ ] DNS 解析正常（suk.link, www, api, monitor）
- [ ] SSL 证书已安装且有效
- [ ] 服务器防火墙配置正确
- [ ] Nginx 正常运行
- [ ] MongoDB 和 Redis 运行正常

### 应用部署
- [ ] 代码已部署到 /opt/suk-platform
- [ ] .env 配置完整且正确
- [ ] 应用正常运行（Docker 或 PM2）
- [ ] 数据库已初始化
- [ ] 健康检查 API 正常

### 第三方服务
- [ ] 阿里云 VoD 配置正确
- [ ] Telegram Bot 已创建
- [ ] Telegram Webhook 已设置
- [ ] Telegram Menu Button 已配置
- [ ] TON 钱包地址已配置
- [ ] 以太坊 RPC 连接正常

### 安全配置
- [ ] HTTPS 强制跳转
- [ ] 防火墙规则正确
- [ ] SSH 密钥登录（禁用密码）
- [ ] 所有默认密码已修改
- [ ] fail2ban 已启用

### 监控和备份
- [ ] Prometheus 监控运行
- [ ] Grafana 仪表板配置
- [ ] 自动备份配置
- [ ] 日志轮转配置

### 功能测试
- [ ] 所有核心功能测试通过
- [ ] 支付流程完整测试
- [ ] 视频播放正常
- [ ] 评论系统工作
- [ ] 性能测试达标

---

## 📞 获取帮助

如有问题，请查看：

- 📖 **完整文档**：`/opt/suk-platform/README.md`
- 📖 **API文档**：`/opt/suk-platform/API.md`
- 📖 **测试指南**：`/opt/suk-platform/TESTING.md`
- 📖 **监控指南**：`/opt/suk-platform/MONITORING_GUIDE.md`

---

## 🚀 上线发布

当所有检查项都完成后：

```bash
# 最后一次完整测试
cd /opt/suk-platform
npm run test:integration  # 如果配置了测试

# 重启所有服务
docker-compose restart
# 或
pm2 restart all

# 清理日志
docker-compose exec app pm2 flush
# 或
pm2 flush

# 🎉 宣布上线！
echo "🎉 SUK.WTF Drama Platform is now LIVE! 🚀"
echo "Main Site: https://suk.link"
echo "API: https://api.suk.link"
echo "Monitoring: https://monitor.suk.link:3001"
```

---

**部署完成时间**: 2024-11-16  
**域名**: suk.link  
**版本**: v1.2.0  
**状态**: ✅ 生产就绪

🎊 **祝您上线顺利！** 🎊
