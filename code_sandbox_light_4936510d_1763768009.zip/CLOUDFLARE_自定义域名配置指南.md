# 🌐 SUK Protocol - Cloudflare Pages 自定义域名配置完整指南

> 📅 更新时间: 2024-11-18  
> 🎯 目标: 将 SUK Protocol 绑定到自定义域名（如 suk.link）

---

## 📋 目录

1. [前置准备](#前置准备)
2. [域名配置步骤](#域名配置步骤)
3. [DNS 配置详解](#dns-配置详解)
4. [SSL/HTTPS 配置](#sslhttps-配置)
5. [多域名配置](#多域名配置)
6. [域名验证](#域名验证)
7. [故障排查](#故障排查)
8. [常见问题](#常见问题)

---

## 前置准备

### ✅ 必需条件

1. **已部署的 Cloudflare Pages 项目**
   ```
   项目名称: suk-protocol
   默认 URL: https://suk-protocol.pages.dev
   状态: 部署成功 ✅
   ```

2. **拥有的域名**
   ```
   示例域名: suk.link
   域名状态: 已注册且可管理
   DNS 访问: 有权限修改 DNS 记录
   ```

3. **域名 DNS 管理权限**
   - 能够添加/修改 DNS 记录
   - 能够修改 Nameservers（如需要）

---

## 域名配置步骤

### 步骤 1: 登录 Cloudflare Dashboard

```
1. 访问 https://dash.cloudflare.com/
2. 登录您的 Cloudflare 账号
3. 进入 Pages 项目管理
```

### 步骤 2: 打开自定义域名设置

```
1. 点击左侧菜单 "Workers & Pages"
2. 选择您的项目: suk-protocol
3. 点击 "Custom domains" 标签
4. 点击 "Set up a custom domain" 按钮
```

![Cloudflare Pages Custom Domains](https://developers.cloudflare.com/pages/assets/custom-domains-add.png)

### 步骤 3: 输入您的域名

根据您的需求选择：

#### 选项 A: 根域名（推荐）
```
域名: suk.link
说明: 用户访问 https://suk.link
```

#### 选项 B: www 子域名
```
域名: www.suk.link
说明: 用户访问 https://www.suk.link
```

#### 选项 C: 自定义子域名
```
域名: app.suk.link
说明: 用户访问 https://app.suk.link
```

**推荐配置**: 同时配置根域名和 www，然后设置重定向

### 步骤 4: 验证域名所有权

Cloudflare 会检测域名的 DNS 配置：

#### 场景 1: 域名已在 Cloudflare 托管 ✨（最简单）

```
✅ 自动检测并配置
✅ 无需手动操作
✅ 立即生效
✅ 自动 SSL 证书
```

#### 场景 2: 域名在其他 DNS 提供商

Cloudflare 会提供 DNS 记录配置说明（继续下一步）

---

## DNS 配置详解

### 场景 A: 域名在 Cloudflare 托管 ⭐（推荐）

**优势**:
- ✅ 自动配置 DNS
- ✅ 自动申请 SSL 证书
- ✅ 启用 Cloudflare CDN
- ✅ 无需等待 DNS 传播

**操作**:
```
1. Cloudflare 自动检测域名
2. 自动创建所需的 DNS 记录
3. 自动申请 SSL 证书
4. 立即生效（< 1分钟）
```

**如何将域名迁移到 Cloudflare**:
```
1. 在 Cloudflare Dashboard 点击 "Add a Site"
2. 输入域名: suk.link
3. 选择免费计划
4. Cloudflare 会扫描现有 DNS 记录
5. 在域名注册商处修改 Nameservers 为:
   - Nameserver 1: xxx.ns.cloudflare.com
   - Nameserver 2: yyy.ns.cloudflare.com
6. 等待 DNS 传播（1-24小时）
7. 域名迁移完成 ✅
```

---

### 场景 B: 域名在其他 DNS 提供商

需要手动配置 DNS 记录

#### 配置 1: 根域名（suk.link）

在您的 DNS 提供商添加以下记录：

##### 方法 1: CNAME 记录（推荐，如果支持）

```
类型:   CNAME
名称:   @ (或留空，表示根域名)
值:     suk-protocol.pages.dev
TTL:    Auto (或 3600)
代理:   启用（如果有此选项）
```

##### 方法 2: A 记录（备选）

如果 DNS 提供商不支持根域名 CNAME，使用 A 记录：

```
类型:   A
名称:   @
值:     192.0.2.1 (Cloudflare Pages IP，由 Cloudflare 提供)
TTL:    Auto
```

**注意**: Cloudflare 会在域名添加界面显示正确的 IP 地址

#### 配置 2: www 子域名（www.suk.link）

```
类型:   CNAME
名称:   www
值:     suk-protocol.pages.dev
TTL:    Auto (或 3600)
代理:   启用（如果有此选项）
```

#### 配置 3: 自定义子域名（app.suk.link）

```
类型:   CNAME
名称:   app
值:     suk-protocol.pages.dev
TTL:    Auto (或 3600)
代理:   启用（如果有此选项）
```

---

### 常见 DNS 提供商配置示例

#### 1. 阿里云（万网）

```
1. 登录 https://dns.console.aliyun.com/
2. 选择域名: suk.link
3. 点击 "解析设置"
4. 点击 "添加记录"
5. 配置:
   记录类型: CNAME
   主机记录: @ (根域名) 或 www (子域名)
   记录值: suk-protocol.pages.dev
   TTL: 10分钟
6. 点击 "确认"
```

#### 2. 腾讯云 DNSPod

```
1. 登录 https://console.dnspod.cn/
2. 选择域名: suk.link
3. 点击 "添加记录"
4. 配置:
   主机记录: @ 或 www
   记录类型: CNAME
   线路类型: 默认
   记录值: suk-protocol.pages.dev
   TTL: 600
5. 点击 "保存"
```

#### 3. Namecheap

```
1. 登录 https://www.namecheap.com/
2. Domain List → Manage → Advanced DNS
3. 点击 "Add New Record"
4. 配置:
   Type: CNAME Record
   Host: @ (或 www)
   Value: suk-protocol.pages.dev
   TTL: Automatic
5. 点击 "Save"
```

#### 4. GoDaddy

```
1. 登录 https://dcc.godaddy.com/
2. 选择域名 → DNS → 管理
3. 添加记录:
   类型: CNAME
   名称: @ (或 www)
   值: suk-protocol.pages.dev
   TTL: 1小时
4. 保存
```

#### 5. Google Domains

```
1. 登录 https://domains.google.com/
2. 选择域名 → DNS
3. 自定义资源记录:
   名称: @ (或 www)
   类型: CNAME
   TTL: 1小时
   数据: suk-protocol.pages.dev
4. 添加
```

---

## SSL/HTTPS 配置

### 自动 SSL 证书

Cloudflare Pages 自动提供免费 SSL 证书：

```
✅ 自动申请 Let's Encrypt 证书
✅ 自动续期（无需手动操作）
✅ 支持通配符证书
✅ 强制 HTTPS 重定向
✅ TLS 1.3 支持
```

### SSL 证书申请流程

```
1. 添加自定义域名
   ↓
2. 验证域名所有权（DNS 记录）
   ↓
3. Cloudflare 自动申请 SSL 证书
   ↓
4. 证书签发（通常 < 15分钟）
   ↓
5. 自动启用 HTTPS
   ↓
6. HTTP 自动重定向到 HTTPS
```

### SSL 证书状态检查

```
1. 进入 Cloudflare Pages 项目
2. Custom domains 标签
3. 查看域名状态:
   ✅ Active - 证书已激活，HTTPS 可用
   🟡 Pending - 证书申请中（等待15分钟）
   ❌ Failed - 证书申请失败（检查 DNS）
```

### 强制 HTTPS

Cloudflare Pages 自动强制 HTTPS，但您也可以在 `_headers` 文件中配置：

```
/*
  Strict-Transport-Security: max-age=31536000; includeSubDomains; preload
```

这会告诉浏览器始终使用 HTTPS 访问。

---

## 多域名配置

### 配置多个域名指向同一项目

您可以为同一个 Cloudflare Pages 项目配置多个域名：

#### 示例配置

```
主域名:
  ✅ suk.link (根域名)
  ✅ www.suk.link (www子域名)

功能域名:
  ✅ app.suk.link (应用主页)
  ✅ staking.suk.link (质押控制面板)
  ✅ investor.suk.link (投资者控制面板)

环境域名:
  ✅ staging.suk.link (测试环境)
  ✅ dev.suk.link (开发环境)
```

#### 域名重定向规则

在 `_redirects` 文件中配置域名重定向：

```bash
# 将 www 重定向到根域名（SEO 友好）
https://www.suk.link/* https://suk.link/:splat 301

# 或将根域名重定向到 www
https://suk.link/* https://www.suk.link/:splat 301

# 旧域名重定向到新域名
https://old-domain.com/* https://suk.link/:splat 301
```

#### 子域名路由

使用 Cloudflare Workers 实现更复杂的路由：

```javascript
// 根据子域名路由到不同页面
export default {
  async fetch(request) {
    const url = new URL(request.url);
    const hostname = url.hostname;
    
    if (hostname === 'staking.suk.link') {
      return Response.redirect('https://suk.link/staking-dashboard.html', 301);
    }
    
    if (hostname === 'investor.suk.link') {
      return Response.redirect('https://suk.link/investor-dashboard.html', 301);
    }
    
    // 默认处理
    return fetch(request);
  }
}
```

---

## 域名验证

### 步骤 1: DNS 传播检查

使用在线工具检查 DNS 是否已传播：

#### 工具 1: DNS Checker
```
网址: https://dnschecker.org/
输入: suk.link
类型: CNAME
查看: 全球各地的 DNS 解析结果
```

#### 工具 2: What's My DNS
```
网址: https://www.whatsmydns.net/
输入: suk.link
类型: CNAME
查看: 多个国家的解析情况
```

#### 命令行检查

**Windows**:
```cmd
nslookup suk.link
ping suk.link
```

**macOS/Linux**:
```bash
dig suk.link
host suk.link
nslookup suk.link
```

**预期结果**:
```
suk.link.    CNAME    suk-protocol.pages.dev.
```

### 步骤 2: SSL 证书验证

#### 浏览器验证
```
1. 访问 https://suk.link
2. 点击地址栏左侧的锁图标
3. 查看证书信息:
   ✅ 颁发者: Let's Encrypt
   ✅ 有效期: 90天
   ✅ 域名匹配
```

#### 命令行验证
```bash
# OpenSSL 检查
openssl s_client -connect suk.link:443 -servername suk.link

# 或使用 curl
curl -I https://suk.link
```

### 步骤 3: 功能验证

访问以下 URL 确认正常工作：

```
✅ https://suk.link/
✅ https://suk.link/staking-dashboard.html
✅ https://suk.link/investor-dashboard.html
✅ https://suk.link/revenue-claim.html
✅ https://suk.link/investor-subscription.html
```

### 步骤 4: 性能验证

使用 PageSpeed Insights 检查性能：
```
网址: https://pagespeed.web.dev/
输入: https://suk.link
查看: 性能评分和优化建议
```

---

## 故障排查

### 问题 1: 域名无法访问（DNS_PROBE_FINISHED_NXDOMAIN）

**原因**: DNS 记录未正确配置或尚未传播

**解决方案**:
```bash
1. 检查 DNS 记录是否正确添加
   - 登录 DNS 提供商后台
   - 确认 CNAME 记录存在
   - 确认记录值为: suk-protocol.pages.dev

2. 检查 DNS 传播状态
   - 使用 https://dnschecker.org/
   - 等待 DNS 传播（最多 48小时）

3. 清除本地 DNS 缓存
   Windows: ipconfig /flushdns
   macOS: sudo dscacheutil -flushcache
   Linux: sudo systemd-resolve --flush-caches

4. 重启路由器
```

### 问题 2: 证书错误（NET::ERR_CERT_COMMON_NAME_INVALID）

**原因**: SSL 证书尚未签发或配置错误

**解决方案**:
```
1. 检查 Cloudflare Pages 域名状态
   - 进入 Custom domains 页面
   - 确认状态为 "Active"
   - 如果是 "Pending"，等待 15-30 分钟

2. 验证 DNS 记录
   - 确保 DNS 记录正确指向 Cloudflare
   - CNAME 值必须是 suk-protocol.pages.dev

3. 手动触发证书更新
   - 删除自定义域名
   - 等待 5 分钟
   - 重新添加域名

4. 检查域名 Nameservers
   - 如果使用 Cloudflare DNS，确认 Nameservers 正确
```

### 问题 3: 页面显示 404 Not Found

**原因**: 域名配置正确，但文件路径错误

**解决方案**:
```
1. 检查 _redirects 文件
   - 确认 SPA 回退规则存在
   - /* /index.html 200

2. 检查文件路径
   - 确认文件在项目根目录
   - 检查文件名大小写

3. 清除 Cloudflare 缓存
   - 进入 Cloudflare Dashboard
   - 缓存 → 配置
   - 清除所有缓存

4. 重新部署项目
   - 触发新的部署
   - 验证文件是否上传成功
```

### 问题 4: 重定向循环（ERR_TOO_MANY_REDIRECTS）

**原因**: 重定向规则冲突

**解决方案**:
```
1. 检查 _redirects 文件
   - 确保没有循环重定向
   - 例如: A → B, B → A

2. 检查 Cloudflare SSL 设置
   - 进入 SSL/TLS 设置
   - 确认加密模式为 "Full" 或 "Full (strict)"

3. 检查 _headers 文件
   - 移除可能导致重定向的头部

4. 检查 HTML meta 标签
   - 移除可能的 meta refresh 重定向
```

### 问题 5: 慢速加载

**原因**: CDN 缓存未生效或配置不当

**解决方案**:
```
1. 检查 _headers 缓存配置
   - 确认静态资源有长期缓存

2. 启用 Cloudflare 优化
   - Auto Minify (HTML/CSS/JS)
   - Brotli 压缩
   - Rocket Loader

3. 优化资源
   - 压缩图片
   - 使用 WebP 格式
   - 启用懒加载

4. 使用 Performance Insights
   - 检查性能瓶颈
   - 优化关键渲染路径
```

---

## 常见问题

### Q1: 域名添加后多久生效？

**答案**:
```
情况 1: 域名在 Cloudflare 托管
- 生效时间: 立即（< 1分钟）
- SSL 证书: 5-15 分钟

情况 2: 域名在其他 DNS 提供商
- DNS 传播: 5 分钟 - 48 小时（通常 1-2 小时）
- SSL 证书: DNS 传播后 5-15 分钟

加速方法:
- 将域名迁移到 Cloudflare DNS
- 使用较小的 TTL 值（如 300 秒）
```

### Q2: 可以配置多少个自定义域名？

**答案**:
```
Cloudflare Pages 免费计划:
- 自定义域名数量: 无限制 ✅
- 可以添加任意数量的域名和子域名
- 每个域名都会获得免费 SSL 证书
```

### Q3: 如何同时支持根域名和 www？

**答案**:
```
方法 1: 分别添加两个域名
1. 添加 suk.link
2. 添加 www.suk.link
3. 在 _redirects 配置重定向

方法 2: 使用 Cloudflare Page Rules
1. 添加主域名
2. 创建 Page Rule 进行重定向

推荐配置（_redirects）:
https://www.suk.link/* https://suk.link/:splat 301
```

### Q4: 域名可以指向特定页面吗？

**答案**:
```
是的，可以使用重定向规则：

示例 1: 子域名指向特定页面
staking.suk.link → https://suk.link/staking-dashboard.html

配置方法:
1. 添加子域名 staking.suk.link
2. 在 _redirects 添加:
   https://staking.suk.link/* https://suk.link/staking-dashboard.html 301

示例 2: 多个子域名路由
app.suk.link → /index.html
staking.suk.link → /staking-dashboard.html
investor.suk.link → /investor-dashboard.html
```

### Q5: 如何强制 HTTPS？

**答案**:
```
Cloudflare Pages 默认强制 HTTPS：
✅ HTTP 自动重定向到 HTTPS
✅ 无需额外配置

额外优化（_headers）:
/*
  Strict-Transport-Security: max-age=31536000; includeSubDomains; preload

这会：
- 强制浏览器始终使用 HTTPS
- 包括所有子域名
- 可提交到 HSTS Preload 列表
```

### Q6: 域名需要实名认证吗？

**答案**:
```
取决于域名后缀和注册商：

需要实名的情况:
- .cn、.com.cn 等中国域名（必须）
- 部分国际域名（根据注册商政策）

不需要实名的情况:
- .com、.net、.org 等国际域名
- 在国外注册商注册的域名

建议:
- 使用国际通用后缀（.com、.link）
- 在国际注册商注册（Namecheap、GoDaddy）
```

### Q7: 可以使用已有域名的子域名吗？

**答案**:
```
完全可以！

示例:
- 主域名: example.com（用于其他用途）
- SUK Protocol: suk.example.com

配置步骤:
1. 在 Cloudflare Pages 添加 suk.example.com
2. 在 DNS 添加 CNAME 记录:
   名称: suk
   值: suk-protocol.pages.dev
3. 等待 DNS 生效
4. 完成！

优点:
- 不影响主域名
- 独立的 SSL 证书
- 独立的缓存策略
```

---

## 📊 域名配置检查清单

完成域名配置后，使用此清单验证：

### DNS 配置 ✅
```
□ CNAME 记录已添加
□ 记录值正确（suk-protocol.pages.dev）
□ TTL 设置合理（推荐 Auto 或 3600）
□ DNS 传播完成（使用 dnschecker.org 验证）
```

### SSL 证书 ✅
```
□ 证书状态为 "Active"
□ 浏览器显示安全锁图标
□ 证书颁发者为 Let's Encrypt
□ 证书包含正确的域名
□ HTTPS 访问正常
```

### 功能测试 ✅
```
□ 主页加载正常
□ 所有页面可访问
□ 静态资源加载正常
□ JavaScript 执行正常
□ 钱包连接功能正常
```

### 性能测试 ✅
```
□ PageSpeed Insights > 90
□ 首屏加载 < 2 秒
□ CDN 缓存生效
□ Gzip/Brotli 压缩启用
```

### SEO 优化 ✅
```
□ robots.txt 配置正确
□ sitemap.xml 已提交
□ meta 标签完整
□ 结构化数据标记
```

---

## 🎯 推荐域名配置

### 标准配置（推荐）

```
主域名:
✅ suk.link (主站)
✅ www.suk.link (重定向到 suk.link)

功能子域名:
✅ app.suk.link (应用入口)
✅ staking.suk.link (质押面板)
✅ investor.suk.link (投资者面板)
✅ docs.suk.link (文档站点)

环境子域名:
✅ staging.suk.link (测试环境)
✅ dev.suk.link (开发环境)
```

### DNS 记录配置

```bash
# 主域名
suk.link         CNAME  suk-protocol.pages.dev

# www 重定向
www.suk.link     CNAME  suk-protocol.pages.dev

# 功能子域名
app.suk.link     CNAME  suk-protocol.pages.dev
staking.suk.link CNAME  suk-protocol.pages.dev
investor.suk.link CNAME suk-protocol.pages.dev

# 环境子域名
staging.suk.link CNAME  suk-protocol-staging.pages.dev
dev.suk.link     CNAME  suk-protocol-dev.pages.dev
```

---

## 🚀 下一步

域名配置完成后：

1. ✅ **提交搜索引擎收录**
   - Google Search Console
   - Bing Webmaster Tools
   - 百度站长平台

2. ✅ **设置监控和告警**
   - Cloudflare Web Analytics
   - UptimeRobot 可用性监控
   - SSL 证书到期提醒

3. ✅ **优化 SEO**
   - 配置 robots.txt
   - 生成 sitemap.xml
   - 添加结构化数据

4. ✅ **启用高级功能**
   - Cloudflare Bot Protection
   - Rate Limiting
   - WAF 规则

---

## 📞 获取帮助

如果在配置域名时遇到问题：

### 检查文档
- 📖 [Cloudflare Pages 域名文档](https://developers.cloudflare.com/pages/platform/custom-domains/)
- 📖 [DNS 故障排查指南](https://developers.cloudflare.com/dns/troubleshooting/)

### 官方支持
- 💬 [Cloudflare Community](https://community.cloudflare.com/)
- 🎫 [提交工单](https://dash.cloudflare.com/?to=/:account/support)

### 在线工具
- 🔍 [DNS Checker](https://dnschecker.org/)
- 🔍 [SSL Labs](https://www.ssllabs.com/ssltest/)
- 🔍 [What's My DNS](https://www.whatsmydns.net/)

---

**🎉 恭喜！您已成功为 SUK Protocol 配置自定义域名！**

*更新时间: 2024-11-18*  
*SUK Protocol - 全球 Web3.0 链剧资产平台*
