# ⚡ Cloudflare 快速部署指南

## 🎯 目标

将 **SUK LINK** 前端迁移到 **Cloudflare Pages**，实现：
- ✅ 全球CDN加速
- ✅ 免费托管
- ✅ 自动HTTPS
- ✅ 秒级部署

---

## 📋 部署清单

### 前置要求
- [ ] Cloudflare账号（免费）
- [ ] Git仓库（GitHub/GitLab）
- [ ] 域名已添加到Cloudflare
- [ ] 后端API已部署

---

## 🚀 部署步骤

### 方法一：通过 Dashboard（推荐新手）⭐

#### 步骤 1：登录 Cloudflare
```
访问: https://dash.cloudflare.com
注册/登录账号
```

#### 步骤 2：创建 Pages 项目
```
1. 点击左侧 "Workers & Pages"
2. 点击 "Create application"
3. 选择 "Pages" 标签
4. 点击 "Connect to Git"
```

#### 步骤 3：连接 Git 仓库
```
1. 选择 GitHub/GitLab
2. 授权 Cloudflare 访问
3. 选择项目仓库
4. 点击 "Begin setup"
```

#### 步骤 4：配置构建设置
```yaml
Project name: suk-link
Production branch: main

Build settings:
  Framework preset: None
  Build command: (留空)
  Build output directory: /
  
Environment variables:
  (无需配置)
```

#### 步骤 5：部署
```
点击 "Save and Deploy"
等待部署完成（约1-2分钟）
```

#### 步骤 6：配置自定义域名
```
1. 部署完成后，进入项目设置
2. 点击 "Custom domains"
3. 点击 "Set up a custom domain"
4. 输入: suk.link
5. 点击 "Continue"
6. 选择 "Activate domain"
```

#### 步骤 7：验证部署
```
访问:
  https://suk-link.pages.dev (Cloudflare默认域名)
  https://suk.link (自定义域名，需等待DNS生效)
```

---

### 方法二：通过 Wrangler CLI（推荐开发者）⭐⭐⭐

#### 步骤 1：安装 Wrangler
```bash
# 使用 npm
npm install -g wrangler

# 或使用 yarn
yarn global add wrangler

# 验证安装
wrangler --version
```

#### 步骤 2：登录 Cloudflare
```bash
wrangler login
# 会自动打开浏览器进行授权
```

#### 步骤 3：创建配置文件
```bash
# 在项目根目录创建 wrangler.toml
cat > wrangler.toml << 'EOF'
name = "suk-link"
compatibility_date = "2024-11-16"

[site]
bucket = "."

[[pages_build_output_dir]]
output_dir = "."
EOF
```

#### 步骤 4：部署项目
```bash
# 首次部署
wrangler pages publish . \
  --project-name=suk-link \
  --branch=main

# 后续部署
wrangler pages publish .
```

#### 步骤 5：配置域名
```bash
# 方法1: 使用 CLI
wrangler pages domain add suk-link suk.link

# 方法2: 访问 Dashboard 配置
# https://dash.cloudflare.com → Pages → suk-link → Custom domains
```

#### 步骤 6：验证部署
```bash
# 查看部署列表
wrangler pages deployment list --project-name=suk-link

# 访问默认域名
curl https://suk-link.pages.dev

# 访问自定义域名
curl https://suk.link
```

---

## 🔧 配置优化

### 1. 忽略不必要的文件

创建 `.cloudflare-ignore` 文件：
```bash
cat > .cloudflare-ignore << 'EOF'
backend/
node_modules/
functions/
scripts/
deployment/
monitoring/
contracts/
*.md
.git/
.env*
Dockerfile
docker-compose.yml
package.json
server.js
EOF
```

### 2. 配置重定向规则

在项目根目录创建 `_redirects` 文件：
```bash
cat > _redirects << 'EOF'
# API重定向到后端服务器
/api/* https://api.suk.link/api/:splat 301

# 监控重定向
/monitor https://monitor.suk.link:3001 302

# 旧域名重定向（如果需要）
https://old-domain.com/* https://suk.link/:splat 301
EOF
```

### 3. 配置缓存头

在项目根目录创建 `_headers` 文件：
```bash
cat > _headers << 'EOF'
# 静态资源缓存
/*.jpg
  Cache-Control: public, max-age=31536000, immutable
/*.png
  Cache-Control: public, max-age=31536000, immutable
/*.svg
  Cache-Control: public, max-age=31536000, immutable
/*.css
  Cache-Control: public, max-age=86400
/*.js
  Cache-Control: public, max-age=86400

# HTML文件
/*.html
  Cache-Control: public, max-age=3600, must-revalidate

# 安全头
/*
  X-Content-Type-Options: nosniff
  X-Frame-Options: SAMEORIGIN
  X-XSS-Protection: 1; mode=block
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: geolocation=(), microphone=(), camera=()
EOF
```

---

## 🌐 DNS配置

### 在 Cloudflare DNS 添加记录

```bash
# 登录 Cloudflare Dashboard
# 选择域名 suk.link
# 进入 DNS 设置

# 添加以下记录：
Type    Name              Target                    Proxy
CNAME   suk.link          suk-link.pages.dev        开启🧡
CNAME   www               suk.link                  开启🧡
A       api               <你的VPS IP>              开启🧡
A       monitor           <你的监控服务器IP>         开启🧡
```

---

## 🔒 安全配置

### 1. 配置 SSL/TLS

```bash
# 在 Cloudflare Dashboard
1. 进入 SSL/TLS 设置
2. 选择 "Full (strict)" 模式
3. 启用 "Always Use HTTPS"
4. 启用 "Automatic HTTPS Rewrites"
```

### 2. 配置防火墙

```bash
# 在 Cloudflare Dashboard
1. 进入 Security → WAF
2. 启用 "Cloudflare Managed Ruleset"
3. 添加自定义规则（可选）
```

### 3. 配置 DDoS 防护

```bash
# 在 Cloudflare Dashboard
1. 进入 Security → DDoS
2. 确认防护已启用（默认开启）
```

---

## ⚡ 性能优化

### 1. 启用 Brotli 压缩

```bash
# 在 Cloudflare Dashboard
1. 进入 Speed → Optimization
2. 启用 "Brotli"
```

### 2. 启用 Auto Minify

```bash
# 在 Cloudflare Dashboard
1. 进入 Speed → Optimization
2. 勾选 JavaScript, CSS, HTML
```

### 3. 启用 Early Hints

```bash
# 在 Cloudflare Dashboard
1. 进入 Speed → Optimization
2. 启用 "Early Hints"
```

---

## 🧪 测试验证

### 1. 功能测试
```bash
# 访问主页
curl https://suk.link

# 测试API代理
curl https://suk.link/api/health

# 测试HTTPS重定向
curl -I http://suk.link
# 应该返回 301 重定向到 https://
```

### 2. 性能测试
```bash
# 使用 WebPageTest
https://www.webpagetest.org/

# 使用 GTmetrix
https://gtmetrix.com/

# 使用 PageSpeed Insights
https://pagespeed.web.dev/
```

### 3. 安全测试
```bash
# SSL Labs 测试
https://www.ssllabs.com/ssltest/

# Security Headers 测试
https://securityheaders.com/
```

---

## 🔄 持续部署

### Git自动部署（推荐）

```bash
# 每次推送代码到 main 分支，自动触发部署
git add .
git commit -m "Update frontend"
git push origin main

# Cloudflare Pages 会自动：
# 1. 检测到推送
# 2. 构建项目
# 3. 部署到生产环境
# 4. 通知部署状态
```

### 手动部署

```bash
# 使用 Wrangler
wrangler pages publish . --project-name=suk-link

# 或使用 Dashboard
# 访问项目 → View build → Retry deployment
```

---

## 📊 监控和日志

### 查看部署日志
```bash
# 使用 Wrangler
wrangler pages deployment list --project-name=suk-link

# 查看特定部署的日志
wrangler pages deployment tail --project-name=suk-link
```

### 查看分析数据
```bash
# 在 Cloudflare Dashboard
1. 进入 Workers & Pages → suk-link
2. 查看 Analytics 标签
3. 查看请求数、带宽、错误率等
```

---

## 🆘 故障排查

### 问题1：部署失败
```bash
# 检查项目文件
ls -la

# 检查忽略文件
cat .cloudflare-ignore

# 清理缓存重新部署
wrangler pages publish . --project-name=suk-link --skip-caching
```

### 问题2：域名无法访问
```bash
# 检查DNS记录
dig suk.link

# 检查SSL证书
curl -vI https://suk.link

# 等待DNS传播（最多48小时）
```

### 问题3：API请求失败
```bash
# 检查CORS配置
# backend/config/cors.js 需包含 Cloudflare Pages 域名

# 检查API重定向
curl -I https://suk.link/api/health

# 检查后端服务器防火墙
# 允许 Cloudflare IP 访问
```

---

## 📝 检查清单

### 部署前
- [ ] 代码已提交到Git仓库
- [ ] 后端API已部署并可访问
- [ ] 域名已添加到Cloudflare
- [ ] 已安装Wrangler（如使用CLI）

### 部署中
- [ ] 创建Pages项目成功
- [ ] 连接Git仓库成功
- [ ] 构建配置正确
- [ ] 首次部署成功

### 部署后
- [ ] 默认域名可访问
- [ ] 自定义域名已绑定
- [ ] SSL证书已激活
- [ ] API重定向正常
- [ ] 静态资源加载正常
- [ ] 页面功能正常

---

## 💰 成本估算

```
Cloudflare Pages 免费计划:
  ✅ 500次构建/月
  ✅ 100GB带宽/月
  ✅ 无限请求
  ✅ 无限站点

如需更多：
  Pro: $20/月
    - 5,000次构建/月
    - 无限带宽
    - 并发构建
    - 高级分析

通常情况: 免费计划完全够用 💰 $0/月
```

---

## 🎉 完成后的效果

### 性能提升
```
加载速度: ⬆️ 50-70%
TTFB: < 200ms
全球访问: 300+ 边缘节点
SSL: 自动配置
```

### 成本节省
```
Firebase Hosting: $25/月 → $0/月
年度节省: $300 💰
```

### 安全增强
```
DDoS防护: ✅ 无限制
WAF防火墙: ✅ 免费
SSL证书: ✅ 自动续期
```

---

## 📞 获取帮助

### Cloudflare资源
- [Pages文档](https://developers.cloudflare.com/pages/)
- [Community论坛](https://community.cloudflare.com/)
- [Discord社区](https://discord.cloudflare.com/)

### 命令速查
```bash
# 登录
wrangler login

# 部署
wrangler pages publish .

# 查看日志
wrangler pages deployment list

# 配置域名
wrangler pages domain add <project> <domain>
```

---

**创建时间**: 2025-11-16  
**适用项目**: SUK LINK  
**预计时间**: 30分钟部署完成  
**难度**: ⭐⭐ (简单)
