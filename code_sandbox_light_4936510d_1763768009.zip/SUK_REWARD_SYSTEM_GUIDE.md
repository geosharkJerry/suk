# SUK奖励系统完整指南

## 📋 目录

1. [系统概述](#系统概述)
2. [奖励规则](#奖励规则)
3. [数据模型](#数据模型)
4. [API文档](#api文档)
5. [前端集成](#前端集成)
6. [使用流程](#使用流程)
7. [防作弊机制](#防作弊机制)
8. [常见问题](#常见问题)

---

## 系统概述

### 🎯 设计目标

SUK奖励系统旨在激励用户：
1. **观看短剧** - 获得观看奖励
2. **邀请好友** - 获得邀请返佣

### ✨ 核心特性

- **观看奖励**: 观看时长 × 剧集价格的 **1%**
- **邀请奖励**: 被邀请人购买金额的 **7%**
- **防作弊机制**: 智能检测异常行为
- **自动发放**: 奖励审核后自动发放到钱包
- **实时统计**: 累计赚取、待发放、已发放一目了然

---

## 奖励规则

### 1. 观看奖励 📺

#### 计算公式
```
观看奖励 = (观看时长 / 视频总时长) × 剧集价格 × 1%
```

#### 示例
```
短剧: 《霸总的替身娇妻》
剧集: 第1集
价格: 99 SUK
视频时长: 5分钟 (300秒)
观看时长: 4分钟 (240秒)

奖励计算:
(240 / 300) × 99 × 1% = 0.8 × 99 × 0.01 = 0.792 SUK
```

#### 触发条件
- ✅ 观看进度 > 5% （防止误触）
- ✅ 验证得分 ≥ 50 （防作弊）
- ✅ 用户已登录Telegram

#### 状态流转
```
记录 → pending（待审核）→ approved（已批准）→ paid（已发放）
       ↓
     rejected（已拒绝）
```

---

### 2. 邀请奖励 🎁

#### 计算公式
```
邀请奖励 = 被邀请人购买金额 × 7%
```

#### 示例
```
邀请人: 用户A
被邀请人: 用户B
购买短剧: 《闪婚后，大佬每天都在撒糖》
购买金额: 129 SUK

奖励计算:
129 × 7% = 9.03 SUK（用户A获得）
```

#### 触发条件
1. **邀请关系存在**: 被邀请人通过邀请码注册
2. **被邀请人购买**: 完成支付订单
3. **邀请人已绑定钱包**: 必须绑定钱包才能获得奖励

#### 邀请关系建立
```
用户A → 生成邀请码（SUKABC12）
     ↓
用户B → 使用邀请码注册
     ↓
建立邀请关系（inviterId: A, inviteeId: B）
     ↓
用户B购买 → 触发邀请奖励
```

---

## 数据模型

### 1. 观看奖励记录（WatchReward）

```javascript
{
    userId: "123456789",              // Telegram用户ID
    walletAddress: "0x1234...",       // 钱包地址
    dramaId: ObjectId("..."),         // 短剧ID
    episodeId: "ep001",               // 剧集ID
    watchDuration: 240,               // 观看时长（秒）
    totalDuration: 300,               // 总时长（秒）
    watchPercent: 80,                 // 观看百分比
    dramaPrice: 99,                   // 剧集价格
    rewardRate: 0.01,                 // 奖励比例（1%）
    rewardAmount: 0.792,              // 奖励金额
    status: "pending",                // 状态
    isValid: true,                    // 是否有效
    validationScore: 100,             // 验证得分
    createdAt: Date,
    paidAt: Date,                     // 发放时间
    txHash: "0xabc..."                // 区块链交易哈希
}
```

### 2. 邀请奖励记录（InviteReward）

```javascript
{
    inviterId: "123456789",           // 邀请人ID
    inviterWallet: "0x1234...",       // 邀请人钱包
    inviteeId: "987654321",           // 被邀请人ID
    inviteeWallet: "0x5678...",       // 被邀请人钱包
    orderId: ObjectId("..."),         // 订单ID
    dramaId: ObjectId("..."),         // 短剧ID
    purchaseAmount: 129,              // 购买金额
    rewardRate: 0.07,                 // 奖励比例（7%）
    rewardAmount: 9.03,               // 奖励金额
    status: "pending",                // 状态
    isValid: true,                    // 是否有效
    createdAt: Date,
    paidAt: Date,
    txHash: "0xdef..."
}
```

### 3. 邀请关系（InviteRelation）

```javascript
{
    inviterId: "123456789",           // 邀请人ID
    inviterWallet: "0x1234...",       // 邀请人钱包
    inviteeId: "987654321",           // 被邀请人ID（唯一）
    inviteeWallet: "0x5678...",       // 被邀请人钱包
    inviteCode: "SUKABC12",           // 邀请码
    inviteSource: "link",             // 来源：link/code/qrcode
    status: "purchased",              // registered/bound/purchased
    totalPurchaseAmount: 218,         // 累计购买金额
    totalRewardAmount: 15.26,         // 累计奖励金额
    purchaseCount: 2,                 // 购买次数
    registeredAt: Date,               // 注册时间
    boundAt: Date,                    // 绑定时间
    firstPurchaseAt: Date             // 首次购买时间
}
```

### 4. 用户奖励统计（UserRewardStats）

```javascript
{
    userId: "123456789",
    walletAddress: "0x1234...",
    
    // 观看奖励统计
    watchRewards: {
        total: 89.12,                 // 总奖励
        pending: 23.45,               // 待发放
        paid: 65.67,                  // 已发放
        count: 45                     // 次数
    },
    
    // 邀请奖励统计
    inviteRewards: {
        total: 67.66,
        pending: 21.87,
        paid: 45.79,
        count: 12
    },
    
    // 邀请统计
    inviteStats: {
        totalInvites: 15,             // 总邀请人数
        boundInvites: 10,             // 已绑定人数
        purchasedInvites: 8,          // 已购买人数
        conversionRate: 53.33         // 转化率（%）
    },
    
    // 总计
    totalEarned: 156.78,              // 累计赚取
    totalPending: 45.32,              // 待发放
    totalPaid: 111.46,                // 已发放（可提现）
    
    lastUpdated: Date
}
```

---

## API文档

### 1. 记录观看奖励

**POST** `/api/rewards/watch`

**Headers:**
```
X-Telegram-Init-Data: {telegram_init_data}
```

**Body:**
```json
{
    "dramaId": "64a1b2c3d4e5f6",
    "episodeId": "ep001",
    "watchDuration": 240,
    "totalDuration": 300
}
```

**Response:**
```json
{
    "success": true,
    "message": "观看奖励记录成功",
    "data": {
        "_id": "...",
        "userId": "123456789",
        "rewardAmount": 0.792,
        "status": "pending"
    }
}
```

---

### 2. 获取奖励统计

**GET** `/api/rewards/stats`

**Headers:**
```
X-Telegram-Init-Data: {telegram_init_data}
```

**Response:**
```json
{
    "success": true,
    "data": {
        "totalEarned": 156.78,
        "totalPending": 45.32,
        "totalPaid": 111.46,
        "watchRewards": {
            "total": 89.12,
            "pending": 23.45,
            "paid": 65.67,
            "count": 45
        },
        "inviteRewards": {
            "total": 67.66,
            "pending": 21.87,
            "paid": 45.79,
            "count": 12
        },
        "inviteStats": {
            "totalInvites": 15,
            "boundInvites": 10,
            "purchasedInvites": 8,
            "conversionRate": 53.33
        }
    }
}
```

---

### 3. 获取奖励记录

**GET** `/api/rewards/records`

**Query Parameters:**
- `type`: all | watch | invite（默认all）
- `status`: pending | approved | paid | rejected
- `page`: 页码（默认1）
- `limit`: 每页数量（默认20）

**Response:**
```json
{
    "success": true,
    "data": {
        "watch": {
            "data": [
                {
                    "_id": "...",
                    "dramaId": {
                        "title": "霸总的替身娇妻"
                    },
                    "episodeId": "ep001",
                    "rewardAmount": 0.792,
                    "status": "paid",
                    "createdAt": "2025-01-15T10:30:00Z"
                }
            ],
            "total": 45
        },
        "invite": {
            "data": [...],
            "total": 12
        }
    }
}
```

---

### 4. 生成邀请码

**POST** `/api/rewards/invite/code`

**Headers:**
```
X-Telegram-Init-Data: {telegram_init_data}
```

**Response:**
```json
{
    "success": true,
    "data": {
        "inviteCode": "SUKABC12",
        "inviteLink": "https://suk.link/telegram-app.html?inviteCode=SUKABC12",
        "qrCode": "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=..."
    }
}
```

---

### 5. 使用邀请码

**POST** `/api/rewards/invite/use`

**Headers:**
```
X-Telegram-Init-Data: {telegram_init_data}
```

**Body:**
```json
{
    "inviteCode": "SUKABC12"
}
```

**Response:**
```json
{
    "success": true,
    "message": "邀请码使用成功",
    "data": {
        "_id": "...",
        "inviterId": "123456789",
        "inviteeId": "987654321",
        "status": "registered"
    }
}
```

---

### 6. 获取邀请列表

**GET** `/api/rewards/invite/list`

**Query Parameters:**
- `status`: registered | bound | purchased
- `page`: 页码
- `limit`: 每页数量

**Response:**
```json
{
    "success": true,
    "data": [
        {
            "inviteeId": "user123",
            "status": "purchased",
            "totalPurchaseAmount": 218,
            "purchaseCount": 2,
            "registeredAt": "2025-01-10T10:00:00Z"
        }
    ],
    "pagination": {
        "page": 1,
        "limit": 20,
        "total": 15,
        "pages": 1
    }
}
```

---

### 7. 绑定钱包

**POST** `/api/rewards/bind-wallet`

**Headers:**
```
X-Telegram-Init-Data: {telegram_init_data}
```

**Body:**
```json
{
    "walletAddress": "0x1234567890abcdef1234567890abcdef12345678"
}
```

**Response:**
```json
{
    "success": true,
    "message": "钱包绑定成功",
    "data": {
        "walletAddress": "0x1234..."
    }
}
```

---

### 8. 提现奖励

**POST** `/api/rewards/withdraw`

**Headers:**
```
X-Telegram-Init-Data: {telegram_init_data}
```

**Body:**
```json
{
    "amount": 100,
    "walletAddress": "0x1234567890abcdef1234567890abcdef12345678"
}
```

**Response:**
```json
{
    "success": true,
    "message": "提现申请已提交，预计24小时内到账",
    "data": {
        "amount": 100,
        "walletAddress": "0x1234...",
        "estimatedTime": "24小时"
    }
}
```

---

## 前端集成

### 1. 在播放器中记录观看奖励

```javascript
// telegram-player.html 或 telegram-player-optimized.html

// 在播放结束或用户离开时记录
async function recordWatchReward() {
    const watchDuration = player.getCurrentTime();
    const totalDuration = player.getDuration();
    
    try {
        const response = await fetch('/api/rewards/watch', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Telegram-Init-Data': tg.initData
            },
            body: JSON.stringify({
                dramaId: currentDrama.id,
                episodeId: currentEpisode.id,
                watchDuration: Math.floor(watchDuration),
                totalDuration: Math.floor(totalDuration)
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // 显示奖励提示
            showRewardToast(`🎉 获得 ${result.data.rewardAmount.toFixed(2)} SUK 观看奖励！`);
        }
    } catch (error) {
        console.error('记录观看奖励失败:', error);
    }
}

// 在播放器事件中调用
player.on('ended', recordWatchReward);
window.addEventListener('beforeunload', recordWatchReward);
```

---

### 2. 在主页添加奖励入口

```html
<!-- telegram-app.html -->

<!-- 在用户卡片中添加奖励按钮 -->
<div class="user-card">
    <div class="user-info">
        <!-- 用户信息 -->
    </div>
    <button class="reward-button" onclick="openRewardCenter()">
        💰 我的奖励
    </button>
</div>

<script>
function openRewardCenter() {
    window.location.href = '/telegram-reward-center.html';
}
</script>
```

---

### 3. 在注册时使用邀请码

```javascript
// telegram-app.html - 页面加载时检查URL参数

async function checkInviteCode() {
    const urlParams = new URLSearchParams(window.location.search);
    const inviteCode = urlParams.get('inviteCode');
    
    if (inviteCode) {
        try {
            const response = await fetch('/api/rewards/invite/use', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Telegram-Init-Data': tg.initData
                },
                body: JSON.stringify({ inviteCode })
            });
            
            const result = await response.json();
            
            if (result.success) {
                tg.showAlert('🎉 邀请码使用成功！\n\n购买短剧后邀请人将获得7%SUK奖励');
            }
        } catch (error) {
            console.error('使用邀请码失败:', error);
        }
    }
}

// 在初始化时调用
checkInviteCode();
```

---

## 使用流程

### 用户旅程1: 观看赚奖励

```
1. 用户打开短剧
   ↓
2. 观看视频（记录观看时长）
   ↓
3. 视频结束 / 用户离开
   ↓
4. 自动调用 POST /api/rewards/watch
   ↓
5. 后端计算奖励金额
   ↓
6. 创建观看奖励记录（status: pending）
   ↓
7. 防作弊检查（validationScore）
   ↓
8. 管理员审核（approved）
   ↓
9. 自动发放到钱包（paid）
   ↓
10. 用户可在奖励中心查看和提现
```

---

### 用户旅程2: 邀请赚奖励

```
1. 用户A绑定钱包（必需）
   ↓
2. 生成邀请码（POST /api/rewards/invite/code）
   ↓
3. 分享邀请码给用户B
   ↓
4. 用户B通过邀请链接打开App
   ↓
5. 自动使用邀请码（POST /api/rewards/invite/use）
   ↓
6. 建立邀请关系（inviter: A, invitee: B）
   ↓
7. 用户B购买短剧
   ↓
8. 订单支付成功后触发
   ↓
9. 创建邀请奖励记录（7%购买金额）
   ↓
10. 更新邀请关系统计
   ↓
11. 管理员审核后发放
   ↓
12. 用户A在奖励中心查看和提现
```

---

## 防作弊机制

### 验证得分计算

```javascript
验证得分 = 100分

扣分规则:
1. 观看时长 > 总时长: -50分（严重可疑）
2. 观看百分比 < 5%: -20分（观看太少）
3. 1分钟内多次记录（>5次）: -30分（频繁刷奖励）
4. 待发放奖励过多（>100条）: -20分（可能作弊）

最终得分 < 50: 自动拒绝（status: rejected）
```

### 防作弊策略

1. **观看时长验证**
   - 检查观看时长是否超过总时长
   - 检查观看百分比是否合理

2. **频率限制**
   - 同一用户1分钟内最多记录5次
   - 同一剧集每天最多获得3次奖励

3. **行为分析**
   - 检测异常观看模式
   - 机器学习识别作弊行为

4. **邀请关系验证**
   - 一个用户只能被邀请一次
   - 不能邀请自己
   - 检测批量注册

---

## 常见问题

### Q1: 如何绑定钱包？

**A:** 
```
1. 打开奖励中心
2. 点击"绑定钱包"
3. 输入钱包地址（0x开头，40位十六进制）
4. 确认绑定
```

**注意**: 必须先绑定钱包才能获得邀请奖励！

---

### Q2: 奖励什么时候发放？

**A:**
```
观看奖励: 自动记录 → 24小时内审核 → 审核通过后48小时内发放
邀请奖励: 好友购买后 → 24小时内审核 → 审核通过后48小时内发放

状态说明:
- pending: 待审核（刚记录）
- approved: 已批准（等待发放）
- paid: 已发放（可提现）
- rejected: 已拒绝（不符合规则）
```

---

### Q3: 为什么我的奖励被拒绝？

**A:** 可能原因：
1. 观看时长不足5%
2. 检测到异常行为（刷奖励）
3. 邀请关系无效
4. 系统验证得分过低

---

### Q4: 如何提现奖励？

**A:**
```
1. 确保钱包已绑定
2. 等待奖励状态变为 "paid"
3. 在奖励中心点击"提现"
4. 输入提现金额和钱包地址
5. 提交申请
6. 24小时内到账
```

**最低提现**: 10 SUK  
**手续费**: 暂无

---

### Q5: 邀请码在哪里找？

**A:**
```
方式1: 
奖励中心 → "我的邀请"标签 → 复制邀请码

方式2:
主页 → 点击"邀请好友" → 生成邀请码

方式3:
API调用 POST /api/rewards/invite/code
```

---

### Q6: 观看多长时间才有奖励？

**A:**
```
最低要求: 观看时长 > 5%

示例:
视频5分钟 → 至少观看15秒
视频10分钟 → 至少观看30秒

建议: 完整观看获得最多奖励！
```

---

### Q7: 邀请奖励有上限吗？

**A:**
```
单笔上限: 无
总额上限: 无
时间限制: 永久有效

只要好友购买，就能获得7%奖励！
```

---

### Q8: 如何查看我的邀请效果？

**A:**
```
奖励中心 → "我的邀请"标签

可以看到:
- 总邀请人数
- 已购买人数
- 转化率
- 每个好友的购买记录
- 累计获得的奖励
```

---

## 🎉 快速开始

### 后端集成

1. **安装依赖**（已在package.json中）
2. **导入路由**
```javascript
// server.js
const rewardRoutes = require('./backend/routes/reward.routes');
app.use('/api/rewards', rewardRoutes);
```

3. **创建索引**
```bash
node scripts/init-reward-db.js
```

### 前端集成

1. **添加奖励中心链接**到主页
2. **在播放器中调用**观看奖励API
3. **在注册时检查**邀请码

### 测试

```bash
# 启动服务器
npm run dev

# 测试API
curl -X GET http://localhost:3000/api/rewards/stats \
  -H "X-Telegram-Init-Data: test"

# 打开前端页面
http://localhost:3000/telegram-reward-center.html
```

---

**文档版本**: v1.0  
**最后更新**: 2025-01-16  
**状态**: ✅ 完整实现，可投入使用
